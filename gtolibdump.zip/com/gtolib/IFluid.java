package com.gtolib;

import appeng.api.stacks.AEFluidKey;
import com.gregtechceu.gtceu.api.recipe.ingredient.FluidIngredient;
import com.gtolib.IUnique;
import com.gtolib.e;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;

@e
public interface IFluid
extends IUnique {
    @NotNull
    public ResourceLocation gtolib$getIdLocation();

    @NotNull
    public String gtolib$getIdString();

    @NotNull
    public AEFluidKey gtolib$getAEKey();

    @NotNull
    public FluidIngredient.FluidValue gtolib$getFluidValue();

    public int gtolib$getOrCreateMapFluid();

    public int gtolib$getMapFluid();
}

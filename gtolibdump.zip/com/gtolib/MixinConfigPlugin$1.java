package com.gtolib;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.lang.invoke.MethodHandle;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.embeddedt.embeddium_integrity.MixinTaintDetector;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.IMixinTransformer;
import org.spongepowered.asm.mixin.transformer.ext.Extensions;
import org.spongepowered.asm.mixin.transformer.ext.IExtension;
import org.spongepowered.asm.mixin.transformer.ext.ITargetClassContext;

class MixinConfigPlugin$1
implements IExtension {
    MixinConfigPlugin$1() {
    }

    public boolean checkActive(MixinEnvironment mixinEnvironment) {
        return true;
    }

    public void preApply(ITargetClassContext iTargetClassContext) {
        try {
            Object object;
            Object object2;
            if (m == null) {
                Iterator iterator = MixinEnvironment.getDefaultEnvironment().getActiveTransformer();
                if (iterator instanceof IMixinTransformer && (iterator = (object2 = (IMixinTransformer)((Object)iterator)).getExtensions()) instanceof Extensions) {
                    object = (Extensions)((Object)iterator);
                    e.removeIf(iExtension -> iExtension instanceof MixinTaintDetector);
                    iterator = object.getClass().getDeclaredField("activeExtensions");
                    ((AccessibleObject)((Object)iterator)).setAccessible(true);
                    Object object3 = new ObjectArrayList((List)((Field)((Object)iterator)).get(object));
                    object3.removeIf(iExtension -> iExtension instanceof MixinTaintDetector);
                    ((Field)((Object)iterator)).set(object, Collections.unmodifiableList(object3));
                }
                object2 = MixinTaintDetector.class.getDeclaredField("GET_MIXINS_ON_CLASS_INFO");
                ((AccessibleObject)object2).setAccessible(true);
                m = (MethodHandle)((Field)object2).get(null);
            }
            if ((object2 = iTargetClassContext.getClassInfo()).isInterface()) {
                return;
            }
            object = object2.getClassName();
            if (((String)object).startsWith("com.gregtechceu")) {
                for (Object object3 : m.invokeExact((ClassInfo)object2)) {
                    if (object3.getClassName().startsWith("com.gtolib.mixin.") || object3.getClassName().startsWith("com.gtocore.mixin.") || object3.getClassName().startsWith("dev.uncandango.alltheleaks.mixin.core.main.")) continue;
                    throw new RuntimeException("Detected taint in " + (String)object + "!");
                }
            } else {
                int n;
                if (((String)object).startsWith("com.gtocore")) {
                    throw new RuntimeException("Detected taint in " + (String)object + "!");
                }
                if (((String)object).startsWith("com.gtolib")) {
                    throw new RuntimeException("Detected taint in " + (String)object + "!");
                }
                if (((String)object).startsWith("appeng") && (n = m.invokeExact((ClassInfo)object2).size()) > a.getOrDefault(object, 1)) {
                    throw new RuntimeException("Detected taint in " + (String)object + "!");
                }
            }
        }
        catch (Throwable throwable) {
            throw new RuntimeException(throwable);
        }
    }

    public void postApply(ITargetClassContext iTargetClassContext) {
    }

    public void export(MixinEnvironment mixinEnvironment, String string, boolean bl, ClassNode classNode) {
    }
}

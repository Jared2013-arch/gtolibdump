package com.gtolib.adastra;

import com.gtolib.e;
import net.minecraft.world.item.crafting.Ingredient;

@e
public record IAdDisplayTagName$CountIngredient(Ingredient ingredient, int holderCount, int count) {
}

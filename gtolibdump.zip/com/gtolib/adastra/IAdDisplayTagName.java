package com.gtolib.adastra;

import com.gtolib.e;
import java.util.List;
import java.util.Map;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;

@e
public interface IAdDisplayTagName {
    public Map<ResourceKey<Level>, List<CountIngredient>> gtocore$getAdastraDisplayTagNames();

    @e
    public record CountIngredient(Ingredient ingredient, int holderCount, int count) {
    }
}

package com.gtolib.ae2.me2in1.a;

import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import appeng.core.sync.network.NetworkHandler;
import appeng.core.sync.packets.InventoryActionPacket;
import appeng.helpers.InventoryAction;
import appeng.menu.me.common.GridInventoryEntry;
import appeng.menu.me.common.MEStorageMenu;
import appeng.menu.slot.FakeSlot;
import appeng.util.CraftingRecipeUtil;
import com.google.common.math.LongMath;
import com.gregtechceu.gtceu.api.data.chemical.ChemicalHelper;
import com.gregtechceu.gtceu.api.data.chemical.material.Material;
import com.gregtechceu.gtceu.api.data.tag.TagPrefix;
import com.gregtechceu.gtceu.common.data.GTMaterials;
import com.gregtechceu.gtceu.utils.collection.O2IOpenCacheHashMap;
import com.gtocore.client.ClientCache;
import com.gtocore.common.data.GTORecipeTypes;
import com.gtocore.common.item.ItemMap;
import com.gtocore.integration.emi.GTEMIRecipe;
import com.gtolib.api.ae2.me2in1.ExtendedEncodingMenu;
import com.gtolib.api.ae2.me2in1.encoding.ExtendedEncodingMode;
import com.gtolib.utils.AEChemicalHelper;
import dev.emi.emi.api.recipe.EmiRecipe;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import java.lang.invoke.LambdaMetafactory;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import net.minecraft.core.NonNullList;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeType;
import org.apache.commons.lang3.tuple.Pair;
import org.jetbrains.annotations.Nullable;

public class a {
    private static final Set<AEKey> b = (Set)ItemMap.UNIVERSAL_CIRCUITS.stream().map(AEItemKey::of).collect(Collectors.toUnmodifiableSet());
    static final Comparator<GridInventoryEntry> a = Comparator.comparing(gridInventoryEntry -> com.gtolib.c.a.a.b.contains(gridInventoryEntry.getWhat())).thenComparing(gridInventoryEntry -> b.contains(gridInventoryEntry.getWhat())).thenComparing(GridInventoryEntry::isCraftable).thenComparing(a::a).thenComparing(GridInventoryEntry::getStoredAmount);
    private static final Set<RecipeType<?>> c = Set.of((Object[])new RecipeType[]{GTORecipeTypes.FURNACE_RECIPES, GTORecipeTypes.BENDER_RECIPES, GTORecipeTypes.MACERATOR_RECIPES, GTORecipeTypes.COMPRESSOR_RECIPES, GTORecipeTypes.CUTTER_RECIPES, GTORecipeTypes.EXTRUDER_RECIPES, GTORecipeTypes.FLUID_SOLIDFICATION_RECIPES, GTORecipeTypes.FORGE_HAMMER_RECIPES, GTORecipeTypes.LATHE_RECIPES, GTORecipeTypes.PACKER_RECIPES, GTORecipeTypes.LASER_WELDER_RECIPES, GTORecipeTypes.WIREMILL_RECIPES, GTORecipeTypes.BLAST_RECIPES, GTORecipeTypes.IMPLOSION_RECIPES, GTORecipeTypes.UNPACKER_RECIPES, GTORecipeTypes.CLUSTER_RECIPES, GTORecipeTypes.ROLLING_RECIPES, GTORecipeTypes.LAMINATOR_RECIPES, GTORecipeTypes.LOOM_RECIPES, GTORecipeTypes.ELECTRIC_IMPLOSION_COMPRESSOR_RECIPES, GTORecipeTypes.LIQUEFACTION_FURNACE_RECIPES, GTORecipeTypes.THREE_DIMENSIONAL_PRINTER_RECIPES, GTORecipeTypes.SINTERING_FURNACE_RECIPES, GTORecipeTypes.ISOSTATIC_PRESSING_RECIPES, GTORecipeTypes.HEAVY_ROLLING});
    private static final Set<RecipeType<?>> d = Set.of((Object)GTORecipeTypes.ASSEMBLY_LINE_RECIPES, (Object)GTORecipeTypes.CIRCUIT_ASSEMBLY_LINE_RECIPES, (Object)GTORecipeTypes.AGGREGATION_DEVICE_RECIPES);

    public static Comparator<GridInventoryEntry> a() {
        return a;
    }

    private static Boolean a(GridInventoryEntry gridInventoryEntry) {
        AEItemKey aEItemKey;
        AEKey aEKey = gridInventoryEntry.getWhat();
        return !(aEKey instanceof AEItemKey) || !(aEItemKey = (AEItemKey)aEKey).isDamaged();
    }

    public static void a(ExtendedEncodingMenu extendedEncodingMenu, List<List<GenericStack>> list, List<GenericStack> list2, boolean bl) {
        extendedEncodingMenu.setMode(ExtendedEncodingMode.PROCESSING);
        Object2IntOpenHashMap<AEKey> object2IntOpenHashMap = com.gtolib.ae2.me2in1.a.a.a(extendedEncodingMenu, a);
        com.gtolib.ae2.me2in1.a.a.a(list, object2IntOpenHashMap, extendedEncodingMenu.getProcessingInputSlots(), bl, ClientCache.autoRenameName);
        com.gtolib.ae2.me2in1.a.a.a(list2.stream().map((Function<GenericStack, List>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, of(java.lang.Object ), (Lappeng/api/stacks/GenericStack;)Ljava/util/List;)()).toList(), object2IntOpenHashMap, extendedEncodingMenu.getProcessingOutputSlots(), bl, ClientCache.autoRenameName);
    }

    public static void a(ExtendedEncodingMenu extendedEncodingMenu, List<List<GenericStack>> list, List<GenericStack> list2) {
        extendedEncodingMenu.setMode(ExtendedEncodingMode.BATCH);
        Object2IntOpenHashMap<AEKey> object2IntOpenHashMap = com.gtolib.ae2.me2in1.a.a.a(extendedEncodingMenu, a);
        com.gtolib.ae2.me2in1.a.a.a(list, object2IntOpenHashMap, extendedEncodingMenu.getProcessingInputSlots(), false, null);
        com.gtolib.ae2.me2in1.a.a.a(list2.stream().map((Function<GenericStack, List>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, of(java.lang.Object ), (Lappeng/api/stacks/GenericStack;)Ljava/util/List;)()).toList(), object2IntOpenHashMap, extendedEncodingMenu.getProcessingOutputSlots(), false, null);
        Set set = list.stream().flatMap(Collection::stream).map(GenericStack::what).map(AEChemicalHelper::getMaterial).filter(material -> material != GTMaterials.NULL).collect(Collectors.toSet());
        Set set2 = list2.stream().map(GenericStack::what).map(AEChemicalHelper::getMaterial).filter(material -> material != GTMaterials.NULL).collect(Collectors.toSet());
        if (!set.isEmpty() && !set2.isEmpty()) {
            Material material2 = set.stream().filter(set2::contains).findFirst().orElse(GTMaterials.NULL);
            if (material2 != GTMaterials.NULL) {
                NetworkHandler.instance().sendToServer(new InventoryActionPacket(InventoryAction.SET_FILTER, extendedEncodingMenu.getMaterialSlots()[0].f_40219_, ChemicalHelper.getIngotOrDust(material2, 3628800L)));
                ReferenceOpenHashSet referenceOpenHashSet = new ReferenceOpenHashSet();
                list.stream().flatMap(Collection::stream).map(GenericStack::what).filter(aEKey -> AEChemicalHelper.getMaterial(aEKey) == material2).map(AEChemicalHelper::getTagPrefix).filter(tagPrefix -> tagPrefix != TagPrefix.NULL_PREFIX).forEach(referenceOpenHashSet::add);
                list2.stream().map(GenericStack::what).filter(aEKey -> AEChemicalHelper.getMaterial(aEKey) == material2).map(AEChemicalHelper::getTagPrefix).filter(tagPrefix -> tagPrefix != TagPrefix.NULL_PREFIX).forEach(referenceOpenHashSet::add);
                com.gtolib.ae2.me2in1.a.a.a(extendedEncodingMenu, material2, referenceOpenHashSet);
            } else {
                extendedEncodingMenu.clearFilter();
            }
        }
    }

    private static void a(ExtendedEncodingMenu extendedEncodingMenu, Material material2, Set<TagPrefix> set) {
        ObjectArrayList objectArrayList = new ObjectArrayList(com.gtolib.c.a.a.b);
        Collections.reverse(objectArrayList);
        List list = objectArrayList.stream().map(AEChemicalHelper::getMaterial).filter(material -> material != GTMaterials.NULL).filter(material -> set.stream().allMatch(tagPrefix -> ChemicalHelper.get(tagPrefix, material) != ItemStack.f_41583_)).toList();
        int n = 0;
        ReferenceOpenHashSet referenceOpenHashSet = new ReferenceOpenHashSet(9);
        referenceOpenHashSet.add(material2);
        for (Material material3 : list) {
            if (n >= 8) {
                return;
            }
            if (!referenceOpenHashSet.add(material3)) continue;
            NetworkHandler.instance().sendToServer(new InventoryActionPacket(InventoryAction.SET_FILTER, extendedEncodingMenu.getMaterialSlots()[++n].f_40219_, ChemicalHelper.getIngotOrDust(material3, 3628800L)));
        }
        for (int i = n + 1; i < extendedEncodingMenu.getMaterialSlots().length; ++i) {
            NetworkHandler.instance().sendToServer(new InventoryActionPacket(InventoryAction.SET_FILTER, extendedEncodingMenu.getMaterialSlots()[i].f_40219_, ItemStack.f_41583_));
        }
    }

    private static void a(List<List<GenericStack>> list, Object2IntOpenHashMap<AEKey> object2IntOpenHashMap, FakeSlot[] fakeSlotArray, boolean bl, @Nullable String string) {
        ObjectArrayList objectArrayList = new ObjectArrayList();
        for (List<GenericStack> list2 : list) {
            if (list2.isEmpty()) continue;
            if (bl) {
                com.gtolib.ae2.me2in1.a.a.a(objectArrayList, com.gtolib.ae2.me2in1.a.a.a(object2IntOpenHashMap, list2), string);
                continue;
            }
            com.gtolib.ae2.me2in1.a.a.a(objectArrayList, com.gtolib.ae2.me2in1.a.a.a(object2IntOpenHashMap, list2));
        }
        for (int i = 0; i < fakeSlotArray.length; ++i) {
            List<GenericStack> list2;
            list2 = fakeSlotArray[i];
            ItemStack itemStack = i < objectArrayList.size() ? GenericStack.wrapInItemStack((GenericStack)objectArrayList.get(i)) : ItemStack.f_41583_;
            NetworkHandler.instance().sendToServer(new InventoryActionPacket(InventoryAction.SET_FILTER, ((FakeSlot)((Object)list2)).f_40219_, itemStack));
        }
    }

    public static boolean a(@Nullable EmiRecipe emiRecipe) {
        if (!(emiRecipe instanceof GTEMIRecipe)) {
            return false;
        }
        GTEMIRecipe gTEMIRecipe = (GTEMIRecipe)((Object)emiRecipe);
        RecipeType recipeType = gTEMIRecipe.getRecipeType();
        return c.contains(recipeType);
    }

    public static boolean b(@Nullable EmiRecipe emiRecipe) {
        if (!(emiRecipe instanceof GTEMIRecipe)) {
            return false;
        }
        GTEMIRecipe gTEMIRecipe = (GTEMIRecipe)((Object)emiRecipe);
        RecipeType recipeType = gTEMIRecipe.getRecipeType();
        return d.contains(recipeType);
    }

    public static void a(ExtendedEncodingMenu extendedEncodingMenu, @Nullable Recipe<?> recipe, List<List<GenericStack>> list, Predicate<ItemStack> predicate) {
        if (recipe != null && recipe.m_6671_().equals(RecipeType.f_44112_)) {
            extendedEncodingMenu.setMode(ExtendedEncodingMode.STONECUTTING);
            extendedEncodingMenu.setStonecuttingRecipeId(recipe.m_6423_());
        } else if (recipe != null && recipe.m_6671_().equals(RecipeType.f_44113_)) {
            extendedEncodingMenu.setMode(ExtendedEncodingMode.SMITHING_TABLE);
        } else {
            extendedEncodingMenu.setMode(ExtendedEncodingMode.CRAFTING);
        }
        Object2IntOpenHashMap<AEKey> object2IntOpenHashMap = com.gtolib.ae2.me2in1.a.a.a(extendedEncodingMenu, a);
        NonNullList nonNullList = NonNullList.m_122780_(extendedEncodingMenu.getCraftingGridSlots().length, ItemStack.f_41583_);
        if (recipe != null) {
            NonNullList nonNullList2 = CraftingRecipeUtil.ensure3by3CraftingMatrix(recipe);
            for (int i = 0; i < nonNullList2.size(); ++i) {
                var8_13 = (Ingredient)nonNullList2.get(i);
                if (((Ingredient)var8_13).m_43947_()) continue;
                Optional<ItemStack> optional = object2IntOpenHashMap.entrySet().stream().filter(arg_0 -> a.a((Ingredient)var8_13, arg_0)).max(Comparator.comparingInt(Map.Entry::getValue)).map(entry -> {
                    ItemStack itemStack;
                    Object k = entry.getKey();
                    if (k instanceof AEItemKey) {
                        AEItemKey aEItemKey = (AEItemKey)k;
                        itemStack = aEItemKey.toStack();
                    } else {
                        itemStack = null;
                    }
                    return itemStack;
                });
                ItemStack itemStack = optional.orElseGet(() -> a.a((Ingredient)var8_13, predicate));
                nonNullList.set(i, itemStack);
            }
        } else {
            for (int i = 0; i < list.size(); ++i) {
                List<GenericStack> list2 = list.get(i);
                if (list2.isEmpty()) continue;
                var8_13 = com.gtolib.ae2.me2in1.a.a.a(object2IntOpenHashMap, list2).what();
                if (var8_13 instanceof AEItemKey) {
                    AEItemKey aEItemKey = (AEItemKey)var8_13;
                    nonNullList.set(i, aEItemKey.toStack());
                    continue;
                }
                nonNullList.set(i, GenericStack.wrapInItemStack((AEKey)var8_13, 1L));
            }
        }
        for (int i = 0; i < nonNullList.size(); ++i) {
            ItemStack itemStack = (ItemStack)nonNullList.get(i);
            NetworkHandler.instance().sendToServer(new InventoryActionPacket(InventoryAction.SET_FILTER, extendedEncodingMenu.getCraftingGridSlots()[i].f_40219_, itemStack));
        }
        for (FakeSlot fakeSlot : extendedEncodingMenu.getProcessingOutputSlots()) {
            NetworkHandler.instance().sendToServer(new InventoryActionPacket(InventoryAction.SET_FILTER, fakeSlot.f_40219_, ItemStack.f_41583_));
        }
    }

    private static GenericStack a(Object2IntOpenHashMap<AEKey> object2IntOpenHashMap, List<GenericStack> list) {
        return (GenericStack)list.stream().map(genericStack -> Pair.of(genericStack, object2IntOpenHashMap.getOrDefault(genericStack.what(), Integer.MIN_VALUE))).max(Comparator.comparingInt(Pair::getRight)).map(Pair::getLeft).orElseThrow();
    }

    private static void a(List<GenericStack> list, GenericStack genericStack, @Nullable String string) {
        for (int i = 0; i < list.size(); ++i) {
            GenericStack genericStack2 = list.get(i);
            if (!Objects.equals(genericStack2.what(), genericStack.what())) continue;
            long l = genericStack.amount();
            AEKey aEKey = genericStack2.what();
            if (aEKey instanceof AEItemKey) {
                AEItemKey aEItemKey = (AEItemKey)aEKey;
                if (string != null && !string.isEmpty() && !string.equals("{}")) {
                    aEKey = AEItemKey.of(aEItemKey.toStack().m_41714_(Component.m_237113_(string)));
                }
            }
            list.add(new GenericStack(aEKey, l));
            return;
        }
        list.add(genericStack);
    }

    private static void a(List<GenericStack> list, GenericStack genericStack) {
        for (int i = 0; i < list.size(); ++i) {
            GenericStack genericStack2 = list.get(i);
            if (!Objects.equals(genericStack2.what(), genericStack.what())) continue;
            long l = LongMath.saturatedAdd(genericStack2.amount(), genericStack.amount());
            list.set(i, new GenericStack(genericStack.what(), l));
            long l2 = genericStack.amount() - (l - genericStack2.amount());
            if (l2 > 0L) {
                list.add(new GenericStack(genericStack.what(), l2));
            }
            return;
        }
        list.add(genericStack);
    }

    public static Object2IntOpenHashMap<AEKey> a(MEStorageMenu mEStorageMenu, Comparator<GridInventoryEntry> comparator) {
        List list = mEStorageMenu.getClientRepo().getAllEntries().stream().sorted(comparator).map(GridInventoryEntry::getWhat).toList();
        O2IOpenCacheHashMap o2IOpenCacheHashMap = new O2IOpenCacheHashMap(list.size());
        for (int i = 0; i < list.size(); ++i) {
            o2IOpenCacheHashMap.put((AEKey)list.get(i), i);
        }
        for (ItemStack itemStack : mEStorageMenu.getPlayerInventory().f_35974_) {
            AEItemKey aEItemKey = AEItemKey.of(itemStack);
            if (aEItemKey == null) continue;
            o2IOpenCacheHashMap.putIfAbsent(aEItemKey, -1);
        }
        return o2IOpenCacheHashMap;
    }

    private static ItemStack a(Ingredient ingredient, Predicate predicate) {
        for (ItemStack itemStack : ingredient.m_43908_()) {
            if (!predicate.test(itemStack)) continue;
            return itemStack;
        }
        return ingredient.m_43908_()[0];
    }

    private static boolean a(Ingredient ingredient, Map.Entry entry) {
        AEItemKey aEItemKey;
        Object k = entry.getKey();
        return k instanceof AEItemKey && (aEItemKey = (AEItemKey)k).matches(ingredient);
    }
}

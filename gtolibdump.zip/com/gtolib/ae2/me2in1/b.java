package com.gtolib.ae2.me2in1;

import appeng.client.gui.me.common.Repo;
import appeng.menu.SlotSemantic;
import appeng.menu.slot.FakeSlot;
import appeng.menu.slot.RestrictedInputSlot;
import com.gtolib.api.ae2.IPatterEncodingTermMenu;
import com.gtolib.api.ae2.me2in1.encoding.ExtendedEncodingMode;
import it.unimi.dsi.fastutil.ints.IntSet;
import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.crafting.StonecutterRecipe;
import org.jetbrains.annotations.Nullable;

public interface b
extends IPatterEncodingTermMenu {
    public void encodeAndTransferToProvider();

    public void clearPattern();

    public FakeSlot getQuickRemovePatternFilterSlot();

    public void clear();

    public void setSubstitute(boolean var1);

    public boolean isAutoEncodeRenaming();

    public void setAutoEncodeRenaming(boolean var1);

    public void setSubstituteFluids(boolean var1);

    public boolean isSubstitute();

    public boolean isSubstituteFluids();

    public IntSet slotsSupportingFluidSubstitution();

    public FakeSlot[] getCraftingGridSlots();

    public FakeSlot[] getProcessingInputSlots();

    public FakeSlot[] getProcessingOutputSlots();

    public void cycleProcessingOutput();

    public boolean canCycleProcessingOutputs();

    public Slot addClientSideSlot(Slot var1, SlotSemantic var2);

    public FakeSlot[] getMaterialSlots();

    public FakeSlot getSmithingTableTemplateSlot();

    public FakeSlot getSmithingTableBaseSlot();

    public FakeSlot getSmithingTableAdditionSlot();

    public Player getPlayer();

    public List<StonecutterRecipe> getStonecuttingRecipes();

    @Nullable
    public ResourceLocation getStonecuttingRecipeId();

    public void setStonecuttingRecipeId(ResourceLocation var1);

    public FakeSlot getStonecuttingInputSlot();

    public RestrictedInputSlot[] getEncodedPatternSlots();

    public void encode(boolean var1);

    public void cycleProcessingInput();

    public boolean canCycleProcessingInputs();

    public Slot getCraftingResultSlot();

    public void setMode(ExtendedEncodingMode var1);

    public ExtendedEncodingMode getMode();

    public boolean canModifyAmountForSlot(Slot var1);

    public boolean isProcessingPatternSlot(Slot var1);

    public Repo getRepo();

    public void clearFilter();
}

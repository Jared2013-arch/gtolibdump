package com.gtolib.ae2.me2in1.panel;

import appeng.api.config.ActionItems;
import appeng.api.stacks.AEItemKey;
import appeng.client.Point;
import appeng.client.gui.Icon;
import appeng.client.gui.style.Blitter;
import appeng.client.gui.widgets.ActionButton;
import appeng.client.gui.widgets.IconButton;
import appeng.core.definitions.AEItems;
import appeng.menu.SlotSemantics;
import appeng.menu.slot.RestrictedInputSlot;
import com.gtolib.ae2.me2in1.b;
import com.gtolib.ae2.me2in1.panel.d;
import com.gtolib.api.ae2.gui.FixedRepoSlot;
import com.gtolib.api.ae2.me2in1.Me2in1Menu;
import com.gtolib.api.ae2.me2in1.Me2in1Screen;
import com.gtolib.api.ae2.me2in1.UtilsMiscs;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.runtime.EmiFavorite;
import dev.emi.emi.runtime.EmiFavorites;
import java.lang.invoke.LambdaMetafactory;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.network.chat.Component;

public class a
extends d
implements GuiEventListener {
    private static final Blitter a = Blitter.texture("guis/pattern_buffer_area.png").src(0, 0, 91, 231);
    private static final int b = 40;
    private static final int c = 58;
    private static final int d = 22;
    private static final int e = 3;
    private static final int l = 40;
    private static final int m = -18;
    private static final int n = 13;
    private static final int o = 23;
    private static final int p = 2;
    private static final int q = -36;
    private final ActionButton r = new ActionButton(ActionItems.ENCODE, actionItems -> this.c().encode(Screen.m_96638_()));
    private final IconButton s;
    private final IconButton t;
    private final ActionButton u;
    private final FixedRepoSlot v;

    public a(Me2in1Screen<?> me2in1Screen) {
        super(me2in1Screen, 210, 36, "bufferPanel");
        me2in1Screen.getSubWidgets().put("encodeBtn", (AbstractWidget)((Object)this.r));
        this.s = UtilsMiscs.createIconButton(Icon.INSCRIBER_BUFFER_HIGH, button -> {
            List list = EmiFavorites.favorites.stream().map((Function<EmiFavorite, EmiRecipe>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, getRecipe(), (Ldev/emi/emi/runtime/EmiFavorite;)Ldev/emi/emi/api/recipe/EmiRecipe;)()).filter(Objects::nonNull).toList();
        });
        this.t = UtilsMiscs.createIconButton(Icon.AUTO_EXPORT_ON, button -> this.c().encodeAndTransferToProvider());
        this.t.m_93666_(Component.m_237115_("gtocore.ae.appeng.me2in1.encode_to.accessor"));
        me2in1Screen.getSubWidgets().put("encodeToPatternBtn", (AbstractWidget)((Object)this.t));
        this.u = new ActionButton(ActionItems.CLOSE, actionItems -> this.c().clearPattern());
        me2in1Screen.getSubWidgets().put("clrPatternBtn", (AbstractWidget)((Object)this.u));
        this.v = new FixedRepoSlot(this.c().getRepo(), AEItemKey.of(AEItems.BLANK_PATTERN.m_5456_()), 0, 0);
        ((Me2in1Menu)this.j().m_6262_()).addClientSideSlot(this.v, SlotSemantics.BLANK_PATTERN);
    }

    private b c() {
        return ((Me2in1Menu)this.f.m_6262_()).getEncoding();
    }

    @Override
    int a() {
        return 4;
    }

    @Override
    int b() {
        return -34;
    }

    @Override
    public Rect2i getBounds() {
        return new Rect2i(this.h + 2, this.i + -36, a.getSrcWidth(), a.getSrcHeight());
    }

    @Override
    public void updateBeforeRender() {
        super.updateBeforeRender();
        this.r.m_264152_(this.h + this.getGuiLeft() + 40, this.i + 3 + this.getGuiTop());
        this.t.m_264152_(this.h + this.getGuiLeft() + 22, this.i + 3 + this.getGuiTop());
        this.u.m_264152_(this.h + this.getGuiLeft() + 58, this.i + 3 + this.getGuiTop());
        UtilsMiscs.setSlotPos(this.v, this.h + 40, this.i + -18);
        AtomicInteger atomicInteger = new AtomicInteger(0);
        for (RestrictedInputSlot restrictedInputSlot : this.c().getEncodedPatternSlots()) {
            UtilsMiscs.setSlotPos(restrictedInputSlot, this.h + atomicInteger.get() % 4 * 18 + 13, this.i + 23 + atomicInteger.getAndIncrement() / 4 * 18);
        }
    }

    @Override
    public void drawBackgroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
        super.drawBackgroundLayer(guiGraphics, rect2i, point);
        a.dest(this.h + rect2i.m_110085_() + 2, this.i + rect2i.m_110086_() + -36).blit(guiGraphics);
    }

    public void m_93692_(boolean bl) {
        this.r.m_93692_(bl);
    }

    public boolean m_93696_() {
        return this.r.m_93696_();
    }
}

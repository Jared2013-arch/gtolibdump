package com.gtolib.ae2.me2in1.panel;

import com.gtolib.api.ae2.me2in1.encoding.ExtendedEncodingMode;

class c$1 {
    static final int[] a;

    static {
        a = new int[ExtendedEncodingMode.values().length];
        try {
            c$1.a[ExtendedEncodingMode.STONECUTTING.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            c$1.a[ExtendedEncodingMode.CRAFTING.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            c$1.a[ExtendedEncodingMode.SMITHING_TABLE.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            c$1.a[ExtendedEncodingMode.PROCESSING.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            c$1.a[ExtendedEncodingMode.BATCH.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

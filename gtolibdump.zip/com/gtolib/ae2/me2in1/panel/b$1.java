package com.gtolib.ae2.me2in1.panel;

import appeng.client.Point;
import appeng.client.gui.AEBaseScreen;
import appeng.client.gui.WidgetContainer;
import com.gtolib.api.ae2.gui.hooks.IStylelessCompositeWidget;
import java.util.function.Consumer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.Rect2i;

class b$1
implements IStylelessCompositeWidget {
    b$1() {
    }

    @Override
    public void initialize(String string, WidgetContainer widgetContainer) {
    }

    @Override
    public AEBaseScreen<?> getScreen() {
        return b.this.f;
    }

    public void populateScreen(Consumer<AbstractWidget> consumer, Rect2i rect2i, AEBaseScreen<?> aEBaseScreen) {
        b.this.C.populateScreen(consumer, rect2i, aEBaseScreen);
    }

    @Override
    public void setPosition(Point point) {
    }

    public void setSize(int n, int n2) {
    }

    @Override
    public Rect2i getBounds() {
        return new Rect2i(b.this.h + 3 - 16, b.this.i + 24 - 8, 102, 82);
    }

    @Override
    public boolean onMouseWheel(Point point, double d2) {
        return !Screen.m_96638_() && b.this.D.onMouseWheel(point, d2);
    }

    @Override
    public boolean onMouseDown(Point point, int n) {
        if (b.this.D.getBounds().m_110087_(point.getX(), point.getY())) {
            return b.this.D.onMouseDown(point, n);
        }
        return false;
    }

    @Override
    public boolean onMouseUp(Point point, int n) {
        if (b.this.D.getBounds().m_110087_(point.getX(), point.getY())) {
            return b.this.D.onMouseUp(point, n);
        }
        return false;
    }

    public boolean onMouseDrag(Point point, int n) {
        if (b.this.D.getBounds().m_110087_(point.getX(), point.getY())) {
            return b.this.D.onMouseDrag(point, n);
        }
        return false;
    }

    @Override
    public void drawForegroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
        b.this.D.drawForegroundLayer(guiGraphics, rect2i, point);
    }

    @Override
    public void drawBackgroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
        l.dest(b.this.h + -9 + this.getGuiLeft(), b.this.i + -8 + this.getGuiTop()).blit(guiGraphics);
        b.this.D.drawBackgroundLayer(guiGraphics, rect2i, point);
    }

    @Override
    public void updateBeforeRender() {
        b.this.D.setPosition(new Point(b.this.h + 3, b.this.i + 24));
        b.this.C.setPosition(new Point(b.this.h + -10, b.this.i + 4));
        b.this.C.updateBeforeRender();
    }
}

package com.gtolib.ae2.me2in1.panel;

import appeng.client.Point;
import appeng.client.gui.AEBaseScreen;
import appeng.client.gui.WidgetContainer;
import appeng.client.gui.me.common.RepoSlot;
import appeng.client.gui.style.Blitter;
import appeng.client.gui.style.StyleManager;
import appeng.client.gui.widgets.AETextField;
import appeng.client.gui.widgets.Scrollbar;
import appeng.client.gui.widgets.VerticalButtonBar;
import appeng.core.localization.GuiText;
import com.gtolib.ae2.me2in1.panel.d;
import com.gtolib.api.ae2.gui.hooks.IStylelessCompositeWidget;
import com.gtolib.api.ae2.me2in1.Me2in1Screen;
import com.gtolib.api.ae2.me2in1.UtilsMiscs;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.Rect2i;

public class b
extends d {
    public static final int a = 4;
    public static final Blitter b = Blitter.texture("guis/pattern_buffer_area.png").src(10, 58, 72, 18);
    public static final Blitter c = Blitter.texture("guis/pattern_buffer_area.png").src(10, 76, 72, 18);
    public static final Blitter d = Blitter.texture("guis/pattern_buffer_area.png").src(10, 94, 72, 18);
    private static final Blitter l = Blitter.texture("guis/pattern_buffer_area.png").src(112, 0, 101, 112);
    public static String e;
    private static final int m = -9;
    private static final int n = -8;
    private static final int o = 9;
    private static final int p = 23;
    private static final int q = 12;
    private static final int r = 24;
    private static final int s = 10;
    private static final int t = 2;
    private static final int u = -10;
    private static final int v = 4;
    private static final int w = 3;
    private static final int x = 24;
    private static final int y = -8;
    private static final int z = -6;
    private final AETextField A;
    private final RepoSlot[] B;
    private final VerticalButtonBar C = new VerticalButtonBar();
    private final Scrollbar D;

    public AETextField c() {
        return this.A;
    }

    public b(Me2in1Screen<?> me2in1Screen, Scrollbar scrollbar, Consumer<String> consumer, RepoSlot[] repoSlotArray) {
        super(me2in1Screen, -120, 0, "mePanel");
        this.D = scrollbar;
        this.A = new AETextField(StyleManager.loadStyleDoc("/screens/terminals/terminal.json"), Minecraft.m_91087_().f_91062_, 0, 0, 0, 0);
        this.A.m_94182_(false);
        this.A.m_94199_(25);
        this.A.m_94202_(0xFFFFFF);
        this.A.setSelectionColor(-16777088);
        this.A.m_94194_(true);
        this.A.m_93674_(64);
        Objects.requireNonNull(Minecraft.m_91087_().f_91062_);
        this.A.setHeight(9 + 2);
        this.A.setPlaceholder(GuiText.SearchPlaceholder.text());
        this.A.m_94151_(consumer);
        me2in1Screen.getSubWidgets().put("mePanelSearchField", (AbstractWidget)((Object)this.A));
        this.B = repoSlotArray;
    }

    @Override
    public void initialize(String string, WidgetContainer widgetContainer) {
        super.initialize(string, widgetContainer);
        widgetContainer.add("mePanelWidget", new IStylelessCompositeWidget(){

            @Override
            public void initialize(String string, WidgetContainer widgetContainer) {
            }

            @Override
            public AEBaseScreen<?> getScreen() {
                return b.this.f;
            }

            public void populateScreen(Consumer<AbstractWidget> consumer, Rect2i rect2i, AEBaseScreen<?> aEBaseScreen) {
                b.this.C.populateScreen(consumer, rect2i, aEBaseScreen);
            }

            @Override
            public void setPosition(Point point) {
            }

            public void setSize(int n, int n2) {
            }

            @Override
            public Rect2i getBounds() {
                return new Rect2i(b.this.h + 3 - 16, b.this.i + 24 - 8, 102, 82);
            }

            @Override
            public boolean onMouseWheel(Point point, double d2) {
                return !Screen.m_96638_() && b.this.D.onMouseWheel(point, d2);
            }

            @Override
            public boolean onMouseDown(Point point, int n) {
                if (b.this.D.getBounds().m_110087_(point.getX(), point.getY())) {
                    return b.this.D.onMouseDown(point, n);
                }
                return false;
            }

            @Override
            public boolean onMouseUp(Point point, int n) {
                if (b.this.D.getBounds().m_110087_(point.getX(), point.getY())) {
                    return b.this.D.onMouseUp(point, n);
                }
                return false;
            }

            public boolean onMouseDrag(Point point, int n) {
                if (b.this.D.getBounds().m_110087_(point.getX(), point.getY())) {
                    return b.this.D.onMouseDrag(point, n);
                }
                return false;
            }

            @Override
            public void drawForegroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
                b.this.D.drawForegroundLayer(guiGraphics, rect2i, point);
            }

            @Override
            public void drawBackgroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
                l.dest(b.this.h + -9 + this.getGuiLeft(), b.this.i + -8 + this.getGuiTop()).blit(guiGraphics);
                b.this.D.drawBackgroundLayer(guiGraphics, rect2i, point);
            }

            @Override
            public void updateBeforeRender() {
                b.this.D.setPosition(new Point(b.this.h + 3, b.this.i + 24));
                b.this.C.setPosition(new Point(b.this.h + -10, b.this.i + 4));
                b.this.C.updateBeforeRender();
            }
        });
    }

    @Override
    public Rect2i getBounds() {
        return new Rect2i(this.h + -10, this.i, l.getSrcWidth() + -10, l.getSrcHeight());
    }

    @Override
    public void updateBeforeRender() {
        super.updateBeforeRender();
        this.A.m_264152_(this.h + 10 + this.getGuiLeft(), this.i + 2 + this.getGuiTop());
        AtomicInteger atomicInteger = new AtomicInteger(0);
        for (RepoSlot repoSlot : this.B) {
            if (repoSlot == null) continue;
            UtilsMiscs.setSlotPos(repoSlot, this.h + 12 + atomicInteger.get() % 4 * 18, this.i + 24 + atomicInteger.getAndIncrement() / 4 * 18);
        }
    }

    public <BUTTON extends Button> BUTTON a(BUTTON BUTTON) {
        this.C.add(BUTTON);
        return BUTTON;
    }

    @Override
    int a() {
        return -8;
    }

    @Override
    int b() {
        return -6;
    }

    public void d() {
        this.D.setHeight(4 * c.getSrcHeight() - 2);
        int n = (this.f.gtolib$getRepo().size() + 4 - 1) / 4;
        if (this.f.gtolib$getRepo().hasPinnedRow()) {
            ++n;
        }
        this.D.setRange(0, n - 4, 1);
    }

    public VerticalButtonBar e() {
        return this.C;
    }
}

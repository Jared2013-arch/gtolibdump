package com.gtolib.ae2.me2in1.panel;

import appeng.client.Point;
import appeng.client.gui.AEBaseScreen;
import appeng.client.gui.Icon;
import appeng.client.gui.Tooltip;
import appeng.client.gui.WidgetContainer;
import appeng.client.gui.style.Blitter;
import com.gtolib.api.ae2.gui.hooks.IStylelessCompositeWidget;
import com.gtolib.api.ae2.me2in1.Me2in1Menu;
import com.gtolib.api.ae2.me2in1.Me2in1Screen;
import java.util.function.BiConsumer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.Nullable;

public abstract class d
implements IStylelessCompositeWidget {
    protected final Me2in1Screen<?> f;
    protected final a g;
    private final String a;
    protected int h;
    protected int i;
    protected final int j;
    protected final int k;

    public String f() {
        return this.a;
    }

    public int g() {
        return this.h;
    }

    public int h() {
        return this.i;
    }

    @Override
    public void setPosition(Point point) {
        this.h = point.getX();
        this.i = point.getY();
    }

    public void setSize(int n, int n2) {
    }

    public void i() {
        this.h = this.j;
        this.i = this.k;
        ((Me2in1Menu)this.f.m_6262_()).updateC2SPanelPos(this);
    }

    @Override
    public void drawForegroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
        IStylelessCompositeWidget.super.drawForegroundLayer(guiGraphics, rect2i, point);
    }

    @Override
    public void initialize(String string, WidgetContainer widgetContainer) {
        widgetContainer.add(this.a + "draggableMark", this.g);
    }

    public Me2in1Screen<?> j() {
        return this.f;
    }

    public d(Me2in1Screen<?> me2in1Screen, int n3, int n4, String string) {
        this.a = string;
        this.f = me2in1Screen;
        this.j = n3;
        this.k = n4;
        this.setPosition(new Point(n3, n4));
        this.g = new a((n, n2) -> {
            this.h = n - this.a();
            this.i = n2 - this.b();
        });
    }

    @Override
    public void updateBeforeRender() {
        this.g.setPosition(new Point(this.a() + this.h, this.b() + this.i));
    }

    abstract int a();

    abstract int b();

    public AEBaseScreen getScreen() {
        return this.j();
    }

    public class a
    implements IStylelessCompositeWidget {
        private static final Blitter b = Icon.WRENCH_DISABLED.getBlitter();
        private static final Blitter c = Icon.WRENCH.getBlitter();
        private final BiConsumer<Integer, Integer> d;
        private boolean e = false;
        private int f = 0;
        private int g = 0;

        public a(BiConsumer<Integer, Integer> biConsumer) {
            this.d = biConsumer;
        }

        public boolean wantsAllMouseUpEvents() {
            return true;
        }

        @Override
        public boolean onMouseDown(Point point, int n) {
            if (point.getX() >= this.f && point.getX() <= this.f + 16 && point.getY() >= this.g && point.getY() <= this.g + 16) {
                this.e = true;
                return true;
            }
            return false;
        }

        @Override
        public boolean onMouseUp(Point point, int n) {
            this.e = false;
            ((Me2in1Menu)d.this.f.m_6262_()).updateC2SPanelPos(d.this);
            return false;
        }

        public boolean onMouseDrag(Point point, int n) {
            if (this.e) {
                int n2 = point.getX() - 8;
                int n3 = point.getY() - 8;
                this.d.accept(n2, n3);
                return true;
            }
            return false;
        }

        @Override
        public void setPosition(Point point) {
            this.f = point.getX();
            this.g = point.getY();
        }

        public void setSize(int n, int n2) {
        }

        @Override
        public Rect2i getBounds() {
            return new Rect2i(this.f, this.g, 16, 16);
        }

        @Override
        public void drawForegroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
            (this.e ? c : b).copy().dest(this.f + rect2i.m_110085_(), this.g + rect2i.m_110086_()).blit(guiGraphics);
        }

        @Override
        public void initialize(String string, WidgetContainer widgetContainer) {
        }

        @Override
        public AEBaseScreen<?> getScreen() {
            return d.this.f;
        }

        @Override
        @Nullable
        public Tooltip getTooltip(int n, int n2) {
            return new Tooltip(new Component[]{Component.m_237115_("gtocore.ae.appeng.me2in1.draggable_mark.tooltip")});
        }
    }
}

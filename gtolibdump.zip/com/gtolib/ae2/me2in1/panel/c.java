package com.gtolib.ae2.me2in1.panel;

import appeng.client.Point;
import appeng.client.gui.WidgetContainer;
import appeng.client.gui.widgets.TabButton;
import com.gtolib.ae2.me2in1.b;
import com.gtolib.ae2.me2in1.panel.d;
import com.gtolib.api.ae2.me2in1.Me2in1Menu;
import com.gtolib.api.ae2.me2in1.Me2in1Screen;
import com.gtolib.api.ae2.me2in1.encoding.BatchEncodingPanel;
import com.gtolib.api.ae2.me2in1.encoding.CraftingEncodingPanel;
import com.gtolib.api.ae2.me2in1.encoding.EncodingModePanel;
import com.gtolib.api.ae2.me2in1.encoding.ExtendedEncodingMode;
import com.gtolib.api.ae2.me2in1.encoding.ProcessingEncodingPanel;
import com.gtolib.api.ae2.me2in1.encoding.SmithingTableEncodingPanel;
import com.gtolib.api.ae2.me2in1.encoding.StonecuttingEncodingPanel;
import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.client.renderer.Rect2i;
import org.apache.commons.lang3.NotImplementedException;

public class c
extends d {
    private static final int a = -8;
    private static final int b = -10;
    private static final int c = 0;
    private static final int d = -34;
    private static final int e = 22;
    private final Map<ExtendedEncodingMode, EncodingModePanel> l = new EnumMap<ExtendedEncodingMode, EncodingModePanel>(ExtendedEncodingMode.class);
    private final Map<ExtendedEncodingMode, TabButton> m = new EnumMap<ExtendedEncodingMode, TabButton>(ExtendedEncodingMode.class);

    public c(Me2in1Screen<?> me2in1Screen) {
        super(me2in1Screen, -146, 170, "encodingModePanel");
        for (ExtendedEncodingMode extendedEncodingMode : ExtendedEncodingMode.values()) {
            EncodingModePanel encodingModePanel = switch (extendedEncodingMode) {
                case ExtendedEncodingMode.STONECUTTING -> new StonecuttingEncodingPanel(me2in1Screen);
                case ExtendedEncodingMode.CRAFTING -> new CraftingEncodingPanel(me2in1Screen);
                case ExtendedEncodingMode.SMITHING_TABLE -> new SmithingTableEncodingPanel(me2in1Screen);
                case ExtendedEncodingMode.PROCESSING -> new ProcessingEncodingPanel(me2in1Screen);
                case ExtendedEncodingMode.BATCH -> new BatchEncodingPanel(me2in1Screen);
                default -> throw new NotImplementedException();
            };
            TabButton tabButton = new TabButton(encodingModePanel.getTabIconItem(), encodingModePanel.getTabTooltip(), button -> this.c().setMode(extendedEncodingMode));
            tabButton.setStyle(TabButton.Style.BOX);
            int n = this.m.size();
            this.m.put(extendedEncodingMode, tabButton);
            me2in1Screen.getSubWidgets().put("modeTabButton_" + extendedEncodingMode.name(), tabButton);
            this.l.put(extendedEncodingMode, encodingModePanel);
        }
    }

    private b c() {
        return ((Me2in1Menu)this.f.m_6262_()).getEncoding();
    }

    @Override
    public void initialize(String string, WidgetContainer widgetContainer) {
        super.initialize(string, widgetContainer);
        for (Map.Entry<ExtendedEncodingMode, EncodingModePanel> entry : this.l.entrySet()) {
            ExtendedEncodingMode extendedEncodingMode = entry.getKey();
            EncodingModePanel encodingModePanel = entry.getValue();
            widgetContainer.add(string + "_" + extendedEncodingMode.name(), encodingModePanel);
        }
    }

    @Override
    public void updateBeforeRender() {
        super.updateBeforeRender();
        AtomicInteger atomicInteger = new AtomicInteger(this.h + 0);
        for (ExtendedEncodingMode extendedEncodingMode : ExtendedEncodingMode.values()) {
            boolean bl = this.c().getMode() == extendedEncodingMode;
            this.m.get((Object)extendedEncodingMode).setSelected(bl);
            this.m.get((Object)extendedEncodingMode).m_264152_(this.getGuiLeft() + atomicInteger.getAndAdd(22), this.getGuiTop() + this.i + -34);
            this.l.get((Object)extendedEncodingMode).setVisible(false);
        }
        EncodingModePanel encodingModePanel = this.l.get((Object)this.c().getMode());
        encodingModePanel.setPosition(new Point(this.h, this.i));
        encodingModePanel.setVisible(true);
        encodingModePanel.updateBeforeRender();
    }

    @Override
    int a() {
        return -8;
    }

    @Override
    int b() {
        return -10;
    }

    @Override
    public Rect2i getBounds() {
        return new Rect2i(this.h - 30, this.i - 12 - 22, 161, 132);
    }
}

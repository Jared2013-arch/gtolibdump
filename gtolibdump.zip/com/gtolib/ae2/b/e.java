package com.gtolib.ae2.b;

import appeng.api.stacks.GenericStack;
import com.gtolib.api.ae2.stacks.IGenericStack;

final class e {
    private final GenericStack[] b;
    final GenericStack[] a;

    private e(GenericStack[] genericStackArray, long l) {
        this.b = genericStackArray;
        this.a = new GenericStack[genericStackArray.length];
        for (int i = 0; i < genericStackArray.length; ++i) {
            this.a[i] = genericStackArray[i] == null ? null : new GenericStack(genericStackArray[i].what(), genericStackArray[i].amount() * l);
        }
    }

    static e a(GenericStack[] genericStackArray, long l) {
        return new e(genericStackArray, l);
    }

    void a(long l) {
        for (int i = 0; i < this.b.length; ++i) {
            GenericStack genericStack = this.b[i];
            if (genericStack == null) continue;
            IGenericStack.of(this.a[i]).setAmount(genericStack.amount() * l);
        }
    }
}

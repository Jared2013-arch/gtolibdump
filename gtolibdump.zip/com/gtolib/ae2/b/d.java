package com.gtolib.ae2.b;

import appeng.api.crafting.IPatternDetails;
import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.GenericStack;
import appeng.crafting.pattern.AEStonecuttingPattern;
import com.gtolib.ae2.b.e;
import com.gtolib.ae2.b.f;
import com.gtolib.api.ae2.pattern.IParallelPatternDetails;
import net.minecraft.world.level.Level;

public final class d
extends AEStonecuttingPattern
implements IParallelPatternDetails {
    private long a;
    private IParallelPatternDetails b;
    private final f[] c;
    private final e d;
    private final Level e;

    public d(AEItemKey aEItemKey, Level level, long l) {
        super(aEItemKey, level);
        this.e = level;
        this.a = l;
        this.c = f.a(super.getInputs(), l);
        this.d = com.gtolib.ae2.b.e.a(super.getOutputs(), l);
    }

    @Override
    public IPatternDetails.IInput[] getInputs() {
        return this.c;
    }

    @Override
    public GenericStack[] getOutputs() {
        return this.d.a;
    }

    @Override
    public void parallel(long l) {
        this.a = l;
        f.a(this.c, l);
        this.d.a(l);
    }

    @Override
    public IParallelPatternDetails copy(long l, Level level) {
        return new d(this.getDefinition(), level, l);
    }

    @Override
    public IParallelPatternDetails getCopy() {
        if (this.b != null) {
            return this.b;
        }
        this.b = this.copy(this.a, this.e);
        return this.b;
    }

    @Override
    public long getParallel() {
        return this.a;
    }
}

package com.gtolib.ae2.b;

import appeng.api.crafting.IPatternDetails;
import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import com.gtolib.api.ae2.stacks.IGenericStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

final class f
implements IPatternDetails.IInput {
    private final IPatternDetails.IInput a;
    private final GenericStack[] b;

    private f(IPatternDetails.IInput iInput, long l) {
        this.a = iInput;
        GenericStack[] genericStackArray = iInput.getPossibleInputs();
        this.b = new GenericStack[genericStackArray.length];
        for (int i = 0; i < genericStackArray.length; ++i) {
            this.b[i] = new GenericStack(genericStackArray[i].what(), genericStackArray[i].amount() * l);
        }
    }

    static f[] a(IPatternDetails.IInput[] iInputArray, long l) {
        f[] fArray = new f[iInputArray.length];
        for (int i = 0; i < iInputArray.length; ++i) {
            fArray[i] = new f(iInputArray[i], l);
        }
        return fArray;
    }

    static void a(f[] fArray, long l) {
        for (f f2 : fArray) {
            GenericStack[] genericStackArray = f2.a.getPossibleInputs();
            for (int i = 0; i < genericStackArray.length; ++i) {
                IGenericStack.of(f2.b[i]).setAmount(genericStackArray[i].amount() * l);
            }
        }
    }

    @Override
    public GenericStack[] getPossibleInputs() {
        return this.b;
    }

    @Override
    public long getMultiplier() {
        return this.a.getMultiplier();
    }

    @Override
    public boolean isValid(AEKey aEKey, Level level) {
        return this.a.isValid(aEKey, level);
    }

    @Nullable
    public AEKey getRemainingKey(AEKey aEKey) {
        return null;
    }
}

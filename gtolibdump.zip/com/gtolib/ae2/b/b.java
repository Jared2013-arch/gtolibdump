package com.gtolib.ae2.b;

import appeng.api.crafting.IPatternDetails;
import appeng.api.stacks.AEFluidKey;
import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import appeng.api.stacks.KeyCounter;
import appeng.crafting.pattern.AEProcessingPattern;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtocore.common.machine.multiblock.part.ae.MEPatternBufferPartMachine;
import com.gtolib.ae2.b.e;
import com.gtolib.ae2.b.f;
import com.gtolib.api.ae2.pattern.IParallelPatternDetails;
import com.gtolib.utils.holder.ObjectHolder;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.util.Iterator;
import net.minecraft.world.level.Level;

public final class b
extends AEProcessingPattern
implements IParallelPatternDetails {
    private ObjectHolder<Object2ObjectOpenHashMap<AEKey, Object>> a = new ObjectHolder<Object>(null);
    private long b;
    private IParallelPatternDetails c;
    private final f[] d;
    private final e e;
    private final e f;
    private final e g;

    public b(AEItemKey aEItemKey, long l) {
        super(aEItemKey);
        this.b = l;
        this.d = com.gtolib.ae2.b.f.a(super.getInputs(), l);
        this.e = com.gtolib.ae2.b.e.a(super.getOutputs(), l);
        this.f = com.gtolib.ae2.b.e.a(super.getSparseInputs(), l);
        this.g = com.gtolib.ae2.b.e.a(super.getSparseOutputs(), l);
    }

    @Override
    public IPatternDetails.IInput[] getInputs() {
        return this.d;
    }

    @Override
    public GenericStack[] getOutputs() {
        return this.e.a;
    }

    @Override
    public GenericStack[] getSparseInputs() {
        return this.f.a;
    }

    @Override
    public GenericStack[] getSparseOutputs() {
        return this.g.a;
    }

    @Override
    public void parallel(long l) {
        this.b = l;
        com.gtolib.ae2.b.f.a(this.d, l);
        this.e.a(l);
    }

    @Override
    public IParallelPatternDetails copy(long l, Level level) {
        b b2 = new b(this.getDefinition(), l);
        b2.a = this.a;
        return b2;
    }

    @Override
    public IParallelPatternDetails getCopy() {
        if (this.c != null) {
            return this.c;
        }
        this.c = this.copy(this.b, null);
        return this.c;
    }

    @Override
    public long getParallel() {
        return this.b;
    }

    @Override
    public void pushInputsToExternalInventory(KeyCounter[] keyCounterArray, IPatternDetails.PatternInputSink patternInputSink) {
        if (patternInputSink instanceof MEPatternBufferPartMachine.InputSink) {
            Object2LongMap.Entry entry;
            MEPatternBufferPartMachine.InputSink inputSink = (MEPatternBufferPartMachine.InputSink)((Object)patternInputSink);
            if (this.a.value == null) {
                this.a.value = new O2OOpenCacheHashMap();
                for (KeyCounter keyCounter : keyCounterArray) {
                    Iterator iterator = keyCounter.iterator();
                    while (iterator.hasNext()) {
                        entry = (Object2LongMap.Entry)iterator.next();
                        AEKey aEKey = (AEKey)entry.getKey();
                        if (aEKey instanceof AEItemKey) {
                            AEItemKey aEItemKey = (AEItemKey)aEKey;
                            ((Object2ObjectOpenHashMap)this.a.value).put(aEItemKey, aEItemKey.toStack());
                            continue;
                        }
                        if (!(aEKey instanceof AEFluidKey)) continue;
                        AEFluidKey aEFluidKey = (AEFluidKey)aEKey;
                        ((Object2ObjectOpenHashMap)this.a.value).put(aEFluidKey, aEFluidKey.toStack(1));
                    }
                }
            }
            for (KeyCounter keyCounter : keyCounterArray) {
                Iterator iterator = keyCounter.iterator();
                while (iterator.hasNext()) {
                    entry = (Object2LongMap.Entry)iterator.next();
                    inputSink.pushInput(((Object2ObjectOpenHashMap)this.a.value).get(entry.getKey()), entry.getLongValue());
                }
            }
        } else {
            if (this.getSparseInputs().length == this.getInputs().length) {
                super.pushInputsToExternalInventory(keyCounterArray, patternInputSink);
                return;
            }
            KeyCounter keyCounter = new KeyCounter();
            for (KeyCounter keyCounter2 : keyCounterArray) {
                keyCounter.addAll(keyCounter2);
            }
            for (GenericStack genericStack : this.getSparseInputs()) {
                if (genericStack == null) continue;
                AEKey aEKey = genericStack.what();
                long l = genericStack.amount();
                long l2 = keyCounter.get(aEKey);
                if (l2 < l) {
                    throw new RuntimeException("Expected at least %d of %s when pushing pattern, but only %d available".formatted(new Object[]{l, aEKey, l2}));
                }
                patternInputSink.pushInput(aEKey, l);
                keyCounter.remove(aEKey, l);
            }
        }
    }
}

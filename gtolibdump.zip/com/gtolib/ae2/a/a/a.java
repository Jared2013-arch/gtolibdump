package com.gtolib.ae2.a.a;

import appeng.api.stacks.AEKey;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtolib.ae2.a.a.b;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.util.Iterator;
import org.jetbrains.annotations.NotNull;

public class a
implements Iterable<Object2ObjectMap.Entry<AEKey, b>> {
    private final Object2ObjectOpenHashMap<AEKey, b> a = new O2OOpenCacheHashMap();

    public b a(AEKey aEKey) {
        return (b)this.a.computeIfAbsent((Object)aEKey, object -> new b());
    }

    public int a() {
        return this.a.size();
    }

    public b b(AEKey aEKey) {
        return (b)this.a.get((Object)aEKey);
    }

    @Override
    @NotNull
    public Iterator<Object2ObjectMap.Entry<AEKey, b>> iterator() {
        return this.a.object2ObjectEntrySet().fastIterator();
    }

    public final boolean equals(Object object) {
        if (!(object instanceof a)) {
            return false;
        }
        a a2 = (a)object;
        return this.a.equals(a2.a);
    }

    public int hashCode() {
        return this.a.hashCode();
    }
}

package com.gtolib.ae2.a.a;

import appeng.api.crafting.IPatternDetails;
import appeng.api.stacks.AEKey;
import com.gregtechceu.gtceu.utils.collection.O2LOpenCacheHashMap;
import it.unimi.dsi.fastutil.objects.Object2LongOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectList;

public class b {
    private final ObjectList<IPatternDetails> a = new ObjectArrayList();
    private final Object2LongOpenHashMap<AEKey> b = new O2LOpenCacheHashMap();

    public void a(IPatternDetails iPatternDetails) {
        this.a.add((Object)iPatternDetails);
    }

    public void a(AEKey aEKey, long l) {
        this.b.addTo((Object)aEKey, l);
    }

    public final boolean equals(Object object) {
        if (!(object instanceof b)) {
            return false;
        }
        b b2 = (b)object;
        return ((Object)this.a).equals(b2.a) && this.b.equals(b2.b);
    }

    public int hashCode() {
        int n = ((Object)this.a).hashCode();
        n = 31 * n + this.b.hashCode();
        return n;
    }

    public ObjectList<IPatternDetails> a() {
        return this.a;
    }

    public Object2LongOpenHashMap<AEKey> b() {
        return this.b;
    }
}

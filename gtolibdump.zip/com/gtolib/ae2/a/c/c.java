package com.gtolib.ae2.a.c;

import appeng.api.stacks.AEFluidKey;
import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.AEKey;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;

public final class c {
    public static Component a(List<List<AEKey>> list) {
        MutableComponent mutableComponent = c.a(list.size());
        c.a(mutableComponent, list);
        c.a(mutableComponent, list.size());
        return mutableComponent;
    }

    private static MutableComponent a(int n) {
        return Component.m_237115_("gtocore.ae.appeng.crafting.cycle_error.main").m_130944_(new ChatFormatting[]{ChatFormatting.RED, ChatFormatting.BOLD}).m_7220_(Component.m_237110_("gtocore.ae.appeng.crafting.cycle_error.count", new Object[]{n}).m_130940_(ChatFormatting.YELLOW));
    }

    private static void a(MutableComponent mutableComponent, List<List<AEKey>> list) {
        int n = Math.min(list.size(), 5);
        for (int i = 0; i < n; ++i) {
            List<AEKey> list2 = list.get(i);
            c.a(mutableComponent, list2, i + 1);
        }
        if (list.size() > 5) {
            mutableComponent.m_7220_(Component.m_237110_("gtocore.ae.appeng.crafting.cycle_error.more_cycles", new Object[]{list.size() - 5}).m_130940_(ChatFormatting.GRAY));
        }
    }

    private static void a(MutableComponent mutableComponent, List<AEKey> list, int n) {
        mutableComponent.m_7220_(Component.m_237110_("gtocore.ae.appeng.crafting.cycle_error.cycle_number", new Object[]{n}).m_130940_(ChatFormatting.AQUA));
        for (AEKey aEKey : list) {
            MutableComponent mutableComponent2 = c.a(aEKey);
            mutableComponent.m_7220_(Component.m_237115_("gtocore.ae.appeng.crafting.cycle_error.indent")).m_7220_(mutableComponent2);
        }
        if (!list.isEmpty()) {
            MutableComponent mutableComponent3 = c.a(list.get(0));
            mutableComponent.m_7220_(Component.m_237115_("gtocore.ae.appeng.crafting.cycle_error.indent")).m_7220_(mutableComponent3);
        }
    }

    private static void a(MutableComponent mutableComponent, int n) {
        mutableComponent.m_7220_(Component.m_237115_("gtocore.ae.appeng.crafting.cycle_error.footer").m_130940_(ChatFormatting.RED)).m_7220_(Component.m_237115_("gtocore.ae.appeng.crafting.cycle_error.click_instruction").m_130944_(new ChatFormatting[]{ChatFormatting.GRAY, ChatFormatting.ITALIC}));
    }

    private static MutableComponent a(AEKey aEKey) {
        String string = c.b(aEKey);
        String string2 = c.c(aEKey);
        return Component.m_237115_("gtocore.ae.appeng.crafting.cycle_error.item_prefix").m_130940_(ChatFormatting.GRAY).m_7220_(c.a(string)).m_7220_(Component.m_237115_("gtocore.ae.appeng.crafting.cycle_error.bracket_open").m_130940_(ChatFormatting.GRAY)).m_7220_(c.b(string2)).m_7220_(Component.m_237115_("gtocore.ae.appeng.crafting.cycle_error.bracket_close").m_130940_(ChatFormatting.GRAY));
    }

    private static MutableComponent a(String string) {
        return Component.m_237113_(string).m_130940_(ChatFormatting.YELLOW).m_130948_(Style.f_131099_.m_131142_(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, string)).m_131144_(new HoverEvent(HoverEvent.Action.f_130831_, Component.m_237110_("gtocore.ae.appeng.crafting.cycle_error.click_to_copy", new Object[]{string}).m_130940_(ChatFormatting.GREEN))));
    }

    private static MutableComponent b(String string) {
        return Component.m_237113_(string).m_130940_(ChatFormatting.WHITE).m_130948_(Style.f_131099_.m_131142_(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, string)).m_131144_(new HoverEvent(HoverEvent.Action.f_130831_, Component.m_237110_("gtocore.ae.appeng.crafting.cycle_error.click_to_copy", new Object[]{string}).m_130940_(ChatFormatting.GREEN))));
    }

    private static String b(AEKey aEKey) {
        if (aEKey instanceof AEItemKey) {
            AEItemKey aEItemKey = (AEItemKey)aEKey;
            return BuiltInRegistries.f_257033_.m_7981_(aEItemKey.getItem()).toString();
        }
        if (aEKey instanceof AEFluidKey) {
            AEFluidKey aEFluidKey = (AEFluidKey)aEKey;
            return BuiltInRegistries.f_257020_.m_7981_(aEFluidKey.getFluid()).toString();
        }
        return aEKey.toString();
    }

    private static String c(AEKey aEKey) {
        try {
            if (aEKey instanceof AEItemKey) {
                AEItemKey aEItemKey = (AEItemKey)aEKey;
                return aEItemKey.getItem().m_7626_(aEItemKey.toStack()).getString();
            }
            if (aEKey instanceof AEFluidKey) {
                AEFluidKey aEFluidKey = (AEFluidKey)aEKey;
                return aEFluidKey.getFluid().getFluidType().getDescription().getString();
            }
            return aEKey.getDisplayName().getString();
        }
        catch (Exception exception) {
            return c.b(aEKey);
        }
    }
}

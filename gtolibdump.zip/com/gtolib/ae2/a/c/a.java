package com.gtolib.ae2.a.c;

import appeng.api.crafting.IPatternDetails;
import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import appeng.api.stacks.KeyCounter;
import com.gregtechceu.gtceu.utils.collection.O2LOpenCacheHashMap;
import com.gregtechceu.gtceu.utils.collection.OpenCacheHashSet;
import com.gtolib.ae2.a.a.b;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import it.unimi.dsi.fastutil.objects.Object2LongOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.List;
import java.util.Set;

public final class a {
    public static boolean a(IPatternDetails iPatternDetails, com.gtolib.ae2.a.b.a a2) {
        Set<AEKey> set = a.a(iPatternDetails);
        boolean bl = false;
        for (IPatternDetails.IInput iInput : iPatternDetails.getInputs()) {
            AEKey aEKey = iInput.getPossibleInputs()[0].what();
            if (!set.contains(aEKey)) continue;
            bl = true;
            a2.h.a.add(List.of((Object)aEKey, (Object)aEKey));
        }
        return !bl && iPatternDetails.getPrimaryOutput().amount() > 0L;
    }

    private static Set<AEKey> a(IPatternDetails iPatternDetails) {
        GenericStack[] genericStackArray = iPatternDetails.getOutputs();
        OpenCacheHashSet openCacheHashSet = new OpenCacheHashSet(genericStackArray.length);
        for (GenericStack genericStack : genericStackArray) {
            openCacheHashSet.add(genericStack.what());
        }
        return openCacheHashSet;
    }

    public static long a(IPatternDetails iPatternDetails, AEKey aEKey) {
        for (GenericStack genericStack : iPatternDetails.getOutputs()) {
            if (!genericStack.what().equals(aEKey)) continue;
            return genericStack.amount();
        }
        return 0L;
    }

    public static long a(long l, long l2) {
        return (l + l2 - 1L) / l2;
    }

    public static KeyCounter a(KeyCounter keyCounter) {
        keyCounter.removeZeros();
        KeyCounter keyCounter2 = new KeyCounter();
        keyCounter2.addAll(keyCounter);
        return keyCounter2;
    }

    public static Object2LongOpenHashMap<IPatternDetails> a(Object2LongOpenHashMap<IPatternDetails> object2LongOpenHashMap) {
        O2LOpenCacheHashMap o2LOpenCacheHashMap = new O2LOpenCacheHashMap(object2LongOpenHashMap);
        ObjectIterator objectIterator = ((Object2LongOpenHashMap)o2LOpenCacheHashMap).object2LongEntrySet().fastIterator();
        while (objectIterator.hasNext()) {
            if (((Object2LongMap.Entry)objectIterator.next()).getLongValue() >= 1L) continue;
            objectIterator.remove();
        }
        return o2LOpenCacheHashMap;
    }

    public static boolean a(com.gtolib.ae2.a.a.a a2) {
        if (a2 == null) {
            return false;
        }
        for (Object2ObjectMap.Entry<AEKey, b> entry : a2) {
            b b2 = (b)entry.getValue();
            if (b2 == null || b2.a().size() <= 1) continue;
            return true;
        }
        return false;
    }
}

package com.gtolib.ae2.a.c;

import appeng.api.stacks.AEKey;
import com.gregtechceu.gtceu.utils.collection.OpenCacheHashSet;
import com.gtolib.ae2.a.a.a;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.List;
import java.util.Set;

public final class b {
    public static List<List<AEKey>> a(a a2) {
        OpenCacheHashSet openCacheHashSet = new OpenCacheHashSet();
        OpenCacheHashSet openCacheHashSet2 = new OpenCacheHashSet();
        ObjectArrayList objectArrayList = new ObjectArrayList();
        for (Object2ObjectMap.Entry<AEKey, com.gtolib.ae2.a.a.b> entry : a2) {
            AEKey aEKey = (AEKey)entry.getKey();
            if (!openCacheHashSet.contains(aEKey)) {
                ObjectArrayList objectArrayList2 = new ObjectArrayList();
                b.a(aEKey, (com.gtolib.ae2.a.a.b)entry.getValue(), a2, openCacheHashSet, openCacheHashSet2, objectArrayList2, objectArrayList, 0);
                if (objectArrayList.size() >= 10) break;
            }
            if (objectArrayList.size() % 5 != 0) continue;
            b.a();
        }
        return objectArrayList;
    }

    private static boolean a(AEKey aEKey, com.gtolib.ae2.a.a.b b2, a a2, Set<AEKey> set, Set<AEKey> set2, List<AEKey> list, List<List<AEKey>> list2, int n) {
        if (n > 50) {
            return false;
        }
        set.add(aEKey);
        set2.add(aEKey);
        list.add(aEKey);
        if (b2 != null) {
            ObjectIterator objectIterator = b2.b().keySet().iterator();
            while (objectIterator.hasNext()) {
                AEKey aEKey2 = (AEKey)objectIterator.next();
                if (!set.contains(aEKey2)) {
                    if (!b.a(aEKey2, a2.b(aEKey2), a2, set, set2, list, list2, n + 1) || list2.size() < 10) continue;
                    return true;
                }
                if (!set2.contains(aEKey2)) continue;
                b.a(aEKey2, list, list2);
            }
        }
        set2.remove(aEKey);
        list.remove(list.size() - 1);
        return false;
    }

    private static void a(AEKey aEKey, List<AEKey> list, List<List<AEKey>> list2) {
        List<AEKey> list3 = b.a(aEKey, list);
        if (list3.size() > 1 && !b.a(list3, list2)) {
            list2.add(list3);
        }
    }

    private static List<AEKey> a(AEKey aEKey, List<AEKey> list) {
        ObjectArrayList objectArrayList = new ObjectArrayList();
        int n = b.b(aEKey, list);
        if (n >= 0) {
            int n2 = list.size();
            for (int i = n; i < n2; ++i) {
                objectArrayList.add(list.get(i));
            }
        }
        return objectArrayList;
    }

    private static int b(AEKey aEKey, List<AEKey> list) {
        for (int i = list.size() - 1; i >= 0; --i) {
            if (!list.get(i).equals(aEKey)) continue;
            return i;
        }
        return -1;
    }

    private static boolean a(List<AEKey> list, List<List<AEKey>> list2) {
        OpenCacheHashSet openCacheHashSet = new OpenCacheHashSet(list);
        for (List<AEKey> list3 : list2) {
            OpenCacheHashSet openCacheHashSet2;
            if (list3.size() != list.size() || !(openCacheHashSet2 = new OpenCacheHashSet(list3)).equals(openCacheHashSet)) continue;
            return true;
        }
        return false;
    }

    private static void a() {
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
    }
}

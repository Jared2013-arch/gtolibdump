package com.gtolib.ae2.a.c;

import appeng.api.stacks.AEKey;
import com.gregtechceu.gtceu.utils.collection.O2IOpenCacheHashMap;
import com.gtolib.ae2.a.a.a;
import com.gtolib.ae2.a.a.b;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.LinkedList;
import java.util.Queue;

public final class d {
    public static ObjectArrayList<AEKey> a(a a2) {
        Object2IntOpenHashMap<AEKey> object2IntOpenHashMap = d.b(a2);
        Queue<AEKey> queue = d.a(object2IntOpenHashMap);
        ObjectArrayList objectArrayList = new ObjectArrayList();
        int n = 0;
        while (!queue.isEmpty()) {
            if (++n % 10 == 0) {
                d.a();
            }
            AEKey aEKey = queue.poll();
            objectArrayList.add(aEKey);
            d.a(aEKey, a2, object2IntOpenHashMap, queue);
        }
        return objectArrayList.size() == a2.a() ? objectArrayList : null;
    }

    private static Object2IntOpenHashMap<AEKey> b(a a2) {
        O2IOpenCacheHashMap o2IOpenCacheHashMap = new O2IOpenCacheHashMap();
        for (Object2ObjectMap.Entry<AEKey, b> entry : a2) {
            b b2 = (b)entry.getValue();
            o2IOpenCacheHashMap.addTo((AEKey)entry.getKey(), b2 == null ? 0 : b2.b().size());
        }
        return o2IOpenCacheHashMap;
    }

    private static Queue<AEKey> a(Object2IntOpenHashMap<AEKey> object2IntOpenHashMap) {
        LinkedList<AEKey> linkedList = new LinkedList<AEKey>();
        ObjectIterator objectIterator = object2IntOpenHashMap.object2IntEntrySet().fastIterator();
        while (objectIterator.hasNext()) {
            Object2IntMap.Entry entry = (Object2IntMap.Entry)objectIterator.next();
            if (entry.getIntValue() != 0) continue;
            linkedList.offer((AEKey)entry.getKey());
        }
        return linkedList;
    }

    private static void a(AEKey aEKey, a a2, Object2IntOpenHashMap<AEKey> object2IntOpenHashMap, Queue<AEKey> queue) {
        for (Object2ObjectMap.Entry<AEKey, b> entry : a2) {
            AEKey aEKey2;
            int n;
            b b2 = (b)entry.getValue();
            if (b2 == null || !b2.b().containsKey((Object)aEKey) || (n = object2IntOpenHashMap.addTo((Object)(aEKey2 = (AEKey)entry.getKey()), -1)) != 1) continue;
            queue.offer(aEKey2);
        }
    }

    private static void a() {
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
    }
}

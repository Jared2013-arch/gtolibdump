package com.gtolib.ae2.a.b.c;

import com.gtolib.ae2.a.b.a;
import com.gtolib.ae2.a.b.a.a.b;

public class e
implements b {
    @Override
    public void a(a a2) {
        if (!a2.h.a.isEmpty()) {
            a2.h.a();
        }
    }
}

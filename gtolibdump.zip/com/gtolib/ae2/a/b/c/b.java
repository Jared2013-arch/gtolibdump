package com.gtolib.ae2.a.b.c;

import appeng.api.networking.crafting.CalculationStrategy;
import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import com.gtolib.ae2.a.b.a.a;
import com.gtolib.ae2.a.b.b.c;
import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;

public class b
implements com.gtolib.ae2.a.b.a.a.b {
    @Override
    public void a(com.gtolib.ae2.a.b.a a2) {
        if (a2.b.equals(CalculationStrategy.REPORT_MISSING_ITEMS)) {
            a2.a(b.a((com.gtolib.ae2.a.b.a)a2, (long)a2.k.amount()).b);
        } else if (a2.b.equals(CalculationStrategy.CRAFT_LESS)) {
            long l = 0L;
            long l2 = a2.k.amount();
            a a3 = b.a(a2, l2);
            if (a3.a) {
                a2.a(a3.b);
                return;
            }
            while (l <= l2) {
                long l3 = l + (l2 - l + 1L) / 2L;
                a a4 = b.a(a2, l3);
                if (a4.a) {
                    a3 = a4;
                    l = l3 + 1L;
                    continue;
                }
                l2 = l3 - 1L;
            }
            a2.a(a3.b);
        }
    }

    private static a a(com.gtolib.ae2.a.b.a a2, long l) {
        boolean bl;
        long l2;
        com.gtolib.ae2.a.b.a a3 = a2.a();
        a3.k = new GenericStack(a3.k.what(), l);
        a3.p.add(a3.k.what(), l);
        com.gtolib.ae2.a.b.a.a a4 = a.a.a(new com.gtolib.ae2.a.b.b.b(), new c(), new com.gtolib.ae2.a.b.b.a());
        for (AEKey aEKey : a2.g) {
            l2 = a3.p.get(aEKey);
            a4.a(a3, aEKey, l2);
        }
        for (AEKey aEKey : a2.g) {
            l2 = a3.p.get(aEKey);
            a3.p.remove(aEKey, l2);
            a3.o.add(aEKey, l2);
        }
        a3.o.removeZeros();
        if (a3.o.isEmpty() && l > 0L) {
            a3.l = false;
            bl = true;
        } else {
            a3.l = true;
            bl = false;
        }
        return new a(bl, a3);
    }

    record a(boolean a, com.gtolib.ae2.a.b.a b) {
        public final String toString() {
            return ObjectMethods.bootstrap("toString", new MethodHandle[]{a.class, "success;temporaryContext", "a", "b"}, this);
        }

        public final int hashCode() {
            return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{a.class, "success;temporaryContext", "a", "b"}, this);
        }

        public final boolean equals(Object object) {
            return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{a.class, "success;temporaryContext", "a", "b"}, this, object);
        }
    }
}

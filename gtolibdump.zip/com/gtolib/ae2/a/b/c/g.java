package com.gtolib.ae2.a.b.c;

import com.gtocore.config.GTOConfig;
import com.gtolib.GTOCore;
import com.gtolib.ae2.a.b.a;
import com.gtolib.ae2.a.b.a.a.b;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.time.Duration;
import java.time.Instant;

public class g
implements b {
    private static final String a = "[g..t.o ae计算]";
    private static final String b = "[ae计算过长]";

    @Override
    public void a(a a2) {
        if (GTOConfig.INSTANCE.aeLog && a2.i != null) {
            Instant instant = Instant.now();
            Duration duration = Duration.between(a2.i, instant);
            g.a(duration, "G.T..O 优化ae算法, 请求者 {} , 计算时间: {} μs , 字节数: {} bytes", a2.a.getActionSource(), duration.toNanos() / 1000L, a2.j);
            g.a(duration, "模拟 : {}", a2.l);
            g.a(duration, "目标 : {}", a2.k);
            long l = 0L;
            ObjectIterator objectIterator = a2.q.object2LongEntrySet().fastIterator();
            while (objectIterator.hasNext()) {
                l += ((Object2LongMap.Entry)objectIterator.next()).getLongValue();
            }
            g.a(duration, "步数 : {}", l);
        }
    }

    private static void a(Duration duration, String string, Object ... objectArray) {
        if (duration.toMillis() <= 50L) {
            if (GTOConfig.INSTANCE.aeLog) {
                String string2 = a + string;
                GTOCore.LOGGER.info(string2, objectArray);
            }
        } else {
            String string3 = b + string;
            GTOCore.LOGGER.error(string3, objectArray);
        }
    }
}

package com.gtolib$ae2.a.b.c;

import com.gtolib$ae2.a.b$a;
import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;

record b$a(boolean a, a b) {
    public final String toString() {
        return ObjectMethods.bootstrap("toString", new MethodHandle[]{b$a.class, "success;temporaryContext", "a", "b"}, this);
    }

    public final int hashCode() {
        return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{b$a.class, "success;temporaryContext", "a", "b"}, this);
    }

    public final boolean equals(Object object) {
        return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{b$a.class, "success;temporaryContext", "a", "b"}, this, object);
    }
}

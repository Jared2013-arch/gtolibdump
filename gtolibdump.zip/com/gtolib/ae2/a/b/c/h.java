package com.gtolib.ae2.a.b.c;

import com.gtolib.ae2.a.b.a;
import com.gtolib.ae2.a.b.a.a.b;
import java.time.Instant;

public class h
implements b {
    @Override
    public void a(a a2) {
        a2.i = Instant.now();
    }
}

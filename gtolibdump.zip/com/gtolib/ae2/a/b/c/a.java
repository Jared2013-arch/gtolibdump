package com.gtolib.ae2.a.b.c;

import appeng.api.crafting.IPatternDetails;
import appeng.api.stacks.KeyCounter;
import appeng.crafting.CraftingPlan;
import com.gtolib.ae2.a.b.a.a.b;
import it.unimi.dsi.fastutil.objects.Object2LongOpenHashMap;

public class a
implements b {
    @Override
    public void a(com.gtolib.ae2.a.b.a a2) {
        KeyCounter keyCounter = com.gtolib.ae2.a.c.a.a(a2.m);
        KeyCounter keyCounter2 = com.gtolib.ae2.a.c.a.a(a2.n);
        KeyCounter keyCounter3 = com.gtolib.ae2.a.c.a.a(a2.o);
        Object2LongOpenHashMap<IPatternDetails> object2LongOpenHashMap = com.gtolib.ae2.a.c.a.a(a2.q);
        a2.r = new CraftingPlan(a2.k, a2.j, a2.l, false, keyCounter, keyCounter2, keyCounter3, object2LongOpenHashMap);
    }
}

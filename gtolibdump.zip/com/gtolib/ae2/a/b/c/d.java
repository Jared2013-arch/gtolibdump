package com.gtolib.ae2.a.b.c;

import appeng.api.crafting.IPatternDetails;
import appeng.api.stacks.AEKey;
import appeng.core.AELog;
import com.gregtechceu.gtceu.utils.collection.OpenCacheHashSet;
import com.gtolib.ae2.a.a.b;
import com.gtolib.ae2.a.b.a;
import java.util.LinkedList;

public class d
implements com.gtolib.ae2.a.b.a.a.b {
    @Override
    public void a(a a2) {
        a2.f = d.b(a2);
    }

    private static com.gtolib.ae2.a.a.a b(a a2) {
        com.gtolib.ae2.a.a.a a3 = new com.gtolib.ae2.a.a.a();
        OpenCacheHashSet openCacheHashSet = new OpenCacheHashSet();
        LinkedList<AEKey> linkedList = new LinkedList<AEKey>();
        linkedList.offer(a2.k.what());
        openCacheHashSet.add(a2.k.what());
        while (!linkedList.isEmpty()) {
            AEKey aEKey = (AEKey)linkedList.poll();
            b b2 = a3.a(aEKey);
            if (a2.b().isEmpty()) {
                AELog.craftingDebug("(G.T.O Optimized)Grid invalid, skipping pattern search for: " + String.valueOf(aEKey), new Object[0]);
                continue;
            }
            if (!a2.c().isPresent()) continue;
            for (IPatternDetails iPatternDetails : a2.c().get().getCraftingFor(aEKey)) {
                if (!com.gtolib.ae2.a.c.a.a(iPatternDetails, a2)) continue;
                b2.a(iPatternDetails);
                for (IPatternDetails.IInput iInput : iPatternDetails.getInputs()) {
                    AEKey aEKey2 = a2.c.a(iInput);
                    if (!openCacheHashSet.contains(aEKey2)) {
                        openCacheHashSet.add(aEKey2);
                        linkedList.offer(aEKey2);
                    }
                    b2.a(aEKey2, iInput.getMultiplier());
                }
            }
        }
        return a3;
    }
}

package com.gtolib.ae2.a.b.c;

import appeng.api.stacks.AEKey;
import com.gtolib.ae2.a.b.a;
import com.gtolib.ae2.a.b.a.a.b;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import java.util.Iterator;

public class c
implements b {
    @Override
    public void a(a a2) {
        Iterator iterator = a2.m.iterator();
        while (iterator.hasNext()) {
            Object2LongMap.Entry entry = (Object2LongMap.Entry)iterator.next();
            a2.j += entry.getLongValue() / (long)((AEKey)entry.getKey()).getAmountPerByte();
        }
        iterator = a2.q.object2LongEntrySet().fastIterator();
        while (iterator.hasNext()) {
            a2.j += ((Object2LongMap.Entry)iterator.next()).getLongValue();
        }
    }
}

package com.gtolib.ae2.a.b.c;

import appeng.api.stacks.AEKey;
import com.gtolib.ae2.a.b.a;
import com.gtolib.ae2.a.b.b;
import com.gtolib.ae2.a.c.d;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Collections;
import java.util.List;

public class f
implements com.gtolib.ae2.a.b.a.a.b {
    @Override
    public void a(a a2) {
        block6: {
            try {
                ObjectArrayList<AEKey> objectArrayList = d.a(a2.f);
                if (objectArrayList != null) {
                    Collections.reverse(objectArrayList);
                    a2.g = objectArrayList;
                }
                if (objectArrayList != null) break block6;
                a2.l = true;
                a2.e = true;
                if (a2.d().isEmpty()) {
                    a2.h = new b(a2, Collections.emptyList());
                    break block6;
                }
                List<Object> list = Collections.emptyList();
                try {
                    list = com.gtolib.ae2.a.c.b.a(a2.f);
                }
                catch (InterruptedException interruptedException) {
                    // empty catch block
                }
                a2.h.a.addAll(list);
            }
            catch (InterruptedException interruptedException) {
                // empty catch block
            }
        }
    }
}

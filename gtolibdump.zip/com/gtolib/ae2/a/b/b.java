package com.gtolib.ae2.a.b;

import appeng.api.stacks.AEKey;
import com.gtolib.ae2.a.b.a;
import com.gtolib.ae2.a.c.c;
import java.util.List;
import net.minecraft.network.chat.Component;

public class b {
    private final a b;
    public final List<List<AEKey>> a;

    public b(a a2, List<List<AEKey>> list) {
        this.a = list;
        this.b = a2;
    }

    public void a() {
        Component component = c.a(this.a);
        this.b.d().ifPresent(player -> player.m_213846_(component));
    }
}

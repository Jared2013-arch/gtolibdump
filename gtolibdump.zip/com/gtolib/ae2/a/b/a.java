package com.gtolib.ae2.a.b;

import appeng.api.crafting.IPatternDetails;
import appeng.api.networking.IGrid;
import appeng.api.networking.crafting.CalculationStrategy;
import appeng.api.networking.crafting.ICraftingPlan;
import appeng.api.networking.crafting.ICraftingService;
import appeng.api.networking.crafting.ICraftingSimulationRequester;
import appeng.api.networking.storage.IStorageService;
import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import appeng.api.stacks.KeyCounter;
import com.gregtechceu.gtceu.utils.collection.O2LOpenCacheHashMap;
import com.gtolib.ae2.a.b.b;
import com.gtolib.ae2.a.b.c;
import com.gtolib.api.ae2.IExpandedStorageService;
import it.unimi.dsi.fastutil.objects.Object2LongOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.time.Instant;
import java.util.Optional;
import net.minecraft.world.entity.player.Player;

public final class a {
    public final ICraftingSimulationRequester a;
    public final CalculationStrategy b;
    private final IGrid s;
    public final c c;
    public final KeyCounter d = new KeyCounter();
    public boolean e = false;
    public com.gtolib.ae2.a.a.a f;
    public ObjectArrayList<AEKey> g;
    public b h = new b(this, new ObjectArrayList());
    public Instant i;
    public long j = 0L;
    public GenericStack k;
    public boolean l;
    public KeyCounter m = new KeyCounter();
    public KeyCounter n = new KeyCounter();
    public KeyCounter o = new KeyCounter();
    public KeyCounter p = new KeyCounter();
    public Object2LongOpenHashMap<IPatternDetails> q = new O2LOpenCacheHashMap();
    public ICraftingPlan r;

    public static a a(ICraftingSimulationRequester iCraftingSimulationRequester, CalculationStrategy calculationStrategy, IGrid iGrid, GenericStack genericStack, c c2, boolean bl) {
        a a2 = new a(iCraftingSimulationRequester, calculationStrategy, iGrid, genericStack, c2, bl);
        c2.a(a2);
        return a2;
    }

    public a a() {
        a a2 = new a(this.a, this.b, this.s, this.k, this.c, this.l);
        a2.f = this.f;
        a2.g = this.g;
        a2.h = this.h;
        a2.e = this.e;
        a2.i = this.i;
        return a2;
    }

    public void a(a a2) {
        this.j = a2.j;
        this.k = a2.k;
        this.l = a2.l;
        this.m = a2.m;
        this.n = a2.n;
        this.o = a2.o;
        this.p = a2.p;
        this.q = a2.q;
        this.r = a2.r;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private a(ICraftingSimulationRequester iCraftingSimulationRequester, CalculationStrategy calculationStrategy, IGrid iGrid, GenericStack genericStack, c c2, boolean bl) {
        this.a = iCraftingSimulationRequester;
        this.b = calculationStrategy;
        this.s = iGrid;
        this.k = genericStack;
        this.c = c2;
        this.l = bl;
        IStorageService iStorageService = iGrid.getStorageService();
        Object object = IExpandedStorageService.of(iStorageService).gtolib$getLock();
        synchronized (object) {
            this.d.addAll(iStorageService.getCachedInventory());
        }
    }

    public Optional<IGrid> b() {
        if (this.a.getGridNode() != null && this.a.getGridNode().isActive()) {
            return Optional.of(this.a.getGridNode().getGrid());
        }
        return Optional.empty();
    }

    public Optional<ICraftingService> c() {
        if (this.b().isPresent() && this.b().get().getCraftingService() != null) {
            return Optional.of(this.b().get().getCraftingService());
        }
        return Optional.empty();
    }

    public long a(AEKey aEKey) {
        return this.d.get(aEKey) - this.m.get(aEKey);
    }

    public Optional<Player> d() {
        if (this.a.getActionSource() != null) {
            return this.a.getActionSource().player();
        }
        return Optional.empty();
    }
}

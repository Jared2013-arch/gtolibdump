package com.gtolib.ae2.a.b.a;

import appeng.api.stacks.AEKey;

public abstract class a {
    protected a a;

    private a a(a a2) {
        this.a = a2;
        return this;
    }

    public void a(com.gtolib.ae2.a.b.a a2, AEKey aEKey, long l) {
        if (this.a(a2, aEKey)) {
            this.b(a2, aEKey, l);
        } else if (this.a != null) {
            this.a.a(a2, aEKey, l);
        } else if (l > 0L) {
            a2.o.add(aEKey, l);
            a2.p.remove(aEKey, l);
        }
    }

    protected abstract boolean a(com.gtolib.ae2.a.b.a var1, AEKey var2);

    protected abstract void b(com.gtolib.ae2.a.b.a var1, AEKey var2, long var3);

    public static final class a {
        public static a a(a ... aArray) {
            for (int i = 0; i < aArray.length - 1; ++i) {
                aArray[i].a(aArray[i + 1]);
            }
            return aArray[0];
        }
    }
}

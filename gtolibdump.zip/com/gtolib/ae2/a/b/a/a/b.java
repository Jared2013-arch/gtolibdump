package com.gtolib.ae2.a.b.a.a;

import com.gtolib.ae2.a.b.a;

public interface b {
    public void a(a var1);
}

package com.gtolib.ae2.a.b.a.a;

import com.gtolib.ae2.a.b.a.a.b;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;

public class a {
    private final List<b> a = new ObjectArrayList();
    private final List<b> b = new ObjectArrayList();

    public final a a(b b2) {
        this.a.add(b2);
        return this;
    }

    public final a b(b b2) {
        this.b.add(b2);
        return this.a(b2);
    }

    public final com.gtolib.ae2.a.b.a a(com.gtolib.ae2.a.b.a a2) {
        for (b b2 : this.a) {
            if (a2.e && !this.b.contains(b2)) continue;
            b2.a(a2);
        }
        return a2;
    }
}

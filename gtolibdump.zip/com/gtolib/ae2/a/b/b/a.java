package com.gtolib.ae2.a.b.b;

import appeng.api.crafting.IPatternDetails;
import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import it.unimi.dsi.fastutil.objects.ObjectList;

public class a
extends com.gtolib.ae2.a.b.a.a {
    @Override
    protected boolean a(com.gtolib.ae2.a.b.a a2, AEKey aEKey) {
        return a2.c().map(iCraftingService -> iCraftingService.isCraftable(aEKey)).orElse(false);
    }

    @Override
    protected void b(com.gtolib.ae2.a.b.a a2, AEKey aEKey, long l) {
        ObjectList<IPatternDetails> objectList = a2.f.b(aEKey).a();
        IPatternDetails iPatternDetails = a2.c.a(objectList);
        if (iPatternDetails == null) {
            if (this.a != null) {
                this.a.a(a2, aEKey, l);
            } else {
                a2.o.add(aEKey, l);
                a2.p.remove(aEKey, l);
            }
        } else {
            long l2 = com.gtolib.ae2.a.c.a.a(iPatternDetails, aEKey);
            long l3 = com.gtolib.ae2.a.c.a.a(l, l2);
            a2.q.addTo((Object)iPatternDetails, l3);
            block0: for (IPatternDetails.IInput iInput : iPatternDetails.getInputs()) {
                AEKey aEKey2 = a2.c.a(iInput);
                for (GenericStack genericStack : iInput.getPossibleInputs()) {
                    if (!genericStack.what().equals(aEKey2)) continue;
                    long l4 = genericStack.amount() * iInput.getMultiplier() * l3;
                    a2.p.add(aEKey2, l4);
                    continue block0;
                }
            }
            a2.p.remove(aEKey, l);
            if (this.a != null) {
                this.a.a(a2, aEKey, 0L);
            }
        }
    }
}

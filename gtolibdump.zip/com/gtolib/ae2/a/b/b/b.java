package com.gtolib.ae2.a.b.b;

import appeng.api.stacks.AEKey;
import com.gtolib.ae2.a.b.a;

public class b
extends com.gtolib.ae2.a.b.a.a {
    @Override
    protected boolean a(a a2, AEKey aEKey) {
        return a2.c().map(iCraftingService -> iCraftingService.canEmitFor(aEKey)).orElse(false);
    }

    @Override
    protected void b(a a2, AEKey aEKey, long l) {
        a2.n.add(aEKey, l);
        a2.p.remove(aEKey, l);
    }
}

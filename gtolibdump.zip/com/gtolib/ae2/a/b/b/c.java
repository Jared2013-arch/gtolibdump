package com.gtolib.ae2.a.b.b;

import appeng.api.stacks.AEKey;
import com.gtolib.ae2.a.b.a;

public class c
extends com.gtolib.ae2.a.b.a.a {
    @Override
    protected boolean a(a a2, AEKey aEKey) {
        return !a2.k.what().equals(aEKey) && a2.a(aEKey) > 0L;
    }

    @Override
    protected void b(a a2, AEKey aEKey, long l) {
        long l2 = a2.a(aEKey);
        long l3 = Math.min(l2, l);
        a2.m.add(aEKey, l3);
        a2.p.remove(aEKey, l3);
        if ((l -= l3) > 0L) {
            this.a.a(a2, aEKey, l);
        }
    }
}

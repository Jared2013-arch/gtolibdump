package com.gtolib.ae2.a.b;

import appeng.api.crafting.IPatternDetails;
import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import com.gtolib.ae2.a.b.a;
import java.util.Collection;

public class c {
    private a a;

    public c(a a2) {
        this.a = a2;
    }

    public c a(a a2) {
        this.a = a2;
        return this;
    }

    public AEKey a(IPatternDetails.IInput iInput) {
        long l = 0L;
        AEKey aEKey = iInput.getPossibleInputs()[0].what();
        for (GenericStack genericStack : iInput.getPossibleInputs()) {
            long l2 = this.a.a(genericStack.what());
            if (l2 <= l) continue;
            l = l2;
            aEKey = genericStack.what();
        }
        return aEKey;
    }

    public IPatternDetails a(Collection<IPatternDetails> collection) {
        for (IPatternDetails iPatternDetails : collection) {
            if (!com.gtolib.ae2.a.c.a.a(iPatternDetails, this.a)) continue;
            return iPatternDetails;
        }
        return null;
    }
}

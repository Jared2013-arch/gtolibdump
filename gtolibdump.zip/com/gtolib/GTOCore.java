package com.gtolib;

import com.gtolib.e.a;
import com.gtolib.syncdata.b;
import dev.architectury.networking.simple.SimpleNetworkManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod(value="gtolib")
public final class GTOCore {
    public static final String MOD_ID = "gtocore";
    public static final String NAME = "GTO Core";
    public static final Logger LOGGER = LoggerFactory.getLogger("GTO Core");
    public static final SimpleNetworkManager NETWORK_MANAGER = SimpleNetworkManager.create("gtocore");
    public static int difficulty = 2;

    public GTOCore() {
        a.b();
        b.a();
    }

    public static ResourceLocation id(String string) {
        return new ResourceLocation(MOD_ID, string, null);
    }

    public static boolean isSimple() {
        return difficulty == 1;
    }

    public static boolean isNormal() {
        return difficulty == 2;
    }

    public static boolean isExpert() {
        return difficulty == 3;
    }
}

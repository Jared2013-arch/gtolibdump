package com.gtolib.e;

import appeng.core.settings.TickRates;
import com.gregtechceu.gtceu.api.item.ComponentItem;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gtocore.config.GTOConfig;
import com.gtocore.integration.jade.provider.AEGridProvider;
import com.gtolib.GTOCore;
import com.gtolib.api.annotation.dynamic.DynamicInitialData;
import com.gtolib.api.data.GTODimensions;
import com.gtolib.api.player.IEnhancedPlayer;
import com.gtolib.api.player.PlayerData;
import com.gtolib.api.recipe.AsyncRecipeOutputTask;
import com.gtolib.api.recipe.lookup.RecipeLookup;
import com.gtolib.b;
import com.gtolib.b.c;
import com.gtolib.b.d;
import com.gtolib.utils.PlayerUtils;
import com.gtolib.utils.ServerUtils;
import com.gtolib.utils.SrmManager;
import com.hepdd.gtmthings.api.misc.WirelessEnergyContainer;
import com.hepdd.gtmthings.data.CustomItems;
import com.hepdd.gtmthings.data.WirelessEnergySavaedData;
import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.context.ParsedCommandNode;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.IntSupplier;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.storage.PrimaryLevelData;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.CommandEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.LevelEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import org.apache.commons.lang3.tuple.Pair;

public final class a {
    public static final Object a = new Object();
    private static int b = 2;

    public static void a() {
        TickRates.Interface.setMin(20);
        TickRates.ImportBus.setMin(20);
        TickRates.ImportBus.setMax(80);
        TickRates.ExportBus.setMin(20);
        TickRates.ExportBus.setMax(80);
        TickRates.AnnihilationPlane.setMin(20);
        TickRates.METunnel.setMin(10);
        TickRates.METunnel.setMax(40);
        TickRates.IOPort.setMin(5);
        TickRates.IOPort.setMax(40);
        TickRates.StorageBus.setMin(20);
        TickRates.LightTunnel.setMin(20);
    }

    public static void b() {
        IEventBus iEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        iEventBus.addListener(a::a);
        MinecraftForge.EVENT_BUS.register(a.class);
        MinecraftForge.EVENT_BUS.addListener(EventPriority.HIGH, a::a);
        MinecraftForge.EVENT_BUS.addListener(a::a);
        MinecraftForge.EVENT_BUS.addListener(a::a);
        MinecraftForge.EVENT_BUS.addListener(a::a);
        MinecraftForge.EVENT_BUS.addListener(a::a);
        MinecraftForge.EVENT_BUS.addListener(a::a);
        MinecraftForge.EVENT_BUS.addListener(a::a);
        MinecraftForge.EVENT_BUS.addListener(a::a);
        com.gtolib.e.a.c();
    }

    public static void a(FMLCommonSetupEvent fMLCommonSetupEvent) {
        ((ComponentItem)CustomItems.ADVANCED_TERMINAL.get()).getComponents().clear();
        ((ComponentItem)CustomItems.ADVANCED_TERMINAL.get()).getComponents().add(new com.gtolib.f.b());
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void a(TickEvent.ServerTickEvent serverTickEvent) {
        if (serverTickEvent.phase == TickEvent.Phase.START) {
            Object object = a;
            synchronized (object) {
                MetaMachine.OBSERVE = false;
                AEGridProvider.OBSERVE = false;
            }
        }
    }

    private static void a(LevelEvent.Load load) {
        LevelAccessor levelAccessor = load.getLevel();
        if (levelAccessor instanceof ServerLevel) {
            int n;
            ServerLevel serverLevel = (ServerLevel)levelAccessor;
            if ((levelAccessor = serverLevel.m_7654_().m_129880_(Level.f_46428_)) == null) {
                return;
            }
            b = GTOCore.difficulty;
            WirelessEnergyContainer.server = ((ServerLevel)levelAccessor).m_7654_();
            RecipeLookup.initLookup();
            com.gtolib.b.a.a = (com.gtolib.b.a)((ServerLevel)levelAccessor).m_8895_().m_164861_(com.gtolib.b.a::new, com.gtolib.b.a::new, "storage_cell_data");
            WirelessEnergySavaedData.INSTANCE = (WirelessEnergySavaedData)((Object)((ServerLevel)levelAccessor).m_8895_().m_164861_(c::new, c::new, "wireless_energy_data"));
            com.gtolib.b.b.a = (com.gtolib.b.b)((ServerLevel)levelAccessor).m_8895_().m_164861_(com.gtolib.b.b::new, com.gtolib.b.b::new, "common_data");
            d.a = (d)((ServerLevel)levelAccessor).m_8895_().m_164861_(d::new, d::new, "wireless_mana_data");
            if (GTOConfig.INSTANCE.selfRestraint && !ServerUtils.getPersistentData().m_128471_("srm")) {
                ServerUtils.getPersistentData().m_128379_("srm", true);
                com.gtolib.b.b.a.m_77762_();
            }
            if (GTOConfig.INSTANCE.dev && !ServerUtils.getPersistentData().m_128471_("dev")) {
                ServerUtils.getPersistentData().m_128379_("dev", true);
                com.gtolib.b.b.a.m_77762_();
            }
            if ((n = ServerUtils.getPersistentData().m_128451_("difficulty")) == 0) {
                n = b;
                ServerUtils.getPersistentData().m_128405_("difficulty", n);
                com.gtolib.b.b.a.m_77762_();
            } else if (n != b) {
                GTOCore.difficulty = n;
                GTOCore.LOGGER.error("Current difficulty: {} | World difficulty: {}", (Object)b, (Object)n);
            }
            Object object = ((ServerLevel)levelAccessor).m_6106_();
            if (object instanceof PrimaryLevelData) {
                PrimaryLevelData primaryLevelData = (PrimaryLevelData)object;
                object = (b)((Object)primaryLevelData.m_5926_());
                object.gto$setGTODifficulty(n);
                object.gto$setDevMode(ServerUtils.getPersistentData().m_128471_("dev"));
                object.gto$setSrm(ServerUtils.getPersistentData().m_128471_("srm"));
            }
        }
    }

    private static void a(LevelEvent.Unload unload) {
        ServerLevel serverLevel;
        LevelAccessor levelAccessor = unload.getLevel();
        if (levelAccessor instanceof ServerLevel && (serverLevel = (ServerLevel)levelAccessor).m_46472_().m_135782_().equals(GTODimensions.OVERWORLD)) {
            GTOCore.difficulty = b;
        }
    }

    private static void a(ServerStoppingEvent serverStoppingEvent) {
        AsyncRecipeOutputTask.releaseExecutorService();
        GTOCore.difficulty = b;
    }

    private static void a(PlayerEvent.Clone clone) {
        PlayerData playerData = IEnhancedPlayer.of(clone.getOriginal()).getPlayerData();
        PlayerData playerData2 = IEnhancedPlayer.of(clone.getEntity()).getPlayerData();
        playerData2.organItemStacks.addAll(playerData.organItemStacks);
        playerData2.organTierCache.putAll(playerData.organTierCache);
        PlayerUtils.refreshPlayerFlyStatement(clone.getEntity());
    }

    private static void a(PlayerEvent.PlayerLoggedInEvent playerLoggedInEvent) {
        PlayerUtils.refreshPlayerFlyStatement(playerLoggedInEvent.getEntity());
    }

    private static void a(PlayerEvent.PlayerChangedDimensionEvent playerChangedDimensionEvent) {
        PlayerUtils.refreshPlayerFlyStatement(playerChangedDimensionEvent.getEntity());
    }

    private static void c() {
        SimpleChannel simpleChannel = NetworkRegistry.newSimpleChannel(GTOCore.id("handshake"), () -> "1", string -> true, string -> true);
        class A
        implements IntSupplier {
            final int a;
            int b;

            A() {
                this(GTOCore.difficulty);
            }

            A(int n) {
                this.a = n;
            }

            @Override
            public int getAsInt() {
                return this.a;
            }

            public int a() {
                return this.b;
            }

            public void a(int n) {
                this.b = n;
            }
        }
        simpleChannel.messageBuilder(A.class, 1, NetworkDirection.LOGIN_TO_CLIENT).encoder((a2, friendlyByteBuf) -> friendlyByteBuf.m_236835_(Optional.of(a2.getAsInt()), FriendlyByteBuf::writeInt)).decoder(friendlyByteBuf -> new A(friendlyByteBuf.m_236860_(FriendlyByteBuf::readInt).orElse(GTOCore.difficulty))).consumerNetworkThread((a2, supplier) -> {
            if (GTOCore.difficulty != a2.getAsInt()) {
                ((NetworkEvent.Context)supplier.get()).getNetworkManager().m_129507_(Component.m_237110_("message.gtocore.difficulty_mismatch", new Object[]{DynamicInitialData.getDifficultyComponent(a2.getAsInt()), DynamicInitialData.getDifficultyComponent(GTOCore.difficulty)}));
            }
        }).loginIndex(A::a, A::a).noResponse().buildLoginPacketList(bl -> bl != false ? List.of() : List.of(Pair.of(A.class.getName(), new A()))).add();
    }

    private static void a(CommandEvent commandEvent) {
        boolean bl;
        if (!SrmManager.isSrmMode()) {
            return;
        }
        ParseResults parseResults = commandEvent.getParseResults();
        String string = ((ParsedCommandNode)parseResults.getContext().getNodes().get(0)).getNode().getName();
        CommandSourceStack commandSourceStack = (CommandSourceStack)parseResults.getContext().getSource();
        if (!commandSourceStack.m_6761_(4) || SrmManager.isWhiteList(string)) {
            return;
        }
        boolean bl2 = commandSourceStack.m_81377_() == commandSourceStack.f_81288_;
        boolean bl3 = bl = commandSourceStack.m_230897_() && IEnhancedPlayer.of((Player)commandSourceStack.m_230896_()).getPlayerData().cmdState;
        if (bl2 || bl) {
            GTOCore.LOGGER.warn("command {} is not in whitelist", (Object)string);
            if (commandSourceStack.m_230897_()) {
                Objects.requireNonNull(commandSourceStack.m_230896_()).m_213846_(Component.m_237113_(string).m_7220_(Component.m_237115_("item.apotheosis.potion_charm.disabled")));
            }
            commandEvent.setCanceled(true);
        }
    }
}

package com.gtolib.e;

import com.gtolib.GTOCore;
import java.util.function.IntSupplier;

class a$a
implements IntSupplier {
    final int a;
    int b;

    a$a() {
        this(GTOCore.difficulty);
    }

    a$a(int n) {
        this.a = n;
    }

    @Override
    public int getAsInt() {
        return this.a;
    }

    public int a() {
        return this.b;
    }

    public void a(int n) {
        this.b = n;
    }
}

package com.gtolib;

import appeng.api.stacks.AEItemKey;
import com.gtolib.IUnique;
import com.gtolib.e;
import java.util.function.Supplier;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@e
public interface IItem
extends IUnique,
Comparable<Item> {
    @NotNull
    public ResourceLocation gtolib$getIdLocation();

    @NotNull
    public String gtolib$getIdString();

    @NotNull
    public Ingredient gtolib$getInnerIngredient();

    @NotNull
    public AEItemKey gtolib$getAEKey();

    public int gtolib$getUid();

    public int @Nullable [] gtolib$getMapItem();

    public void gtolib$setMapItem(int @NotNull [] var1);

    @NotNull
    public ItemStack gtolib$getReadOnlyStack();

    public void gtolib$setToolTips(Supplier<Component> ... var1);

    public Supplier<Component>[] gtolib$getToolTips();
}

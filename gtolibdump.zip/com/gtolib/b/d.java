package com.gtolib.b;

import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtolib.api.wireless.WirelessManaContainer;
import java.math.BigInteger;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.world.level.saveddata.SavedData;
import org.jetbrains.annotations.NotNull;

public class d
extends SavedData {
    public static d a = new d();
    public final Map<UUID, WirelessManaContainer> b = new O2OOpenCacheHashMap();

    public d(CompoundTag compoundTag) {
        ListTag listTag = compoundTag.m_128437_("all", 10);
        for (int i = 0; i < listTag.size(); ++i) {
            WirelessManaContainer wirelessManaContainer = d.a(listTag.m_128728_(i));
            this.b.put(wirelessManaContainer.getUuid(), wirelessManaContainer);
        }
    }

    @NotNull
    public CompoundTag m_7176_(@NotNull CompoundTag compoundTag) {
        ListTag listTag = new ListTag();
        for (WirelessManaContainer wirelessManaContainer : this.b.values()) {
            CompoundTag compoundTag2 = d.a(wirelessManaContainer);
            if (compoundTag2.m_128456_()) continue;
            listTag.add(compoundTag2);
        }
        compoundTag.m_128365_("all", listTag);
        return compoundTag;
    }

    private static WirelessManaContainer a(CompoundTag compoundTag) {
        String string = compoundTag.m_128461_("mana");
        return new WirelessManaContainer(compoundTag.m_128342_("uuid"), new BigInteger(string.isEmpty() ? "0" : string));
    }

    private static CompoundTag a(WirelessManaContainer wirelessManaContainer) {
        CompoundTag compoundTag = new CompoundTag();
        BigInteger bigInteger = wirelessManaContainer.getStorage();
        if (!Objects.equals(bigInteger, BigInteger.ZERO)) {
            compoundTag.m_128359_("mana", bigInteger.toString());
        }
        if (!compoundTag.m_128456_()) {
            compoundTag.m_128362_("uuid", wirelessManaContainer.getUuid());
        }
        return compoundTag;
    }

    public d() {
    }
}

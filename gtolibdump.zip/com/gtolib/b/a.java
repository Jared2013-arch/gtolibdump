package com.gtolib.b;

import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtolib.api.ae2.storage.BigCellDataStorage;
import com.gtolib.api.ae2.storage.CellDataStorage;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.Map;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.world.level.saveddata.SavedData;
import org.jetbrains.annotations.NotNull;

public final class a
extends SavedData {
    public static a a = new a();
    private final Object2ObjectOpenHashMap<UUID, CellDataStorage> b = new O2OOpenCacheHashMap();
    private final Object2ObjectOpenHashMap<UUID, BigCellDataStorage> c = new O2OOpenCacheHashMap();

    public a() {
    }

    public a(CompoundTag compoundTag) {
        this();
        ListTag listTag = compoundTag.m_128437_("l", 10);
        int n = listTag.size();
        for (int i = 0; i < n; ++i) {
            CompoundTag compoundTag2 = listTag.m_128728_(i);
            this.b.put((Object)compoundTag2.m_128342_("u"), (Object)CellDataStorage.fromNbt(compoundTag2.m_128469_("d")));
        }
        ListTag listTag2 = compoundTag.m_128437_("b", 10);
        n = listTag2.size();
        for (int i = 0; i < n; ++i) {
            CompoundTag compoundTag3 = listTag2.m_128728_(i);
            this.c.put((Object)compoundTag3.m_128342_("u"), (Object)BigCellDataStorage.fromNbt(compoundTag3.m_128469_("d")));
        }
    }

    @NotNull
    public CompoundTag m_7176_(@NotNull CompoundTag compoundTag) {
        CompoundTag compoundTag2;
        CompoundTag compoundTag3;
        Object object;
        ListTag listTag = new ListTag();
        ListTag listTag2 = new ListTag();
        ObjectIterator objectIterator = this.b.object2ObjectEntrySet().fastIterator();
        while (objectIterator.hasNext()) {
            object = (Map.Entry)objectIterator.next();
            compoundTag3 = ((CellDataStorage)object.getValue()).toNbt();
            if (compoundTag3 == null) continue;
            compoundTag2 = new CompoundTag();
            compoundTag2.m_128362_("u", (UUID)object.getKey());
            compoundTag2.m_128365_("d", compoundTag3);
            listTag.add(compoundTag2);
        }
        objectIterator = this.c.object2ObjectEntrySet().fastIterator();
        while (objectIterator.hasNext()) {
            object = (Object2ObjectMap.Entry)objectIterator.next();
            compoundTag3 = ((BigCellDataStorage)object.getValue()).toNbt();
            if (compoundTag3 == null) continue;
            compoundTag2 = new CompoundTag();
            compoundTag2.m_128362_("u", (UUID)object.getKey());
            compoundTag2.m_128365_("d", compoundTag3);
            listTag2.add(compoundTag2);
        }
        compoundTag.m_128365_("l", listTag);
        compoundTag.m_128365_("b", listTag2);
        return compoundTag;
    }

    public void a(@NotNull UUID uUID) {
        this.b.remove((Object)uUID);
        this.m_77762_();
    }

    public void b(@NotNull UUID uUID) {
        this.c.remove((Object)uUID);
        this.m_77762_();
    }

    public CellDataStorage c(@NotNull UUID uUID) {
        return (CellDataStorage)this.b.computeIfAbsent((Object)uUID, object -> new CellDataStorage());
    }

    public BigCellDataStorage d(@NotNull UUID uUID) {
        return (BigCellDataStorage)this.c.computeIfAbsent((Object)uUID, object -> new BigCellDataStorage());
    }
}

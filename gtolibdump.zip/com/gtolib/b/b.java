package com.gtolib.b;

import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gregtechceu.gtceu.utils.collection.OpenCacheHashSet;
import com.gtolib.utils.RLUtils;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.saveddata.SavedData;
import org.jetbrains.annotations.NotNull;

public final class b
extends SavedData {
    public static b a = new b();
    private final Map<UUID, Set<ResourceLocation>> b = new O2OOpenCacheHashMap();
    private CompoundTag c = new CompoundTag();

    public static void a(CompoundTag compoundTag) {
        com.gtolib.b.b.a.c = compoundTag;
        a.m_77762_();
    }

    public static CompoundTag a() {
        return com.gtolib.b.b.a.c;
    }

    public b() {
    }

    public b(CompoundTag compoundTag) {
        this();
        this.c = (CompoundTag)compoundTag.m_128423_("data");
        ListTag listTag = compoundTag.m_128437_("l", 10);
        Iterator iterator = listTag.iterator();
        while (iterator.hasNext()) {
            Tag tag = (Tag)iterator.next();
            CompoundTag compoundTag2 = (CompoundTag)tag;
            OpenCacheHashSet openCacheHashSet = new OpenCacheHashSet();
            ListTag listTag2 = compoundTag2.m_128437_("p", 10);
            Iterator iterator2 = listTag2.iterator();
            while (iterator2.hasNext()) {
                Tag tag2 = (Tag)iterator2.next();
                openCacheHashSet.add(RLUtils.parse(((CompoundTag)tag2).m_128461_("n")));
            }
            this.b.put(compoundTag2.m_128342_("u"), openCacheHashSet);
        }
    }

    @NotNull
    public CompoundTag m_7176_(@NotNull CompoundTag compoundTag) {
        ListTag listTag = new ListTag();
        this.b.forEach((uUID, set) -> {
            CompoundTag compoundTag = new CompoundTag();
            compoundTag.m_128362_("u", (UUID)uUID);
            ListTag listTag2 = new ListTag();
            set.forEach(resourceLocation -> {
                CompoundTag compoundTag = new CompoundTag();
                compoundTag.m_128359_("n", resourceLocation.toString());
                listTag2.add(compoundTag);
            });
            compoundTag.m_128365_("p", listTag2);
            listTag.add(compoundTag);
        });
        compoundTag.m_128365_("data", this.c);
        compoundTag.m_128365_("l", listTag);
        return compoundTag;
    }

    public Map<UUID, Set<ResourceLocation>> b() {
        return this.b;
    }
}

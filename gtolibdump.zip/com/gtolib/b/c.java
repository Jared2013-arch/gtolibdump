package com.gtolib.b;

import com.gtolib.api.wireless.ExtendWirelessEnergyContainer;
import com.gtolib.utils.GTOUtils;
import com.hepdd.gtmthings.api.misc.WirelessEnergyContainer;
import com.hepdd.gtmthings.data.WirelessEnergySavaedData;
import java.math.BigInteger;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.core.GlobalPos;
import net.minecraft.nbt.CompoundTag;

public final class c
extends WirelessEnergySavaedData {
    public c() {
    }

    public c(CompoundTag compoundTag) {
        super(compoundTag);
    }

    protected WirelessEnergyContainer readTag(CompoundTag compoundTag) {
        UUID uUID = compoundTag.m_128342_("u");
        String string = compoundTag.m_128461_("s");
        String string2 = compoundTag.m_128461_("c");
        BigInteger bigInteger = new BigInteger(string.isEmpty() ? "0" : string);
        BigInteger bigInteger2 = new BigInteger(string2.isEmpty() ? "0" : string2);
        long l = compoundTag.m_128454_("r");
        int n = compoundTag.m_128451_("l");
        GlobalPos globalPos = GTOUtils.readGlobalPos(compoundTag.m_128461_("d"), compoundTag.m_128454_("p"));
        return new ExtendWirelessEnergyContainer(uUID, bigInteger, l, globalPos, bigInteger2, n);
    }

    protected CompoundTag toTag(WirelessEnergyContainer wirelessEnergyContainer) {
        CompoundTag compoundTag = new CompoundTag();
        if (wirelessEnergyContainer instanceof ExtendWirelessEnergyContainer) {
            GlobalPos globalPos;
            int n;
            long l;
            BigInteger bigInteger;
            ExtendWirelessEnergyContainer extendWirelessEnergyContainer = (ExtendWirelessEnergyContainer)wirelessEnergyContainer;
            BigInteger bigInteger2 = extendWirelessEnergyContainer.getStorage();
            if (!Objects.equals(bigInteger2, BigInteger.ZERO)) {
                compoundTag.m_128359_("s", bigInteger2.toString());
            }
            if (!Objects.equals(bigInteger = extendWirelessEnergyContainer.getCapacity(), BigInteger.ZERO)) {
                compoundTag.m_128359_("c", bigInteger.toString());
            }
            if ((l = extendWirelessEnergyContainer.getRate()) != 0L) {
                compoundTag.m_128356_("r", l);
            }
            if ((n = extendWirelessEnergyContainer.getLoss()) != 0) {
                compoundTag.m_128405_("l", n);
            }
            if ((globalPos = extendWirelessEnergyContainer.getBindPos()) != null) {
                compoundTag.m_128359_("d", globalPos.m_122640_().m_135782_().toString());
                compoundTag.m_128356_("p", globalPos.m_122646_().m_121878_());
            }
            if (!compoundTag.m_128456_()) {
                compoundTag.m_128362_("u", extendWirelessEnergyContainer.getUuid());
            }
        }
        return compoundTag;
    }
}

package com.gtolib.syncdata;

import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtolib.GTOCore;
import com.gtolib.api.capability.ISync;
import com.gtolib.e;
import com.gtolib.syncdata.a;
import java.util.Map;
import org.apache.commons.lang3.ArrayUtils;

@e
public class SyncManagedFieldHolder {
    final Map<String, a> fieldNameMap = new O2OOpenCacheHashMap();
    a[] fields;

    public SyncManagedFieldHolder(Class<? extends ISync> clazz) {
        this.fields = a.a(clazz, object -> object);
        this.resetSyncFieldIndexMap();
    }

    public SyncManagedFieldHolder(Class<? extends ISync> clazz, SyncManagedFieldHolder syncManagedFieldHolder) {
        this(clazz);
        this.fields = ArrayUtils.addAll(this.fields, syncManagedFieldHolder.fields);
        this.resetSyncFieldIndexMap();
    }

    public String getSyncFieldName(ISync iSync, Object object) {
        for (a a2 : this.fields) {
            if (!(a2 instanceof a.a)) continue;
            a.a a3 = (a.a)a2;
            if (a3.a.getType() != object.getClass()) continue;
            try {
                if (a3.a.get(a3.c.apply(iSync)) != object) continue;
                return a3.b;
            }
            catch (Throwable throwable) {
                throwable.printStackTrace();
            }
        }
        GTOCore.LOGGER.error("Sync field not found: {}", object);
        return null;
    }

    private void resetSyncFieldIndexMap() {
        this.fieldNameMap.clear();
        for (a a2 : this.fields) {
            if (this.fieldNameMap.containsKey(a2.a())) {
                GTOCore.LOGGER.error("Duplicate sync field name: {}", (Object)a2.a());
                continue;
            }
            this.fieldNameMap.put(a2.a(), a2);
        }
    }
}

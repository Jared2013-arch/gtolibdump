package com.gtolib.syncdata;

import net.minecraftforge.fml.LogicalSide;

interface a$b$b {
    public static final a$b$b a = (object, logicalSide, object2, object3) -> {};

    public void onSync(Object var1, LogicalSide var2, Object var3, Object var4);
}

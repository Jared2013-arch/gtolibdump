package com.gtolib.syncdata;

import com.gtolib.api.capability.ISync;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import java.lang.invoke.MethodHandle;
import java.lang.reflect.Field;
import java.lang.runtime.ObjectMethods;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.fml.LogicalSide;

public class a$b
implements com.gtolib.syncdata.a {
    private static final Map<Class<?>, a> a = new Reference2ObjectOpenHashMap();
    private final String b;
    private final Field c;
    private final b d;
    private final d e;
    private final c f;
    private final Function<Object, Object> g;

    private static void a(Class<?> clazz, d d2, c c2) {
        a.put(clazz, new a(d2, c2));
    }

    a$b(Field field, b b2, Function<Object, Object> function) {
        this.b = field.getName();
        this.c = field;
        this.d = b2;
        this.g = function;
        field.setAccessible(true);
        Class<?> clazz = field.getType();
        a a2 = clazz.isEnum() ? com.gtolib.syncdata.a$b$a.c : a.get(clazz);
        this.e = a2.a();
        this.f = a2.b();
    }

    @Override
    public String a() {
        return this.b;
    }

    @Override
    public void a(ISync iSync, FriendlyByteBuf friendlyByteBuf) {
        this.e.handle(this.g.apply(iSync), this.c, friendlyByteBuf);
    }

    @Override
    public void a(ISync iSync, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide) {
        this.f.handle(this.g.apply(iSync), this.c, friendlyByteBuf, logicalSide, this.d);
    }

    static {
        a$b.a(Boolean.TYPE, (Object object, Field field, FriendlyByteBuf friendlyByteBuf) -> friendlyByteBuf.writeBoolean(field.getBoolean(object)), (Object object, Field field, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide, b b2) -> {
            boolean bl = field.getBoolean(object);
            boolean bl2 = friendlyByteBuf.readBoolean();
            field.setBoolean(object, bl2);
            b2.onSync(object, logicalSide, bl, bl2);
        });
        a$b.a(Byte.TYPE, (Object object, Field field, FriendlyByteBuf friendlyByteBuf) -> friendlyByteBuf.writeByte(field.getByte(object)), (Object object, Field field, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide, b b2) -> {
            byte by = field.getByte(object);
            byte by2 = friendlyByteBuf.readByte();
            field.setByte(object, by2);
            b2.onSync(object, logicalSide, by, by2);
        });
        a$b.a(Integer.TYPE, (Object object, Field field, FriendlyByteBuf friendlyByteBuf) -> friendlyByteBuf.writeInt(field.getInt(object)), (Object object, Field field, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide, b b2) -> {
            int n = field.getInt(object);
            int n2 = friendlyByteBuf.readInt();
            field.setInt(object, n2);
            b2.onSync(object, logicalSide, n, n2);
        });
        a$b.a(Long.TYPE, (Object object, Field field, FriendlyByteBuf friendlyByteBuf) -> friendlyByteBuf.writeLong(field.getLong(object)), (Object object, Field field, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide, b b2) -> {
            long l = field.getLong(object);
            long l2 = friendlyByteBuf.readLong();
            field.setLong(object, l2);
            b2.onSync(object, logicalSide, l, l2);
        });
        a$b.a(Float.TYPE, (Object object, Field field, FriendlyByteBuf friendlyByteBuf) -> friendlyByteBuf.writeFloat(field.getFloat(object)), (Object object, Field field, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide, b b2) -> {
            float f = field.getFloat(object);
            float f2 = friendlyByteBuf.readFloat();
            field.setFloat(object, f2);
            b2.onSync(object, logicalSide, Float.valueOf(f), Float.valueOf(f2));
        });
        a$b.a(Double.TYPE, (Object object, Field field, FriendlyByteBuf friendlyByteBuf) -> friendlyByteBuf.writeDouble(field.getDouble(object)), (Object object, Field field, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide, b b2) -> {
            double d2 = field.getDouble(object);
            double d3 = friendlyByteBuf.readDouble();
            field.setDouble(object, d3);
            b2.onSync(object, logicalSide, d2, d3);
        });
        a$b.a(String.class, (Object object, Field field, FriendlyByteBuf friendlyByteBuf) -> friendlyByteBuf.m_130070_((String)field.get(object)), (Object object, Field field, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide, b b2) -> {
            Object object2 = field.get(object);
            String string = friendlyByteBuf.m_130277_();
            field.set(object, string);
            b2.onSync(object, logicalSide, object2, string);
        });
        a$b.a(UUID.class, (Object object, Field field, FriendlyByteBuf friendlyByteBuf) -> friendlyByteBuf.m_130077_((UUID)field.get(object)), (Object object, Field field, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide, b b2) -> {
            Object object2 = field.get(object);
            UUID uUID = friendlyByteBuf.m_130259_();
            field.set(object, uUID);
            b2.onSync(object, logicalSide, object2, uUID);
        });
    }

    private record a(d a, c b) {
        private static final a c = new a((object, field, friendlyByteBuf) -> friendlyByteBuf.m_130068_((Enum)field.get(object)), (object, field, friendlyByteBuf, logicalSide, b2) -> {
            Object object2 = field.get(object);
            Enum enum_ = friendlyByteBuf.m_130066_(field.getType());
            field.set(object, enum_);
            b2.onSync(object, logicalSide, object2, enum_);
        });

        public final String toString() {
            return ObjectMethods.bootstrap("toString", new MethodHandle[]{a.class, "writeBuffer;readBuffer", "a", "b"}, this);
        }

        public final int hashCode() {
            return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{a.class, "writeBuffer;readBuffer", "a", "b"}, this);
        }

        public final boolean equals(Object object) {
            return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{a.class, "writeBuffer;readBuffer", "a", "b"}, this, object);
        }
    }

    private static interface d {
        public void handle(Object var1, Field var2, FriendlyByteBuf var3);
    }

    private static interface c {
        public void handle(Object var1, Field var2, FriendlyByteBuf var3, LogicalSide var4, b var5);
    }

    private static interface b {
        public static final b a = (object, logicalSide, object2, object3) -> {};

        public void onSync(Object var1, LogicalSide var2, Object var3, Object var4);
    }
}

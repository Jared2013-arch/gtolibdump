package com.gtolib.syncdata;

import com.gtolib.syncdata.a;
import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;

record a$b$a(a.b.d a, a.b.c b) {
    private static final a$b$a c = new a$b$a((object, field, friendlyByteBuf) -> friendlyByteBuf.m_130068_((Enum)field.get(object)), (object, field, friendlyByteBuf, logicalSide, b2) -> {
        Object object2 = field.get(object);
        Enum enum_ = friendlyByteBuf.m_130066_(field.getType());
        field.set(object, enum_);
        b2.onSync(object, logicalSide, object2, enum_);
    });

    public final String toString() {
        return ObjectMethods.bootstrap("toString", new MethodHandle[]{a$b$a.class, "writeBuffer;readBuffer", "a", "b"}, this);
    }

    public final int hashCode() {
        return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{a$b$a.class, "writeBuffer;readBuffer", "a", "b"}, this);
    }

    public final boolean equals(Object object) {
        return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{a$b$a.class, "writeBuffer;readBuffer", "a", "b"}, this, object);
    }
}

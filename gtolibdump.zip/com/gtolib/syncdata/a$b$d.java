package com.gtolib.syncdata;

import java.lang.reflect.Field;
import net.minecraft.network.FriendlyByteBuf;

interface a$b$d {
    public void handle(Object var1, Field var2, FriendlyByteBuf var3);
}

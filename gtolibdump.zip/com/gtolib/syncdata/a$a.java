package com.gtolib.syncdata;

import com.gtolib.api.capability.ISync;
import com.gtolib.syncdata$a;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.function.Function;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.fml.LogicalSide;

public static class a$a
implements a {
    private final Method d;
    private final Method e;
    final Field a;
    final String b;
    final Function<Object, Object> c;

    private a$a(Method method, Method method2, Field field, Function<Object, Object> function) {
        this.d = method;
        this.e = method2;
        this.a = field;
        this.b = field.getName();
        this.c = function;
    }

    @Override
    public String a() {
        return this.b;
    }

    @Override
    public void a(ISync iSync, FriendlyByteBuf friendlyByteBuf) {
        try {
            this.d.invoke(this.a.get(this.c.apply(iSync)), friendlyByteBuf);
        }
        catch (InvocationTargetException invocationTargetException) {
            invocationTargetException.printStackTrace();
        }
    }

    @Override
    public void a(ISync iSync, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide) {
        try {
            this.e.invoke(this.a.get(this.c.apply(iSync)), friendlyByteBuf, logicalSide);
        }
        catch (InvocationTargetException invocationTargetException) {
            invocationTargetException.printStackTrace();
        }
    }
}

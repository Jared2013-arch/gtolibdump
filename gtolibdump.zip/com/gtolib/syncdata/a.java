package com.gtolib.syncdata;

import com.gtolib.GTOCore;
import com.gtolib.api.annotation.Synced;
import com.gtolib.api.annotation.SyncedManager;
import com.gtolib.api.capability.ISync;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import java.lang.invoke.MethodHandle;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.runtime.ObjectMethods;
import java.util.Arrays;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.fml.LogicalSide;
import org.apache.commons.lang3.ClassUtils;

interface a {
    public static a[] a(Class<?> clazz, Function<Object, Object> function) {
        ObjectArrayList objectArrayList = new ObjectArrayList();
        for (Field field : clazz.getDeclaredFields()) {
            Object object2;
            if (Modifier.isStatic(field.getModifiers())) continue;
            Class<?> clazz2 = field.getType();
            boolean bl = false;
            for (Class<?> clazz3 : ClassUtils.getAllInterfaces(clazz2)) {
                if (clazz3 != ISync.ISyncedField.class) continue;
                bl = true;
                break;
            }
            if (bl) {
                try {
                    field.setAccessible(true);
                    object2 = clazz2.getMethod("writeBuffer", FriendlyByteBuf.class);
                    Method method = clazz2.getMethod("readBuffer", FriendlyByteBuf.class, LogicalSide.class);
                    objectArrayList.add(new a((Method)object2, method, field, function));
                }
                catch (NoSuchMethodException noSuchMethodException) {
                    GTOCore.LOGGER.error("couldn't find the buffer method for synced field {}", (Object)field.getName());
                    noSuchMethodException.printStackTrace();
                }
                continue;
            }
            if (field.isAnnotationPresent(Synced.class)) {
                object2 = null;
                String string = field.getAnnotation(Synced.class).listener();
                if (!string.isEmpty()) {
                    try {
                        object2 = clazz.getDeclaredMethod(string, LogicalSide.class, clazz2, clazz2);
                        ((AccessibleObject)object2).setAccessible(true);
                    }
                    catch (NoSuchMethodException noSuchMethodException) {
                        GTOCore.LOGGER.error("couldn't find the listener method {} for synced field {}", (Object)string, (Object)field.getName());
                        noSuchMethodException.printStackTrace();
                    }
                }
                Object object3 = object2;
                b b2 = new b(field, object2 == null ? b.b.a : (arg_0, arg_1, arg_2, arg_3) -> a.a((Method)object3, arg_0, arg_1, arg_2, arg_3), function);
                objectArrayList.add(b2);
                continue;
            }
            if (!field.isAnnotationPresent(SyncedManager.class)) continue;
            field.setAccessible(true);
            objectArrayList.addAll(Arrays.asList(a.a(field.getType(), object -> {
                try {
                    return field.get(function.apply(object));
                }
                catch (IllegalAccessException illegalAccessException) {
                    throw new RuntimeException(illegalAccessException);
                }
            })));
        }
        return (a[])objectArrayList.toArray(a[]::new);
    }

    public String a();

    public void a(ISync var1, FriendlyByteBuf var2);

    public void a(ISync var1, FriendlyByteBuf var2, LogicalSide var3);

    private static void a(Method method, Object object, LogicalSide logicalSide, Object object2, Object object3) {
        try {
            method.invoke(object, logicalSide, object2, object3);
        }
        catch (IllegalAccessException | InvocationTargetException reflectiveOperationException) {
            GTOCore.LOGGER.error("error when invoke listener method {}", (Object)reflectiveOperationException.toString());
        }
    }

    public static class a
    implements a {
        private final Method d;
        private final Method e;
        final Field a;
        final String b;
        final Function<Object, Object> c;

        private a(Method method, Method method2, Field field, Function<Object, Object> function) {
            this.d = method;
            this.e = method2;
            this.a = field;
            this.b = field.getName();
            this.c = function;
        }

        @Override
        public String a() {
            return this.b;
        }

        @Override
        public void a(ISync iSync, FriendlyByteBuf friendlyByteBuf) {
            try {
                this.d.invoke(this.a.get(this.c.apply(iSync)), friendlyByteBuf);
            }
            catch (InvocationTargetException invocationTargetException) {
                invocationTargetException.printStackTrace();
            }
        }

        @Override
        public void a(ISync iSync, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide) {
            try {
                this.e.invoke(this.a.get(this.c.apply(iSync)), friendlyByteBuf, logicalSide);
            }
            catch (InvocationTargetException invocationTargetException) {
                invocationTargetException.printStackTrace();
            }
        }
    }

    public static class com.gtolib.syncdata.a$b
    implements com.gtolib.syncdata.a {
        private static final Map<Class<?>, a> a = new Reference2ObjectOpenHashMap();
        private final String b;
        private final Field c;
        private final b d;
        private final d e;
        private final c f;
        private final Function<Object, Object> g;

        private static void a(Class<?> clazz, d d2, c c2) {
            a.put(clazz, new a(d2, c2));
        }

        com.gtolib.syncdata.a$b(Field field, b b2, Function<Object, Object> function) {
            this.b = field.getName();
            this.c = field;
            this.d = b2;
            this.g = function;
            field.setAccessible(true);
            Class<?> clazz = field.getType();
            a a2 = clazz.isEnum() ? a.c : a.get(clazz);
            this.e = a2.a();
            this.f = a2.b();
        }

        @Override
        public String a() {
            return this.b;
        }

        @Override
        public void a(ISync iSync, FriendlyByteBuf friendlyByteBuf) {
            this.e.handle(this.g.apply(iSync), this.c, friendlyByteBuf);
        }

        @Override
        public void a(ISync iSync, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide) {
            this.f.handle(this.g.apply(iSync), this.c, friendlyByteBuf, logicalSide, this.d);
        }

        static {
            com.gtolib.syncdata.a$b.a(Boolean.TYPE, (Object object, Field field, FriendlyByteBuf friendlyByteBuf) -> friendlyByteBuf.writeBoolean(field.getBoolean(object)), (Object object, Field field, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide, b b2) -> {
                boolean bl = field.getBoolean(object);
                boolean bl2 = friendlyByteBuf.readBoolean();
                field.setBoolean(object, bl2);
                b2.onSync(object, logicalSide, bl, bl2);
            });
            com.gtolib.syncdata.a$b.a(Byte.TYPE, (Object object, Field field, FriendlyByteBuf friendlyByteBuf) -> friendlyByteBuf.writeByte(field.getByte(object)), (Object object, Field field, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide, b b2) -> {
                byte by = field.getByte(object);
                byte by2 = friendlyByteBuf.readByte();
                field.setByte(object, by2);
                b2.onSync(object, logicalSide, by, by2);
            });
            com.gtolib.syncdata.a$b.a(Integer.TYPE, (Object object, Field field, FriendlyByteBuf friendlyByteBuf) -> friendlyByteBuf.writeInt(field.getInt(object)), (Object object, Field field, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide, b b2) -> {
                int n = field.getInt(object);
                int n2 = friendlyByteBuf.readInt();
                field.setInt(object, n2);
                b2.onSync(object, logicalSide, n, n2);
            });
            com.gtolib.syncdata.a$b.a(Long.TYPE, (Object object, Field field, FriendlyByteBuf friendlyByteBuf) -> friendlyByteBuf.writeLong(field.getLong(object)), (Object object, Field field, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide, b b2) -> {
                long l = field.getLong(object);
                long l2 = friendlyByteBuf.readLong();
                field.setLong(object, l2);
                b2.onSync(object, logicalSide, l, l2);
            });
            com.gtolib.syncdata.a$b.a(Float.TYPE, (Object object, Field field, FriendlyByteBuf friendlyByteBuf) -> friendlyByteBuf.writeFloat(field.getFloat(object)), (Object object, Field field, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide, b b2) -> {
                float f = field.getFloat(object);
                float f2 = friendlyByteBuf.readFloat();
                field.setFloat(object, f2);
                b2.onSync(object, logicalSide, Float.valueOf(f), Float.valueOf(f2));
            });
            com.gtolib.syncdata.a$b.a(Double.TYPE, (Object object, Field field, FriendlyByteBuf friendlyByteBuf) -> friendlyByteBuf.writeDouble(field.getDouble(object)), (Object object, Field field, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide, b b2) -> {
                double d2 = field.getDouble(object);
                double d3 = friendlyByteBuf.readDouble();
                field.setDouble(object, d3);
                b2.onSync(object, logicalSide, d2, d3);
            });
            com.gtolib.syncdata.a$b.a(String.class, (Object object, Field field, FriendlyByteBuf friendlyByteBuf) -> friendlyByteBuf.m_130070_((String)field.get(object)), (Object object, Field field, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide, b b2) -> {
                Object object2 = field.get(object);
                String string = friendlyByteBuf.m_130277_();
                field.set(object, string);
                b2.onSync(object, logicalSide, object2, string);
            });
            com.gtolib.syncdata.a$b.a(UUID.class, (Object object, Field field, FriendlyByteBuf friendlyByteBuf) -> friendlyByteBuf.m_130077_((UUID)field.get(object)), (Object object, Field field, FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide, b b2) -> {
                Object object2 = field.get(object);
                UUID uUID = friendlyByteBuf.m_130259_();
                field.set(object, uUID);
                b2.onSync(object, logicalSide, object2, uUID);
            });
        }

        private record a(d a, c b) {
            private static final a c = new a((object, field, friendlyByteBuf) -> friendlyByteBuf.m_130068_((Enum)field.get(object)), (object, field, friendlyByteBuf, logicalSide, b2) -> {
                Object object2 = field.get(object);
                Enum enum_ = friendlyByteBuf.m_130066_(field.getType());
                field.set(object, enum_);
                b2.onSync(object, logicalSide, object2, enum_);
            });

            public final String toString() {
                return ObjectMethods.bootstrap("toString", new MethodHandle[]{a.class, "writeBuffer;readBuffer", "a", "b"}, this);
            }

            public final int hashCode() {
                return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{a.class, "writeBuffer;readBuffer", "a", "b"}, this);
            }

            public final boolean equals(Object object) {
                return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{a.class, "writeBuffer;readBuffer", "a", "b"}, this, object);
            }
        }

        private static interface d {
            public void handle(Object var1, Field var2, FriendlyByteBuf var3);
        }

        private static interface c {
            public void handle(Object var1, Field var2, FriendlyByteBuf var3, LogicalSide var4, b var5);
        }

        private static interface b {
            public static final b a = (object, logicalSide, object2, object3) -> {};

            public void onSync(Object var1, LogicalSide var2, Object var3, Object var4);
        }
    }
}

package com.gtolib.syncdata;

import com.gregtechceu.gtceu.GTCEu;
import com.gtolib.GTOCore;
import com.gtolib.api.capability.ISync;
import com.gtolib.api.data.GTODimensions;
import com.gtolib.d;
import com.gtolib.utils.ServerUtils;
import dev.architectury.networking.NetworkManager;
import dev.architectury.networking.simple.BaseC2SMessage;
import dev.architectury.networking.simple.BaseS2CMessage;
import dev.architectury.networking.simple.MessageType;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraftforge.fml.LogicalSide;
import org.jetbrains.annotations.NotNull;

public class b {
    private static final MessageType b = GTOCore.NETWORK_MANAGER.registerC2S("sync_from_client", a::new);
    private static final MessageType c = GTOCore.NETWORK_MANAGER.registerS2C("sync_from_server", b::new);
    private static final byte d = 1;
    private static final byte e = 2;
    public final Long2ObjectOpenHashMap<ISync> a = new Long2ObjectOpenHashMap();
    private final ResourceLocation f;

    public static void a() {
        com.gtolib.h.a.a();
    }

    public b(Level level) {
        this.f = level.m_46472_().m_135782_();
    }

    public void a(ISync iSync, String string) {
        new a(1, friendlyByteBuf -> {
            try {
                friendlyByteBuf.m_130085_(this.f);
                friendlyByteBuf.writeLong(iSync.getPos().m_121878_());
                friendlyByteBuf.m_130070_(string);
                iSync.getSyncHolder().fieldNameMap.get(string).a(iSync, (FriendlyByteBuf)friendlyByteBuf);
            }
            catch (IllegalAccessException illegalAccessException) {
                illegalAccessException.printStackTrace();
            }
        }).sendToServer();
    }

    public void b(ISync iSync, String string) {
        new b(1, friendlyByteBuf -> {
            try {
                friendlyByteBuf.m_130085_(this.f);
                friendlyByteBuf.writeLong(iSync.getPos().m_121878_());
                friendlyByteBuf.m_130070_(string);
                iSync.getSyncHolder().fieldNameMap.get(string).a(iSync, (FriendlyByteBuf)friendlyByteBuf);
            }
            catch (IllegalAccessException illegalAccessException) {
                illegalAccessException.printStackTrace();
            }
        }).sendToAll(ServerUtils.getServer());
    }

    public void a(ISync iSync) {
        new a(2, friendlyByteBuf -> {
            try {
                friendlyByteBuf.m_130085_(this.f);
                friendlyByteBuf.writeLong(iSync.getPos().m_121878_());
                for (com.gtolib.syncdata.a a2 : iSync.getSyncHolder().fields) {
                    a2.a(iSync, (FriendlyByteBuf)friendlyByteBuf);
                }
            }
            catch (IllegalAccessException illegalAccessException) {
                illegalAccessException.printStackTrace();
            }
        }).sendToServer();
    }

    public void b(ISync iSync) {
        new b(2, friendlyByteBuf -> {
            try {
                friendlyByteBuf.m_130085_(this.f);
                friendlyByteBuf.writeLong(iSync.getPos().m_121878_());
                for (com.gtolib.syncdata.a a2 : iSync.getSyncHolder().fields) {
                    a2.a(iSync, (FriendlyByteBuf)friendlyByteBuf);
                }
            }
            catch (IllegalAccessException illegalAccessException) {
                illegalAccessException.printStackTrace();
            }
        }).sendToAll(ServerUtils.getServer());
    }

    private static void a(FriendlyByteBuf friendlyByteBuf, ISync iSync, LogicalSide logicalSide) {
        try {
            iSync.getSyncHolder().fieldNameMap.get(friendlyByteBuf.m_130277_()).a(iSync, friendlyByteBuf, logicalSide);
        }
        catch (IllegalAccessException illegalAccessException) {
            illegalAccessException.printStackTrace();
        }
    }

    private static void b(FriendlyByteBuf friendlyByteBuf, ISync iSync, LogicalSide logicalSide) {
        try {
            for (com.gtolib.syncdata.a a2 : iSync.getSyncHolder().fields) {
                a2.a(iSync, friendlyByteBuf, logicalSide);
            }
        }
        catch (IllegalAccessException illegalAccessException) {
            illegalAccessException.printStackTrace();
        }
    }

    private static final class a
    extends BaseC2SMessage {
        private final byte a;
        private Consumer<FriendlyByteBuf> b;
        private FriendlyByteBuf c;
        private long d;
        private d e;

        private a(byte by, @NotNull Consumer<FriendlyByteBuf> consumer) {
            this.a = by;
            this.b = consumer;
        }

        private a(FriendlyByteBuf friendlyByteBuf) {
            this.a = friendlyByteBuf.readByte();
            ResourceKey<Level> resourceKey = GTODimensions.getDimensionKey(friendlyByteBuf.m_130281_());
            ServerLevel serverLevel = ServerUtils.getServer().m_129880_(resourceKey);
            if (serverLevel == null) {
                GTOCore.LOGGER.error("Invalid dimension key: {}", (Object)resourceKey);
            } else {
                this.d = friendlyByteBuf.readLong();
                this.e = (d)((Object)serverLevel);
                this.c = new FriendlyByteBuf(friendlyByteBuf.copy());
            }
        }

        public MessageType getType() {
            return b;
        }

        public void write(FriendlyByteBuf friendlyByteBuf) {
            friendlyByteBuf.writeByte(this.a);
            this.b.accept(friendlyByteBuf);
        }

        public void handle(NetworkManager.PacketContext packetContext) {
            if (this.e != null) {
                ISync iSync = (ISync)this.e.gtolib$getSyncFieldManager().a.get(this.d);
                if (iSync == null) {
                    GTOCore.LOGGER.error("Invalid server sync object: {}", (Object)BlockPos.m_122022_(this.d));
                } else {
                    switch (this.a) {
                        case 1: {
                            com.gtolib.syncdata.b.a(this.c, iSync, LogicalSide.SERVER);
                            break;
                        }
                        case 2: {
                            com.gtolib.syncdata.b.b(this.c, iSync, LogicalSide.SERVER);
                        }
                    }
                }
            }
        }
    }

    private static final class b
    extends BaseS2CMessage {
        private final byte a;
        private Consumer<FriendlyByteBuf> b;
        private FriendlyByteBuf c;
        private long d;
        private d e;

        private b(byte by, @NotNull Consumer<FriendlyByteBuf> consumer) {
            this.a = by;
            this.b = consumer;
        }

        private b(FriendlyByteBuf friendlyByteBuf) {
            this.a = friendlyByteBuf.readByte();
            ClientLevel clientLevel = Minecraft.m_91087_().f_91073_;
            if (clientLevel != null && clientLevel.m_46472_().m_135782_().equals(friendlyByteBuf.m_130281_())) {
                this.d = friendlyByteBuf.readLong();
                this.e = (d)((Object)clientLevel);
                this.c = new FriendlyByteBuf(friendlyByteBuf.copy());
            }
        }

        public MessageType getType() {
            return c;
        }

        public void write(FriendlyByteBuf friendlyByteBuf) {
            friendlyByteBuf.writeByte(this.a);
            this.b.accept(friendlyByteBuf);
        }

        public void handle(NetworkManager.PacketContext packetContext) {
            if (this.e != null) {
                ISync iSync = (ISync)this.e.gtolib$getSyncFieldManager().a.get(this.d);
                if (iSync == null && GTCEu.isDev()) {
                    GTOCore.LOGGER.error("Invalid client sync object: {}", (Object)BlockPos.m_122022_(this.d));
                } else {
                    switch (this.a) {
                        case 1: {
                            com.gtolib.syncdata.b.a(this.c, iSync, LogicalSide.CLIENT);
                            break;
                        }
                        case 2: {
                            com.gtolib.syncdata.b.b(this.c, iSync, LogicalSide.CLIENT);
                        }
                    }
                }
            }
        }
    }
}

package com.gtolib.syncdata;

import com.gtolib.GTOCore;
import com.gtolib$api.capability.ISync;
import com.gtolib$api.data.GTODimensions;
import com.gtolib.d;
import com.gtolib.syncdata.b;
import com.gtolib.utils.ServerUtils;
import dev.architectury.networking.NetworkManager;
import dev.architectury.networking.simple.BaseC2SMessage;
import dev.architectury.networking.simple.MessageType;
import java.util.function.Consumer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraftforge.fml.LogicalSide;
import org.jetbrains.annotations.NotNull;

private static final class b$a
extends BaseC2SMessage {
    private final byte a;
    private Consumer<FriendlyByteBuf> b;
    private FriendlyByteBuf c;
    private long d;
    private d e;

    private b$a(byte by, @NotNull Consumer<FriendlyByteBuf> consumer) {
        this.a = by;
        this.b = consumer;
    }

    private b$a(FriendlyByteBuf friendlyByteBuf) {
        this.a = friendlyByteBuf.readByte();
        ResourceKey<Level> resourceKey = GTODimensions.getDimensionKey(friendlyByteBuf.m_130281_());
        ServerLevel serverLevel = ServerUtils.getServer().m_129880_(resourceKey);
        if (serverLevel == null) {
            GTOCore.LOGGER.error("Invalid dimension key: {}", (Object)resourceKey);
        } else {
            this.d = friendlyByteBuf.readLong();
            this.e = (d)((Object)serverLevel);
            this.c = new FriendlyByteBuf(friendlyByteBuf.copy());
        }
    }

    public MessageType getType() {
        return b;
    }

    public void write(FriendlyByteBuf friendlyByteBuf) {
        friendlyByteBuf.writeByte(this.a);
        this.b$accept(friendlyByteBuf);
    }

    public void handle(NetworkManager.PacketContext packetContext) {
        if (this.e != null) {
            ISync iSync = (ISync)this.e.gtolib$getSyncFieldManager().a.get(this.d);
            if (iSync == null) {
                GTOCore.LOGGER.error("Invalid server sync object: {}", (Object)BlockPos.m_122022_(this.d));
            } else {
                switch (this.a) {
                    case 1: {
                        com.gtolib.syncdata.b$a(this.c, iSync, LogicalSide.SERVER);
                        break;
                    }
                    case 2: {
                        com.gtolib.syncdata.b.b(this.c, iSync, LogicalSide.SERVER);
                    }
                }
            }
        }
    }
}

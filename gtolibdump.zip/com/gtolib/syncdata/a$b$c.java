package com.gtolib.syncdata;

import com.gtolib.syncdata.a;
import java.lang.reflect.Field;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.fml.LogicalSide;

interface a$b$c {
    public void handle(Object var1, Field var2, FriendlyByteBuf var3, LogicalSide var4, a.b.b var5);
}

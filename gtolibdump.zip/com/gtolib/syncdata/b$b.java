package com.gtolib.syncdata;

import com.gregtechceu.gtceu.GTCEu;
import com.gtolib.GTOCore;
import com.gtolib.api.capability.ISync;
import com.gtolib.d;
import com.gtolib.syncdata.b;
import dev.architectury.networking.NetworkManager;
import dev.architectury.networking.simple.BaseS2CMessage;
import dev.architectury.networking.simple.MessageType;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.fml.LogicalSide;
import org.jetbrains.annotations.NotNull;

final class b$b
extends BaseS2CMessage {
    private final byte a;
    private Consumer<FriendlyByteBuf> b;
    private FriendlyByteBuf c;
    private long d;
    private d e;

    private b$b(byte by, @NotNull Consumer<FriendlyByteBuf> consumer) {
        this.a = by;
        this.b = consumer;
    }

    private b$b(FriendlyByteBuf friendlyByteBuf) {
        this.a = friendlyByteBuf.readByte();
        ClientLevel clientLevel = Minecraft.m_91087_().f_91073_;
        if (clientLevel != null && clientLevel.m_46472_().m_135782_().equals(friendlyByteBuf.m_130281_())) {
            this.d = friendlyByteBuf.readLong();
            this.e = (d)((Object)clientLevel);
            this.c = new FriendlyByteBuf(friendlyByteBuf.copy());
        }
    }

    public MessageType getType() {
        return c;
    }

    public void write(FriendlyByteBuf friendlyByteBuf) {
        friendlyByteBuf.writeByte(this.a);
        this.b.accept(friendlyByteBuf);
    }

    public void handle(NetworkManager.PacketContext packetContext) {
        if (this.e != null) {
            ISync iSync = (ISync)this.e.gtolib$getSyncFieldManager().a.get(this.d);
            if (iSync == null && GTCEu.isDev()) {
                GTOCore.LOGGER.error("Invalid client sync object: {}", (Object)BlockPos.m_122022_(this.d));
            } else {
                switch (this.a) {
                    case 1: {
                        com.gtolib.syncdata.b.a(this.c, iSync, LogicalSide.CLIENT);
                        break;
                    }
                    case 2: {
                        com.gtolib.syncdata.b$b(this.c, iSync, LogicalSide.CLIENT);
                    }
                }
            }
        }
    }
}

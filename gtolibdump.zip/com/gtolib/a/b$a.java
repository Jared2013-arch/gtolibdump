package com.gtolib$a;

import java.lang.ref.SoftReference;

protected static class b$a<K, V>
extends SoftReference<V> {
    private final K a;
    private final int b;

    protected b$a(K k, V v, int n) {
        super(v);
        this.a = k;
        this.b = n;
    }
}

package com.gtolib.a;

import appeng.api.stacks.AEItemKey;
import com.gregtechceu.gtceu.utils.ItemStackHashStrategy;
import com.gtocore.mixin.ae2.stacks.AEItemKeyInvoker;
import com.gtolib.a.b;
import com.gtolib.api.ae2.stacks.IAEItemKey;
import net.minecraft.world.item.ItemStack;

public final class a
extends b<ItemStack, AEItemKey> {
    public a() {
        super(ItemStackHashStrategy.ITEM_AND_TAG, null, true);
    }

    @Override
    protected AEItemKey a(int n, int n2, ItemStack itemStack) {
        if (n < 0) {
            itemStack = itemStack.m_255036_(1);
        }
        AEItemKey aEItemKey = AEItemKeyInvoker.of(itemStack.m_41720_(), itemStack.m_41783_(), AEItemKeyInvoker.serializeStackCaps(itemStack));
        IAEItemKey iAEItemKey = (IAEItemKey)((Object)aEItemKey);
        iAEItemKey.gtolib$setMaxStackSize(itemStack.m_41741_());
        iAEItemKey.gtolib$setReadOnlyStack(itemStack);
        this.a[n] = new b.a<ItemStack, AEItemKey>(itemStack, aEItemKey, n2);
        return aEItemKey;
    }
}

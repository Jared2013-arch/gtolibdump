package com.gtolib.a;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.gtolib.api.misc.IMapValueCache;
import it.unimi.dsi.fastutil.Hash;
import it.unimi.dsi.fastutil.HashCommon;
import java.lang.ref.SoftReference;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

public class b<K, V>
implements IMapValueCache<K, V> {
    private static final ThreadFactory b = new ThreadFactoryBuilder().setNameFormat("Cache Clean Thread-%d").setDaemon(true).build();
    private final Hash.Strategy<K> c;
    private final Function<K, V> d;
    protected a<K, V>[] a;
    private int e;
    private int f;
    private int g;
    private int h;

    public b(Hash.Strategy<K> strategy, Function<K, V> function, boolean bl) {
        this.c = strategy;
        this.d = function;
        this.f = HashCommon.arraySize(16, 0.75f);
        this.e = this.f - 1;
        this.g = HashCommon.maxFill(this.f, 0.75f);
        this.a = new a[this.f + 1];
        if (bl) {
            Executors.newSingleThreadScheduledExecutor(b).scheduleAtFixedRate(this::a, 1L, 30L, TimeUnit.SECONDS);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public V get(K k) {
        int n = this.c.hashCode(k);
        b b2 = this;
        synchronized (b2) {
            a<K, V>[] aArray = this.a;
            int n2 = this.e;
            int n3 = HashCommon.mix(n) & n2;
            a<K, V> a2 = aArray[n3];
            if (a2 == null) {
                n3 = -(n3 + 1);
            } else if (n != a2.b || !this.c.equals(k, a2.a)) {
                do {
                    if ((a2 = aArray[n3 = n3 + 1 & n2]) != null) continue;
                    n3 = -(n3 + 1);
                    break;
                } while (n != a2.b || !this.c.equals(k, a2.a));
            }
            if (n3 >= 0) {
                a<K, V> a3 = aArray[n3];
                Object t = a3.get();
                if (t != null) {
                    return (V)t;
                }
                return this.a(n3, n, a3.a);
            }
            V v = this.a(-n3 - 1, n, k);
            if (this.h++ >= this.g) {
                this.a(HashCommon.arraySize(this.h + 1, 0.75f));
            }
            return v;
        }
    }

    protected V a(int n, int n2, K k) {
        V v = this.d.apply(k);
        this.a[n] = new a<K, V>(k, v, n2);
        return v;
    }

    private void a(int n) {
        a<K, V>[] aArray = this.a;
        int n2 = n - 1;
        a[] aArray2 = new a[n + 1];
        int n3 = this.f;
        int n4 = this.h;
        while (n4-- != 0) {
            while (aArray[--n3] == null) {
            }
            int n5 = HashCommon.mix(aArray[n3].b) & n2;
            if (aArray2[n5] != null) {
                while (aArray2[n5 = n5 + 1 & n2] != null) {
                }
            }
            aArray2[n5] = aArray[n3];
        }
        this.f = n;
        this.e = n2;
        this.g = HashCommon.maxFill(this.f, 0.75f);
        this.a = aArray2;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void a() {
        b b2 = this;
        synchronized (b2) {
            for (a<K, V> a2 : this.a) {
                if (a2 == null || a2.get() != null) continue;
                this.a[var2_2] = null;
                --this.h;
            }
            if (this.h < 0) {
                this.h = 0;
            }
            if (this.h < this.g / 2) {
                this.a(HashCommon.arraySize(this.h + 1, 0.75f));
            }
        }
    }

    protected static class a<K, V>
    extends SoftReference<V> {
        private final K a;
        private final int b;

        protected a(K k, V v, int n) {
            super(v);
            this.a = k;
            this.b = n;
        }
    }
}

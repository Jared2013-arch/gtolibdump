package com.gtolib.mixin.bootstrap;

import appeng.core.AEConfig;
import com.gtolib.e.a;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={AEConfig.class})
public class AEConfigMixin {
    @Overwrite(remap=false)
    public boolean isPortableCellDisassemblyEnabled() {
        return false;
    }

    @Inject(method={"syncCommonConfig"}, at={@At(value="TAIL")}, remap=false)
    public void syncCommonConfig(CallbackInfo callbackInfo) {
        a.a();
    }
}

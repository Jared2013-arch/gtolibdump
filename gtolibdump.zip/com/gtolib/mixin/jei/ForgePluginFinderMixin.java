package com.gtolib.mixin.jei;

import com.gtocore.integration.emi.GTEMIPlugin;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import mezz.jei.api.IModPlugin;
import mezz.jei.forge.startup.ForgePluginFinder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={ForgePluginFinder.class})
public final class ForgePluginFinderMixin {
    @Overwrite(remap=false)
    public static List<IModPlugin> getModPlugins() {
        ObjectArrayList objectArrayList = new ObjectArrayList();
        GTEMIPlugin.addJEIPlugin(objectArrayList);
        return objectArrayList;
    }
}

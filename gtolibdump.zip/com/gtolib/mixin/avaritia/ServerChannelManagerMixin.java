package com.gtolib.mixin.avaritia;

import committee.nova.mods.avaritia.core.channel.ServerChannelManager;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.LevelEvent;
import net.minecraftforge.event.server.ServerAboutToStartEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={ServerChannelManager.class})
public class ServerChannelManagerMixin {
    @Overwrite(remap=false)
    @SubscribeEvent
    public static void onServerLoad(ServerAboutToStartEvent serverAboutToStartEvent) {
    }

    @Overwrite(remap=false)
    @SubscribeEvent
    public void onPlayerJoin(PlayerEvent.PlayerLoggedInEvent playerLoggedInEvent) {
    }

    @Overwrite(remap=false)
    @SubscribeEvent
    public void onTick(TickEvent.ServerTickEvent serverTickEvent) {
    }

    @Overwrite(remap=false)
    @SubscribeEvent
    public void onLevelSave(LevelEvent.Save save) {
    }
}

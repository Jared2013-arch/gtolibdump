package com.gtolib.mixin.avaritia;

import committee.nova.mods.avaritia.api.init.event.RegisterRecipesEvent;
import committee.nova.mods.avaritia.init.handler.InternalRecipeHandler;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={InternalRecipeHandler.class})
public final class InternalRecipeHandlerMixin {
    @Overwrite(remap=false)
    @SubscribeEvent
    public static void onRegisterRecipes(RegisterRecipesEvent registerRecipesEvent) {
    }
}

package com.gtolib.mixin.avaritia;

import com.gtolib.api.player.IEnhancedPlayer;
import com.llamalad7.mixinextras.sugar.Local;
import committee.nova.mods.avaritia.init.handler.AbilityHandler;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={AbilityHandler.class})
public abstract class AbilityHandlerMixin {
    @ModifyArg(method={"updateAbilities"}, at=@At(value="INVOKE", target="Lcommittee/nova/mods/avaritia/init/handler/AbilityHandler;handleChestStateChange(Lnet/minecraft/world/entity/player/Player;Ljava/lang/String;Z)V"), index=2, remap=false)
    private static boolean modify(boolean bl, @Local Player player) {
        if (!bl && player instanceof IEnhancedPlayer) {
            IEnhancedPlayer iEnhancedPlayer = (IEnhancedPlayer)((Object)player);
            return iEnhancedPlayer.getPlayerData().canFly();
        }
        return true;
    }

    @Inject(method={"handleChestStateChange"}, at={@At(value="INVOKE", target="Lcom/google/common/collect/Lists;newArrayList(Ljava/lang/Iterable;)Ljava/util/ArrayList;")}, remap=false, cancellable=true)
    private static void change(Player player, String string, boolean bl, CallbackInfo callbackInfo) {
        IEnhancedPlayer iEnhancedPlayer;
        if (!bl && player instanceof IEnhancedPlayer && (iEnhancedPlayer = (IEnhancedPlayer)((Object)player)).getPlayerData().canFly()) {
            callbackInfo.cancel();
        }
    }
}

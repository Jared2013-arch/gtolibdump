package com.gtolib.mixin.avaritia;

import committee.nova.mods.avaritia.init.handler.InfinityHandler;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={InfinityHandler.class})
public class InfinityHandlerMixin {
    @SubscribeEvent(priority=EventPriority.HIGHEST)
    @Overwrite(remap=false)
    public static void onDeath(LivingDeathEvent livingDeathEvent) {
    }
}

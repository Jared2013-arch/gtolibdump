package com.gtolib.mixin.oculus;

import com.llamalad7.mixinextras.sugar.Local;
import java.util.function.Function;
import kroppeb.stareval.function.Type;
import kroppeb.stareval.resolver.ExpressionResolver;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={ExpressionResolver.class})
public class ExpressionResolverMixin {
    @Redirect(method={"resolveExpressionInternal"}, at=@At(value="INVOKE", target="Ljava/util/function/Function;apply(Ljava/lang/Object;)Ljava/lang/Object;"), remap=false)
    public Object resolveExpressionInternal$apply(Function function, Object object, @Local(argsOnly=true) Type type) {
        Object object2 = function.apply(object);
        if (object2 == null) {
            object2 = type;
        }
        return object2;
    }
}

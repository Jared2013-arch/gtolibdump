package com.gtolib.mixin.forge;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.items.ItemHandlerHelper;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={ItemHandlerHelper.class})
public class ItemHandlerHelperMixin {
    @Overwrite(remap=false)
    public static boolean canItemStacksStack(@NotNull ItemStack itemStack, @NotNull ItemStack itemStack2) {
        Item item = itemStack.m_41720_();
        if (item == Items.f_41852_) {
            return false;
        }
        Item item2 = itemStack2.m_41720_();
        if (item == item2) {
            CompoundTag compoundTag = itemStack.m_41783_();
            CompoundTag compoundTag2 = itemStack2.m_41783_();
            if (compoundTag == null || compoundTag.m_128456_()) {
                return compoundTag2 == null || compoundTag2.m_128456_();
            }
            return compoundTag.equals(compoundTag2);
        }
        return false;
    }

    @Overwrite(remap=false)
    public static boolean canItemStacksStackRelaxed(@NotNull ItemStack itemStack, @NotNull ItemStack itemStack2) {
        Item item = itemStack.m_41720_();
        if (item == Items.f_41852_) {
            return false;
        }
        Item item2 = itemStack2.m_41720_();
        if (item == item2) {
            CompoundTag compoundTag = itemStack.m_41783_();
            CompoundTag compoundTag2 = itemStack2.m_41783_();
            if (compoundTag == null || compoundTag.m_128456_()) {
                return compoundTag2 == null || compoundTag2.m_128456_();
            }
            if (!itemStack.m_41753_()) {
                return false;
            }
            return compoundTag.equals(compoundTag2);
        }
        return false;
    }
}

package com.gtolib.mixin.forge;

import com.gtolib.utils.EmptyStream;
import java.util.stream.Stream;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.common.crafting.StrictNBTIngredient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={StrictNBTIngredient.class})
public class StrictNBTIngredientMixin {
    @Redirect(method={"<init>"}, at=@At(value="INVOKE", target="Ljava/util/stream/Stream;of(Ljava/lang/Object;)Ljava/util/stream/Stream;"), remap=false)
    private static Stream<? extends Ingredient.Value> of(Object object) {
        return EmptyStream.create(new Ingredient.Value[]{(Ingredient.Value)object});
    }
}

package com.gtolib.mixin.gtmt;

import com.hepdd.gtmthings.forge.ForgeCommonEventListener;
import net.minecraftforge.event.level.LevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={ForgeCommonEventListener.class})
public final class ForgeCommonEventListenerMixin {
    @SubscribeEvent
    @Overwrite(remap=false)
    public static void serverSetup(LevelEvent.Load load) {
    }
}

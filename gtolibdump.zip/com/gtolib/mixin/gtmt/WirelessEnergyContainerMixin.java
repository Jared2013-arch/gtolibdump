package com.gtolib.mixin.gtmt;

import com.gtolib.api.wireless.ExtendWirelessEnergyContainer;
import com.hepdd.gtmthings.api.misc.WirelessEnergyContainer;
import com.hepdd.gtmthings.data.WirelessEnergySavaedData;
import com.hepdd.gtmthings.utils.TeamUtil;
import java.util.UUID;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={WirelessEnergyContainer.class})
public final class WirelessEnergyContainerMixin {
    @Overwrite(remap=false)
    public static WirelessEnergyContainer getOrCreateContainer(UUID uUID) {
        return WirelessEnergySavaedData.INSTANCE.containerMap.computeIfAbsent(TeamUtil.getTeamUUID(uUID), ExtendWirelessEnergyContainer::new);
    }
}

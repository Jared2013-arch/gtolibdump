package com.gtolib.mixin.gtmt;

import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.machine.MachineDefinition;
import com.gregtechceu.gtceu.api.machine.multiblock.MultiblockControllerMachine;
import com.gregtechceu.gtceu.api.registry.registrate.GTRegistrate;
import com.gregtechceu.gtceu.api.registry.registrate.MachineBuilder;
import com.gtocore.common.machine.multiblock.part.ae.MEDualOutputPartMachine;
import com.hepdd.gtmthings.data.CustomMachines;
import java.util.function.Function;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={CustomMachines.class})
public class CustomMachinesMixin {
    @Redirect(method={"<clinit>"}, at=@At(value="INVOKE", target="Lcom/gregtechceu/gtceu/api/registry/registrate/GTRegistrate;machine(Ljava/lang/String;Ljava/util/function/Function;)Lcom/gregtechceu/gtceu/api/registry/registrate/MachineBuilder;"), remap=false)
    private static MachineBuilder<MachineDefinition> me_export_buffer(GTRegistrate gTRegistrate, String string, Function<MetaMachineBlockEntity, ? extends MultiblockControllerMachine> function) {
        return gTRegistrate.machine("me_export_buffer", MEDualOutputPartMachine::new);
    }
}

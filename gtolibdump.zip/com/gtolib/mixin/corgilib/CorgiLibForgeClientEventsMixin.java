package com.gtolib.mixin.corgilib;

import corgitaco.corgilib.forge.client.CorgiLibForgeClientEvents;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={CorgiLibForgeClientEvents.class})
public final class CorgiLibForgeClientEventsMixin {
    @Overwrite(remap=false)
    @SubscribeEvent
    public static void screenInit(ScreenEvent.Init.Post post) {
    }

    @Overwrite(remap=false)
    @SubscribeEvent
    public static void playerTick(TickEvent.PlayerTickEvent playerTickEvent) {
    }

    @Overwrite(remap=false)
    @SubscribeEvent
    public static void registerClientCommands(RegisterClientCommandsEvent registerClientCommandsEvent) {
    }
}

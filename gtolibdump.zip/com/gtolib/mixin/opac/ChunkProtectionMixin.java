package com.gtolib.mixin.opac;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.SectionPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.apache.commons.lang3.function.TriFunction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import xaero.pac.common.parties.party.IPartyPlayerInfo;
import xaero.pac.common.parties.party.ally.IPartyAlly;
import xaero.pac.common.parties.party.member.IPartyMember;
import xaero.pac.common.server.IServerData;
import xaero.pac.common.server.claims.protection.ChunkProtection;
import xaero.pac.common.server.parties.party.IServerParty;
import xaero.pac.common.server.player.config.IPlayerConfig;
import xaero.pac.common.server.player.config.api.IPlayerConfigAPI;
import xaero.pac.common.server.player.config.api.IPlayerConfigOptionSpecAPI;

@Mixin(value={ChunkProtection.class})
public class ChunkProtectionMixin {
    @Overwrite(remap=false)
    public boolean hasChunkAccess(IPlayerConfigAPI iPlayerConfigAPI, Entity entity, UUID uUID) {
        return true;
    }

    @Overwrite(remap=false)
    public boolean onBlockInteraction(IServerData<?, ?> iServerData, BlockState blockState, Entity entity, InteractionHand interactionHand, ItemStack itemStack, ServerLevel serverLevel, BlockPos blockPos, Direction direction, boolean bl, boolean bl2) {
        return false;
    }

    @Overwrite(remap=false)
    public boolean onEntityPlaceBlock(IServerData<?, ?> iServerData, Entity entity, ServerLevel serverLevel, BlockPos blockPos, IPlayerConfigOptionSpecAPI<Integer> iPlayerConfigOptionSpecAPI) {
        return false;
    }

    @Overwrite(remap=false)
    public boolean onItemRightClick(IServerData<?, ?> iServerData, InteractionHand interactionHand, ItemStack itemStack, BlockPos blockPos, LivingEntity livingEntity, boolean bl) {
        return false;
    }

    @Overwrite(remap=false)
    public boolean onMobGrief(IServerData<?, ?> iServerData, Entity entity) {
        return false;
    }

    @Overwrite(remap=false)
    public boolean onEntityInteraction(IServerData<?, ?> iServerData, Entity entity, Entity entity2, Entity entity3, ItemStack itemStack, InteractionHand interactionHand, boolean bl, boolean bl2, boolean bl3) {
        return false;
    }

    @Overwrite(remap=false)
    public boolean onEntityFire(IServerData<?, ?> iServerData, Entity entity) {
        return false;
    }

    @Overwrite(remap=false)
    public void onEntityEnterChunk(IServerData<?, ?> iServerData, Entity entity, double d, double d2, SectionPos sectionPos, SectionPos sectionPos2) {
    }

    @Overwrite(remap=false)
    public boolean onChorusFruitTeleport(IServerData<?, ?> iServerData, Vec3 vec3, Entity entity) {
        return false;
    }

    @Overwrite(remap=false)
    public void onLightningBolt(IServerData<?, ?> iServerData, LightningBolt lightningBolt) {
    }

    @Overwrite(remap=false)
    public boolean onCropTrample(IServerData<?, ?> iServerData, Entity entity, BlockPos blockPos) {
        return false;
    }

    @Overwrite(remap=false)
    public boolean onUseItemAt(IServerData<?, ?> iServerData, Entity entity, ServerLevel serverLevel, BlockPos blockPos, Direction direction, ItemStack itemStack, InteractionHand interactionHand, boolean bl, boolean bl2, boolean bl3) {
        return false;
    }

    @Overwrite(remap=false)
    public boolean onFluidSpread(IServerData<?, ?> iServerData, ServerLevel serverLevel, BlockPos blockPos, BlockPos blockPos2) {
        return false;
    }

    @Overwrite(remap=false)
    public boolean onDispenseFrom(IServerData<?, ?> iServerData, ServerLevel serverLevel, BlockPos blockPos) {
        return false;
    }

    @Overwrite(remap=false)
    public boolean onPistonPush(IServerData<?, ?> iServerData, ServerLevel serverLevel, List<BlockPos> list, List<BlockPos> list2, BlockPos blockPos, Direction direction, boolean bl) {
        return false;
    }

    @Overwrite(remap=false)
    public void onEntitiesPushBlock(IServerData<?, ?> iServerData, ServerLevel serverLevel, BlockPos blockPos, Block block, List<? extends Entity> list) {
    }

    @Overwrite(remap=false)
    public void onEntitiesCollideWithEntity(IServerData<?, ?> iServerData, Entity entity, List<? extends Entity> list) {
    }

    @Overwrite(remap=false)
    public void onEntityAffectsEntities(IServerData<?, IServerParty<IPartyMember, IPartyPlayerInfo, IPartyAlly>> iServerData, Entity entity, List<Entity> list) {
    }

    @Overwrite(remap=false)
    public boolean onNetherPortal(IServerData<?, ?> iServerData, Entity entity, ServerLevel serverLevel, BlockPos blockPos) {
        return false;
    }

    @Overwrite(remap=false)
    public boolean onRaidSpawn(IServerData<?, ?> iServerData, ServerLevel serverLevel, BlockPos blockPos) {
        return false;
    }

    @Overwrite(remap=false)
    public boolean onMobSpawn(IServerData<?, ?> iServerData, Entity entity, double d, double d2, double d3, MobSpawnType mobSpawnType) {
        return false;
    }

    @Overwrite(remap=false)
    public boolean onItemAddedToWorld(IServerData<?, ?> iServerData, ItemEntity itemEntity) {
        return false;
    }

    @Overwrite(remap=false)
    public boolean onLivingLootEntity(IServerData<?, ?> iServerData, LivingEntity livingEntity, Entity entity, DamageSource damageSource) {
        return false;
    }

    @Overwrite(remap=false)
    public boolean onEntityPickup(IServerData<?, ?> iServerData, Entity entity, Entity entity2, UUID uUID, UUID uUID2, Map<Entity, Set<ChunkPos>> map, TriFunction<IPlayerConfig, Entity, Entity, IPlayerConfigOptionSpecAPI<Integer>> triFunction) {
        return false;
    }

    @Overwrite(remap=false)
    public boolean onItemPickup(IServerData<?, ?> iServerData, Entity entity, ItemEntity itemEntity) {
        return false;
    }

    @Overwrite(remap=false)
    public boolean onEntityMerge(IServerData<?, ?> iServerData, Entity entity, UUID uUID, UUID uUID2, Entity entity2, UUID uUID3, UUID uUID4, IPlayerConfigOptionSpecAPI<Integer> iPlayerConfigOptionSpecAPI, IPlayerConfigOptionSpecAPI<Integer> iPlayerConfigOptionSpecAPI2, IPlayerConfigOptionSpecAPI<Boolean> iPlayerConfigOptionSpecAPI3) {
        return false;
    }

    @Overwrite(remap=false)
    public boolean onCreateMod(IServerData<?, ?> iServerData, ServerLevel serverLevel, int n, int n2, @Nullable BlockPos blockPos, boolean bl, boolean bl2, boolean bl3) {
        return false;
    }

    @Overwrite(remap=false)
    public <E> boolean onCreateModAffectPositionedObjects(IServerData<?, ?> iServerData, ServerLevel serverLevel, List<E> list, Function<E, ChunkPos> function, BlockPos blockPos, boolean bl, boolean bl2, boolean bl3, boolean bl4) {
        return false;
    }
}

package com.gtolib.mixin.deeperdarker;

import com.kyanite.deeperdarker.content.DDItems;
import com.kyanite.deeperdarker.util.DDTiers;
import java.util.function.Supplier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(value={DDItems.class})
public class DDItemsMixin {
    @ModifyArg(method={"<clinit>"}, at=@At(value="INVOKE", target="Lnet/minecraftforge/registries/DeferredRegister;register(Ljava/lang/String;Ljava/util/function/Supplier;)Lnet/minecraftforge/registries/RegistryObject;", ordinal=36), remap=false, index=1)
    private static Supplier<? extends Item> wardenSword(Supplier<? extends Item> supplier) {
        return () -> new SwordItem(DDTiers.WARDEN, 300, -2.4f, new Item.Properties().m_41497_(Rarity.RARE).m_41486_());
    }
}

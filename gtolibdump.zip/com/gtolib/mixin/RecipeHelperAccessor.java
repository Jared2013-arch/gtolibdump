package com.gtolib.mixin;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import dev.shadowsoffire.placebo.recipe.RecipeHelper;
import java.util.function.Consumer;
import net.minecraft.world.item.crafting.RecipeManager;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={RecipeHelper.class})
public interface RecipeHelperAccessor {
    @Accessor(value="PROVIDERS", remap=false)
    @NotNull
    public static Multimap<String, Consumer<RecipeHelper.RecipeFactory>> getProviders() {
        return HashMultimap.create();
    }

    @Invoker(value="addRecipes", remap=false)
    public static void addRecipes(RecipeManager recipeManager) {
    }
}

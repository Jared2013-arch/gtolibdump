package com.gtolib.mixin.modernfix;

import com.gregtechceu.gtceu.GTCEu;
import com.gtocore.common.CommonProxy;
import com.gtolib.c.b;
import org.embeddedt.modernfix.util.ClassInfoManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={ClassInfoManager.class})
public class ClassInfoManagerMixin {
    @Shadow(remap=false)
    private static boolean hasRun;

    @Inject(method={"clear"}, at={@At(value="HEAD")}, remap=false, cancellable=true)
    private static void clear(CallbackInfo callbackInfo) {
        if (hasRun) {
            return;
        }
        CommonProxy.afterStartup();
        if (GTCEu.isClientSide()) {
            b.a();
            return;
        }
        callbackInfo.cancel();
    }
}

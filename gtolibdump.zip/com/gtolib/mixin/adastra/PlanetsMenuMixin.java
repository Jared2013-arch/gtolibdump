package com.gtolib.mixin.adastra;

import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtolib.adastra.IAdDisplayTagName;
import earth.terrarium.adastra.common.handlers.base.SpaceStation;
import earth.terrarium.adastra.common.menus.PlanetsMenu;
import earth.terrarium.adastra.common.recipes.SpaceStationRecipe;
import earth.terrarium.adastra.common.recipes.base.IngredientHolder;
import earth.terrarium.adastra.common.registry.ModRecipeTypes;
import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.GlobalPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={PlanetsMenu.class})
public class PlanetsMenuMixin
implements IAdDisplayTagName {
    @Shadow(remap=false)
    @Final
    protected Player player;
    @Shadow(remap=false)
    @Final
    protected int tier;
    @Final
    @Shadow(remap=false)
    protected Level level;
    @Final
    @Shadow(remap=false)
    protected Inventory inventory;
    @Unique
    protected Map<ResourceKey<Level>, List<IAdDisplayTagName.CountIngredient>> gtocore$planetItems = null;

    @Inject(method={"tier"}, at={@At(value="HEAD")}, remap=false, cancellable=true)
    private void tier(CallbackInfoReturnable<Integer> callbackInfoReturnable) {
        if (this.tier == 100) {
            callbackInfoReturnable.setReturnValue((Object)10);
        }
    }

    @Inject(method={"<init>(ILnet/minecraft/world/entity/player/Inventory;Ljava/util/Set;Ljava/util/Map;Lit/unimi/dsi/fastutil/objects/Object2BooleanMap;Ljava/util/Set;)V"}, at={@At(value="TAIL")}, remap=false)
    private void adastra$init(int n, Inventory inventory, Set<ResourceLocation> set, Map<ResourceKey<Level>, Map<UUID, Set<SpaceStation>>> map, Object2BooleanMap<ResourceKey<Level>> object2BooleanMap, Set<GlobalPos> set2, CallbackInfo callbackInfo) {
        this.gtocore$planetItems = this.gtocore$getSpaceStationRecipes();
    }

    @Unique
    private Map<ResourceKey<Level>, List<IAdDisplayTagName.CountIngredient>> gtocore$getSpaceStationRecipes() {
        List list = this.level.m_7465_().m_44013_((RecipeType)ModRecipeTypes.SPACE_STATION_RECIPE.get());
        O2OOpenCacheHashMap o2OOpenCacheHashMap = new O2OOpenCacheHashMap(list.size());
        for (SpaceStationRecipe spaceStationRecipe : list) {
            for (IngredientHolder ingredientHolder : spaceStationRecipe.ingredients()) {
                int n = 0;
                for (int i = 0; i < this.inventory.m_6643_(); ++i) {
                    ItemStack itemStack = this.inventory.m_8020_(i);
                    if (!ingredientHolder.ingredient().test(itemStack)) continue;
                    n += itemStack.m_41613_();
                }
                o2OOpenCacheHashMap.computeIfAbsent(spaceStationRecipe.dimension(), resourceKey -> new ObjectArrayList()).add(new IAdDisplayTagName.CountIngredient(ingredientHolder.ingredient(), ingredientHolder.count(), n));
            }
        }
        return o2OOpenCacheHashMap;
    }

    @Override
    public Map<ResourceKey<Level>, List<IAdDisplayTagName.CountIngredient>> gtocore$getAdastraDisplayTagNames() {
        return this.gtocore$planetItems;
    }
}

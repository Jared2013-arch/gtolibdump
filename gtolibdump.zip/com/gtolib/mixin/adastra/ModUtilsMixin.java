package com.gtolib.mixin.adastra;

import com.gregtechceu.gtceu.GTCEu;
import com.gtolib.api.misc.PlanetManagement;
import earth.terrarium.adastra.api.planets.Planet;
import earth.terrarium.adastra.common.config.AdAstraConfig;
import earth.terrarium.adastra.common.entities.vehicles.Lander;
import earth.terrarium.adastra.common.entities.vehicles.Rocket;
import earth.terrarium.adastra.common.menus.PlanetsMenu;
import earth.terrarium.adastra.common.registry.ModEntityTypes;
import earth.terrarium.adastra.common.utils.ModUtils;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={ModUtils.class})
public final class ModUtilsMixin {
    @Overwrite(remap=false)
    public static boolean canTeleportToPlanet(Player player, Planet planet) {
        if (GTCEu.isDev() || player.m_20137_("spaceelevatorst")) {
            player.m_20049_("canTeleportToPlanet");
            return true;
        }
        if (!(player.f_36096_ instanceof PlanetsMenu)) {
            return false;
        }
        if (!player.m_7500_() && !player.m_5833_()) {
            String[] stringArray;
            for (String string : stringArray = AdAstraConfig.disabledPlanets.split(",")) {
                if (!string.equals(planet.dimension().m_135782_().toString())) continue;
                return false;
            }
            Entity entity = player.m_20202_();
            if (entity instanceof Rocket) {
                Rocket rocket = (Rocket)((Object)entity);
                if (rocket.m_20186_() < (double)AdAstraConfig.atmosphereLeave) {
                    return false;
                }
                return PlanetManagement.calculateTier(planet, rocket.m_9236_().m_46472_().m_135782_()) <= rocket.tier();
            }
            return false;
        }
        return true;
    }

    @Inject(method={"land"}, at={@At(value="HEAD")}, remap=false, cancellable=true)
    private static void land(ServerPlayer serverPlayer, ServerLevel serverLevel, Vec3 vec3, CallbackInfo callbackInfo) {
        if (serverPlayer.m_20137_("canTeleportToPlanet")) {
            callbackInfo.cancel();
            serverPlayer.m_20219_(vec3);
            Lander lander = (Lander)((EntityType)ModEntityTypes.LANDER.get()).m_20615_(serverLevel);
            if (lander == null) {
                return;
            }
            lander.m_146884_(vec3);
            serverLevel.m_7967_(lander);
            ModUtils.teleportToDimension(serverPlayer, serverLevel).m_20329_(lander);
        }
    }
}

package com.gtolib.mixin.adastra;

import earth.terrarium.adastra.AdAstra;
import earth.terrarium.adastra.api.systems.GravityApi;
import earth.terrarium.adastra.api.systems.OxygenApi;
import earth.terrarium.adastra.api.systems.PlanetData;
import earth.terrarium.adastra.api.systems.TemperatureApi;
import earth.terrarium.adastra.common.network.NetworkHandler;
import earth.terrarium.adastra.common.network.messages.ClientboundSyncLocalPlanetDataPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={AdAstra.class})
public final class AdAstraMixin {
    @Redirect(method={"init"}, at=@At(value="INVOKE", target="Learth/terrarium/adastra/common/utils/radio/StationLoader;init()V"), remap=false)
    private static void stationLoader() {
    }

    @Overwrite(remap=false)
    public static void onServerTick(MinecraftServer minecraftServer) {
        if (minecraftServer.m_129921_() % 40 == 0) {
            minecraftServer.m_6846_().m_11314_().forEach(serverPlayer -> NetworkHandler.CHANNEL.sendToPlayer(new ClientboundSyncLocalPlanetDataPacket(new PlanetData(OxygenApi.API.hasOxygen((Entity)serverPlayer), TemperatureApi.API.getTemperature((Entity)serverPlayer), GravityApi.API.getGravity((Entity)serverPlayer))), (ServerPlayer)serverPlayer));
        }
    }
}

package com.gtolib.mixin.adastra;

import com.gtolib.d;
import earth.terrarium.adastra.api.planets.Planet;
import earth.terrarium.adastra.common.planets.PlanetApiImpl;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={PlanetApiImpl.class})
public class PlanetApiImplMixin {
    @Overwrite(remap=false)
    @Nullable
    public Planet getPlanet(Level level) {
        return ((d)((Object)level)).gtolib$getPlanet();
    }

    @Overwrite(remap=false)
    public boolean isPlanet(Level level) {
        return ((d)((Object)level)).gtolib$getPlanet() != null;
    }

    @Overwrite(remap=false)
    public boolean isSpace(Level level) {
        Planet planet = ((d)((Object)level)).gtolib$getPlanet();
        if (planet != null) {
            return planet.isSpace();
        }
        return false;
    }

    @Overwrite(remap=false)
    public long getSolarPower(Level level) {
        Planet planet = ((d)((Object)level)).gtolib$getPlanet();
        if (planet != null) {
            return planet.solarPower();
        }
        return 16L;
    }
}

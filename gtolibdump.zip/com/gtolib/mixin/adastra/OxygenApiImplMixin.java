package com.gtolib.mixin.adastra;

import com.gtolib.d;
import earth.terrarium.adastra.api.planets.Planet;
import earth.terrarium.adastra.common.systems.OxygenApiImpl;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={OxygenApiImpl.class})
public class OxygenApiImplMixin {
    @Overwrite(remap=false)
    public boolean hasOxygen(Level level) {
        Planet planet = ((d)((Object)level)).gtolib$getPlanet();
        if (planet != null) {
            return planet.oxygen();
        }
        return true;
    }
}

package com.gtolib.mixin.adastra;

import com.gtolib.d;
import earth.terrarium.adastra.api.planets.Planet;
import earth.terrarium.adastra.common.systems.TemperatureApiImpl;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={TemperatureApiImpl.class})
public class TemperatureApiImplMixin {
    @Overwrite(remap=false)
    public short getTemperature(Level level) {
        Planet planet = ((d)((Object)level)).gtolib$getPlanet();
        if (planet != null) {
            return planet.temperature();
        }
        return 15;
    }
}

package com.gtolib.mixin.adastra;

import com.gtolib.d;
import earth.terrarium.adastra.api.planets.Planet;
import earth.terrarium.adastra.common.systems.GravityApiImpl;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={GravityApiImpl.class})
public class GravityApiImplMixin {
    @Overwrite(remap=false)
    public float getGravity(Level level) {
        Planet planet = ((d)((Object)level)).gtolib$getPlanet();
        if (planet != null) {
            return planet.gravity() / 9.807f;
        }
        return 1.0f;
    }
}

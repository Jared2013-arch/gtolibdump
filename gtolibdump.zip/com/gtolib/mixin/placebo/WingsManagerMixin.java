package com.gtolib.mixin.placebo;

import dev.shadowsoffire.placebo.patreon.WingsManager;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={WingsManager.class})
public final class WingsManagerMixin {
    @Overwrite(remap=false)
    public static void init(FMLClientSetupEvent fMLClientSetupEvent) {
    }

    @Overwrite(remap=false)
    public static void addLayers(EntityRenderersEvent.AddLayers addLayers) {
    }

    @SubscribeEvent
    @Overwrite(remap=false)
    public static void keys(InputEvent.Key key) {
    }
}

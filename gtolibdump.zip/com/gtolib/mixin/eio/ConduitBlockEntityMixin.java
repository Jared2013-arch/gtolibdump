package com.gtolib.mixin.eio;

import com.enderio.api.conduit.ConduitType;
import com.enderio.conduits.common.conduit.block.ConduitBlockEntity;
import com.enderio.conduits.common.menu.ConduitMenu;
import com.enderio.core.common.blockentity.EnderBlockEntity;
import com.gtolib.d.a;
import java.lang.ref.WeakReference;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={ConduitBlockEntity.class})
public abstract class ConduitBlockEntityMixin
extends EnderBlockEntity
implements a {
    @Shadow(remap=false)
    private ConduitBlockEntity.UpdateState checkConnection;
    @Unique
    private boolean gtolib$update;
    @Unique
    private WeakReference<ServerPlayer> gtolib$player;

    @Shadow(remap=false)
    public abstract void updateConnections(Level var1, BlockPos var2, @Nullable BlockPos var3, boolean var4);

    @Shadow(remap=false)
    public abstract MenuProvider menuProvider(Direction var1, ConduitType<?> var2);

    @Inject(method={"<init>"}, at={@At(value="TAIL")}, remap=false)
    private void init(CallbackInfo callbackInfo) {
        this.gtolib$update = true;
    }

    protected ConduitBlockEntityMixin(BlockEntityType<?> blockEntityType, BlockPos blockPos, BlockState blockState) {
        super(blockEntityType, blockPos, blockState);
    }

    @Overwrite(remap=false)
    public void everyTick() {
        if (this.f_58857_ != null && !this.f_58857_.f_46443_) {
            ServerPlayer serverPlayer;
            this.checkConnection = this.checkConnection.next();
            if (this.checkConnection.isInitialized()) {
                this.updateConnections(this.f_58857_, this.f_58858_, null, false);
            }
            boolean bl = false;
            if (this.gtolib$player != null && (serverPlayer = (ServerPlayer)this.gtolib$player.get()) != null && serverPlayer.f_36096_ instanceof ConduitMenu) {
                bl = true;
            }
            if (this.gtolib$update || bl) {
                this.sync();
                this.gtolib$update = false;
            }
        }
    }

    @Inject(method={"updateConnections"}, at={@At(value="TAIL")}, remap=false)
    private void update(Level level, BlockPos blockPos, BlockPos blockPos2, boolean bl, CallbackInfo callbackInfo) {
        if (bl) {
            this.gtolib$update = true;
        }
    }

    @Override
    @NotNull
    public MenuProvider gtolib$menuProvider(ServerPlayer serverPlayer, Direction direction, ConduitType<?> conduitType) {
        this.gtolib$player = new WeakReference<ServerPlayer>(serverPlayer);
        return this.menuProvider(direction, conduitType);
    }
}

package com.gtolib.mixin.eio;

import com.enderio.api.conduit.ConduitType;
import com.enderio.api.conduit.SlotType;
import com.enderio.conduits.common.conduit.ConduitGraphObject;
import com.enderio.conduits.common.conduit.block.ConduitBlockEntity;
import com.enderio.conduits.common.conduit.connection.ConnectionState;
import com.enderio.conduits.common.conduit.connection.DynamicConnectionState;
import com.enderio.conduits.common.conduit.connection.StaticConnectionStates;
import java.util.Arrays;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(targets={"com.enderio.conduits.common.conduit.ConduitBundle$ConduitConnection"})
public class ConduitConnectionMixin {
    @Shadow(remap=false)
    @Final
    private ConnectionState[] connectionStates;
    @Unique
    private boolean gtolib$change;
    @Unique
    private int gtolib$hashCode;

    @Overwrite(remap=false)
    public void addType(int n) {
        for (int i = 8; i > n; --i) {
            this.setConnectionState(i, this.connectionStates[i - 1]);
        }
        this.setConnectionState(n, StaticConnectionStates.DISCONNECTED);
    }

    @Overwrite(remap=false)
    public void connectTo(Level level, BlockPos blockPos, ConduitGraphObject<?> conduitGraphObject, Direction direction, ConduitType<?> conduitType, int n, boolean bl) {
        if (bl) {
            DynamicConnectionState dynamicConnectionState = DynamicConnectionState.defaultConnection(level, blockPos, direction, conduitType);
            this.setConnectionState(n, dynamicConnectionState);
            ConduitBlockEntity.pushIOState(direction, conduitGraphObject, dynamicConnectionState);
        } else {
            this.setConnectionState(n, StaticConnectionStates.CONNECTED);
        }
    }

    @Overwrite(remap=false)
    public void tryDisconnect(int n) {
        if (this.connectionStates[n] != StaticConnectionStates.DISABLED) {
            this.setConnectionState(n, StaticConnectionStates.DISCONNECTED);
        }
    }

    @Overwrite(remap=false)
    public void removeType(int n) {
        this.setConnectionState(n, StaticConnectionStates.DISCONNECTED);
        for (int i = n + 1; i < 9; ++i) {
            this.setConnectionState(i - 1, this.connectionStates[i]);
        }
        this.setConnectionState(8, StaticConnectionStates.DISCONNECTED);
    }

    @Overwrite(remap=false)
    public void disconnectType(int n) {
        this.setConnectionState(n, StaticConnectionStates.DISCONNECTED);
    }

    @Overwrite(remap=false)
    public void disableType(int n) {
        this.setConnectionState(n, StaticConnectionStates.DISABLED);
    }

    @Overwrite(remap=false)
    public void setConnectionState(int n, ConnectionState connectionState) {
        if (this.connectionStates[n] != connectionState) {
            this.connectionStates[n] = connectionState;
            this.gtolib$change = true;
        }
    }

    @Overwrite(remap=false)
    public void setItem(SlotType slotType, int n, ItemStack itemStack) {
        ConnectionState connectionState = this.connectionStates[n];
        if (connectionState instanceof DynamicConnectionState) {
            DynamicConnectionState dynamicConnectionState = (DynamicConnectionState)connectionState;
            this.setConnectionState(n, dynamicConnectionState.withItem(slotType, itemStack));
        }
    }

    @Overwrite(remap=false)
    public int hashCode() {
        if (this.gtolib$change || this.gtolib$hashCode == 0) {
            this.gtolib$hashCode = Arrays.hashCode(this.connectionStates);
            this.gtolib$change = false;
        }
        return this.gtolib$hashCode;
    }
}

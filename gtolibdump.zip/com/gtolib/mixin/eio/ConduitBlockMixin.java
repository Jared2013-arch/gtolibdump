package com.gtolib.mixin.eio;

import com.enderio.api.conduit.ConduitType;
import com.enderio.conduits.common.conduit.block.ConduitBlock;
import com.enderio.conduits.common.conduit.block.ConduitBlockEntity;
import com.gtolib.d.a;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={ConduitBlock.class})
public class ConduitBlockMixin {
    @Redirect(method={"handleScreen"}, at=@At(value="INVOKE", target="Lcom/enderio/conduits/common/conduit/block/ConduitBlockEntity;menuProvider(Lnet/minecraft/core/Direction;Lcom/enderio/api/conduit/ConduitType;)Lnet/minecraft/world/MenuProvider;"), remap=false)
    private MenuProvider handleScreen(ConduitBlockEntity conduitBlockEntity, Direction direction, ConduitType<?> conduitType, @Local ServerPlayer serverPlayer) {
        return ((a)((Object)conduitBlockEntity)).gtolib$menuProvider(serverPlayer, direction, conduitType);
    }
}

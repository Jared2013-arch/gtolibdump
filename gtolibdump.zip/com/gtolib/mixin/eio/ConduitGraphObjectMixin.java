package com.gtolib.mixin.eio;

import com.enderio.api.conduit.ConduitData;
import com.enderio.api.conduit.ConduitNode;
import com.enderio.conduits.common.conduit.ConduitGraphObject;
import com.enderio.conduits.common.conduit.connection.DynamicConnectionState;
import java.util.Map;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={ConduitGraphObject.class}, remap=false)
public class ConduitGraphObjectMixin<T extends ConduitData<T>> {
    @Shadow
    @Final
    private BlockPos pos;
    @Shadow
    @Final
    private T conduitData;
    @Shadow
    @Final
    private Map<Direction, ConduitNode.IOState> ioStates;
    @Shadow
    @Final
    private Map<Direction, DynamicConnectionState> connectionStates;
    @Unique
    private boolean gtolib$change;
    @Unique
    private int gtolib$hashCode;

    @Inject(method={"pushState"}, at={@At(value="HEAD")}, remap=false)
    private void pushState(Direction direction, DynamicConnectionState dynamicConnectionState, CallbackInfo callbackInfo) {
        this.gtolib$change = true;
    }

    @Inject(method={"clearState"}, at={@At(value="HEAD")}, remap=false)
    private void clearState(Direction direction, CallbackInfo callbackInfo) {
        this.gtolib$change = true;
    }

    @Overwrite(remap=false)
    public int hashContents() {
        if (this.gtolib$change || this.gtolib$hashCode == 0) {
            this.gtolib$hashCode = Objects.hash(this.pos, this.ioStates, this.connectionStates);
            this.gtolib$change = false;
        }
        return this.gtolib$hashCode * 31 + this.conduitData.hashCode();
    }
}

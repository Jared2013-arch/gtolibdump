package com.gtolib.mixin.eio;

import com.enderio.api.glider.GliderMovementInfo;
import com.enderio.base.common.hangglider.PlayerMovementHandler;
import java.util.Optional;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={PlayerMovementHandler.class})
public final class PlayerMovementHandlerMixin {
    @Overwrite(remap=false)
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent playerTickEvent) {
    }

    @Overwrite(remap=false)
    public static Optional<GliderMovementInfo> calculateGliderMovementInfo(Player player, boolean bl) {
        return Optional.empty();
    }
}

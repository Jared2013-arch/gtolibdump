package com.gtolib.mixin.arsnouveau;

import com.hollingsworth.arsnouveau.setup.reward.Rewards;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={Rewards.class})
public final class RewardsMixin {
    @Overwrite(remap=false)
    public static void init() {
    }
}

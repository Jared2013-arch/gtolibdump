package com.gtolib.mixin.registrate;

import com.tterrag.registrate.builders.BlockBuilder;
import com.tterrag.registrate.providers.loot.RegistrateBlockLootTables;
import com.tterrag.registrate.util.nullness.NonNullBiConsumer;
import net.minecraft.world.level.block.Block;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={BlockBuilder.class})
public class BlockBuilderMixin<T extends Block, P> {
    @Overwrite(remap=false)
    public BlockBuilder<T, P> loot(NonNullBiConsumer<RegistrateBlockLootTables, T> nonNullBiConsumer) {
        return (BlockBuilder)((Object)this);
    }
}

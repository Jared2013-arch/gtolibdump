package com.gtolib.mixin.registrate;

import com.tterrag.registrate.AbstractRegistrate;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={AbstractRegistrate.class})
public interface AbstractRegistrateAccessor {
    @Accessor(value="defaultCreativeModeTab", remap=false)
    public ResourceKey<CreativeModeTab> defaultCreativeModeTab();
}

package com.gtolib.mixin.lowdraglib;

import com.gtolib.api.recipe.Recipe;
import com.lowdragmc.lowdraglib.syncdata.AccessorOp;
import com.lowdragmc.lowdraglib.syncdata.accessor.RecipeAccessor;
import com.lowdragmc.lowdraglib.syncdata.payload.ITypedPayload;
import com.lowdragmc.lowdraglib.syncdata.payload.NbtTagPayload;
import net.minecraft.nbt.CompoundTag;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={RecipeAccessor.class})
public class RecipeAccessorMixin {
    @Inject(method={"serialize(Lcom/lowdragmc/lowdraglib/syncdata/AccessorOp;Lnet/minecraft/world/item/crafting/Recipe;)Lcom/lowdragmc/lowdraglib/syncdata/payload/ITypedPayload;"}, at={@At(value="HEAD")}, remap=false, cancellable=true)
    private void serialize(AccessorOp accessorOp, net.minecraft.world.item.crafting.Recipe recipe, CallbackInfoReturnable<ITypedPayload<?>> callbackInfoReturnable) {
        if (recipe instanceof Recipe) {
            Recipe recipe2 = (Recipe)recipe;
            callbackInfoReturnable.setReturnValue((Object)NbtTagPayload.of(recipe2.serializeNBT()));
        }
    }

    @Inject(method={"deserialize(Lcom/lowdragmc/lowdraglib/syncdata/AccessorOp;Lcom/lowdragmc/lowdraglib/syncdata/payload/ITypedPayload;)Lnet/minecraft/world/item/crafting/Recipe;"}, at={@At(value="HEAD")}, remap=false, cancellable=true)
    private void deserialize(AccessorOp accessorOp, ITypedPayload<?> iTypedPayload, CallbackInfoReturnable<net.minecraft.world.item.crafting.Recipe> callbackInfoReturnable) {
        CompoundTag compoundTag;
        NbtTagPayload nbtTagPayload;
        Object object;
        if (iTypedPayload instanceof NbtTagPayload && (object = (nbtTagPayload = (NbtTagPayload)((Object)iTypedPayload)).getPayload()) instanceof CompoundTag && !(compoundTag = (CompoundTag)object).m_128441_("type")) {
            callbackInfoReturnable.setReturnValue((Object)Recipe.deserializeNBT(compoundTag));
        }
    }
}

package com.gtolib.mixin.lowdraglib;

import com.lowdragmc.lowdraglib.client.model.custommodel.CustomBakedModel;
import com.lowdragmc.lowdraglib.client.model.forge.CustomBakedModelImpl;
import com.lowdragmc.lowdraglib.client.model.forge.LDLRendererModel;
import java.util.List;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.client.model.data.ModelData;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={CustomBakedModelImpl.class})
public class CustomBakedModelImplMixin
extends CustomBakedModel {
    public CustomBakedModelImplMixin(BakedModel bakedModel) {
        super(bakedModel);
    }

    @Overwrite(remap=false)
    @NotNull
    public List<BakedQuad> getQuads(@Nullable BlockState blockState, @Nullable Direction direction, @NotNull RandomSource randomSource, @NotNull ModelData modelData, @Nullable RenderType renderType) {
        BlockAndTintGetter blockAndTintGetter = (BlockAndTintGetter)modelData.get(LDLRendererModel.RendererBakedModel.WORLD);
        BlockPos blockPos = (BlockPos)modelData.get(LDLRendererModel.RendererBakedModel.POS);
        if (blockAndTintGetter != null && blockPos != null && blockState != null) {
            return this.getCustomQuads(blockAndTintGetter, blockPos, blockState, direction, randomSource);
        }
        return this.parent.m_213637_(blockState, direction, randomSource);
    }

    @Overwrite(remap=false)
    @NotNull
    public ModelData getModelData(@NotNull BlockAndTintGetter blockAndTintGetter, @NotNull BlockPos blockPos, @NotNull BlockState blockState, @NotNull ModelData modelData) {
        return modelData.derive().with(LDLRendererModel.RendererBakedModel.WORLD, blockAndTintGetter).with(LDLRendererModel.RendererBakedModel.POS, blockPos).build();
    }
}

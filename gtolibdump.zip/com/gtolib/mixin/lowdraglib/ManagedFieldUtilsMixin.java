package com.gtolib.mixin.lowdraglib;

import com.lowdragmc.lowdraglib.LDLib;
import com.lowdragmc.lowdraglib.syncdata.IManaged;
import com.lowdragmc.lowdraglib.syncdata.ManagedFieldUtils;
import com.lowdragmc.lowdraglib.syncdata.annotation.DescSynced;
import com.lowdragmc.lowdraglib.syncdata.annotation.DropSaved;
import com.lowdragmc.lowdraglib.syncdata.annotation.LazyManaged;
import com.lowdragmc.lowdraglib.syncdata.annotation.Persisted;
import com.lowdragmc.lowdraglib.syncdata.annotation.ReadOnlyManaged;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedKey;
import com.lowdragmc.lowdraglib.syncdata.managed.IRef;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.Reference2ReferenceOpenHashMap;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Type;
import net.minecraft.nbt.CompoundTag;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={ManagedFieldUtils.class})
public final class ManagedFieldUtilsMixin {
    @Overwrite(remap=false)
    public static ManagedKey[] getManagedFields(Class<?> clazz) {
        ObjectArrayList objectArrayList = new ObjectArrayList();
        for (Field field : clazz.getDeclaredFields()) {
            Object object;
            if (Modifier.isStatic(field.getModifiers())) continue;
            boolean bl = field.isAnnotationPresent(DescSynced.class);
            boolean bl2 = field.isAnnotationPresent(Persisted.class);
            if (!bl && !bl2) continue;
            boolean bl3 = field.isAnnotationPresent(LazyManaged.class);
            boolean bl4 = field.isAnnotationPresent(DropSaved.class);
            boolean bl5 = field.isAnnotationPresent(ReadOnlyManaged.class);
            String string = field.getName();
            Type type = field.getGenericType();
            ManagedKey managedKey = new ManagedKey(string, bl, bl2, bl4, bl3, type, field);
            if (bl2) {
                object = field.getAnnotation(Persisted.class);
                managedKey.setPersistentKey(object.key());
            }
            if (bl5) {
                object = field.getAnnotation(ReadOnlyManaged.class);
                Class<?> clazz2 = field.getType();
                try {
                    Method method = clazz.getDeclaredMethod(object.onDirtyMethod(), clazz2);
                    Method method2 = clazz.getDeclaredMethod(object.serializeMethod(), clazz2);
                    Method method3 = clazz.getDeclaredMethod(object.deserializeMethod(), CompoundTag.class);
                    method.setAccessible(true);
                    method2.setAccessible(true);
                    method3.setAccessible(true);
                    managedKey.setRedOnlyManaged(method, method2, method3);
                }
                catch (NoSuchMethodException noSuchMethodException) {
                    LDLib.LOGGER.warn("No such methods for @ReadOnlyManaged field {}", (Object)field);
                }
            }
            objectArrayList.add(managedKey);
        }
        return (ManagedKey[])objectArrayList.toArray(ManagedKey[]::new);
    }

    @Overwrite(remap=false)
    public static ManagedFieldUtils.FieldRefs getFieldRefs(ManagedKey[] managedKeyArray, Object object, ManagedFieldUtils.FieldChangedCallback fieldChangedCallback, ManagedFieldUtils.FieldChangedCallback fieldChangedCallback2) {
        ObjectArrayList objectArrayList = new ObjectArrayList();
        ObjectArrayList objectArrayList2 = new ObjectArrayList();
        ObjectArrayList objectArrayList3 = new ObjectArrayList();
        Reference2ReferenceOpenHashMap reference2ReferenceOpenHashMap = new Reference2ReferenceOpenHashMap();
        for (ManagedKey managedKey : managedKeyArray) {
            IRef iRef = managedKey.createRef(object);
            iRef.markAsDirty();
            reference2ReferenceOpenHashMap.put(managedKey, iRef);
            if (!iRef.isLazy()) {
                objectArrayList3.add(iRef);
            }
            if (managedKey.isDestSync()) {
                objectArrayList.add(iRef);
            }
            if (!managedKey.isPersist()) continue;
            objectArrayList2.add(iRef);
            if (!(object instanceof IManaged)) continue;
            IManaged iManaged = (IManaged)object;
            iRef.setOnPersistedListener(bl -> {
                if (bl) {
                    iManaged.onChanged();
                }
            });
        }
        return new ManagedFieldUtils.FieldRefs((IRef[])objectArrayList.toArray(IRef[]::new), (IRef[])objectArrayList2.toArray(IRef[]::new), (IRef[])objectArrayList3.toArray(IRef[]::new), reference2ReferenceOpenHashMap);
    }
}

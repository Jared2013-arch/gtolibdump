package com.gtolib.mixin.lowdraglib;

import com.lowdragmc.lowdraglib.gui.util.ClickData;
import com.lowdragmc.lowdraglib.gui.widget.ButtonWidget;
import com.lowdragmc.lowdraglib.gui.widget.Widget;
import com.lowdragmc.lowdraglib.utils.Position;
import com.lowdragmc.lowdraglib.utils.Size;
import java.lang.invoke.LambdaMetafactory;
import java.util.function.Consumer;
import net.minecraft.network.FriendlyByteBuf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(value={ButtonWidget.class})
public abstract class ButtonWidgetMixin
extends Widget {
    @Shadow(remap=false)
    protected boolean isClicked;
    @Shadow(remap=false)
    protected Consumer<ClickData> onPressCallback;

    protected ButtonWidgetMixin(Position position, Size size) {
        super(position, size);
    }

    public boolean mouseClicked(double d, double d2, int n) {
        if (this.isMouseOverElement(d, d2)) {
            this.isClicked = true;
            ClickData clickData = new ClickData();
            this.writeClientAction(1, (Consumer<FriendlyByteBuf>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, writeToBuf(net.minecraft.network.FriendlyByteBuf ), (Lnet/minecraft/network/FriendlyByteBuf;)V)((ClickData)clickData));
            if (this.onPressCallback != null) {
                this.onPressCallback.accept(clickData);
            }
            ButtonWidgetMixin.playButtonClickSound();
            return true;
        }
        return false;
    }
}

package com.gtolib.mixin.lowdraglib;

import com.lowdragmc.lowdraglib.client.bakedpipeline.Quad;
import com.lowdragmc.lowdraglib.client.bakedpipeline.Submap;
import com.lowdragmc.lowdraglib.client.model.ModelFactory;
import com.lowdragmc.lowdraglib.client.model.custommodel.Connections;
import com.lowdragmc.lowdraglib.client.model.custommodel.CustomBakedModel;
import com.lowdragmc.lowdraglib.client.model.custommodel.LDLMetadataSection;
import it.unimi.dsi.fastutil.bytes.Byte2ObjectOpenHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentMap;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={CustomBakedModel.class})
public abstract class CustomBakedModelMixin {
    @Shadow(remap=false)
    @Final
    protected List<BakedQuad> noSideCache;
    @Mutable
    @Shadow(remap=false)
    @Final
    protected ConcurrentMap<Direction, ConcurrentMap<Connections, List<BakedQuad>>> sideCache;
    @Shadow(remap=false)
    @Final
    protected BakedModel parent;
    @Unique
    private Byte2ObjectOpenHashMap<List<BakedQuad>> gtolib$DOWNCache;
    @Unique
    private Byte2ObjectOpenHashMap<List<BakedQuad>> gtolib$UPCache;
    @Unique
    private Byte2ObjectOpenHashMap<List<BakedQuad>> gtolib$NORTHCache;
    @Unique
    private Byte2ObjectOpenHashMap<List<BakedQuad>> gtolib$SOUTHCache;
    @Unique
    private Byte2ObjectOpenHashMap<List<BakedQuad>> gtolib$WESTCache;
    @Unique
    private Byte2ObjectOpenHashMap<List<BakedQuad>> gtolib$EASTCache;

    @Shadow(remap=false)
    protected static Quad makeQuad(BakedQuad bakedQuad, LDLMetadataSection lDLMetadataSection, float f) {
        return null;
    }

    @Inject(method={"<init>"}, at={@At(value="TAIL")}, remap=false)
    public void init(BakedModel bakedModel, CallbackInfo callbackInfo) {
        this.sideCache = null;
        this.gtolib$DOWNCache = new Byte2ObjectOpenHashMap();
        this.gtolib$UPCache = new Byte2ObjectOpenHashMap();
        this.gtolib$NORTHCache = new Byte2ObjectOpenHashMap();
        this.gtolib$SOUTHCache = new Byte2ObjectOpenHashMap();
        this.gtolib$WESTCache = new Byte2ObjectOpenHashMap();
        this.gtolib$EASTCache = new Byte2ObjectOpenHashMap();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Nonnull
    @Overwrite(remap=false)
    public List<BakedQuad> getCustomQuads(BlockAndTintGetter blockAndTintGetter, BlockPos blockPos, @Nonnull BlockState blockState, @Nullable Direction direction, RandomSource randomSource) {
        List list;
        Connections connections = Connections.checkConnections(blockAndTintGetter, blockPos, blockState, direction);
        if (direction == null) {
            if (this.noSideCache.isEmpty()) {
                List<BakedQuad> list2 = this.noSideCache;
                synchronized (list2) {
                    if (this.noSideCache.isEmpty()) {
                        this.noSideCache.addAll(CustomBakedModelMixin.buildCustomQuads(connections, this.parent.m_213637_(blockState, null, randomSource), 0.0f));
                    }
                }
            }
            return this.noSideCache;
        }
        switch (direction.ordinal()) {
            case 0: {
                Byte2ObjectOpenHashMap<List<BakedQuad>> byte2ObjectOpenHashMap = this.gtolib$DOWNCache;
                synchronized (byte2ObjectOpenHashMap) {
                    list = (List)this.gtolib$DOWNCache.computeIfAbsent((byte)connections.hashCode(), by -> CustomBakedModelMixin.buildCustomQuads(connections, this.parent.m_213637_(blockState, direction, randomSource), 0.0f));
                    break;
                }
            }
            case 1: {
                Byte2ObjectOpenHashMap<List<BakedQuad>> byte2ObjectOpenHashMap = this.gtolib$UPCache;
                synchronized (byte2ObjectOpenHashMap) {
                    list = (List)this.gtolib$UPCache.computeIfAbsent((byte)connections.hashCode(), by -> CustomBakedModelMixin.buildCustomQuads(connections, this.parent.m_213637_(blockState, direction, randomSource), 0.0f));
                    break;
                }
            }
            case 2: {
                Byte2ObjectOpenHashMap<List<BakedQuad>> byte2ObjectOpenHashMap = this.gtolib$NORTHCache;
                synchronized (byte2ObjectOpenHashMap) {
                    list = (List)this.gtolib$NORTHCache.computeIfAbsent((byte)connections.hashCode(), by -> CustomBakedModelMixin.buildCustomQuads(connections, this.parent.m_213637_(blockState, direction, randomSource), 0.0f));
                    break;
                }
            }
            case 3: {
                Byte2ObjectOpenHashMap<List<BakedQuad>> byte2ObjectOpenHashMap = this.gtolib$SOUTHCache;
                synchronized (byte2ObjectOpenHashMap) {
                    list = (List)this.gtolib$SOUTHCache.computeIfAbsent((byte)connections.hashCode(), by -> CustomBakedModelMixin.buildCustomQuads(connections, this.parent.m_213637_(blockState, direction, randomSource), 0.0f));
                    break;
                }
            }
            case 4: {
                Byte2ObjectOpenHashMap<List<BakedQuad>> byte2ObjectOpenHashMap = this.gtolib$WESTCache;
                synchronized (byte2ObjectOpenHashMap) {
                    list = (List)this.gtolib$WESTCache.computeIfAbsent((byte)connections.hashCode(), by -> CustomBakedModelMixin.buildCustomQuads(connections, this.parent.m_213637_(blockState, direction, randomSource), 0.0f));
                    break;
                }
            }
            default: {
                Byte2ObjectOpenHashMap<List<BakedQuad>> byte2ObjectOpenHashMap = this.gtolib$EASTCache;
                synchronized (byte2ObjectOpenHashMap) {
                    list = (List)this.gtolib$EASTCache.computeIfAbsent((byte)connections.hashCode(), by -> CustomBakedModelMixin.buildCustomQuads(connections, this.parent.m_213637_(blockState, direction, randomSource), 0.0f));
                    break;
                }
            }
        }
        return list;
    }

    @Overwrite(remap=false)
    public static List<BakedQuad> buildCustomQuads(Connections connections, List<BakedQuad> list, float f) {
        LinkedList<BakedQuad> linkedList = new LinkedList<BakedQuad>();
        for (BakedQuad bakedQuad : list) {
            TextureAtlasSprite textureAtlasSprite;
            LDLMetadataSection lDLMetadataSection = LDLMetadataSection.getMetadata(bakedQuad.m_173410_());
            TextureAtlasSprite textureAtlasSprite2 = textureAtlasSprite = lDLMetadataSection.connection == null ? null : ModelFactory.getBlockSprite(lDLMetadataSection.connection);
            if (textureAtlasSprite == null) {
                linkedList.add(CustomBakedModelMixin.makeQuad(bakedQuad, lDLMetadataSection, f).rebake());
                continue;
            }
            int[] nArray = connections.getSubmapIndices();
            for (Quad quad : CustomBakedModelMixin.makeQuad(bakedQuad, lDLMetadataSection, f).derotate().subdivide(4)) {
                if (quad == null) continue;
                int n = quad.getUvs().normalize().getQuadrant();
                if ((quad = quad.grow().transformUVs(nArray[n] > 15 ? bakedQuad.m_173410_() : textureAtlasSprite, Submap.uvs[nArray[n]])) == null) continue;
                linkedList.add(quad.rebake());
            }
        }
        return linkedList;
    }
}

package com.gtolib.mixin.lowdraglib;

import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.lowdragmc.lowdraglib.utils.BlockInfo;
import com.lowdragmc.lowdraglib.utils.TrackedDummyWorld;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={TrackedDummyWorld.class})
public class TrackedDummyWorldMixin {
    @Mutable
    @Shadow(remap=false)
    @Final
    public Map<BlockPos, BlockInfo> renderedBlocks;
    @Mutable
    @Shadow(remap=false)
    @Final
    public Map<BlockPos, BlockEntity> blockEntities;

    @Inject(method={"<init>()V"}, at={@At(value="TAIL")}, remap=false)
    private void init(CallbackInfo callbackInfo) {
        this.renderedBlocks = new O2OOpenCacheHashMap();
        this.blockEntities = new O2OOpenCacheHashMap();
    }
}

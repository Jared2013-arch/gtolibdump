package com.gtolib.mixin.lowdraglib;

import com.gregtechceu.gtceu.api.misc.IContentChange;
import com.lowdragmc.lowdraglib.syncdata.IContentChangeAware;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedKey;
import com.lowdragmc.lowdraglib.syncdata.managed.ReadonlyRef;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(value={ReadonlyRef.class})
public abstract class ReadonlyRefMixin {
    @Shadow(remap=false)
    private ManagedKey key;
    @Shadow(remap=false)
    private boolean isSyncDirty;
    @Shadow(remap=false)
    private boolean isPersistedDirty;

    @Shadow(remap=false)
    public abstract void markAsDirty();

    @Overwrite(remap=false)
    protected void replaceHandler(IContentChangeAware iContentChangeAware) {
        Runnable runnable = iContentChangeAware.getOnContentsChanged();
        if (runnable != null) {
            IContentChange iContentChange;
            if (iContentChangeAware instanceof IContentChange && (iContentChange = (IContentChange)((Object)iContentChangeAware)).isFreezeChanged()) {
                iContentChange.setOnContentsChangedAndfreeze(() -> {
                    if (this.key.isDestSync()) {
                        this.isSyncDirty = true;
                    }
                    this.isPersistedDirty = true;
                    runnable.run();
                });
            } else {
                iContentChangeAware.setOnContentsChanged(() -> {
                    this.markAsDirty();
                    runnable.run();
                });
            }
        } else {
            iContentChangeAware.setOnContentsChanged(this::markAsDirty);
        }
    }
}

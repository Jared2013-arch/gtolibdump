package com.gtolib.mixin.guideme;

import guideme.internal.GuideME;
import guideme.internal.network.OpenGuideRequest;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={GuideME.class})
public class GuideMEMixin {
    @Redirect(method={"<init>"}, at=@At(value="INVOKE", target="Lnet/minecraftforge/eventbus/api/IEventBus;addListener(Ljava/util/function/Consumer;)V"), remap=false)
    private void redirectEventBus(IEventBus iEventBus, Consumer<?> consumer) {
    }

    @Redirect(method={"<init>"}, at=@At(value="INVOKE", target="Lnet/minecraftforge/api/distmarker/Dist;isClient()Z"), remap=false)
    private boolean redirectIsClient(Dist dist) {
        return false;
    }

    @Overwrite(remap=false)
    private void handlePacket(OpenGuideRequest openGuideRequest, Supplier<NetworkEvent.Context> supplier) {
    }

    @Overwrite(remap=false)
    public void sendPacket(PacketDistributor.PacketTarget packetTarget, OpenGuideRequest openGuideRequest) {
    }
}

package com.gtolib.mixin.farmersdelight;

import com.gtolib.f.d;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.extensions.IForgeItem;
import org.spongepowered.asm.mixin.Mixin;
import vectorwing.farmersdelight.common.item.KnifeItem;

@Mixin(value={KnifeItem.class})
public abstract class KnifeItemMixin
implements d,
IForgeItem {
    public ItemStack getCraftingRemainingItem(ItemStack itemStack) {
        return this.a(itemStack);
    }

    public boolean hasCraftingRemainingItem(ItemStack itemStack) {
        return true;
    }
}

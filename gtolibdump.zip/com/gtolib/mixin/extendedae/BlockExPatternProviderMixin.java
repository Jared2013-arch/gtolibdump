package com.gtolib.mixin.extendedae;

import com.glodblock.github.extendedae.common.blocks.BlockBaseGui;
import com.glodblock.github.extendedae.common.blocks.BlockExPatternProvider;
import com.glodblock.github.extendedae.common.tileentities.TileExPatternProvider;
import com.gtolib.api.blockentity.IDirectionCacheBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={BlockExPatternProvider.class})
public abstract class BlockExPatternProviderMixin
extends BlockBaseGui<TileExPatternProvider> {
    @Overwrite(remap=false)
    public void m_6861_(@NotNull BlockState blockState, @NotNull Level level, @NotNull BlockPos blockPos, @NotNull Block block, @NotNull BlockPos blockPos2, boolean bl) {
        TileExPatternProvider tileExPatternProvider = (TileExPatternProvider)((Object)this.getBlockEntity(level, blockPos));
        if (tileExPatternProvider != null) {
            IDirectionCacheBlockEntity.getBlockEntityDirectionCache(tileExPatternProvider).clearCache();
            tileExPatternProvider.getLogic().updateRedstoneState();
        }
    }
}

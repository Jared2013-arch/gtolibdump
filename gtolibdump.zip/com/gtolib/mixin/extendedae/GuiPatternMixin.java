package com.gtolib.mixin.extendedae;

import appeng.api.stacks.GenericStack;
import com.glodblock.github.extendedae.client.gui.pattern.GuiPattern;
import com.glodblock.github.extendedae.container.pattern.ContainerPattern;
import com.hepdd.ae2emicraftingforge.client.helper.mapper.EmiStackHelper;
import dev.emi.emi.api.EmiApi;
import dev.emi.emi.api.stack.EmiStack;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value={GuiPattern.class})
public abstract class GuiPatternMixin<T extends ContainerPattern>
extends AbstractContainerScreen<T> {
    public GuiPatternMixin(T t, Inventory inventory, Component component) {
        super((AbstractContainerMenu)t, inventory, component);
    }

    protected void m_6597_(@NotNull Slot slot, int n, int n2, @NotNull ClickType clickType) {
        if (slot instanceof ContainerPattern.DisplayOnlySlot) {
            ContainerPattern.DisplayOnlySlot displayOnlySlot = (ContainerPattern.DisplayOnlySlot)((Object)slot);
            if (!slot.m_7993_().m_41619_()) {
                EmiStack emiStack = EmiStackHelper.toEmiStack(GenericStack.fromItemStack(displayOnlySlot.m_7993_()));
                if (emiStack == null) {
                    return;
                }
                if (n2 == 0) {
                    EmiApi.displayRecipes(emiStack);
                }
                if (n2 == 1) {
                    EmiApi.displayUses(emiStack);
                }
            }
        }
    }
}

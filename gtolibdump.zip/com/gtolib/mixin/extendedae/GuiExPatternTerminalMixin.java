package com.gtolib.mixin.extendedae;

import appeng.client.gui.AEBaseScreen;
import appeng.client.gui.me.patternaccess.PatternContainerRecord;
import appeng.client.gui.style.ScreenStyle;
import appeng.client.gui.widgets.AETextField;
import appeng.client.gui.widgets.ServerSettingToggleButton;
import appeng.menu.AEBaseMenu;
import com.glodblock.github.extendedae.client.gui.GuiExPatternTerminal;
import com.glodblock.github.extendedae.container.ContainerExPatternTerminal;
import com.gregtechceu.gtceu.utils.collection.OpenCacheHashSet;
import com.gtolib.api.ae2.GTOSettings;
import com.gtolib.api.ae2.IPatternAccessTermMenu;
import com.gtolib.api.ae2.ShowMolecularAssembler;
import com.gtolib.api.ae2.gui.hooks.IExtendedGuiEx;
import com.gtolib.api.ae2.me2in1.Me2in1Menu;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={GuiExPatternTerminal.class})
public abstract class GuiExPatternTerminalMixin<T extends ContainerExPatternTerminal>
extends AEBaseScreen<T>
implements IExtendedGuiEx {
    @Shadow(remap=false)
    @Final
    private Map<String, Set<Object>> cachedSearches;
    @Shadow(remap=false)
    @Final
    private AETextField searchOutField;
    @Unique
    private ServerSettingToggleButton<ShowMolecularAssembler> gtolib$showMolecularAssembler;

    protected GuiExPatternTerminalMixin(T t, Inventory inventory, Component component, ScreenStyle screenStyle) {
        super((AEBaseMenu)t, inventory, component, screenStyle);
    }

    @Inject(method={"<init>"}, at={@At(value="TAIL")}, remap=false)
    private void onInit(ContainerExPatternTerminal containerExPatternTerminal, Inventory inventory, Component component, ScreenStyle screenStyle, CallbackInfo callbackInfo) {
        this.gtolib$showMolecularAssembler = new ServerSettingToggleButton(GTOSettings.TERMINAL_SHOW_MOLECULAR_ASSEMBLERS, ShowMolecularAssembler.ALL);
        this.addToLeftToolbar(this.gtolib$showMolecularAssembler);
    }

    @Redirect(method={"init"}, at=@At(value="INVOKE", target="Lcom/glodblock/github/extendedae/client/gui/GuiExPatternTerminal;setInitialFocus(Lnet/minecraft/client/gui/components/events/GuiEventListener;)V"))
    private void onSetFocus(GuiExPatternTerminal<?> guiExPatternTerminal, GuiEventListener guiEventListener) {
        if (!(this.m_6262_() instanceof Me2in1Menu)) {
            guiExPatternTerminal.m_264313_(guiEventListener);
        }
    }

    @Inject(method={"updateBeforeRender"}, at={@At(value="TAIL")}, remap=false)
    private void updateBeforeRender(CallbackInfo callbackInfo) {
        this.gtolib$showMolecularAssembler.set((Enum)((IPatternAccessTermMenu)((Object)this.m_6262_())).gtolib$getShownMolecularAssemblers());
    }

    @Overwrite(remap=false)
    private Set<Object> getCacheForSearchTerm(String string2) {
        Set set = this.cachedSearches.computeIfAbsent(string2, string -> new OpenCacheHashSet());
        if (set.isEmpty() && string2.length() > 1) {
            set.addAll(this.getCacheForSearchTerm(string2.substring(0, string2.length() - 1)));
        }
        return set;
    }

    @Redirect(method={"refreshList"}, at=@At(value="INVOKE", target="Ljava/util/ArrayList;sort(Ljava/util/Comparator;)V"), remap=false)
    private void sort(ArrayList<PatternContainerRecord> arrayList, Comparator<PatternContainerRecord> comparator) {
    }

    @Override
    public AETextField gtolib$getSearchOutField() {
        return this.searchOutField;
    }
}

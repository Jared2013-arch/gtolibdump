package com.gtolib.mixin.extendedae;

import appeng.helpers.patternprovider.PatternProviderLogic;
import com.glodblock.github.extendedae.common.tileentities.TileExPatternProvider;
import com.gtocore.config.GTOConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={TileExPatternProvider.class})
public abstract class TileExPatternProviderMixin {
    @Unique
    private TileExPatternProvider exae$getSelf() {
        return (TileExPatternProvider)((Object)this);
    }

    @Inject(method={"createLogic"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void modifyCreateLogic(CallbackInfoReturnable<PatternProviderLogic> callbackInfoReturnable) {
        if (GTOConfig.INSTANCE.dev && GTOConfig.INSTANCE.exPatternSize > 36) {
            callbackInfoReturnable.setReturnValue((Object)new PatternProviderLogic(this.exae$getSelf().getMainNode(), this.exae$getSelf(), GTOConfig.INSTANCE.exPatternSize));
        }
    }
}

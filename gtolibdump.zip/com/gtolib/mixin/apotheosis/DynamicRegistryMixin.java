package com.gtolib.mixin.apotheosis;

import com.gtolib.c.b;
import dev.emi.emi.api.stack.EmiStack;
import dev.shadowsoffire.apotheosis.adventure.loot.LootRarity;
import dev.shadowsoffire.apotheosis.adventure.loot.RarityRegistry;
import dev.shadowsoffire.apotheosis.adventure.socket.gem.Gem;
import dev.shadowsoffire.apotheosis.adventure.socket.gem.GemRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets={"dev.shadowsoffire.placebo.reload.DynamicRegistry$SyncManagement"})
public abstract class DynamicRegistryMixin {
    @Inject(method={"endSync"}, at={@At(value="RETURN")}, remap=false)
    private static void endSync(String string, CallbackInfo callbackInfo) {
        if (string.equals("gems")) {
            for (Gem gem : GemRegistry.INSTANCE.getValues()) {
                LootRarity lootRarity = (LootRarity)RarityRegistry.getMaxRarity().get();
                for (LootRarity lootRarity2 = (LootRarity)RarityRegistry.getMinRarity().get(); lootRarity2 != lootRarity; lootRarity2 = lootRarity2.next()) {
                    b.a.add(EmiStack.of(GemRegistry.createGemStack(gem, lootRarity2)));
                }
            }
        }
    }
}

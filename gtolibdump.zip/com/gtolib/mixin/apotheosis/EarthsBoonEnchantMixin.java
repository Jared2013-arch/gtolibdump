package com.gtolib.mixin.apotheosis;

import com.gregtechceu.gtceu.api.data.chemical.ChemicalHelper;
import com.gregtechceu.gtceu.api.data.tag.TagPrefix;
import com.gtocore.common.data.GTOOres;
import dev.shadowsoffire.apotheosis.ench.enchantments.masterwork.EarthsBoonEnchant;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.common.Tags;
import net.minecraftforge.event.level.BlockEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={EarthsBoonEnchant.class})
public class EarthsBoonEnchantMixin {
    @Overwrite(remap=false)
    public void provideBenefits(BlockEvent.BreakEvent breakEvent) {
        Player player = breakEvent.getPlayer();
        if (player.m_9236_().f_46443_) {
            return;
        }
        ItemStack itemStack = player.m_21205_();
        int n = itemStack.getEnchantmentLevel((EarthsBoonEnchant)((Object)this));
        if (breakEvent.getState().m_204336_(Tags.Blocks.STONE) && n > 0 && player.m_217043_().m_188501_() <= 0.01f * (float)n) {
            Block.m_49840_(player.m_9236_(), breakEvent.getPos(), ChemicalHelper.get(TagPrefix.rawOre, GTOOres.selectMaterial(player.m_9236_().m_46472_().m_135782_())));
        }
    }
}

package com.gtolib.mixin.apotheosis;

import com.google.common.collect.ImmutableList;
import com.gregtechceu.gtceu.api.item.tool.GTToolItem;
import com.gregtechceu.gtceu.api.item.tool.GTToolType;
import com.gtolib.api.item.tool.GTOToolType;
import dev.shadowsoffire.apotheosis.adventure.loot.LootCategory;
import java.util.function.Predicate;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.ToolActions;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={LootCategory.class})
public abstract class LootCategoryMixin {
    @Unique
    private static final ImmutableList<GTToolType> gtolib$PICKAXE_TOOL_TYPES = ImmutableList.of(GTToolType.PICKAXE, GTToolType.DRILL_LV, GTToolType.DRILL_MV, GTToolType.DRILL_HV, GTToolType.DRILL_EV, GTToolType.DRILL_IV, GTToolType.WRENCH, GTToolType.WRENCH_HV, GTToolType.WRENCH_LV, GTToolType.WRENCH_IV, GTToolType.AXE, GTToolType.CHAINSAW_LV, GTToolType.MINING_HAMMER, GTToolType.HARD_HAMMER, GTOToolType.VAJRA_EV, GTOToolType.VAJRA_HV, GTOToolType.VAJRA_IV);
    @Unique
    private static final ImmutableList<GTToolType> gtolib$SHOVEL_TYPES = ImmutableList.of(GTToolType.SHOVEL, GTToolType.SPADE);

    @Shadow(remap=false)
    public static LootCategory register(@Nullable LootCategory lootCategory, String string, Predicate<ItemStack> predicate, EquipmentSlot[] equipmentSlotArray) {
        return null;
    }

    @Shadow(remap=false)
    private static EquipmentSlot[] arr(EquipmentSlot ... equipmentSlotArray) {
        return null;
    }

    @Inject(method={"register(Ljava/lang/String;Ljava/util/function/Predicate;[Lnet/minecraft/world/entity/EquipmentSlot;)Ldev/shadowsoffire/apotheosis/adventure/loot/LootCategory;"}, at={@At(value="HEAD")}, remap=false, cancellable=true)
    private static void register(String string, Predicate<ItemStack> predicate, EquipmentSlot[] equipmentSlotArray, CallbackInfoReturnable<LootCategory> callbackInfoReturnable) {
        switch (string) {
            case "heavy_weapon": {
                callbackInfoReturnable.setReturnValue((Object)LootCategoryMixin.register(null, string, itemStack -> false, LootCategoryMixin.arr(EquipmentSlot.MAINHAND)));
                break;
            }
            case "pickaxe": {
                callbackInfoReturnable.setReturnValue((Object)LootCategoryMixin.register(null, string, itemStack -> {
                    GTToolItem gTToolItem;
                    Item item;
                    return itemStack.canPerformAction(ToolActions.PICKAXE_DIG) || (item = itemStack.m_41720_()) instanceof GTToolItem && gtolib$PICKAXE_TOOL_TYPES.contains((gTToolItem = (GTToolItem)((Object)item)).getToolType());
                }, LootCategoryMixin.arr(EquipmentSlot.MAINHAND)));
                break;
            }
            case "shovel": {
                callbackInfoReturnable.setReturnValue((Object)LootCategoryMixin.register(null, string, itemStack -> {
                    GTToolItem gTToolItem;
                    Item item;
                    return itemStack.canPerformAction(ToolActions.SHOVEL_DIG) || (item = itemStack.m_41720_()) instanceof GTToolItem && gtolib$SHOVEL_TYPES.contains((gTToolItem = (GTToolItem)((Object)item)).getToolType());
                }, LootCategoryMixin.arr(EquipmentSlot.MAINHAND)));
            }
        }
    }
}

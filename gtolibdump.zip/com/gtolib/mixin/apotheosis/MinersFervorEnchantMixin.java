package com.gtolib.mixin.apotheosis;

import com.gregtechceu.gtceu.api.item.IGTTool;
import com.llamalad7.mixinextras.sugar.Local;
import dev.shadowsoffire.apotheosis.ench.enchantments.twisted.MinersFervorEnchant;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraftforge.event.entity.player.PlayerEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={MinersFervorEnchant.class})
public class MinersFervorEnchantMixin {
    @Inject(method={"breakSpeed"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    public void invokeGetExperienceForLevel(PlayerEvent.BreakSpeed breakSpeed, CallbackInfo callbackInfo) {
        Player player = breakSpeed.getEntity();
        ItemStack itemStack = player.m_21205_();
        Item item = itemStack.m_41720_();
        if (item instanceof IGTTool) {
            IGTTool iGTTool = (IGTTool)((Object)item);
            if (iGTTool.getToolType().name.contains("_vajra") && !itemStack.m_41784_().m_128471_("MinersFervor") && itemStack.m_41784_().m_128457_("ToolSpeed") != 0.0f) {
                breakSpeed.setNewSpeed(itemStack.m_41784_().m_128457_("ToolSpeed"));
                callbackInfo.cancel();
            }
        }
    }

    @Redirect(method={"breakSpeed"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/item/ItemStack;getEnchantmentLevel(Lnet/minecraft/world/item/enchantment/Enchantment;)I"), remap=false)
    public int redirectGetExperienceForLevel(ItemStack itemStack, Enchantment enchantment, @Local Player player) {
        Item item = itemStack.m_41720_();
        if (item instanceof IGTTool) {
            IGTTool iGTTool = (IGTTool)((Object)item);
            if (iGTTool.getToolType().name.contains("_vajra") && itemStack.m_41784_().m_128471_("MinersFervor")) {
                return 5;
            }
        }
        return itemStack.getEnchantmentLevel(enchantment);
    }
}

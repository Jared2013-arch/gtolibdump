package com.gtolib.mixin.emi;

import appeng.api.stacks.GenericStack;
import appeng.client.gui.StackWithBounds;
import appeng.client.gui.me.common.MEStorageScreen;
import appeng.client.gui.me.common.Repo;
import appeng.client.gui.me.crafting.CraftingCPUScreen;
import appeng.helpers.InventoryAction;
import appeng.menu.me.common.GridInventoryEntry;
import appeng.menu.me.common.MEStorageMenu;
import appeng.menu.slot.FakeSlot;
import com.glodblock.github.extendedae.network.EPPNetworkHandler;
import com.glodblock.github.glodium.network.packet.CGenericPacket;
import com.gregtechceu.gtceu.common.data.GTItems;
import com.gtolib.api.ae2.gui.hooks.IRepoSlot;
import com.gtolib.api.ae2.me2in1.Me2in1Screen;
import com.gtolib.utils.ClientUtil;
import com.hepdd.ae2emicraftingforge.client.helper.mapper.EmiStackHelper;
import dev.emi.emi.EmiPort;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.FluidEmiStack;
import dev.emi.emi.config.EmiConfig;
import dev.emi.emi.network.CreateItemC2SPacket;
import dev.emi.emi.network.EmiNetwork;
import dev.emi.emi.platform.EmiClient;
import dev.emi.emi.runtime.EmiReloadManager;
import dev.emi.emi.screen.EmiScreenManager;
import earth.terrarium.adastra.common.menus.PlanetsMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={EmiScreenManager.class})
public final class EmiScreenManagerMixin {
    @Shadow(remap=false)
    private static Minecraft client;
    @Shadow(remap=false)
    public static EmiIngredient pressedStack;
    @Shadow(remap=false)
    public static EmiIngredient draggedStack;

    @Overwrite(remap=false)
    public static boolean isDisabled() {
        return !EmiReloadManager.isLoaded() || !EmiConfig.enabled || ClientUtil.getPlayer().f_36096_ instanceof PlanetsMenu;
    }

    @Overwrite(remap=false)
    private static boolean give(EmiStack emiStack, int n, int n2) {
        Object object;
        Object object2;
        ItemStack itemStack;
        if (emiStack instanceof FluidEmiStack) {
            itemStack = GTItems.FLUID_CELL.asStack();
            object2 = itemStack.m_41784_();
            object = new CompoundTag();
            ((CompoundTag)object).m_128359_("FluidName", emiStack.getId().toString());
            ((CompoundTag)object).m_128405_("Amount", 1000);
            ((CompoundTag)object2).m_128365_("Fluid", (Tag)object);
            itemStack.m_41751_((CompoundTag)object2);
        } else if (!emiStack.getItemStack().m_41619_()) {
            itemStack = emiStack.getItemStack().m_41777_();
        } else {
            return false;
        }
        itemStack.m_41764_(n);
        if (n2 == 1 && EmiScreenManagerMixin.client.f_91074_.m_150110_().f_35937_ && EmiScreenManagerMixin.client.f_91080_ instanceof CreativeModeInventoryScreen) {
            EmiScreenManagerMixin.client.f_91074_.f_36096_.m_142503_(itemStack);
            return true;
        }
        if (EmiClient.onServer) {
            EmiNetwork.sendToServer(new CreateItemC2SPacket(n2, itemStack));
            return true;
        }
        if (!itemStack.m_41619_()) {
            object2 = EmiPort.getItemRegistry().m_7981_(itemStack.m_41720_());
            object = "give @s " + String.valueOf(object2);
            if (itemStack.m_41782_()) {
                object = (String)object + itemStack.m_41783_().toString();
            }
            if (((String)(object = (String)object + " " + n)).length() < 256) {
                EmiScreenManagerMixin.client.f_91074_.f_108617_.m_246623_((String)object);
                return true;
            }
        }
        return false;
    }

    @Unique
    private static boolean gto$isEMIDisabledSlot(AbstractContainerScreen<?> abstractContainerScreen, double d, double d2) {
        Slot slot = abstractContainerScreen.m_97744_(d, d2);
        return slot instanceof FakeSlot || slot instanceof IRepoSlot;
    }

    @Inject(remap=false, method={"mouseClicked"}, at={@At(value="HEAD")}, cancellable=true)
    private static void onMouseClicked(double d, double d2, int n, CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        Object object;
        Screen screen = EmiScreenManagerMixin.client.f_91080_;
        if (screen instanceof AbstractContainerScreen && EmiScreenManagerMixin.gto$isEMIDisabledSlot(object = (AbstractContainerScreen)screen, d, d2)) {
            callbackInfoReturnable.setReturnValue((Object)false);
        }
        if (Screen.m_96638_() && n == 0 && screen instanceof CraftingCPUScreen) {
            object = (CraftingCPUScreen)((Object)screen);
            StackWithBounds stackWithBounds = ((CraftingCPUScreen)object).getStackUnderMouse(d, d2);
            if (stackWithBounds == null) {
                return;
            }
            callbackInfoReturnable.setReturnValue((Object)false);
            EPPNetworkHandler.INSTANCE.sendToServer(new CGenericPacket("requestPendingBlocks", new Object[]{GenericStack.wrapInItemStack(stackWithBounds.stack())}));
            Minecraft.m_91087_().m_91106_().m_120367_(SimpleSoundInstance.m_263171_(SoundEvents.f_12490_, 1.0f));
        }
    }

    @Inject(remap=false, method={"mouseReleased"}, at={@At(value="HEAD")}, cancellable=true)
    private static void onMouseRleased(double d, double d2, int n, CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        Object object;
        Screen screen = EmiScreenManagerMixin.client.f_91080_;
        if (screen instanceof AbstractContainerScreen && EmiScreenManagerMixin.gto$isEMIDisabledSlot(object = (AbstractContainerScreen)screen, d, d2) && draggedStack == EmiStack.EMPTY) {
            callbackInfoReturnable.setReturnValue((Object)false);
        }
        if (EmiScreenManagerMixin.client.f_91066_.f_92097_.m_90830_(n)) {
            Object object2;
            object = null;
            MEStorageMenu mEStorageMenu = null;
            if (screen instanceof MEStorageScreen) {
                object2 = (MEStorageScreen)((Object)screen);
                object = ((MEStorageMenu)((Object)((MEStorageScreen)object2).m_6262_())).getClientRepo();
                mEStorageMenu = (MEStorageMenu)((Object)((MEStorageScreen)object2).m_6262_());
            }
            if (screen instanceof Me2in1Screen) {
                object2 = (Me2in1Screen)((Object)screen);
                object = ((Me2in1Screen)object2).gtolib$getRepo();
                mEStorageMenu = ((Me2in1Screen)object2).gtolib$getMenu();
            }
            if (object != null && ((Repo)object).hasPower() && !pressedStack.isEmpty()) {
                object2 = EmiStackHelper.toGenericStack(pressedStack.getEmiStacks().stream().findFirst().orElse(EmiStack.EMPTY));
                if (object2 == null) {
                    return;
                }
                long l = object.getAllEntries().stream().filter(gridInventoryEntry -> gridInventoryEntry.getWhat() != null).filter(GridInventoryEntry::isCraftable).filter(arg_0 -> EmiScreenManagerMixin.lambda$onMouseRleased$1((GenericStack)object2, arg_0)).findFirst().map(GridInventoryEntry::getSerial).orElse(-1L);
                if (l != -1L) {
                    mEStorageMenu.handleInteraction(l, InventoryAction.AUTO_CRAFT);
                    callbackInfoReturnable.setReturnValue((Object)true);
                }
            }
        }
    }

    private static boolean lambda$onMouseRleased$1(GenericStack genericStack, GridInventoryEntry gridInventoryEntry) {
        return gridInventoryEntry.getWhat().equals(genericStack.what());
    }
}

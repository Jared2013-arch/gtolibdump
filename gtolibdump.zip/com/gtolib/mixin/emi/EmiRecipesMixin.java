package com.gtolib.mixin.emi;

import com.gtolib.c.b;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.registry.EmiRecipes;
import dev.emi.emi.runtime.EmiLog;
import java.util.List;
import java.util.Map;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(value={EmiRecipes.class})
public final class EmiRecipesMixin {
    @Shadow(remap=false)
    private static Map<EmiRecipeCategory, List<EmiIngredient>> workstations;
    @Shadow(remap=false)
    private static List<EmiRecipe> recipes;

    @Overwrite(remap=false)
    public static void bake() {
        long l = System.currentTimeMillis();
        EmiRecipes.manager = new b(EmiRecipes.categories, workstations, recipes);
        EmiLog.info("Baked " + recipes.size() + " recipes in " + (System.currentTimeMillis() - l) + "ms");
    }
}

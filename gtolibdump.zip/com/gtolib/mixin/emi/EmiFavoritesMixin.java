package com.gtolib.mixin.emi;

import com.gtolib.c.a;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.runtime.EmiFavorites;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={EmiFavorites.class})
public class EmiFavoritesMixin {
    @Inject(method={"addFavorite(Ldev/emi/emi/api/stack/EmiIngredient;Ldev/emi/emi/api/recipe/EmiRecipe;)V"}, at={@At(value="TAIL")}, remap=false)
    private static void onAddFavorite(EmiIngredient emiIngredient, EmiRecipe emiRecipe, CallbackInfo callbackInfo) {
        a.a();
    }

    @Inject(method={"removeFavorite"}, at={@At(value="RETURN")}, remap=false)
    private static void onRemoveFavorite(EmiIngredient emiIngredient, CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        if (((Boolean)callbackInfoReturnable.getReturnValue()).booleanValue()) {
            a.a();
        }
    }

    @Inject(method={"addFavoriteAt"}, at={@At(value="TAIL")}, remap=false)
    private static void onAddFavoriteAt(EmiIngredient emiIngredient, int n, CallbackInfo callbackInfo) {
        a.a();
    }
}

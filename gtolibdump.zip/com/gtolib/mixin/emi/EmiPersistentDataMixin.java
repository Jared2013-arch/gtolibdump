package com.gtolib.mixin.emi;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.gtocore.client.ClientCache;
import com.gtocore.config.GTOConfig;
import com.gtocore.integration.emi.EmiPersist;
import com.gtolib.GTOCore;
import com.llamalad7.mixinextras.sugar.Local;
import dev.emi.emi.bom.BoM;
import dev.emi.emi.runtime.EmiPersistentData;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.attribute.FileAttribute;
import java.util.HashMap;
import java.util.UUID;
import net.minecraft.util.GsonHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={EmiPersistentData.class})
public class EmiPersistentDataMixin {
    @Unique
    private static final String FAVORITES_KEY = "favorites";

    @Unique
    private static FileReader gtolib$openFileReader() {
        if (!EmiPersistentData.FILE.exists()) {
            Files.createFile(EmiPersistentData.FILE.toPath(), new FileAttribute[0]);
        }
        return new FileReader(EmiPersistentData.FILE);
    }

    @Inject(method={"save"}, at={@At(value="INVOKE", target="Ldev/emi/emi/runtime/EmiSidebars;save(Lcom/google/gson/JsonObject;)V")}, remap=false, cancellable=true)
    private static void save(CallbackInfo callbackInfo, @Local JsonObject jsonObject) {
        Object object;
        jsonObject.add("recipe_defaults", BoM.saveAdded());
        EmiPersist emiPersist = (EmiPersist)EmiPersistentData.GSON.fromJson(EmiPersistentDataMixin.gtolib$openFileReader(), EmiPersist.class);
        if (emiPersist == null) {
            emiPersist = new EmiPersist();
        }
        if (!GTOConfig.INSTANCE.emiGlobalFavorites) {
            if (emiPersist.byId == null) {
                emiPersist.byId = new HashMap();
            }
            GTOCore.LOGGER.info(emiPersist.byId.toString());
            object = ClientCache.SERVER_IDENTIFIER;
            if (object == null) {
                GTOCore.LOGGER.warn("server id unavaliable now, skippping emi saving");
                return;
            }
            GTOCore.LOGGER.info(String.valueOf(object));
            emiPersist.byId.put(object, jsonObject);
            GTOCore.LOGGER.info(emiPersist.toString());
        } else {
            emiPersist.favorites = jsonObject.getAsJsonArray(FAVORITES_KEY);
            emiPersist.recipeDefaults = jsonObject.getAsJsonObject("recipe_defaults");
        }
        object = new FileWriter(EmiPersistentData.FILE);
        EmiPersistentData.GSON.toJson(emiPersist, (Appendable)object);
        ((OutputStreamWriter)object).close();
        callbackInfo.cancel();
    }

    @Inject(method={"load"}, at={@At(value="INVOKE", target="Ldev/emi/emi/runtime/EmiSidebars;load(Lcom/google/gson/JsonObject;)V")}, remap=false, cancellable=true)
    private static void load(CallbackInfo callbackInfo, @Local JsonObject jsonObject) {
        if (GsonHelper.m_144772_(jsonObject, "recipe_defaults")) {
            BoM.loadAdded(GsonHelper.m_13930_(jsonObject, "recipe_defaults"));
        }
        callbackInfo.cancel();
    }

    @Unique
    private static JsonObject gtolib$defaultData() {
        JsonObject jsonObject = new JsonObject();
        jsonObject.add(FAVORITES_KEY, new JsonArray());
        return jsonObject;
    }

    @Redirect(method={"load"}, at=@At(value="INVOKE", target="Lcom/google/gson/Gson;fromJson(Ljava/io/Reader;Ljava/lang/Class;)Ljava/lang/Object;"), remap=false)
    private static Object load_persist(Gson gson, Reader reader, Class<?> clazz) {
        EmiPersist emiPersist = (EmiPersist)gson.fromJson(reader, EmiPersist.class);
        if (emiPersist == null) {
            emiPersist = new EmiPersist();
        }
        if (!GTOConfig.INSTANCE.emiGlobalFavorites && emiPersist.byId != null) {
            GTOCore.LOGGER.info(emiPersist.byId.toString());
            UUID uUID = ClientCache.SERVER_IDENTIFIER;
            if (uUID == null) {
                GTOCore.LOGGER.warn("server id unavaliable now, returning empty emi persist data");
                EmiPersist.needsRefresh = true;
                return EmiPersistentDataMixin.gtolib$defaultData();
            }
            GTOCore.LOGGER.info(String.valueOf(uUID));
            return emiPersist.byId.getOrDefault(uUID, EmiPersistentDataMixin.gtolib$defaultData());
        }
        JsonObject jsonObject = EmiPersistentDataMixin.gtolib$defaultData();
        if (emiPersist.favorites != null) {
            jsonObject.add(FAVORITES_KEY, emiPersist.favorites);
        }
        if (emiPersist.recipeDefaults != null) {
            jsonObject.add("recipe_defaults", emiPersist.recipeDefaults);
        }
        return jsonObject;
    }
}

package com.gtolib.mixin.emi;

import com.gregtechceu.gtceu.api.item.IGTTool;
import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiUtil;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.ItemEmiStack;
import dev.emi.emi.api.stack.TagEmiIngredient;
import dev.emi.emi.recipe.EmiShapedRecipe;
import dev.emi.emi.runtime.EmiLog;
import java.util.List;
import net.minecraft.world.inventory.TransientCraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingRecipe;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={EmiShapedRecipe.class})
public final class EmiShapedRecipeMixin {
    @Overwrite(remap=false)
    public static void setRemainders(List<EmiIngredient> list, CraftingRecipe craftingRecipe) {
        try {
            String string = craftingRecipe.m_6423_().m_135827_();
            if (string.equals("gtceu") || string.equals("gtocore")) {
                for (EmiIngredient emiIngredient : list) {
                    if (!(emiIngredient instanceof TagEmiIngredient)) continue;
                    List list2 = emiIngredient.getEmiStacks();
                    for (EmiStack emiStack : list2) {
                        ItemEmiStack itemEmiStack;
                        Object object;
                        if (!(emiStack instanceof ItemEmiStack) || !((object = (itemEmiStack = (ItemEmiStack)emiStack).getKey()) instanceof IGTTool)) continue;
                        emiStack.setRemainder(itemEmiStack);
                    }
                }
            } else {
                TransientCraftingContainer transientCraftingContainer = EmiUtil.getCraftingInventory();
                for (int i = 0; i < list.size(); ++i) {
                    EmiIngredient emiIngredient = list.get(i);
                    if (emiIngredient.isEmpty()) continue;
                    for (int j = 0; j < list.size(); ++j) {
                        if (j == i || list.get(j).isEmpty()) continue;
                        transientCraftingContainer.m_6836_(j, ((EmiStack)list.get(j).getEmiStacks().get(0)).getItemStack());
                    }
                    List list3 = emiIngredient.getEmiStacks();
                    for (EmiStack emiStack : list3) {
                        transientCraftingContainer.m_6836_(i, emiStack.getItemStack());
                        ItemStack itemStack = (ItemStack)craftingRecipe.m_7457_(transientCraftingContainer).get(i);
                        if (itemStack.m_41619_()) continue;
                        emiStack.setRemainder(EmiStack.of(itemStack));
                    }
                    transientCraftingContainer.m_6211_();
                }
            }
        }
        catch (Exception exception) {
            EmiLog.error("Exception thrown setting remainders for " + String.valueOf(EmiPort.getId(craftingRecipe)));
        }
    }
}

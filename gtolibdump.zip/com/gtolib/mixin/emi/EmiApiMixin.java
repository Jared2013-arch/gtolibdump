package com.gtolib.mixin.emi;

import appeng.api.stacks.AEFluidKey;
import appeng.api.stacks.GenericStack;
import dev.emi.emi.VanillaPlugin;
import dev.emi.emi.api.EmiApi;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.ListEmiIngredient;
import dev.emi.emi.api.stack.TagEmiIngredient;
import dev.emi.emi.bom.BoM;
import dev.emi.emi.recipe.EmiSyntheticIngredientRecipe;
import dev.emi.emi.recipe.EmiTagRecipe;
import dev.emi.emi.registry.EmiRecipes;
import dev.emi.emi.runtime.EmiFavorite;
import dev.emi.emi.runtime.EmiSidebars;
import dev.emi.emi.screen.BoMScreen;
import dev.emi.emi.screen.RecipeScreen;
import dev.ftb.mods.ftblibrary.ui.ScreenWrapper;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(value={EmiApi.class})
public abstract class EmiApiMixin {
    @Shadow(remap=false)
    @Final
    private static Minecraft client;

    @Shadow(remap=false)
    private static void push() {
    }

    @Shadow(remap=false)
    public static AbstractContainerScreen<?> getHandledScreen() {
        return null;
    }

    @Shadow(remap=false)
    private static Map<EmiRecipeCategory, List<EmiRecipe>> mapRecipes(List<EmiRecipe> list) {
        return null;
    }

    @Shadow(remap=false)
    private static List<EmiRecipe> pruneUses(List<EmiRecipe> list, EmiIngredient emiIngredient) {
        return null;
    }

    @Shadow(remap=false)
    private static List<EmiRecipe> pruneSources(List<EmiRecipe> list, EmiStack emiStack) {
        return null;
    }

    @Overwrite(remap=false)
    private static void setPages(Map<EmiRecipeCategory, List<EmiRecipe>> map, EmiIngredient emiIngredient) {
        if (!(map = map.entrySet().stream().filter(entry -> !((List)entry.getValue()).isEmpty()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue))).isEmpty()) {
            Screen screen;
            EmiSidebars.lookup(emiIngredient);
            if (EmiApiMixin.client.f_91080_ instanceof ScreenWrapper) {
                RecipeScreen recipeScreen = new RecipeScreen(new InventoryScreen(EmiApiMixin.client.f_91074_), map);
                client.m_91152_(recipeScreen);
                return;
            }
            if (EmiApiMixin.getHandledScreen() == null) {
                client.m_91152_(new InventoryScreen(EmiApiMixin.client.f_91074_));
            }
            if ((screen = EmiApiMixin.client.f_91080_) instanceof AbstractContainerScreen) {
                AbstractContainerScreen abstractContainerScreen = (AbstractContainerScreen)screen;
                EmiApiMixin.push();
                client.m_91152_(new RecipeScreen(abstractContainerScreen, map));
            } else {
                screen = EmiApiMixin.client.f_91080_;
                if (screen instanceof BoMScreen) {
                    BoMScreen boMScreen = (BoMScreen)((Object)screen);
                    EmiApiMixin.push();
                    client.m_91152_(new RecipeScreen(boMScreen.old, map));
                } else {
                    screen = EmiApiMixin.client.f_91080_;
                    if (screen instanceof RecipeScreen) {
                        RecipeScreen recipeScreen = (RecipeScreen)screen;
                        EmiApiMixin.push();
                        screen = new RecipeScreen(recipeScreen.old, map);
                        client.m_91152_(screen);
                        ((RecipeScreen)screen).focusCategory(recipeScreen.getFocusedCategory());
                    }
                }
            }
        }
    }

    @Overwrite(remap=false)
    public static void displayUses(EmiIngredient emiIngredient) {
        if (!emiIngredient.isEmpty()) {
            List<EmiRecipe> list;
            EmiStack emiStack = (EmiStack)emiIngredient.getEmiStacks().get(0);
            ObjectArrayList objectArrayList = new ObjectArrayList();
            ObjectArrayList objectArrayList2 = EmiApiMixin.pruneUses(EmiApi.getRecipeManager().getRecipesByInput(emiStack), emiIngredient);
            objectArrayList2 = objectArrayList2 == null ? new ObjectArrayList() : new ObjectArrayList((Collection)objectArrayList2);
            EmiIngredient emiIngredient2 = EmiApiMixin.gtolib$getBucketFluid(emiIngredient);
            if (emiIngredient2 != null && (list = EmiApiMixin.pruneUses(EmiApi.getRecipeManager().getRecipesByInput((EmiStack)emiIngredient2.getEmiStacks().get(0)), emiIngredient2)) != null) {
                objectArrayList2.addAll(list);
            }
            list = EmiRecipes.byWorkstation.getOrDefault(emiStack, new ObjectArrayList());
            for (EmiRecipe emiRecipe : objectArrayList2) {
                if (objectArrayList.contains(emiRecipe)) continue;
                objectArrayList.add(emiRecipe);
            }
            for (EmiRecipe emiRecipe : list) {
                if (objectArrayList.contains(emiRecipe)) continue;
                objectArrayList.add(emiRecipe);
            }
            Map<EmiRecipeCategory, List<EmiRecipe>> map = EmiApiMixin.mapRecipes(objectArrayList);
            EmiApiMixin.setPages(map, emiIngredient);
        }
    }

    @Overwrite(remap=false)
    public static void displayRecipes(EmiIngredient emiIngredient) {
        Object object;
        if (emiIngredient instanceof EmiFavorite) {
            object = (EmiFavorite)((Object)emiIngredient);
            emiIngredient = ((EmiFavorite)object).getStack();
        }
        if (emiIngredient instanceof TagEmiIngredient) {
            object = (TagEmiIngredient)((Object)emiIngredient);
            for (EmiRecipe emiRecipe : EmiApi.getRecipeManager().getRecipes(VanillaPlugin.TAG)) {
                if (!(emiRecipe instanceof EmiTagRecipe)) continue;
                EmiTagRecipe emiTagRecipe = (EmiTagRecipe)((Object)emiRecipe);
                if (!emiTagRecipe.key.equals(((TagEmiIngredient)object).key)) continue;
                EmiApiMixin.setPages(Map.of((Object)VanillaPlugin.TAG, (Object)List.of((Object)emiRecipe)), emiIngredient);
                break;
            }
        } else if (emiIngredient instanceof ListEmiIngredient) {
            EmiApiMixin.setPages(Map.of((Object)VanillaPlugin.INGREDIENT, (Object)List.of((Object)new EmiSyntheticIngredientRecipe(emiIngredient))), emiIngredient);
        } else {
            ObjectArrayList objectArrayList = new ObjectArrayList();
            EmiIngredient emiIngredient2 = EmiApiMixin.gtolib$getBucketFluid(emiIngredient);
            EmiStack emiStack = (EmiStack)emiIngredient.getEmiStacks().get(0);
            if (emiIngredient2 != null) {
                EmiStack emiStack2 = (EmiStack)emiIngredient2.getEmiStacks().get(0);
                objectArrayList.addAll(EmiApiMixin.pruneSources(EmiApi.getRecipeManager().getRecipesByOutput(emiStack2), emiStack2));
            }
            if (emiIngredient.getEmiStacks().size() == 1) {
                objectArrayList.addAll(EmiApiMixin.pruneSources(EmiApi.getRecipeManager().getRecipesByOutput(emiStack), emiStack));
            } else if (!objectArrayList.isEmpty()) {
                emiStack = (EmiStack)emiIngredient2.getEmiStacks().get(0);
            }
            if (objectArrayList.isEmpty()) {
                return;
            }
            EmiApiMixin.setPages(EmiApiMixin.mapRecipes(objectArrayList), emiIngredient);
            EmiApi.focusRecipe(BoM.getRecipe(emiStack));
        }
    }

    @Unique
    private static EmiIngredient gtolib$getBucketFluid(EmiIngredient emiIngredient) {
        if (emiIngredient instanceof EmiStack) {
            EmiStack emiStack = (EmiStack)emiIngredient;
            AtomicReference<Fluid> atomicReference = new AtomicReference<Fluid>(Fluids.f_76191_);
            Object object = emiStack.getKey();
            if (object instanceof BucketItem) {
                BucketItem bucketItem = (BucketItem)object;
                atomicReference.set(bucketItem.getFluid());
            } else if (Optional.ofNullable(GenericStack.fromItemStack(emiStack.getItemStack())).map(GenericStack::what).stream().anyMatch(AEFluidKey.class::isInstance)) {
                object = (AEFluidKey)GenericStack.fromItemStack(emiStack.getItemStack()).what();
                atomicReference.set(((AEFluidKey)object).getFluid());
            } else if (emiStack.hasNbt()) {
                emiStack.getItemStack().getCapability(ForgeCapabilities.FLUID_HANDLER_ITEM).ifPresent(iFluidHandlerItem -> atomicReference.set(iFluidHandlerItem.getFluidInTank(0).getFluid()));
            }
            return atomicReference.get() == Fluids.f_76191_ ? null : EmiStack.of(atomicReference.get());
        }
        return null;
    }
}

package com.gtolib.mixin.emi;

import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.ItemEmiStack;
import dev.emi.emi.search.EmiSearch;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={EmiSearch.class})
public class EmiSearchMixin {
    @Redirect(method={"bake"}, at=@At(value="INVOKE", target="Ldev/emi/emi/api/stack/EmiStack;getTooltipText()Ljava/util/List;"), remap=false)
    private static List<Component> getTooltipText(EmiStack emiStack) {
        if (emiStack instanceof ItemEmiStack) {
            ItemEmiStack itemEmiStack = (ItemEmiStack)emiStack;
            ItemStack itemStack = itemEmiStack.getItemStack();
            ObjectArrayList objectArrayList = new ObjectArrayList();
            objectArrayList.add(itemStack.m_41786_());
            ((Item)itemEmiStack.getKey()).m_7373_(itemStack, null, objectArrayList, TooltipFlag.f_256752_);
            return objectArrayList;
        }
        return null;
    }
}

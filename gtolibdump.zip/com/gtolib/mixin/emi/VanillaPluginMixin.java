package com.gtolib.mixin.emi;

import java.util.Collections;
import java.util.List;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.helpers.IJeiHelpers;
import mezz.jei.api.helpers.IPlatformFluidHelper;
import mezz.jei.api.recipe.category.IRecipeCategory;
import mezz.jei.api.registration.IGuiHandlerRegistration;
import mezz.jei.api.registration.IRecipeCatalystRegistration;
import mezz.jei.api.registration.IRecipeCategoryRegistration;
import mezz.jei.api.registration.IRecipeRegistration;
import mezz.jei.api.registration.IRecipeTransferRegistration;
import mezz.jei.api.registration.ISubtypeRegistration;
import mezz.jei.api.registration.IVanillaCategoryExtensionRegistration;
import mezz.jei.common.platform.IPlatformRegistry;
import mezz.jei.common.util.StackHelper;
import mezz.jei.library.plugins.vanilla.VanillaPlugin;
import mezz.jei.library.plugins.vanilla.anvil.AnvilRecipeCategory;
import mezz.jei.library.plugins.vanilla.anvil.SmithingRecipeCategory;
import mezz.jei.library.plugins.vanilla.crafting.CraftingRecipeCategory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.material.Fluid;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={VanillaPlugin.class})
public class VanillaPluginMixin {
    @Shadow(remap=false)
    @Nullable
    private CraftingRecipeCategory craftingCategory;
    @Shadow(remap=false)
    @Nullable
    private SmithingRecipeCategory smithingCategory;

    @Overwrite(remap=false)
    public void registerItemSubtypes(ISubtypeRegistration iSubtypeRegistration) {
    }

    @Redirect(method={"registerIngredients"}, at=@At(value="INVOKE", target="Lmezz/jei/library/plugins/vanilla/ingredients/ItemStackListFactory;create(Lmezz/jei/common/util/StackHelper;)Ljava/util/List;"), remap=false)
    private List<ItemStack> createItem(StackHelper stackHelper) {
        return Collections.emptyList();
    }

    @Redirect(method={"registerFluidIngredients"}, at=@At(value="INVOKE", target="Lmezz/jei/library/plugins/vanilla/ingredients/fluid/FluidStackListFactory;create(Lmezz/jei/common/platform/IPlatformRegistry;Lmezz/jei/api/helpers/IPlatformFluidHelper;)Ljava/util/List;"), remap=false)
    private <T> List<T> createFluid(IPlatformRegistry<Fluid> iPlatformRegistry, IPlatformFluidHelper<T> iPlatformFluidHelper) {
        return Collections.emptyList();
    }

    @Overwrite(remap=false)
    public void registerCategories(IRecipeCategoryRegistration iRecipeCategoryRegistration) {
        IJeiHelpers iJeiHelpers = iRecipeCategoryRegistration.getJeiHelpers();
        IGuiHelper iGuiHelper = iJeiHelpers.getGuiHelper();
        IRecipeCategory[] iRecipeCategoryArray = new IRecipeCategory[3];
        this.craftingCategory = new CraftingRecipeCategory(iGuiHelper);
        iRecipeCategoryArray[0] = this.craftingCategory;
        this.smithingCategory = new SmithingRecipeCategory(iGuiHelper);
        iRecipeCategoryArray[1] = this.smithingCategory;
        iRecipeCategoryArray[2] = new AnvilRecipeCategory(iGuiHelper);
        iRecipeCategoryRegistration.addRecipeCategories(iRecipeCategoryArray);
    }

    @Overwrite(remap=false)
    public void registerVanillaCategoryExtensions(IVanillaCategoryExtensionRegistration iVanillaCategoryExtensionRegistration) {
    }

    @Overwrite(remap=false)
    public void registerRecipes(IRecipeRegistration iRecipeRegistration) {
    }

    @Overwrite(remap=false)
    public void registerGuiHandlers(IGuiHandlerRegistration iGuiHandlerRegistration) {
    }

    @Overwrite(remap=false)
    public void registerRecipeTransferHandlers(IRecipeTransferRegistration iRecipeTransferRegistration) {
    }

    @Overwrite(remap=false)
    public void registerRecipeCatalysts(IRecipeCatalystRegistration iRecipeCatalystRegistration) {
    }
}

package com.gtolib.mixin.emi;

import com.google.common.collect.Lists;
import com.gtocore.integration.emi.GTEMIPlugin;
import dev.emi.emi.platform.EmiAgnos;
import dev.emi.emi.registry.EmiPluginContainer;
import java.util.ArrayList;
import java.util.List;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={EmiAgnos.class})
public final class EmiAgnosMixin {
    @Overwrite(remap=false)
    public static List<EmiPluginContainer> getPlugins() {
        ArrayList<EmiPluginContainer> arrayList = Lists.newArrayList();
        GTEMIPlugin.addEMIPlugin(arrayList);
        return arrayList;
    }
}

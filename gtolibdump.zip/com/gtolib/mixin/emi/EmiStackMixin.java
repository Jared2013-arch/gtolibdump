package com.gtolib.mixin.emi;

import com.gregtechceu.gtceu.api.item.DrumMachineItem;
import com.gregtechceu.gtceu.common.data.GTItems;
import dev.emi.emi.api.stack.EmiStack;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.fluids.FluidStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={EmiStack.class})
public final class EmiStackMixin {
    @Unique
    private static final Set<Item> gtolib$CELL = Set.of((Object)GTItems.FLUID_CELL.m_5456_(), (Object)GTItems.FLUID_CELL_UNIVERSAL.m_5456_(), (Object)GTItems.FLUID_CELL_LARGE_STEEL.m_5456_(), (Object)GTItems.FLUID_CELL_LARGE_ALUMINIUM.m_5456_(), (Object)GTItems.FLUID_CELL_LARGE_STAINLESS_STEEL.m_5456_(), (Object)GTItems.FLUID_CELL_LARGE_TITANIUM.m_5456_(), (Object)GTItems.FLUID_CELL_GLASS_VIAL.m_5456_());

    @Shadow(remap=false)
    public static EmiStack of(Fluid fluid, long l) {
        return null;
    }

    @Inject(method={"of(Lnet/minecraft/world/item/ItemStack;)Ldev/emi/emi/api/stack/EmiStack;"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private static void onItemStackOf(ItemStack itemStack, CallbackInfoReturnable<EmiStack> callbackInfoReturnable) {
        EmiStack emiStack = EmiStackMixin.gtolib$extracted(itemStack);
        if (emiStack != null) {
            callbackInfoReturnable.setReturnValue((Object)emiStack);
        }
    }

    @Inject(method={"of(Lnet/minecraft/world/item/ItemStack;J)Ldev/emi/emi/api/stack/EmiStack;"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private static void onItemStackOfWithAmount(ItemStack itemStack, long l, CallbackInfoReturnable<EmiStack> callbackInfoReturnable) {
        EmiStack emiStack;
        if (l == 1L && (emiStack = EmiStackMixin.gtolib$extracted(itemStack)) != null) {
            callbackInfoReturnable.setReturnValue((Object)emiStack);
        }
    }

    @Unique
    private static EmiStack gtolib$extracted(ItemStack itemStack) {
        Item item;
        if (itemStack.m_41782_() && ((item = itemStack.m_41720_()) instanceof DrumMachineItem || gtolib$CELL.contains(item))) {
            AtomicReference atomicReference = new AtomicReference();
            itemStack.getCapability(ForgeCapabilities.FLUID_HANDLER_ITEM).ifPresent(iFluidHandlerItem -> {
                FluidStack fluidStack = iFluidHandlerItem.getFluidInTank(0);
                if (!fluidStack.isEmpty()) {
                    atomicReference.set(EmiStackMixin.of(fluidStack.getFluid(), fluidStack.getAmount()));
                }
            });
            return (EmiStack)atomicReference.get();
        }
        return null;
    }
}

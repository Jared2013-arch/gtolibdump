package com.gtolib.mixin.emi;

import com.gtocore.integration.emi.multipage.CustomModularEmiRecipe;
import dev.emi.emi.api.EmiApi;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.widget.Bounds;
import dev.emi.emi.api.widget.Widget;
import dev.emi.emi.config.EmiConfig;
import dev.emi.emi.config.SidebarSide;
import dev.emi.emi.screen.RecipeScreen;
import dev.emi.emi.screen.RecipeTab;
import dev.emi.emi.screen.WidgetGroup;
import dev.ftb.mods.ftblibrary.ui.ScreenWrapper;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={RecipeScreen.class})
public abstract class RecipeScreenMixin
extends Screen {
    @Shadow(remap=false)
    int x;
    @Shadow(remap=false)
    int backgroundHeight;
    @Shadow(remap=false)
    int backgroundWidth;
    @Shadow(remap=false)
    int y;
    @Shadow(remap=false)
    private List<RecipeTab> tabs;
    @Shadow(remap=false)
    private int tab;
    @Shadow(remap=false)
    private List<WidgetGroup> currentPage;
    @Unique
    private ScreenWrapper gtocore$oldQuest = null;

    protected RecipeScreenMixin(Component component) {
        super(component);
    }

    @Shadow(remap=false)
    public abstract int getResolveOffset();

    @ModifyArg(method={"render"}, at=@At(value="INVOKE", target="Ldev/emi/emi/EmiRenderHelper;drawNinePatch(Ldev/emi/emi/runtime/EmiDrawContext;Lnet/minecraft/resources/ResourceLocation;IIIIIIII)V", ordinal=4, remap=false), index=2)
    private int modifyx(int n) {
        return n + 18 - 18 * this.gtolib$getList(this.gtolib$getWorkstationAmount());
    }

    @ModifyArg(method={"render"}, at=@At(value="INVOKE", target="Ldev/emi/emi/EmiRenderHelper;drawNinePatch(Ldev/emi/emi/runtime/EmiDrawContext;Lnet/minecraft/resources/ResourceLocation;IIIIIIII)V", ordinal=4, remap=false), index=4)
    private int modifyw(int n) {
        return n - 18 + 18 * this.gtolib$getList(this.gtolib$getWorkstationAmount());
    }

    @ModifyArg(method={"render"}, at=@At(value="INVOKE", target="Ldev/emi/emi/EmiRenderHelper;drawNinePatch(Ldev/emi/emi/runtime/EmiDrawContext;Lnet/minecraft/resources/ResourceLocation;IIIIIIII)V", ordinal=4, remap=false), index=5)
    private int modifyh(int n) {
        return 10 + Math.min(this.gtolib$getWorkstationAmount(), this.gtolib$maxWorkstations()) * 18 + this.getResolveOffset();
    }

    @Inject(method={"<init>"}, at={@At(value="TAIL")}, remap=false)
    public void hookInit(AbstractContainerScreen<?> abstractContainerScreen, Map<EmiRecipeCategory, List<EmiRecipe>> map, CallbackInfo callbackInfo) {
        Screen screen = Minecraft.m_91087_().f_91080_;
        if (screen instanceof ScreenWrapper) {
            ScreenWrapper screenWrapper;
            this.gtocore$oldQuest = screenWrapper = (ScreenWrapper)screen;
        }
    }

    @Inject(method={"onClose"}, at={@At(value="HEAD")}, cancellable=true)
    public void onClose(CallbackInfo callbackInfo) {
        if (this.gtocore$oldQuest != null) {
            Minecraft.m_91087_().m_91152_(this.gtocore$oldQuest);
            callbackInfo.cancel();
        }
    }

    @Inject(method={"keyPressed"}, at={@At(value="HEAD")}, cancellable=true)
    private void initKeyPressed(int n, int n2, int n3, CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        for (WidgetGroup widgetGroup : this.currentPage) {
            for (Widget widget : widgetGroup.widgets) {
                CustomModularEmiRecipe customModularEmiRecipe;
                if (!(widget instanceof CustomModularEmiRecipe) || !(customModularEmiRecipe = (CustomModularEmiRecipe)((Object)widget)).m_7933_(n, n2, n3)) continue;
                callbackInfoReturnable.setReturnValue((Object)true);
            }
        }
    }

    @Overwrite(remap=false)
    public Bounds getWorkstationBounds(int n) {
        Bounds bounds = Bounds.EMPTY;
        int n2 = 0;
        if (n == -1) {
            n = 0;
            n2 = -this.getResolveOffset();
        }
        if (EmiConfig.workstationLocation == SidebarSide.LEFT) {
            bounds = new Bounds(this.x - this.gtolib$getList(n) * 18, this.y + 9 + this.getResolveOffset() + n % this.gtolib$maxWorkstations() * 18 + n2, 18, 18);
        } else if (EmiConfig.workstationLocation == SidebarSide.RIGHT) {
            bounds = new Bounds(this.x + this.gtolib$getList(n) * this.backgroundWidth, this.y + 9 + this.getResolveOffset() + n % this.gtolib$maxWorkstations() * 18 + n2, 18, 18);
        } else if (EmiConfig.workstationLocation == SidebarSide.BOTTOM) {
            bounds = new Bounds(this.x + 5 + this.getResolveOffset() + n * 18 + n2, this.y + this.backgroundHeight - 23, 18, 18);
        }
        return bounds;
    }

    @Overwrite(remap=false)
    public int getMaxWorkstations() {
        return Integer.MAX_VALUE;
    }

    @Unique
    private int gtolib$getWorkstationAmount() {
        return EmiApi.getRecipeManager().getWorkstations(this.tabs.get((int)this.tab).category).size();
    }

    @Unique
    private int gtolib$getList(int n) {
        return (int)Math.floor((double)n / (double)this.gtolib$maxWorkstations()) + 1;
    }

    @Unique
    private int gtolib$maxWorkstations() {
        return switch (EmiConfig.workstationLocation.ordinal()) {
            case 1, 2 -> (this.backgroundHeight - this.getResolveOffset() - 18) / 18;
            case 4 -> (this.backgroundWidth - this.getResolveOffset() - 18) / 18;
            default -> 0;
        };
    }
}

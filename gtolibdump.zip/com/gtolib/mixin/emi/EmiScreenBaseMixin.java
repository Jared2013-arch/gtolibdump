package com.gtolib.mixin.emi;

import appeng.client.gui.me.crafting.CraftConfirmScreen;
import appeng.client.gui.me.crafting.CraftingCPUScreen;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import dev.emi.emi.screen.EmiScreenBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={EmiScreenBase.class})
public class EmiScreenBaseMixin {
    @ModifyExpressionValue(method={"of"}, at={@At(value="INVOKE", target="Lnet/minecraft/core/NonNullList;isEmpty()Z", remap=false)}, remap=false)
    private static boolean addCustomScreenSupport(boolean bl) {
        return !EmiScreenBaseMixin.gto$isCustomScreen() && bl;
    }

    @Unique
    private static boolean gto$isCustomScreen() {
        Screen screen = Minecraft.m_91087_().f_91080_;
        return screen instanceof CraftingCPUScreen || screen instanceof CraftConfirmScreen;
    }
}

package com.gtolib.mixin.emi;

import appeng.integration.modules.jeirei.EncodingHelper;
import appeng.menu.me.common.GridInventoryEntry;
import com.gregtechceu.gtceu.utils.collection.OpenCacheHashSet;
import com.gtolib.ae2.me2in1.a.a;
import com.gtolib.mixin.emi.EncodingHelperAccesspr;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import java.util.Comparator;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value={EncodingHelper.class}, remap=false)
public abstract class EncodingHelperAccesspr$EncodingHelperMixin {
    @ModifyVariable(method={"getIngredientPriorities"}, at=@At(value="HEAD"), argsOnly=true, index=1, remap=false)
    private static Comparator<GridInventoryEntry> modifyComparator(Comparator<GridInventoryEntry> comparator) {
        if (Objects.equals(comparator, EncodingHelperAccesspr.entryComparator())) {
            return a.a();
        }
        return comparator;
    }

    @ModifyExpressionValue(method={"getIngredientPriorities"}, at={@At(value="INVOKE", target="Lappeng/menu/me/common/IClientRepo;getAllEntries()Ljava/util/Set;")}, remap=false)
    private static Set<GridInventoryEntry> modifyMEStorageEntriesForSorting(Set<GridInventoryEntry> set) {
        Set set2 = com.gtolib.c.a.a.b.stream().map(aEKey -> new GridInventoryEntry(-1L, aEKey, 0L, 0L, false)).collect(Collectors.toSet());
        if (!set2.isEmpty()) {
            OpenCacheHashSet openCacheHashSet = new OpenCacheHashSet(set);
            openCacheHashSet.addAll(set2);
            return openCacheHashSet;
        }
        return set;
    }
}

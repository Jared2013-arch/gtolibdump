package com.gtolib.mixin.mc;

import appeng.api.stacks.AEFluidKey;
import com.gregtechceu.gtceu.api.recipe.ingredient.FluidIngredient;
import com.gtocore.mixin.ae2.stacks.AEFluidKeyInvoker;
import com.gtolib.IFluid;
import com.gtolib.IUnique;
import com.gtolib.api.recipe.lookup.MapIngredient;
import com.gtolib.utils.RLUtils;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.registries.ForgeRegistries;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(value={Fluid.class})
public class FluidMixin
implements IFluid {
    @Unique
    private int gtolib$mapFluid;
    @Unique
    private AEFluidKey gtolib$aeFluidKey;
    @Unique
    private FluidIngredient.FluidValue gtolib$fluidValue;
    @Unique
    private ResourceLocation gtolib$id;
    @Unique
    private String gtolib$string;
    @Unique
    private int gtolib$uid = -1;

    @Override
    public int getUid() {
        if (this.gtolib$uid == -1) {
            this.gtolib$uid = IUnique.ID.incrementAndGet();
        }
        return this.gtolib$uid;
    }

    @Override
    @NotNull
    public ResourceLocation gtolib$getIdLocation() {
        if (this.gtolib$id == null) {
            this.gtolib$id = ForgeRegistries.FLUIDS.getKey((Fluid)((Object)this));
            if (this.gtolib$id == null) {
                this.gtolib$id = RLUtils.mc("water");
            }
        }
        return this.gtolib$id;
    }

    @Override
    @NotNull
    public String gtolib$getIdString() {
        if (this.gtolib$string == null) {
            this.gtolib$string = this.gtolib$getIdLocation().toString();
        }
        return this.gtolib$string;
    }

    @Override
    @NotNull
    public AEFluidKey gtolib$getAEKey() {
        if (this.gtolib$aeFluidKey == null) {
            this.gtolib$aeFluidKey = AEFluidKeyInvoker.of((Fluid)((Object)this), null);
        }
        return this.gtolib$aeFluidKey;
    }

    @Override
    public  @NotNull FluidIngredient.FluidValue gtolib$getFluidValue() {
        if (this.gtolib$fluidValue == null) {
            this.gtolib$fluidValue = new FluidIngredient.FluidValue((Fluid)((Object)this));
        }
        return this.gtolib$fluidValue;
    }

    @Override
    public int gtolib$getMapFluid() {
        return this.gtolib$mapFluid;
    }

    @Override
    public int gtolib$getOrCreateMapFluid() {
        if (this.gtolib$mapFluid == 0) {
            this.gtolib$mapFluid = MapIngredient.getCount(null);
        }
        return this.gtolib$mapFluid;
    }
}

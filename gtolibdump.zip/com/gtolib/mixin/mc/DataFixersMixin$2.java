package com.gtolib.mixin.mc;

import com.google.common.collect.ImmutableMap;
import com.mojang.datafixers.DSL;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.Type;
import com.mojang.datafixers.types.templates.TaggedChoice;
import com.mojang.datafixers.types.templates.TypeTemplate;
import java.util.Map;
import java.util.function.Supplier;

class DataFixersMixin$2
extends Schema {
    DataFixersMixin$2(int n, Schema schema) {
        super(n, schema);
    }

    public Map<String, Supplier<TypeTemplate>> registerEntities(Schema schema) {
        return ImmutableMap.of();
    }

    public Map<String, Supplier<TypeTemplate>> registerBlockEntities(Schema schema) {
        return ImmutableMap.of();
    }

    public void registerTypes(Schema schema, Map<String, Supplier<TypeTemplate>> map, Map<String, Supplier<TypeTemplate>> map2) {
    }

    protected Map<String, Type<?>> buildTypes() {
        return ImmutableMap.of();
    }

    public Type<?> getType(DSL.TypeReference typeReference) {
        return null;
    }

    public Type<?> getChoiceType(DSL.TypeReference typeReference, String string) {
        return null;
    }

    public Type<?> getTypeRaw(DSL.TypeReference typeReference) {
        return null;
    }

    public TaggedChoice.TaggedChoiceType<?> findChoiceType(DSL.TypeReference typeReference) {
        return null;
    }
}

package com.gtolib.mixin.mc;

import appeng.api.stacks.AEItemKey;
import com.gtocore.mixin.ae2.stacks.AEItemKeyInvoker;
import com.gtolib.IItem;
import com.gtolib.IUnique;
import com.gtolib.api.ae2.stacks.IAEItemKey;
import com.gtolib.utils.RLUtils;
import java.util.function.Supplier;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;
import net.minecraftforge.common.extensions.IForgeItem;
import net.minecraftforge.registries.ForgeRegistries;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(value={Item.class}, priority=0)
public abstract class ItemMixin
implements IItem,
IForgeItem {
    @Shadow
    @Final
    private int f_41371_;
    @Shadow
    @Final
    private int f_41370_;
    @Unique
    private ItemStack gtolib$readOnlyStack;
    @Unique
    private Ingredient gtolib$innerIngredient;
    @Unique
    private AEItemKey gtolib$aeItemKey;
    @Unique
    private int[] gtolib$mapItem;
    @Unique
    private ResourceLocation gtolib$location;
    @Unique
    private String gtolib$string;
    @Unique
    private Supplier<Component>[] gtolib$components;
    @Unique
    private int gtolib$uid = -1;

    @Shadow
    @Deprecated
    public abstract int m_41459_();

    @Shadow
    public abstract boolean m_41465_();

    @Override
    public int getUid() {
        if (this.gtolib$uid == -1) {
            this.gtolib$uid = IUnique.ID.incrementAndGet();
        }
        return this.gtolib$uid;
    }

    @Override
    @NotNull
    public ResourceLocation gtolib$getIdLocation() {
        if (this.gtolib$location == null) {
            this.gtolib$location = ForgeRegistries.ITEMS.getKey((Item)((Object)this));
            if (this.gtolib$location == null) {
                this.gtolib$location = RLUtils.mc("air");
            }
        }
        return this.gtolib$location;
    }

    @Override
    @NotNull
    public String gtolib$getIdString() {
        if (this.gtolib$string == null) {
            this.gtolib$string = this.gtolib$getIdLocation().toString();
        }
        return this.gtolib$string;
    }

    @Override
    @NotNull
    public Ingredient gtolib$getInnerIngredient() {
        if (this.gtolib$innerIngredient == null) {
            this.gtolib$innerIngredient = Ingredient.m_43929_(new ItemLike[]{(Item)((Object)this)});
        }
        return this.gtolib$innerIngredient;
    }

    @Override
    @NotNull
    public AEItemKey gtolib$getAEKey() {
        if (this.gtolib$aeItemKey == null) {
            this.gtolib$aeItemKey = AEItemKeyInvoker.of((Item)((Object)this), null, null);
            ((IAEItemKey)((Object)this.gtolib$aeItemKey)).gtolib$setMaxStackSize(this.m_41459_());
        }
        return this.gtolib$aeItemKey;
    }

    @Override
    public int[] gtolib$getMapItem() {
        return this.gtolib$mapItem;
    }

    @Override
    public void gtolib$setMapItem(int @NotNull [] nArray) {
        this.gtolib$mapItem = nArray;
    }

    @Override
    @NotNull
    public ItemStack gtolib$getReadOnlyStack() {
        if (this.gtolib$readOnlyStack == null) {
            this.gtolib$readOnlyStack = new ItemStack((Item)((Object)this));
        }
        return this.gtolib$readOnlyStack;
    }

    @Override
    public int compareTo(@NotNull Item item) {
        if (item == this) {
            return 0;
        }
        return 1;
    }

    @Override
    @SafeVarargs
    public final void gtolib$setToolTips(Supplier<Component> ... supplierArray) {
        this.gtolib$components = supplierArray;
    }

    @Override
    public Supplier<Component>[] gtolib$getToolTips() {
        return this.gtolib$components;
    }

    public int getMaxDamage(ItemStack itemStack) {
        return this.f_41371_;
    }

    public int getMaxStackSize(ItemStack itemStack) {
        return this.f_41370_;
    }

    public boolean isDamageable(ItemStack itemStack) {
        return this.m_41465_();
    }
}

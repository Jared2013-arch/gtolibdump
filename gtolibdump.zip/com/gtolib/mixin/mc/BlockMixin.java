package com.gtolib.mixin.mc;

import com.gtolib.d;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.extensions.IForgeBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(value={Block.class})
public abstract class BlockMixin
implements IForgeBlock {
    @Shadow
    public abstract void m_7592_(Level var1, BlockPos var2, Explosion var3);

    public void onBlockExploded(BlockState blockState, Level level, BlockPos blockPos, Explosion explosion) {
        d.a(level, blockPos, true, true);
        this.m_7592_(level, blockPos, explosion);
    }
}

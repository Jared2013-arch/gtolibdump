package com.gtolib.mixin.mc;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.gtocore.common.data.GTOLoots;
import com.mojang.datafixers.util.Pair;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.level.storage.loot.LootDataId;
import net.minecraft.world.level.storage.loot.LootDataManager;
import net.minecraft.world.level.storage.loot.LootDataType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={LootDataManager.class}, priority=0)
public class LootDataManagerMixin {
    @Shadow
    private Multimap<LootDataType<?>, ResourceLocation> f_278404_;
    @Shadow
    private Map<LootDataId<?>, ?> f_278415_;

    @Inject(method={"scheduleElementParse"}, at={@At(value="HEAD")}, cancellable=true)
    private static <T> void scheduleElementParse(LootDataType<T> lootDataType, ResourceManager resourceManager, Executor executor, Map<LootDataType<?>, Map<ResourceLocation, ?>> map, CallbackInfoReturnable<CompletableFuture<?>> callbackInfoReturnable) {
        if (GTOLoots.cache) {
            callbackInfoReturnable.setReturnValue(CompletableFuture.runAsync(() -> {}, executor));
        }
    }

    @Inject(method={"apply"}, at={@At(value="HEAD")}, cancellable=true)
    private void apply(Map<LootDataType<?>, Map<ResourceLocation, ?>> map, CallbackInfo callbackInfo) {
        callbackInfo.cancel();
        if (!GTOLoots.cache) {
            GTOLoots.cache = true;
            Pair pair = GTOLoots.apply(map);
            GTOLoots.ELEMENTS_CACHE = (ImmutableMap)pair.getFirst();
            GTOLoots.TYPEKEYS_CACHE = (ImmutableMultimap)pair.getSecond();
        }
        this.f_278415_ = GTOLoots.ELEMENTS_CACHE;
        this.f_278404_ = GTOLoots.TYPEKEYS_CACHE;
    }
}

package com.gtolib.mixin.mc;

import com.gtocore.config.GTOConfig;
import com.gtocore.config.SparkRange;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.worldselection.WorldOpenFlows;
import org.embeddedt.modernfix.spark.SparkLaunchProfiler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={WorldOpenFlows.class})
public class WorldOpenFlowsMixin {
    @Inject(method={"loadLevel"}, at={@At(value="HEAD")})
    private void loadLevel(Screen screen, String string, CallbackInfo callbackInfo) {
        if (GTOConfig.INSTANCE.startSpark == SparkRange.WORLD) {
            SparkLaunchProfiler.start("all");
        }
    }
}

package com.gtolib.mixin.mc;

import com.gtolib.GTOCore;
import com.gtolib.api.annotation.dynamic.DynamicInitialData;
import com.gtolib.b;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.world.level.LevelSettings;
import net.minecraft.world.level.storage.LevelSummary;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={LevelSummary.class})
public class LevelSummaryMixin {
    @Shadow
    @Final
    private LevelSettings f_78344_;

    @Redirect(method={"createInfo"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/level/storage/LevelSummary;hasCheats()Z"))
    private boolean gtolib$redirectHasCheats(LevelSummary levelSummary, @Local MutableComponent mutableComponent) {
        if (((b)((Object)this.f_78344_)).gto$isSrm()) {
            mutableComponent.m_130946_(", ").m_7220_(Component.m_237115_("selectWorld.self_restraint_mode.enabled").m_130940_(ChatFormatting.RED));
            return false;
        }
        return levelSummary.m_78369_();
    }

    @Inject(method={"createInfo"}, at={@At(value="INVOKE", target="Lnet/minecraft/world/level/storage/LevelSummary;isExperimental()Z", shift=At.Shift.BEFORE)})
    private void gtolib$injectDifficultyInfo(CallbackInfoReturnable<Component> callbackInfoReturnable, @Local MutableComponent mutableComponent) {
        int n = ((b)((Object)this.f_78344_)).gto$getGTODifficulty();
        Component component = n > 0 ? DynamicInitialData.getDifficultyComponent(n) : Component.m_237115_("gtocore.tooltip.unknown").m_130940_(ChatFormatting.DARK_AQUA);
        mutableComponent.m_130946_(", ").m_7220_(Component.m_237110_("selectWorld.gto_difficulty", new Object[]{component}));
        mutableComponent.m_130946_("[").m_7220_(GTOCore.difficulty == n ? Component.m_237113_("✔").m_130940_(ChatFormatting.GREEN).m_6270_(Style.f_131099_.m_131144_(new HoverEvent(HoverEvent.Action.f_130831_, Component.m_237115_("selectWorld.gto_difficulty.current")))) : Component.m_237113_("×").m_130940_(ChatFormatting.RED).m_6270_(Style.f_131099_.m_131144_(new HoverEvent(HoverEvent.Action.f_130831_, Component.m_237115_("selectWorld.gto_difficulty.not_current"))))).m_130946_("]");
        if (((b)((Object)this.f_78344_)).gto$isDevMode()) {
            mutableComponent.m_7220_(Component.m_237113_(" ["));
            mutableComponent.m_7220_(Component.m_237115_("selectWorld.dev_mode").m_130940_(ChatFormatting.AQUA));
            mutableComponent.m_7220_(Component.m_237113_("]"));
        }
    }
}

package com.gtolib.mixin.mc;

import com.gtocore.config.GTOConfig;
import com.gtolib.GTOCore;
import com.gtolib.utils.ServerUtils;
import net.minecraft.core.RegistryAccess;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.storage.PrimaryLevelData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={PrimaryLevelData.class})
public class PrimaryLevelDataMixin {
    @Inject(method={"setTagData"}, at={@At(value="TAIL")})
    private void onSetTagData(RegistryAccess registryAccess, CompoundTag compoundTag, CompoundTag compoundTag2, CallbackInfo callbackInfo) {
        compoundTag.m_128405_("gto$Difficulty", Math.max(GTOCore.difficulty, ServerUtils.getPersistentData().m_128451_("difficulty")));
        compoundTag.m_128379_("gto$SelfRestraint", ServerUtils.getPersistentData().m_128471_("srm") || GTOConfig.INSTANCE.selfRestraint);
        compoundTag.m_128379_("gto$Dev", ServerUtils.getPersistentData().m_128471_("dev") || GTOConfig.INSTANCE.dev);
    }
}

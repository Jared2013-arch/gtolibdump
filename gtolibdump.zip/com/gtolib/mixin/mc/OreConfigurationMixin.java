package com.gtolib.mixin.mc;

import com.kyanite.deeperdarker.content.DDBlocks;
import java.util.List;
import java.util.Set;
import mythicbotany.register.ModBlocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.feature.configurations.OreConfiguration;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value={OreConfiguration.class}, priority=0)
public class OreConfigurationMixin {
    @Unique
    private static Set<Block> EXCLUDED_ORE;

    @ModifyVariable(method={"<init>(Ljava/util/List;IF)V"}, at=@At(value="HEAD"), index=1, argsOnly=true)
    private static List<OreConfiguration.TargetBlockState> gtolib$init(List<OreConfiguration.TargetBlockState> list) {
        if (EXCLUDED_ORE == null) {
            EXCLUDED_ORE = Set.of((Object[])new Block[]{Blocks.f_49997_, Blocks.f_152469_, Blocks.f_152505_, Blocks.f_152506_, Blocks.f_49996_, Blocks.f_152468_, Blocks.f_49995_, Blocks.f_152467_, Blocks.f_49998_, Blocks.f_50089_, Blocks.f_152474_, Blocks.f_50264_, Blocks.f_152479_, Blocks.f_50059_, Blocks.f_152472_, Blocks.f_50173_, Blocks.f_152473_, Blocks.f_50331_, (Block)earth.terrarium.adastra.common.registry.ModBlocks.MOON_DESH_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.DEEPSLATE_DESH_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.MOON_IRON_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.MOON_ICE_SHARD_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.DEEPSLATE_ICE_SHARD_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.MARS_IRON_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.MARS_DIAMOND_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.MARS_OSTRUM_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.DEEPSLATE_OSTRUM_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.MARS_ICE_SHARD_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.MERCURY_IRON_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.VENUS_COAL_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.VENUS_GOLD_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.VENUS_DIAMOND_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.VENUS_CALORITE_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.DEEPSLATE_CALORITE_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.GLACIO_ICE_SHARD_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.GLACIO_COAL_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.GLACIO_COPPER_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.GLACIO_IRON_ORE.get(), (Block)earth.terrarium.adastra.common.registry.ModBlocks.GLACIO_LAPIS_ORE.get(), (Block)DDBlocks.SCULK_STONE_COAL_ORE.get(), (Block)DDBlocks.SCULK_STONE_IRON_ORE.get(), (Block)DDBlocks.SCULK_STONE_COPPER_ORE.get(), (Block)DDBlocks.SCULK_STONE_GOLD_ORE.get(), (Block)DDBlocks.SCULK_STONE_REDSTONE_ORE.get(), (Block)DDBlocks.SCULK_STONE_EMERALD_ORE.get(), (Block)DDBlocks.SCULK_STONE_LAPIS_ORE.get(), (Block)DDBlocks.SCULK_STONE_DIAMOND_ORE.get(), (Block)DDBlocks.GLOOMSLATE_COAL_ORE.get(), (Block)DDBlocks.GLOOMSLATE_IRON_ORE.get(), (Block)DDBlocks.GLOOMSLATE_COPPER_ORE.get(), (Block)DDBlocks.GLOOMSLATE_GOLD_ORE.get(), (Block)DDBlocks.GLOOMSLATE_REDSTONE_ORE.get(), (Block)DDBlocks.GLOOMSLATE_EMERALD_ORE.get(), (Block)DDBlocks.GLOOMSLATE_LAPIS_ORE.get(), (Block)DDBlocks.GLOOMSLATE_DIAMOND_ORE.get(), ModBlocks.elementiumOre, ModBlocks.dragonstoneOre, ModBlocks.goldOre});
        }
        return list.stream().filter(targetBlockState -> !EXCLUDED_ORE.contains(targetBlockState.f_161033_.m_60734_())).toList();
    }
}

package com.gtolib.mixin.mc;

import com.gtolib.utils.MathUtil;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={Mth.class}, priority=0)
public final class MthMixin {
    @Overwrite
    public static float m_14031_(float f) {
        return MathUtil.sin(f);
    }

    @Overwrite
    public static float m_14089_(float f) {
        return MathUtil.cos(f);
    }
}

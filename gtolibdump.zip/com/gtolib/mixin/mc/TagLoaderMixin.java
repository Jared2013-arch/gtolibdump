package com.gtolib.mixin.mc;

import com.google.common.collect.ImmutableMap;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.gregtechceu.gtceu.core.MixinHelpers;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtocore.common.data.GTOTags;
import com.gtolib.GTOCore;
import com.gtolib.c;
import com.mojang.serialization.Dynamic;
import com.mojang.serialization.JsonOps;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.io.BufferedReader;
import java.io.Reader;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import net.minecraft.core.Registry;
import net.minecraft.resources.FileToIdConverter;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.tags.TagEntry;
import net.minecraft.tags.TagFile;
import net.minecraft.tags.TagLoader;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={TagLoader.class}, priority=0)
public class TagLoaderMixin
implements c {
    @Shadow
    @Final
    private String f_13449_;
    @Unique
    private Registry<?> gtceu$storedRegistry;

    @Override
    public void gtceu$setRegistry(Registry<?> registry) {
        this.gtceu$storedRegistry = registry;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Inject(method={"build(Ljava/util/Map;)Ljava/util/Map;"}, at={@At(value="RETURN")})
    public void gtceu$build(Map<ResourceLocation, List<TagLoader.EntryWithSource>> map, CallbackInfoReturnable<Map<ResourceLocation, Collection<?>>> callbackInfoReturnable) {
        Map map2 = MixinHelpers.TAG_CACHE;
        synchronized (map2) {
            MixinHelpers.TAG_CACHE.computeIfAbsent(this.gtceu$storedRegistry, registry -> ImmutableMap.copyOf((Map)callbackInfoReturnable.getReturnValue()));
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Inject(method={"build(Ljava/util/Map;)Ljava/util/Map;"}, at={@At(value="HEAD")}, cancellable=true)
    public void gtceu$setbuild(Map<ResourceLocation, List<TagLoader.EntryWithSource>> map, CallbackInfoReturnable<Map<ResourceLocation, Collection<?>>> callbackInfoReturnable) {
        Map map2 = MixinHelpers.TAG_CACHE;
        synchronized (map2) {
            Map map3 = (Map)MixinHelpers.TAG_CACHE.get(this.gtceu$storedRegistry);
            if (map3 != null) {
                callbackInfoReturnable.setReturnValue((Object)map3);
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Overwrite
    public Map<ResourceLocation, List<TagLoader.EntryWithSource>> m_144495_(ResourceManager resourceManager) {
        Map map = MixinHelpers.TAG_CACHE;
        synchronized (map) {
            if (MixinHelpers.TAG_CACHE.containsKey(this.gtceu$storedRegistry)) {
                return Map.of();
            }
        }
        GTOTags.cache = false;
        map = new O2OOpenCacheHashMap();
        FileToIdConverter fileToIdConverter = FileToIdConverter.m_246568_(this.f_13449_);
        for (Map.Entry entry : fileToIdConverter.m_246760_(resourceManager).entrySet()) {
            ResourceLocation resourceLocation2 = (ResourceLocation)entry.getKey();
            ResourceLocation resourceLocation3 = fileToIdConverter.m_245273_(resourceLocation2);
            for (Resource resource : (List)entry.getValue()) {
                try {
                    BufferedReader bufferedReader = resource.m_215508_();
                    try {
                        JsonElement jsonElement = JsonParser.parseReader(bufferedReader);
                        List list = map.computeIfAbsent(resourceLocation3, resourceLocation -> new ObjectArrayList());
                        TagFile tagFile = (TagFile)TagFile.f_215958_.parse(new Dynamic(JsonOps.INSTANCE, jsonElement)).getOrThrow(false, object -> GTOCore.LOGGER.error(object.toString()));
                        if (tagFile.f_215960_()) {
                            list.clear();
                        }
                        String string = resource.m_215506_();
                        for (TagEntry tagEntry : tagFile.f_215959_()) {
                            if ((tagEntry = GTOTags.convert(resourceLocation3, tagEntry)) == null) continue;
                            list.add(new TagLoader.EntryWithSource(tagEntry, string));
                        }
                        for (TagEntry tagEntry : tagFile.remove()) {
                            list.add(new TagLoader.EntryWithSource(tagEntry, string, true));
                        }
                    }
                    finally {
                        if (bufferedReader == null) continue;
                        ((Reader)bufferedReader).close();
                    }
                }
                catch (Exception exception) {
                    GTOCore.LOGGER.error("Couldn't read tag list {} from {} in data pack {}", resourceLocation3, resourceLocation2, resource.m_215506_(), exception);
                }
            }
        }
        if (this.gtceu$storedRegistry != null) {
            GTOTags.generateDynamicTags(map, this.gtceu$storedRegistry);
        }
        return map;
    }
}

package com.gtolib.mixin.mc.entity;

import java.util.Collections;
import java.util.List;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={Entity.class})
public abstract class EntityMixin {
    @Inject(method={"push(Lnet/minecraft/world/entity/Entity;)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void onPush(@NotNull Entity entity, CallbackInfo callbackInfo) {
        if (this instanceof Player) {
            return;
        }
        callbackInfo.cancel();
    }

    @Redirect(method={"collide"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/level/Level;getEntityCollisions(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;)Ljava/util/List;"))
    private List getEntityCollisions(Level level, Entity entity, AABB aABB) {
        if (entity instanceof Player) {
            return level.m_183134_(entity, aABB);
        }
        return Collections.emptyList();
    }
}

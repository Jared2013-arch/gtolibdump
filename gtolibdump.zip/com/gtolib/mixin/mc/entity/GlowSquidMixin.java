package com.gtolib.mixin.mc.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.GlowSquid;
import net.minecraft.world.entity.animal.Squid;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value={GlowSquid.class})
public abstract class GlowSquidMixin
extends Squid {
    protected GlowSquidMixin(EntityType<? extends Squid> entityType, Level level) {
        super(entityType, level);
    }

    public void m_8119_() {
        this.m_146870_();
    }
}

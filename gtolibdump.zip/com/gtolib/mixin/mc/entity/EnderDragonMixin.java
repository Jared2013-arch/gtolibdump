package com.gtolib.mixin.mc.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={EnderDragon.class}, priority=0)
public class EnderDragonMixin
extends Mob {
    protected EnderDragonMixin(EntityType<? extends Mob> entityType, Level level) {
        super(entityType, level);
    }

    @Inject(method={"tickDeath"}, at={@At(value="INVOKE", target="Lnet/minecraft/world/entity/boss/enderdragon/EnderDragon;remove(Lnet/minecraft/world/entity/Entity$RemovalReason;)V")})
    private void tickDeath(CallbackInfo callbackInfo) {
        this.m_9236_().m_254849_((EnderDragon)((Object)this), this.m_20185_(), this.m_20186_(), this.m_20189_(), 80.0f, Level.ExplosionInteraction.NONE);
    }
}

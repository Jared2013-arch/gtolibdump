package com.gtolib.mixin.mc;

import com.gtocore.client.ClientCache;
import com.gtolib.api.player.IEnhancedPlayer;
import com.gtolib.api.player.PlayerData;
import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={Player.class}, priority=0)
public abstract class PlayerMixin
extends LivingEntity
implements IEnhancedPlayer {
    @Unique
    private PlayerData gtolib$playerData;

    @Inject(method={"<init>"}, at={@At(value="TAIL")}, remap=false)
    private void gtolib$init(Level level, BlockPos blockPos, float f, GameProfile gameProfile, CallbackInfo callbackInfo) {
        this.gtolib$playerData = new PlayerData((Player)((Object)this));
    }

    private PlayerMixin(EntityType<? extends LivingEntity> entityType, Level level) {
        super(entityType, level);
    }

    @Inject(method={"travel"}, at={@At(value="INVOKE", target="Lnet/minecraft/world/entity/player/Player;setSharedFlag(IZ)V")})
    private void travel(Vec3 vec3, CallbackInfo callbackInfo) {
        if (this.f_20900_ == 0.0f && this.f_20902_ == 0.0f && ClientCache.disableDrift) {
            this.m_20256_(this.m_20184_().m_82542_(0.5, 1.0, 0.5));
        }
    }

    @Inject(method={"readAdditionalSaveData"}, at={@At(value="TAIL")})
    private void readAdditionalSaveData(CompoundTag compoundTag, CallbackInfo callbackInfo) {
        this.gtolib$playerData.readAdditionalSaveData(compoundTag);
    }

    @Inject(method={"addAdditionalSaveData"}, at={@At(value="TAIL")})
    private void addAdditionalSaveData(CompoundTag compoundTag, CallbackInfo callbackInfo) {
        this.gtolib$playerData.addAdditionalSaveData(compoundTag);
    }

    @Inject(method={"tick"}, at={@At(value="TAIL")})
    private void tick(CallbackInfo callbackInfo) {
        this.gtolib$playerData.onPlayerTick();
    }

    @Redirect(method={"aiStep"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/food/FoodData;setFoodLevel(I)V"))
    private void gtolib$setFoodLevel(FoodData foodData, int n) {
    }

    @Redirect(method={"hurt"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/damagesource/DamageSource;scalesWithDifficulty()Z"))
    private boolean scalesWithDifficulty(DamageSource damageSource) {
        return false;
    }

    @Override
    public PlayerData getPlayerData() {
        return this.gtolib$playerData;
    }
}

package com.gtolib.mixin.mc;

import com.google.common.collect.ImmutableMap;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.gregtechceu.gtceu.data.pack.GTDynamicDataPack;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtocore.common.data.GTORecipes;
import com.gtolib.GTOCore;
import com.gtolib.mixin.RecipeHelperAccessor;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.GsonHelper;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraftforge.common.crafting.CraftingHelper;
import net.minecraftforge.common.crafting.conditions.ICondition;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={RecipeManager.class}, priority=0)
public abstract class RecipeManagerMixin {
    @Shadow
    private Map<RecipeType<?>, Map<ResourceLocation, Recipe<?>>> f_44007_;
    @Shadow
    private boolean f_44008_;
    @Shadow
    private Map<ResourceLocation, Recipe<?>> f_199900_;
    @Shadow(remap=false)
    @Final
    private ICondition.IContext context;

    @Inject(method={"apply(Ljava/util/Map; Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/util/profiling/ProfilerFiller;)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void apply(Map<ResourceLocation, JsonElement> map2, ResourceManager resourceManager, ProfilerFiller profilerFiller, CallbackInfo callbackInfo) {
        callbackInfo.cancel();
        if (GTORecipes.cache) {
            this.f_44007_ = GTORecipes.RECIPES_CACHE;
            this.f_199900_ = GTORecipes.BYNAME_CACHE;
        } else {
            GTORecipes.cache = true;
            long l = System.currentTimeMillis();
            this.f_44008_ = false;
            O2OOpenCacheHashMap o2OOpenCacheHashMap = new O2OOpenCacheHashMap();
            O2OOpenCacheHashMap o2OOpenCacheHashMap2 = new O2OOpenCacheHashMap(16384);
            for (Map.Entry<ResourceLocation, JsonElement> entry : map2.entrySet()) {
                ResourceLocation resourceLocation = entry.getKey();
                if (resourceLocation.m_135815_().isEmpty() || resourceLocation.m_135815_().charAt(0) == '_') continue;
                try {
                    Recipe recipe;
                    if (entry.getValue().isJsonObject() && !CraftingHelper.processConditions(entry.getValue().getAsJsonObject(), "conditions", this.context) || (recipe = GTORecipes.fromJson(resourceLocation, GsonHelper.m_13918_(entry.getValue(), "top element"), this.context)) == null || (recipe = GTORecipes.convert(recipe)) == null) continue;
                    o2OOpenCacheHashMap.computeIfAbsent(recipe.m_6671_(), recipeType -> new O2OOpenCacheHashMap(64, 0.25f)).put(resourceLocation, recipe);
                    o2OOpenCacheHashMap2.put(resourceLocation, recipe);
                }
                catch (JsonParseException | IllegalArgumentException throwable) {}
            }
            this.f_44007_ = o2OOpenCacheHashMap;
            this.f_199900_ = o2OOpenCacheHashMap2;
            RecipeHelperAccessor.addRecipes((RecipeManager)((Object)this));
            this.f_44007_.replaceAll((recipeType, map) -> ImmutableMap.copyOf(map));
            this.f_44007_ = ImmutableMap.copyOf(this.f_44007_);
            this.f_199900_ = ImmutableMap.copyOf(this.f_199900_);
            GTORecipes.RECIPES_CACHE = this.f_44007_;
            GTORecipes.BYNAME_CACHE = this.f_199900_;
            GTOCore.LOGGER.info("Loaded {} recipes, took {}ms", (Object)GTORecipes.BYNAME_CACHE.size(), (Object)(System.currentTimeMillis() - l));
            GTDynamicDataPack.clearServer();
            RecipeHelperAccessor.getProviders().clear();
        }
    }
}

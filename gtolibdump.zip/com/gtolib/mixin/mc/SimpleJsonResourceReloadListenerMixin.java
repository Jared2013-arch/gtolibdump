package com.gtolib.mixin.mc;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.gtocore.common.data.GTOLoots;
import com.gtocore.common.data.GTORecipes;
import com.gtocore.data.recipe.RecipeFilter;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.Map;
import java.util.function.Predicate;
import net.minecraft.resources.FileToIdConverter;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.GsonHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={SimpleJsonResourceReloadListener.class}, priority=0)
public class SimpleJsonResourceReloadListenerMixin {
    @Inject(method={"scanDirectory"}, at={@At(value="HEAD")}, cancellable=true)
    private static void scanDirectory(ResourceManager resourceManager, String string, Gson gson, Map<ResourceLocation, JsonElement> map, CallbackInfo callbackInfo) {
        callbackInfo.cancel();
        Predicate predicate = null;
        switch (string) {
            case "advancements": {
                return;
            }
            case "recipes": {
                if (GTORecipes.cache) {
                    return;
                }
                predicate = RecipeFilter.getFilter();
                break;
            }
            case "loot_tables": {
                if (GTOLoots.cache) {
                    return;
                }
                predicate = GTOLoots.getFilter();
            }
        }
        Object object = FileToIdConverter.m_246568_(string);
        Map map2 = ((FileToIdConverter)object).m_247457_(resourceManager);
        for (Map.Entry entry : map2.entrySet()) {
            ResourceLocation resourceLocation = (ResourceLocation)entry.getKey();
            ResourceLocation resourceLocation2 = ((FileToIdConverter)object).m_245273_(resourceLocation);
            if (predicate != null && predicate.test(resourceLocation2)) continue;
            try {
                BufferedReader bufferedReader = ((Resource)entry.getValue()).m_215508_();
                try {
                    JsonElement jsonElement = (JsonElement)GsonHelper.m_13776_(gson, bufferedReader, JsonElement.class);
                    JsonElement jsonElement2 = map.put(resourceLocation2, jsonElement);
                    if (jsonElement2 == null) continue;
                    throw new IllegalStateException("Duplicate data file ignored with ID " + String.valueOf(resourceLocation2));
                }
                finally {
                    if (bufferedReader == null) continue;
                    bufferedReader.close();
                }
            }
            catch (JsonParseException | IOException | IllegalArgumentException throwable) {}
        }
    }
}

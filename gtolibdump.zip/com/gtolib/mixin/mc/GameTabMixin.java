package com.gtolib.mixin.mc;

import com.gtocore.config.GTOConfig;
import com.gtocore.config.GTOStartupConfig;
import com.gtolib.GTOCore;
import com.gtolib.api.annotation.dynamic.DynamicInitialData;
import com.gtolib.g.a;
import com.llamalad7.mixinextras.sugar.Local;
import dev.shadowsoffire.placebo.config.Property;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.layouts.GridLayout;
import net.minecraft.client.gui.layouts.LayoutElement;
import net.minecraft.client.gui.screens.worldselection.CreateWorldScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets={"net.minecraft.client.gui.screens.worldselection.CreateWorldScreen$GameTab"})
public class GameTabMixin {
    @Inject(method={"<init>"}, at={@At(value="RETURN")})
    private void init(CreateWorldScreen createWorldScreen, CallbackInfo callbackInfo, @Local(name={"gridlayout$rowhelper"}) GridLayout.RowHelper rowHelper) {
        CycleButton cycleButton2 = CycleButton.m_168894_(difficulty -> Component.m_237119_().m_7220_(DynamicInitialData.getDifficultyComponent(difficulty.ordinal() + 1)).m_130946_(difficulty != GameTabMixin.gto$getCurrentDifficulty() ? "[⚠]" : "")).m_232498_(difficulty -> Tooltip.m_257550_(Component.m_237115_("selectWorld.gto_difficulty.tooltip." + difficulty.name().toLowerCase()).m_130946_("\n").m_7220_(Component.m_237115_("selectWorld.gto_difficulty.tooltip.generic")).m_130946_(difficulty != GameTabMixin.gto$getCurrentDifficulty() ? "\n" : "").m_7220_(difficulty != GameTabMixin.gto$getCurrentDifficulty() ? Component.m_237115_("text.cloth-config.restart_required_sub") : Component.m_237119_()))).m_168961_(GTOConfig.Difficulty.values()).m_168948_(GameTabMixin.gto$getCurrentDifficulty()).m_168936_(0, 0, 210, 20, Component.m_237115_("selectWorld.gto_difficulty.no_suffix"), (cycleButton, difficulty) -> {
            Property property = GTOStartupConfig.config.get("general", "Difficulty", 2);
            property.set(difficulty.name());
            property.setComment("游戏难度：简单/普通/专家 (Simple/Normal/Expert)\n部分特性如下：\n\n简单模式特性：\nAE2使用原始配方（无魔改）\nME网络无限频道\n增幅蒸汽/发电产能，提升发电阵列机器容量/涡轮产出\n可配置维护仓上下限提升\n无需超净间！\n部分配方产量提升/简化\n（MV阶段）ME简易样板总成: 含9个样板槽的样板总成\n装配线无需有序输入\n基岩矿脉/基岩流体矿脉储量无限！\n并行仓/加速仓等数值提升\n蒸汽大机器的并行数值提升\n连锁采掘的限制最大数量提升\n\n普通模式特性：\nAE2全面魔改（MV阶段初步解锁，HV开启自动化）\nME网络无限频道\n怪物增强！（更高血量，更强攻击力，请小心应对）\n装配线需要有序输入物品才能工作\n方块挖掘速度惩罚（你需要手持GT工具才能高效挖掘方块）\n\n专家模式特性：\n更难的AE2魔改（MV阶段初步解锁，EV开启自动化）\nME网络频道有限！请合理规划基地\n怪物增强！（更高血量，更强攻击力，请小心应对）\n方块挖掘速度惩罚（你需要手持GT工具才能高效挖掘方块）\n更少的蒸汽/发电产能\n机器淋雨爆炸！\n配方产出降低/复杂化\n维护仓上下限降低\n机器运行时能量不足将导致配方失败且输入被清空！\n装配线需要有序输入物品与流体才能工作\n并行仓/加速仓等数值降低\n发电设备在输出仓满时将继续发电且销毁多余能量！\n\nGame Difficulty: Simple/Normal/Expert\nSome features are as follows:\n\nSimple Mode Features:\nAE2 uses original recipes (no magic modification)\nME network has unlimited channels\nIncreased steam/power generation capacity, improved machine capacity/turbine output of power generation array\nConfigurable maintenance bay upper and lower limits\nNo clean room required!\nSome recipe output increase/simplification\n(MV stage) ME Simple Pattern Buffer: Pattern buffer with 9 pattern slots\nAssembler does not require ordered input\nBedrock Ore Vein/Bedrock Fluid Ore Vein has unlimited reserves!\nParallel Hatch/Overclocker Hatch and other values are increased\nIncreased parallel values for large steam machines\nIncreased maximum number of vein mining\n\nNormal Mode Features:\nAE2 fully modified (MV stage preliminary unlock, HV opens automation)\nME network has unlimited channels\nMonster enhancement! (Higher health, stronger attack power, please deal with it carefully)\nAssembler requires ordered input of items to work\nBlock mining speed penalty (you need to hold a GT tool to efficiently mine blocks)\n\nExpert Mode Features:\nMore difficult AE2 magic modification (MV stage preliminary unlock, EV opens automation)\nME network channels are limited! Please plan your base reasonably\nMonster enhancement! (Higher health, stronger attack power, please deal with it carefully)\nBlock mining speed penalty (you need to hold a GT tool to efficiently mine blocks)\nLess steam/power generation capacity\nMachines explode when rained on!\nRecipe output reduction/complexity\nMaintenance bay upper and lower limits reduced\nMachine running out of energy will cause the recipe to fail and the input to be cleared!\nAssembler requires ordered input of items and fluids to work\nParallel Hatch/Overclocker Hatch and other values are reduced\nPower generation equipment will continue to generate power when the output bay is full and destroy excess energy!\n");
            GTOStartupConfig.config.save();
            LayoutElement layoutElement = ((a)((Object)createWorldScreen)).gtolib$getCreateWorldButton();
            if (layoutElement instanceof Button) {
                Button button = (Button)((Object)layoutElement);
                button.f_93623_ = difficulty == GameTabMixin.gto$getCurrentDifficulty();
            }
        });
        rowHelper.m_264139_(cycleButton2);
        createWorldScreen.m_267748_().m_267755_(worldCreationUiState -> {});
    }

    @Unique
    private static GTOConfig.Difficulty gto$getCurrentDifficulty() {
        return GTOConfig.Difficulty.values()[GTOCore.difficulty - 1];
    }
}

package com.gtolib.mixin.mc;

import java.util.Collection;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.ServerRecipeBook;
import net.minecraft.world.item.crafting.Recipe;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={ServerRecipeBook.class}, priority=0)
public class ServerRecipeBookMixin {
    @Inject(method={"addRecipes"}, at={@At(value="HEAD")}, cancellable=true)
    private void addRecipes(Collection<Recipe<?>> collection, ServerPlayer serverPlayer, CallbackInfoReturnable<Integer> callbackInfoReturnable) {
        callbackInfoReturnable.setReturnValue((Object)0);
    }

    @Inject(method={"removeRecipes"}, at={@At(value="HEAD")}, cancellable=true)
    private void removeRecipes(Collection<Recipe<?>> collection, ServerPlayer serverPlayer, CallbackInfoReturnable<Integer> callbackInfoReturnable) {
        callbackInfoReturnable.setReturnValue((Object)0);
    }

    @Inject(method={"toNbt"}, at={@At(value="HEAD")}, cancellable=true)
    private void toNbt(CallbackInfoReturnable<CompoundTag> callbackInfoReturnable) {
        callbackInfoReturnable.setReturnValue((Object)new CompoundTag());
    }

    @Inject(method={"fromNbt"}, at={@At(value="HEAD")}, cancellable=true)
    private void fromNbt(CallbackInfo callbackInfo) {
        callbackInfo.cancel();
    }
}

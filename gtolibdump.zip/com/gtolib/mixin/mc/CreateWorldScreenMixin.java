package com.gtolib.mixin.mc;

import com.gtolib.g.a;
import net.minecraft.client.gui.layouts.GridLayout;
import net.minecraft.client.gui.layouts.LayoutElement;
import net.minecraft.client.gui.screens.worldselection.CreateWorldScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={CreateWorldScreen.class})
public class CreateWorldScreenMixin
implements a {
    @Unique
    private LayoutElement gtolib$createWorldButton;

    @Redirect(method={"init"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/gui/layouts/GridLayout$RowHelper;addChild(Lnet/minecraft/client/gui/layouts/LayoutElement;)Lnet/minecraft/client/gui/layouts/LayoutElement;", ordinal=0))
    private <T extends LayoutElement> T gtolib$addCreateWorldButton(GridLayout.RowHelper rowHelper, LayoutElement layoutElement) {
        this.gtolib$createWorldButton = rowHelper.m_264139_(layoutElement);
        return (T)this.gtolib$createWorldButton;
    }

    @Override
    public LayoutElement gtolib$getCreateWorldButton() {
        return this.gtolib$createWorldButton;
    }
}

package com.gtolib.mixin.mc.world;

import it.unimi.dsi.fastutil.longs.Long2ReferenceOpenHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeManager;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(value={BiomeManager.class}, priority=0)
public class BiomeManagerMixin {
    @Unique
    private final Long2ReferenceOpenHashMap<Holder<Biome>> gtolib$biomeCache = new Long2ReferenceOpenHashMap();
    @Shadow
    @Final
    private long f_47863_;
    @Shadow
    @Final
    private BiomeManager.NoiseBiomeSource f_47862_;

    @Shadow
    private static double m_186679_(long l, int n, int n2, int n3, double d, double d2, double d3) {
        return 0.0;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Overwrite
    public Holder<Biome> m_204214_(BlockPos blockPos) {
        int n = blockPos.m_123341_();
        int n2 = blockPos.m_123342_();
        int n3 = blockPos.m_123343_();
        long l2 = BlockPos.m_121882_(n, n2, n3);
        Long2ReferenceOpenHashMap<Holder<Biome>> long2ReferenceOpenHashMap = this.gtolib$biomeCache;
        synchronized (long2ReferenceOpenHashMap) {
            return (Holder)this.gtolib$biomeCache.computeIfAbsent(l2, l -> {
                int n4;
                int n5;
                int n6;
                int n7 = n - 2;
                int n8 = n2 - 2;
                int n9 = n3 - 2;
                int n10 = n7 >> 2;
                int n11 = n8 >> 2;
                int n12 = n9 >> 2;
                double d = (double)(n7 & 3) / 4.0;
                double d2 = (double)(n8 & 3) / 4.0;
                double d3 = (double)(n9 & 3) / 4.0;
                int n13 = 0;
                double d4 = Double.POSITIVE_INFINITY;
                for (n6 = 0; n6 < 8; ++n6) {
                    double d5;
                    double d6;
                    double d7;
                    boolean bl;
                    int n14;
                    int n15;
                    n5 = (n6 & 4) == 0 ? 1 : 0;
                    int n16 = n5 != 0 ? n10 : n10 + 1;
                    double d8 = BiomeManagerMixin.m_186679_(this.f_47863_, n16, n15 = (n4 = (n6 & 2) == 0 ? 1 : 0) != 0 ? n11 : n11 + 1, n14 = (bl = (n6 & 1) == 0) ? n12 : n12 + 1, d7 = n5 != 0 ? d : d - 1.0, d6 = n4 != 0 ? d2 : d2 - 1.0, d5 = bl ? d3 : d3 - 1.0);
                    if (!(d4 > d8)) continue;
                    n13 = n6;
                    d4 = d8;
                }
                n6 = (n13 & 4) == 0 ? n10 : n10 + 1;
                n5 = (n13 & 2) == 0 ? n11 : n11 + 1;
                n4 = (n13 & 1) == 0 ? n12 : n12 + 1;
                return this.f_47862_.m_203495_(n6, n5, n4);
            });
        }
    }
}

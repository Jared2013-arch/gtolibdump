package com.gtolib.mixin.mc.world;

import com.gtolib.a;
import com.gtolib.d;
import java.util.function.BooleanSupplier;
import net.minecraft.server.level.ChunkHolder;
import net.minecraft.server.level.ChunkMap;
import net.minecraft.server.level.ServerChunkCache;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.chunk.LevelChunk;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={ServerChunkCache.class}, priority=0)
public abstract class ServerChunkCacheMixin {
    @Shadow
    @Final
    public ChunkMap f_8325_;
    @Shadow
    @Final
    public ServerLevel f_8329_;

    @Shadow
    protected abstract void m_8490_();

    @Inject(method={"tick"}, at={@At(value="INVOKE", target="Lnet/minecraft/server/level/ChunkMap;tick(Ljava/util/function/BooleanSupplier;)V")})
    private void tick(BooleanSupplier booleanSupplier, boolean bl, CallbackInfo callbackInfo) {
        ((a)((Object)this.f_8325_)).gtolib$setSkip(false);
        if (bl && this.f_8329_.m_7654_().m_129921_() % 80 != 0) {
            ((a)((Object)this.f_8325_)).gtolib$setSkip(true);
        }
    }

    @Redirect(method={"tick"}, at=@At(value="INVOKE", target="Lnet/minecraft/server/level/ServerChunkCache;tickChunks()V"))
    private void tickChunks(ServerChunkCache serverChunkCache) {
        if (((d)((Object)this.f_8329_)).gtolib$isVoid() && this.f_8329_.m_7654_().m_129921_() % 200 != 0) {
            for (ChunkHolder chunkHolder : this.f_8325_.f_140130_.values()) {
                LevelChunk levelChunk = chunkHolder.m_140085_();
                if (levelChunk == null) continue;
                chunkHolder.m_140054_(levelChunk);
            }
            this.f_8325_.m_140421_();
        } else {
            this.m_8490_();
        }
    }

    @Redirect(method={"tickChunks"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/level/GameRules;getBoolean(Lnet/minecraft/world/level/GameRules$Key;)Z"))
    private boolean tickChunks(GameRules gameRules, GameRules.Key<GameRules.BooleanValue> key) {
        if (((d)((Object)this.f_8329_)).gtolib$isVoid()) {
            return false;
        }
        return gameRules.m_46207_(key);
    }
}

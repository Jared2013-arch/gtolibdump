package com.gtolib.mixin.mc.world;

import com.gtolib.api.data.GTODimensions;
import com.gtolib.d;
import com.gtolib.syncdata.b;
import com.llamalad7.mixinextras.lib.apache.commons.ObjectUtils;
import earth.terrarium.adastra.api.planets.Planet;
import earth.terrarium.adastra.api.planets.PlanetApi;
import java.util.function.Supplier;
import net.minecraft.core.Holder;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.WritableLevelData;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={Level.class}, priority=0)
public abstract class LevelMixin
implements d {
    @Shadow
    @Final
    private ResourceKey<Level> f_46421_;
    @Unique
    private Object gtolib$planet;
    @Unique
    private boolean gtolib$isVoid;
    @Unique
    private b gtolib$manager;

    @Inject(method={"<init>"}, at={@At(value="TAIL")})
    private void init(WritableLevelData writableLevelData, ResourceKey resourceKey, RegistryAccess registryAccess, Holder holder, Supplier supplier, boolean bl, boolean bl2, long l, int n, CallbackInfo callbackInfo) {
        this.gtolib$isVoid = GTODimensions.isVoid(resourceKey.m_135782_());
    }

    @Override
    @Nullable
    public Planet gtolib$getPlanet() {
        if (this.gtolib$planet == null) {
            this.gtolib$planet = PlanetApi.API.getPlanet(this.f_46421_);
            if (this.gtolib$planet == null) {
                this.gtolib$planet = ObjectUtils.NULL;
            }
        }
        if (this.gtolib$planet == ObjectUtils.NULL) {
            return null;
        }
        return (Planet)this.gtolib$planet;
    }

    @Override
    public boolean gtolib$isVoid() {
        return this.gtolib$isVoid;
    }

    @Override
    public b gtolib$getSyncFieldManager() {
        if (this.gtolib$manager == null) {
            this.gtolib$manager = new b((Level)((Object)this));
        }
        return this.gtolib$manager;
    }
}

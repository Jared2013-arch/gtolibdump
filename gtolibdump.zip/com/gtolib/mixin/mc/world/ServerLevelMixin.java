package com.gtolib.mixin.mc.world;

import com.gregtechceu.gtceu.api.block.ActiveBlock;
import com.gtolib.d;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.entity.PersistentEntitySectionManager;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={ServerLevel.class}, priority=0)
public abstract class ServerLevelMixin
implements d {
    @Shadow
    @Final
    private PersistentEntitySectionManager<Entity> f_143244_;

    @Inject(method={"sendBlockUpdated"}, at={@At(value="HEAD")}, cancellable=true)
    private void gtolib$sendBlockUpdated(BlockPos blockPos, BlockState blockState, BlockState blockState2, int n, CallbackInfo callbackInfo) {
        Block block = blockState.m_60734_();
        if (block instanceof ActiveBlock) {
            ActiveBlock activeBlock;
            ActiveBlock activeBlock2 = (ActiveBlock)block;
            block = blockState2.m_60734_();
            if (block instanceof ActiveBlock && activeBlock2 == (activeBlock = (ActiveBlock)block)) {
                callbackInfo.cancel();
            }
        }
    }

    @Overwrite
    public boolean m_201918_(BlockPos blockPos) {
        if (this.gtolib$isVoid()) {
            return false;
        }
        return this.f_143244_.m_202167_(blockPos);
    }

    @Overwrite
    public boolean m_201916_(ChunkPos chunkPos) {
        if (this.gtolib$isVoid()) {
            return false;
        }
        return this.f_143244_.m_202165_(chunkPos);
    }
}

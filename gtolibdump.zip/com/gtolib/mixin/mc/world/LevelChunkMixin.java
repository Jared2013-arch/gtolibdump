package com.gtolib.mixin.mc.world;

import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.llamalad7.mixinextras.sugar.Local;
import java.lang.invoke.LambdaMetafactory;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.core.Registry;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.TickingBlockEntity;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.UpgradeData;
import net.minecraft.world.level.levelgen.blending.BlendingData;
import net.minecraft.world.ticks.LevelChunkTicks;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={LevelChunk.class}, priority=0)
public abstract class LevelChunkMixin
extends ChunkAccess {
    @Mutable
    @Shadow
    @Final
    private Map f_156362_;
    @Shadow
    @Final
    private static TickingBlockEntity f_156361_;

    public LevelChunkMixin(ChunkPos chunkPos, UpgradeData upgradeData, LevelHeightAccessor levelHeightAccessor, Registry<Biome> registry, long l, @Nullable LevelChunkSection[] levelChunkSectionArray, @Nullable BlendingData blendingData) {
        super(chunkPos, upgradeData, levelHeightAccessor, registry, l, levelChunkSectionArray, blendingData);
    }

    @Inject(method={"<init>(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/UpgradeData;Lnet/minecraft/world/ticks/LevelChunkTicks;Lnet/minecraft/world/ticks/LevelChunkTicks;J[Lnet/minecraft/world/level/chunk/LevelChunkSection;Lnet/minecraft/world/level/chunk/LevelChunk$PostLoadProcessor;Lnet/minecraft/world/level/levelgen/blending/BlendingData;)V"}, at={@At(value="RETURN")})
    private void init(Level level, ChunkPos chunkPos, UpgradeData upgradeData, LevelChunkTicks levelChunkTicks, LevelChunkTicks levelChunkTicks2, long l, LevelChunkSection[] levelChunkSectionArray, LevelChunk.PostLoadProcessor postLoadProcessor, BlendingData blendingData, CallbackInfo callbackInfo) {
        this.f_156362_ = new O2OOpenCacheHashMap(this.f_156362_);
    }

    @Redirect(method={"getBlockEntityNbtForSaving"}, at=@At(value="INVOKE", target="Ljava/lang/Class;getName()Ljava/lang/String;", remap=false))
    public String getBlockEntityClass(Class clazz, @Local BlockEntity blockEntity) {
        if (blockEntity instanceof MetaMachineBlockEntity) {
            MetaMachineBlockEntity metaMachineBlockEntity = (MetaMachineBlockEntity)blockEntity;
            return metaMachineBlockEntity.metaMachine.getDefinition().toString();
        }
        return clazz.getName();
    }

    @Overwrite
    public void m_187957_() {
        O2OOpenCacheHashMap o2OOpenCacheHashMap = new O2OOpenCacheHashMap(this.f_187610_);
        o2OOpenCacheHashMap.values().forEach((Consumer<BlockEntity>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, onChunkUnloaded(), (Lnet/minecraft/world/level/block/entity/BlockEntity;)V)());
        o2OOpenCacheHashMap.values().forEach((Consumer<BlockEntity>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, m_7651_(), (Lnet/minecraft/world/level/block/entity/BlockEntity;)V)());
        this.f_187610_.clear();
        O2OOpenCacheHashMap o2OOpenCacheHashMap2 = new O2OOpenCacheHashMap(this.f_156362_);
        o2OOpenCacheHashMap2.values().forEach(object -> ((RebindableTickingBlockEntityWrapperAccessor)object).callRebind(f_156361_));
        this.f_156362_.clear();
    }

    @Mixin(targets={"net.minecraft.world.level.chunk.LevelChunk$RebindableTickingBlockEntityWrapper"})
    public static interface RebindableTickingBlockEntityWrapperAccessor {
        @Invoker(value="rebind")
        public void callRebind(TickingBlockEntity var1);
    }
}

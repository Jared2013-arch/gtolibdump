package com.gtolib.mixin.mc;

import com.gregtechceu.gtceu.GTCEu;
import com.gtocore.config.GTOStartupConfig;
import com.gtolib.api.ae2.AE2wtlibEvents;
import com.llamalad7.mixinextras.sugar.Local;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.fml.ModList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={Minecraft.class}, priority=0)
public abstract class MinecraftMixin {
    @Shadow
    @Nullable
    private IntegratedServer f_91007_;
    @Shadow
    public LocalPlayer f_91074_;

    @Shadow
    public abstract boolean m_91294_();

    @Shadow
    @Nullable
    public abstract ServerData m_91089_();

    @Shadow
    @Nullable
    public abstract ClientPacketListener m_91403_();

    @Inject(method={"createTitle"}, at={@At(value="HEAD")}, cancellable=true)
    private void createTitle(CallbackInfoReturnable<String> callbackInfoReturnable) {
        StringBuilder stringBuilder = new StringBuilder("GregTech Odyssey");
        ModList modList = ModList.get();
        if (modList != null) {
            stringBuilder.append(" | ").append(modList.getModFileById("gtocore").versionString()).append(" |");
        }
        stringBuilder.append(" [").append(GTOStartupConfig.difficulty).append(" Mode]").append(GTCEu.isDev() ? " [Dev]" : "");
        ClientPacketListener clientPacketListener = this.m_91403_();
        if (clientPacketListener != null && clientPacketListener.m_104910_().m_129536_()) {
            stringBuilder.append(" - ");
            if (this.f_91007_ != null && !this.f_91007_.m_6992_()) {
                stringBuilder.append(I18n.m_118938_("title.singleplayer", new Object[0]));
            } else if (this.m_91294_()) {
                stringBuilder.append(I18n.m_118938_("title.multiplayer.realms", new Object[0]));
            } else if (!(this.f_91007_ != null || this.m_91089_() != null && this.m_91089_().m_105389_())) {
                stringBuilder.append(I18n.m_118938_("title.multiplayer.other", new Object[0]));
            } else {
                stringBuilder.append(I18n.m_118938_("title.multiplayer.lan", new Object[0]));
            }
        }
        callbackInfoReturnable.setReturnValue((Object)stringBuilder.toString());
    }

    @Inject(method={"pickBlock"}, at={@At(value="INVOKE_ASSIGN", target="Lnet/minecraft/world/entity/player/Inventory;findSlotMatchingItem(Lnet/minecraft/world/item/ItemStack;)I")})
    public void pickBlock(CallbackInfo callbackInfo, @Local ItemStack itemStack, @Local int n) {
        if (!this.f_91074_.m_150110_().f_35937_ && !this.f_91074_.m_5833_() && n == -1) {
            AE2wtlibEvents.pickBlock(itemStack);
        }
    }
}

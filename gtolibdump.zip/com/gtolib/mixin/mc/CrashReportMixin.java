package com.gtolib.mixin.mc;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.CrashReport;
import net.minecraftforge.fml.ModList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={CrashReport.class})
public class CrashReportMixin {
    @Inject(method={"getFriendlyReport"}, at={@At(value="INVOKE", target="Ljava/lang/StringBuilder;append(Ljava/lang/String;)Ljava/lang/StringBuilder;", shift=At.Shift.AFTER, ordinal=6)})
    private void gto$onGetFriendlyReport(CallbackInfoReturnable<String> callbackInfoReturnable, @Local StringBuilder stringBuilder) {
        if (ModList.get() == null) {
            return;
        }
        ModList.get().getMods().stream().filter(iModInfo -> iModInfo.getModId().equals("gtocore")).findFirst().ifPresent(iModInfo -> stringBuilder.append("GTO Core Version: ").append(iModInfo.getVersion()).append("\n"));
    }
}

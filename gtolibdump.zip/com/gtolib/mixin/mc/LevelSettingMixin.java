package com.gtolib.mixin.mc;

import com.gtolib.b;
import com.mojang.serialization.Dynamic;
import net.minecraft.world.level.LevelSettings;
import net.minecraft.world.level.WorldDataConfiguration;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={LevelSettings.class})
public class LevelSettingMixin
implements b {
    @Unique
    private int gto$difficulty = 0;
    @Unique
    private boolean gto$srm = false;
    @Unique
    private boolean gto$dev = false;

    @Override
    public int gto$getGTODifficulty() {
        return this.gto$difficulty;
    }

    @Override
    public void gto$setGTODifficulty(int n) {
        this.gto$difficulty = n;
    }

    @Override
    public boolean gto$isSrm() {
        return this.gto$srm;
    }

    @Override
    public void gto$setSrm(boolean bl) {
        this.gto$srm = bl;
    }

    @Override
    public boolean gto$isDevMode() {
        return this.gto$dev;
    }

    @Override
    public void gto$setDevMode(boolean bl) {
        this.gto$dev = bl;
    }

    @Inject(method={"parse"}, at={@At(value="RETURN")}, cancellable=true)
    private static void parse(Dynamic<?> dynamic, WorldDataConfiguration worldDataConfiguration, CallbackInfoReturnable<LevelSettings> callbackInfoReturnable) {
        LevelSettings levelSettings = (LevelSettings)callbackInfoReturnable.getReturnValue();
        LevelSettings levelSettings2 = levelSettings;
        if (levelSettings2 instanceof b) {
            b b2 = (b)((Object)levelSettings2);
            b2.gto$setGTODifficulty(dynamic.get("gto$Difficulty").asInt(0));
            b2.gto$setSrm(dynamic.get("gto$SelfRestraint").asBoolean(false));
            b2.gto$setDevMode(dynamic.get("gto$Dev").asBoolean(false));
        }
        callbackInfoReturnable.setReturnValue((Object)levelSettings);
    }
}

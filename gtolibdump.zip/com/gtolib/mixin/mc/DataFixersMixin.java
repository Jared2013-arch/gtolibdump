package com.gtolib.mixin.mc;

import com.google.common.collect.ImmutableMap;
import com.mojang.datafixers.DSL;
import com.mojang.datafixers.DataFixer;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.Type;
import com.mojang.datafixers.types.templates.TaggedChoice;
import com.mojang.datafixers.types.templates.TypeTemplate;
import com.mojang.serialization.Dynamic;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;
import net.minecraft.SharedConstants;
import net.minecraft.util.datafix.DataFixers;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={DataFixers.class}, priority=0)
public class DataFixersMixin {
    @Unique
    private static final Schema gtolib$SCHEMA = new Schema(SharedConstants.m_183709_().m_183476_().m_193006_(), null){

        public Map<String, Supplier<TypeTemplate>> registerEntities(Schema schema) {
            return ImmutableMap.of();
        }

        public Map<String, Supplier<TypeTemplate>> registerBlockEntities(Schema schema) {
            return ImmutableMap.of();
        }

        public void registerTypes(Schema schema, Map<String, Supplier<TypeTemplate>> map, Map<String, Supplier<TypeTemplate>> map2) {
        }

        protected Map<String, Type<?>> buildTypes() {
            return ImmutableMap.of();
        }

        public Type<?> getType(DSL.TypeReference typeReference) {
            return null;
        }

        public Type<?> getChoiceType(DSL.TypeReference typeReference, String string) {
            return null;
        }

        public Type<?> getTypeRaw(DSL.TypeReference typeReference) {
            return null;
        }

        public TaggedChoice.TaggedChoiceType<?> findChoiceType(DSL.TypeReference typeReference) {
            return null;
        }
    };

    @Inject(method={"createFixerUpper"}, at={@At(value="HEAD")}, cancellable=true)
    private static synchronized void createFixerUpper(Set<DSL.TypeReference> set, CallbackInfoReturnable<DataFixer> callbackInfoReturnable) {
        callbackInfoReturnable.setReturnValue((Object)new DataFixer(){

            public <T> Dynamic<T> update(DSL.TypeReference typeReference, Dynamic<T> dynamic, int n, int n2) {
                return dynamic;
            }

            public Schema getSchema(int n) {
                return gtolib$SCHEMA;
            }
        });
    }
}

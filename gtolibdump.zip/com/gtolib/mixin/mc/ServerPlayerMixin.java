package com.gtolib.mixin.mc;

import com.gtolib.api.player.IEnhancedPlayer;
import com.gtolib.utils.SrmManager;
import com.mojang.authlib.GameProfile;
import java.util.Collection;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={ServerPlayer.class}, priority=0)
public abstract class ServerPlayerMixin
extends Player {
    @Shadow
    @Final
    public MinecraftServer f_8924_;

    protected ServerPlayerMixin(Level level, BlockPos blockPos, float f, GameProfile gameProfile) {
        super(level, blockPos, f, gameProfile);
    }

    @Inject(method={"awardRecipes"}, at={@At(value="HEAD")}, cancellable=true)
    private void awardRecipes(Collection<Recipe<?>> collection, CallbackInfoReturnable<Integer> callbackInfoReturnable) {
        callbackInfoReturnable.setReturnValue((Object)0);
    }

    @Inject(method={"awardRecipesByKey"}, at={@At(value="HEAD")}, cancellable=true)
    private void awardRecipesByKey(ResourceLocation[] resourceLocationArray, CallbackInfo callbackInfo) {
        callbackInfo.cancel();
    }

    @Inject(method={"getPermissionLevel"}, at={@At(value="HEAD")}, cancellable=true)
    private void getPermissionLevel(CallbackInfoReturnable<Integer> callbackInfoReturnable) {
        if (SrmManager.isSrmMode()) {
            callbackInfoReturnable.setReturnValue((Object)0);
        }
        if (IEnhancedPlayer.of((Player)this).getPlayerData().cmdState) {
            callbackInfoReturnable.setReturnValue((Object)4);
        }
    }
}

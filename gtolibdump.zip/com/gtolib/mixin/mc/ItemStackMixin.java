package com.gtolib.mixin.mc;

import com.gtolib.utils.ItemUtils;
import javax.annotation.Nullable;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityProvider;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.registries.IForgeRegistry;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={ItemStack.class})
public abstract class ItemStackMixin
extends CapabilityProvider<ItemStack> {
    @Unique
    private boolean gtolib$forgeInit;
    @Unique
    private boolean gtolib$isEmpty;
    @Shadow
    @Nullable
    private CompoundTag f_41590_;
    @Shadow
    private int f_41587_;
    @Mutable
    @Shadow
    @Final
    private Item f_41589_;
    @Shadow(remap=false)
    private CompoundTag capNBT;

    protected ItemStackMixin(Class<ItemStack> clazz) {
        super(clazz);
    }

    @Inject(method={"<init>(Ljava/lang/Void;)V"}, at={@At(value="TAIL")})
    private void gtolib$init(Void void_, CallbackInfo callbackInfo) {
        this.gtolib$isEmpty = true;
        this.f_41589_ = Items.f_41852_;
    }

    @Redirect(method={"<init>(Lnet/minecraft/world/level/ItemLike;ILnet/minecraft/nbt/CompoundTag;)V"}, at=@At(value="INVOKE", target="Lnet/minecraftforge/registries/IForgeRegistry;getDelegateOrThrow(Ljava/lang/Object;)Lnet/minecraft/core/Holder$Reference;", remap=false))
    private <V> Holder.Reference<V> getDelegateOrThrow(IForgeRegistry iForgeRegistry, V v) {
        return null;
    }

    @Redirect(method={"<init>(Lnet/minecraft/world/level/ItemLike;ILnet/minecraft/nbt/CompoundTag;)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/item/ItemStack;forgeInit()V", remap=false))
    private void forgeInit(ItemStack itemStack) {
        this.gtolib$isEmpty = this.f_41589_ == Items.f_41852_;
    }

    @Redirect(method={"<init>(Lnet/minecraft/world/level/ItemLike;ILnet/minecraft/nbt/CompoundTag;)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/item/Item;isDamageable(Lnet/minecraft/world/item/ItemStack;)Z", remap=false))
    private boolean isDamageable(Item item, ItemStack itemStack) {
        return item.m_41465_();
    }

    @Redirect(method={"<init>(Lnet/minecraft/nbt/CompoundTag;)V"}, at=@At(value="INVOKE", target="Lnet/minecraftforge/registries/IForgeRegistry;getDelegateOrThrow(Ljava/lang/Object;)Lnet/minecraft/core/Holder$Reference;", remap=false))
    private <V> Holder.Reference<V> getDelegateOrThrowTag(IForgeRegistry iForgeRegistry, V v) {
        return null;
    }

    @Redirect(method={"<init>(Lnet/minecraft/nbt/CompoundTag;)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/item/ItemStack;forgeInit()V", remap=false))
    private void forgeInitTag(ItemStack itemStack) {
        this.gtolib$isEmpty = this.f_41589_ == Items.f_41852_;
    }

    @Redirect(method={"<init>(Lnet/minecraft/nbt/CompoundTag;)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/item/Item;isDamageable(Lnet/minecraft/world/item/ItemStack;)Z", remap=false))
    private boolean isDamageableTag(Item item, ItemStack itemStack) {
        return false;
    }

    @Overwrite
    public boolean m_41619_() {
        return this.gtolib$isEmpty || this.f_41587_ <= 0;
    }

    @Overwrite
    public Item m_41720_() {
        return this.f_41587_ <= 0 ? Items.f_41852_ : this.f_41589_;
    }

    @Overwrite
    public int m_41613_() {
        return this.gtolib$isEmpty ? 0 : this.f_41587_;
    }

    @Overwrite
    public CompoundTag m_41739_(CompoundTag compoundTag) {
        CompoundTag compoundTag2;
        compoundTag.m_128359_("id", ItemUtils.getId(this.m_41720_()));
        compoundTag.m_128344_("Count", (byte)Math.min(64, this.f_41587_));
        if (this.f_41590_ != null) {
            compoundTag.m_128365_("tag", this.f_41590_.m_6426_());
        }
        if ((compoundTag2 = this.serializeCaps()) != null && !compoundTag2.m_128456_()) {
            compoundTag.m_128365_("ForgeCaps", compoundTag2);
        }
        return compoundTag;
    }

    @Overwrite(remap=false)
    private void forgeInit() {
        if (!this.m_41619_()) {
            this.gatherCapabilities(() -> this.f_41589_.initCapabilities((ItemStack)((Object)this), this.capNBT));
            if (this.capNBT != null) {
                this.deserializeCaps(this.capNBT);
            }
        }
    }

    @NotNull
    public <T> LazyOptional<T> getCapability(@NotNull Capability<T> capability, @Nullable Direction direction) {
        if (!this.gtolib$forgeInit) {
            this.gtolib$forgeInit = true;
            this.forgeInit();
        }
        return super.getCapability(capability, direction);
    }
}

package com.gtolib.mixin.mc.nbt;

import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.mojang.serialization.DataResult;
import java.util.Map;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.EndTag;
import net.minecraft.nbt.Tag;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(targets={"net.minecraft.nbt.NbtOps.NbtRecordBuilder"})
public class NbtOpsMixin {
    @Overwrite
    protected DataResult<Tag> build(CompoundTag compoundTag, Tag tag) {
        if (tag != null && tag != EndTag.f_128534_) {
            if (!(tag instanceof CompoundTag)) {
                return DataResult.error(() -> "mergeToMap called with not a map: " + String.valueOf(tag), tag);
            }
            CompoundTag compoundTag2 = (CompoundTag)tag;
            CompoundTag compoundTag3 = new CompoundTag(new O2OOpenCacheHashMap(compoundTag2.f_128329_));
            for (Map.Entry entry : compoundTag.f_128329_.entrySet()) {
                compoundTag3.m_128365_((String)entry.getKey(), (Tag)entry.getValue());
            }
            return DataResult.success(compoundTag3);
        }
        return DataResult.success(compoundTag);
    }
}

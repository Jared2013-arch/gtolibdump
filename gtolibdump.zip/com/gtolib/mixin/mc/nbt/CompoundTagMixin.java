package com.gtolib.mixin.mc.nbt;

import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.nbt.ByteArrayTag;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.IntArrayTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.LongArrayTag;
import net.minecraft.nbt.NumericTag;
import net.minecraft.nbt.Tag;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={CompoundTag.class})
public abstract class CompoundTagMixin {
    @Shadow
    public Map<String, Tag> f_128329_;

    @Overwrite
    public byte m_128445_(String string) {
        try {
            Tag tag = this.f_128329_.get(string);
            if (tag instanceof NumericTag) {
                NumericTag numericTag = (NumericTag)((Object)tag);
                return numericTag.m_7063_();
            }
        }
        catch (ClassCastException classCastException) {
            // empty catch block
        }
        return 0;
    }

    @Overwrite
    public short m_128448_(String string) {
        try {
            Tag tag = this.f_128329_.get(string);
            if (tag instanceof NumericTag) {
                NumericTag numericTag = (NumericTag)((Object)tag);
                return numericTag.m_7053_();
            }
        }
        catch (ClassCastException classCastException) {
            // empty catch block
        }
        return 0;
    }

    @Overwrite
    public int m_128451_(String string) {
        Tag tag = this.f_128329_.get(string);
        if (tag instanceof NumericTag) {
            NumericTag numericTag = (NumericTag)((Object)tag);
            return numericTag.m_7047_();
        }
        return 0;
    }

    @Overwrite
    public long m_128454_(String string) {
        Tag tag = this.f_128329_.get(string);
        if (tag instanceof NumericTag) {
            NumericTag numericTag = (NumericTag)((Object)tag);
            return numericTag.m_7046_();
        }
        return 0L;
    }

    @Overwrite
    public float m_128457_(String string) {
        Tag tag = this.f_128329_.get(string);
        if (tag instanceof NumericTag) {
            NumericTag numericTag = (NumericTag)((Object)tag);
            return numericTag.m_7057_();
        }
        return 0.0f;
    }

    @Overwrite
    public double m_128459_(String string) {
        Tag tag = this.f_128329_.get(string);
        if (tag instanceof NumericTag) {
            NumericTag numericTag = (NumericTag)((Object)tag);
            return numericTag.m_7061_();
        }
        return 0.0;
    }

    @Overwrite
    public String m_128461_(String string) {
        Tag tag = this.f_128329_.get(string);
        if (tag != null && tag.m_7060_() == 8) {
            return tag.m_7916_();
        }
        return "";
    }

    @Overwrite
    public byte[] m_128463_(String string) {
        Tag tag = this.f_128329_.get(string);
        if (tag instanceof ByteArrayTag) {
            ByteArrayTag byteArrayTag = (ByteArrayTag)((Object)tag);
            return byteArrayTag.m_128227_();
        }
        return new byte[0];
    }

    @Overwrite
    public int[] m_128465_(String string) {
        Tag tag = this.f_128329_.get(string);
        if (tag instanceof IntArrayTag) {
            IntArrayTag intArrayTag = (IntArrayTag)((Object)tag);
            return intArrayTag.m_128648_();
        }
        return new int[0];
    }

    @Overwrite
    public long[] m_128467_(String string) {
        Tag tag = this.f_128329_.get(string);
        if (tag instanceof LongArrayTag) {
            LongArrayTag longArrayTag = (LongArrayTag)((Object)tag);
            return longArrayTag.m_128851_();
        }
        return new long[0];
    }

    @Overwrite
    public CompoundTag m_128469_(String string) {
        Tag tag = this.f_128329_.get(string);
        if (tag instanceof CompoundTag) {
            CompoundTag compoundTag = (CompoundTag)tag;
            return compoundTag;
        }
        return new CompoundTag();
    }

    @Overwrite
    public ListTag m_128437_(String string, int n) {
        Tag tag = this.f_128329_.get(string);
        if (tag instanceof ListTag) {
            ListTag listTag = (ListTag)tag;
            if (!listTag.isEmpty() && listTag.m_7264_() != n) {
                return new ListTag();
            }
            return listTag;
        }
        return new ListTag();
    }

    @Overwrite
    protected Map<String, Tag> m_128450_() {
        return this.f_128329_;
    }

    @Inject(method={"<init>(Ljava/util/Map;)V"}, at={@At(value="TAIL")})
    private void init(Map<String, Tag> map, CallbackInfo callbackInfo) {
        if (map instanceof Object2ObjectOpenHashMap) {
            return;
        }
        this.f_128329_ = new O2OOpenCacheHashMap(map);
    }

    @ModifyArg(method={"<init>()V"}, at=@At(value="INVOKE", target="Lnet/minecraft/nbt/CompoundTag;<init>(Ljava/util/Map;)V"))
    private static Map<String, Tag> useFasterCollection(Map<String, Tag> map) {
        return new O2OOpenCacheHashMap();
    }

    @Redirect(method={"<init>()V"}, at=@At(value="INVOKE", target="Lcom/google/common/collect/Maps;newHashMap()Ljava/util/HashMap;", remap=false))
    private static HashMap<?, ?> removeOldMapAlloc() {
        return null;
    }

    @Overwrite
    public CompoundTag m_6426_() {
        O2OOpenCacheHashMap o2OOpenCacheHashMap = new O2OOpenCacheHashMap(this.f_128329_.size());
        ((Object2ObjectOpenHashMap)this.f_128329_).object2ObjectEntrySet().fastForEach(entry -> o2OOpenCacheHashMap.put((String)entry.getKey(), ((Tag)entry.getValue()).m_6426_()));
        return new CompoundTag(o2OOpenCacheHashMap);
    }

    @Mixin(targets={"net.minecraft.nbt.CompoundTag$1"})
    static class Type {
        Type() {
        }

        @ModifyVariable(method={"load(Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag;"}, at=@At(value="INVOKE_ASSIGN", target="Lcom/google/common/collect/Maps;newHashMap()Ljava/util/HashMap;", remap=false))
        private Map<String, Tag> useFasterCollection(Map<String, Tag> map) {
            return new O2OOpenCacheHashMap();
        }

        @Redirect(method={"load(Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag;"}, at=@At(value="INVOKE", target="Lcom/google/common/collect/Maps;newHashMap()Ljava/util/HashMap;", remap=false))
        private HashMap<?, ?> removeOldMapAlloc() {
            return null;
        }
    }
}

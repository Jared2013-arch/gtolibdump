package com.gtolib.mixin.mc;

import com.gtolib.c;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import java.util.concurrent.Executor;
import net.minecraft.core.Holder;
import net.minecraft.core.RegistryAccess;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.tags.TagLoader;
import net.minecraft.tags.TagManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={TagManager.class})
public class TagManagerMixin {
    @ModifyExpressionValue(method={"createLoader"}, at={@At(value="NEW", target="net/minecraft/tags/TagLoader")})
    private <T> TagLoader<Holder<T>> gtceu$saveTagLoaderRegistry(TagLoader<Holder<T>> tagLoader, ResourceManager resourceManager, Executor executor, RegistryAccess.RegistryEntry<T> registryEntry) {
        ((c)((Object)tagLoader)).gtceu$setRegistry(registryEntry.f_206234_());
        return tagLoader;
    }
}

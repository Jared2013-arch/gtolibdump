package com.gtolib.mixin.mc;

import com.mojang.datafixers.DSL;
import com.mojang.datafixers.DataFixer;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.serialization.Dynamic;

class DataFixersMixin$1
implements DataFixer {
    DataFixersMixin$1() {
    }

    public <T> Dynamic<T> update(DSL.TypeReference typeReference, Dynamic<T> dynamic, int n, int n2) {
        return dynamic;
    }

    public Schema getSchema(int n) {
        return gtolib$SCHEMA;
    }
}

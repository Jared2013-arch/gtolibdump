package com.gtolib.mixin.mc;

import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(value={ResourceLocation.class})
public class ResourceLocationMixn {
    @Shadow
    @Final
    private String f_135804_;
    @Shadow
    @Final
    private String f_135805_;
    @Unique
    private int gtolib$hashCode;
    @Unique
    private String gtolib$string;

    @Overwrite
    public String toString() {
        if (this.gtolib$string == null) {
            this.gtolib$string = this.f_135804_ + ":" + this.f_135805_;
        }
        return this.gtolib$string;
    }

    @Overwrite
    public int hashCode() {
        if (this.gtolib$hashCode == 0) {
            this.gtolib$hashCode = 31 * this.f_135804_.hashCode() + this.f_135805_.hashCode();
        }
        return this.gtolib$hashCode;
    }

    @Overwrite
    private static String m_245413_(String string, String string2) {
        return string;
    }

    @Overwrite
    private static String m_245185_(String string, String string2) {
        return string2;
    }
}

package com.gtolib.h;

import com.gtolib.GTOCore;
import com.gtolib.api.ae2.AE2wtlibEvents;
import dev.architectury.networking.NetworkManager;
import dev.architectury.networking.simple.BaseC2SMessage;
import dev.architectury.networking.simple.MessageType;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public class a
extends BaseC2SMessage {
    private static final MessageType a = GTOCore.NETWORK_MANAGER.registerC2S("pick", a::new);
    private final ItemStack b;

    public static void a() {
    }

    public a(ItemStack itemStack) {
        this.b = itemStack;
    }

    private a(FriendlyByteBuf friendlyByteBuf) {
        this.b = friendlyByteBuf.m_130267_();
    }

    public MessageType getType() {
        return a;
    }

    public void write(FriendlyByteBuf friendlyByteBuf) {
        friendlyByteBuf.m_130055_(this.b);
    }

    public void handle(NetworkManager.PacketContext packetContext) {
        Player player = packetContext.getPlayer();
        if (player instanceof ServerPlayer) {
            ServerPlayer serverPlayer = (ServerPlayer)player;
            AE2wtlibEvents.pickBlock(serverPlayer, this.b);
        }
    }
}

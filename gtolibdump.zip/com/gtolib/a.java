package com.gtolib;

public interface a {
    public void gtolib$setSkip(boolean var1);
}

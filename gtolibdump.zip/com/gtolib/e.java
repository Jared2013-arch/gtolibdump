package com.gtolib;

public @interface e {
}

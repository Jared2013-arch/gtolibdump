package com.gtolib.d;

import com.enderio.api.conduit.ConduitType;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import org.jetbrains.annotations.NotNull;

public interface a {
    @NotNull
    public MenuProvider gtolib$menuProvider(ServerPlayer var1, Direction var2, ConduitType<?> var3);
}

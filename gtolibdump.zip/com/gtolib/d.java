package com.gtolib;

import com.gtolib.syncdata.b;
import earth.terrarium.adastra.api.planets.Planet;
import it.unimi.dsi.fastutil.longs.LongSet;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.FullChunkStatus;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.lighting.LightEngine;

public interface d {
    default public LongSet gtolib$getPreventUpdate() {
        return null;
    }

    default public Planet gtolib$getPlanet() {
        return null;
    }

    default public boolean gtolib$isVoid() {
        return false;
    }

    default public b gtolib$getSyncFieldManager() {
        throw new UnsupportedOperationException();
    }

    public static void a(Level level, BlockPos blockPos, boolean bl, boolean bl2) {
        int n = blockPos.m_123342_();
        if (level.m_151562_(n)) {
            return;
        }
        LevelChunk levelChunk = level.m_46745_(blockPos);
        LevelChunkSection levelChunkSection = levelChunk.m_183278_(levelChunk.m_151564_(n));
        if (!levelChunkSection.m_188008_()) {
            int n2;
            int n3;
            if (!bl && levelChunk.m_8055_(blockPos).m_60713_(Blocks.f_50752_)) {
                return;
            }
            BlockState blockState = Blocks.f_50016_.m_49966_();
            int n4 = blockPos.m_123341_() & 0xF;
            BlockState blockState2 = levelChunkSection.m_62986_(n4, n3 = n & 0xF, n2 = blockPos.m_123343_() & 0xF, blockState);
            if (!blockState2.m_60795_()) {
                FullChunkStatus fullChunkStatus;
                levelChunk.m_6005_(Heightmap.Types.MOTION_BLOCKING).m_64249_(n4, n, n2, blockState);
                levelChunk.m_6005_(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES).m_64249_(n4, n, n2, blockState);
                levelChunk.m_6005_(Heightmap.Types.OCEAN_FLOOR).m_64249_(n4, n, n2, blockState);
                levelChunk.m_6005_(Heightmap.Types.WORLD_SURFACE).m_64249_(n4, n, n2, blockState);
                if (bl2 && LightEngine.m_284387_(level, blockPos, blockState2, blockState)) {
                    levelChunk.m_284400_().m_284521_(level, n4, n, n2);
                    level.m_7726_().m_7827_().m_7174_(blockPos);
                }
                if (levelChunkSection.m_188008_()) {
                    level.m_7726_().m_7827_().m_75834_(blockPos, true);
                }
                blockState2.m_60753_(level, blockPos, Blocks.f_50016_.m_49966_(), false);
                if (blockState2.m_155947_()) {
                    level.m_46747_(blockPos);
                }
                if ((fullChunkStatus = levelChunk.m_287138_()) != null && fullChunkStatus.m_287205_(FullChunkStatus.BLOCK_TICKING) && level instanceof ServerLevel) {
                    ServerLevel serverLevel = (ServerLevel)level;
                    serverLevel.m_7726_().m_8450_(blockPos);
                }
                levelChunk.m_8092_(true);
            }
        }
    }
}

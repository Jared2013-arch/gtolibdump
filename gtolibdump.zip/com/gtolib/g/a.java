package com.gtolib.g;

import net.minecraft.client.gui.layouts.LayoutElement;

public interface a {
    public LayoutElement gtolib$getCreateWorldButton();
}

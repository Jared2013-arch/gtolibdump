package com.gtolib;

public interface b {
    public int gto$getGTODifficulty();

    public void gto$setGTODifficulty(int var1);

    public boolean gto$isSrm();

    public void gto$setSrm(boolean var1);

    public boolean gto$isDevMode();

    public void gto$setDevMode(boolean var1);
}

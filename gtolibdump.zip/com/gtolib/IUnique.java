package com.gtolib;

import com.gtolib.e;
import java.util.concurrent.atomic.AtomicInteger;

@e
public interface IUnique {
    public static final AtomicInteger ID = new AtomicInteger(0);

    public int getUid();
}

package com.gtolib.utils;

import com.google.common.base.Equivalence;
import com.gregtechceu.gtceu.utils.ItemStackHashStrategy;
import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;

class SortUtils$1
extends Equivalence<ItemStack> {
    SortUtils$1() {
    }

    @Override
    @ParametersAreNonnullByDefault
    protected boolean doEquivalent(ItemStack itemStack, ItemStack itemStack2) {
        return ItemStackHashStrategy.ITEM_AND_TAG.equals(itemStack, itemStack2);
    }

    @Override
    protected int doHash(@NotNull ItemStack itemStack) {
        return ItemStackHashStrategy.ITEM_AND_TAG.hashCode(itemStack);
    }
}

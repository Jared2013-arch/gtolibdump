package com.gtolib.utils;

import com.gtolib.api.player.IEnhancedPlayer;
import com.gtolib.api.player.PlayerData;
import net.minecraft.world.entity.player.Player;

public class PlayerUtils {
    public static void refreshPlayerFlyStatement(Player player) {
        PlayerData playerData = IEnhancedPlayer.of(player).getPlayerData();
        if (playerData.canFly()) {
            player.m_150110_().f_35936_ = true;
            player.m_6885_();
        }
    }
}

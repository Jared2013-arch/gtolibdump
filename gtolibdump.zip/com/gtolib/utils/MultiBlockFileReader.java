package com.gtolib.utils;

import com.gregtechceu.gtceu.api.machine.MultiblockMachineDefinition;
import com.gregtechceu.gtceu.api.pattern.FactoryBlockPattern;
import com.gregtechceu.gtceu.api.pattern.util.RelativeDirection;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MultiBlockFileReader {
    private static final Pattern PATTERN = Pattern.compile("\"([^\"]*)\"");

    private MultiBlockFileReader() {
    }

    public static FactoryBlockPattern start(MultiblockMachineDefinition multiblockMachineDefinition) {
        return MultiBlockFileReader.start(multiblockMachineDefinition, RelativeDirection.LEFT, RelativeDirection.UP, RelativeDirection.FRONT);
    }

    public static FactoryBlockPattern start(MultiblockMachineDefinition multiblockMachineDefinition, RelativeDirection relativeDirection, RelativeDirection relativeDirection2, RelativeDirection relativeDirection3) {
        FactoryBlockPattern factoryBlockPattern = FactoryBlockPattern.start(multiblockMachineDefinition, relativeDirection, relativeDirection2, relativeDirection3);
        try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(Objects.requireNonNull(MultiBlockFileReader.class.getClassLoader().getResourceAsStream("assets/gtocore/mbs/" + multiblockMachineDefinition.getName()))));){
            String string;
            while ((string = bufferedReader.readLine()) != null) {
                Matcher matcher = PATTERN.matcher(string);
                ObjectArrayList objectArrayList = new ObjectArrayList();
                while (matcher.find()) {
                    objectArrayList.add(matcher.group(1));
                }
                if (objectArrayList.isEmpty()) continue;
                factoryBlockPattern.aisle(objectArrayList.toArray((T[])new String[0]));
            }
        }
        catch (IOException iOException) {
            throw new RuntimeException(iOException);
        }
        return factoryBlockPattern;
    }
}

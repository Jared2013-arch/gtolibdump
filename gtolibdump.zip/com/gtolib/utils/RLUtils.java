package com.gtolib.utils;

import com.gtolib.GTOCore;
import net.minecraft.resources.ResourceLocation;

public final class RLUtils {
    public static final ResourceLocation EMPTY = GTOCore.id("empty");

    private RLUtils() {
    }

    public static ResourceLocation fromNamespaceAndPath(String string, String string2) {
        return new ResourceLocation(string, string2, null);
    }

    public static ResourceLocation parse(String string) {
        String string2 = "minecraft";
        String string3 = string;
        int n = string.indexOf(58);
        if (n >= 0) {
            string3 = string.substring(n + 1);
            if (n >= 1) {
                string2 = string.substring(0, n);
            }
        }
        return new ResourceLocation(string2, string3, null);
    }

    public static ResourceLocation mc(String string) {
        return RLUtils.fromNamespaceAndPath("minecraft", string);
    }

    public static ResourceLocation forge(String string) {
        return RLUtils.fromNamespaceAndPath("forge", string);
    }

    public static ResourceLocation avaritia(String string) {
        return RLUtils.fromNamespaceAndPath("avaritia", string);
    }

    public static ResourceLocation eio(String string) {
        return RLUtils.fromNamespaceAndPath("enderio", string);
    }

    public static ResourceLocation sp(String string) {
        return RLUtils.fromNamespaceAndPath("sophisticatedbackpacks", string);
    }

    public static ResourceLocation fd(String string) {
        return RLUtils.fromNamespaceAndPath("farmersdelight", string);
    }

    public static ResourceLocation fr(String string) {
        return RLUtils.fromNamespaceAndPath("farmersrespite", string);
    }

    public static ResourceLocation ad(String string) {
        return RLUtils.fromNamespaceAndPath("ad_astra", string);
    }

    public static ResourceLocation bot(String string) {
        return RLUtils.fromNamespaceAndPath("botania", string);
    }

    public static ResourceLocation exbot(String string) {
        return RLUtils.fromNamespaceAndPath("extrabotany", string);
    }

    public static ResourceLocation ars(String string) {
        return RLUtils.fromNamespaceAndPath("ars_nouveau", string);
    }

    public static ResourceLocation ae(String string) {
        return RLUtils.fromNamespaceAndPath("ae2", string);
    }

    public static ResourceLocation functionalstorage(String string) {
        return RLUtils.fromNamespaceAndPath("functionalstorage", string);
    }
}

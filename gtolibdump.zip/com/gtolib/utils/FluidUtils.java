package com.gtolib.utils;

import com.gtolib.IFluid;
import com.gtolib.utils.NumberUtils;
import com.gtolib.utils.RLUtils;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import net.minecraftforge.registries.ForgeRegistries;

public final class FluidUtils {
    private FluidUtils() {
    }

    public static String getUnicodeMillibuckets(long l) {
        return l < 1000L ? NumberUtils.formatLong(l) + " mB" : NumberUtils.formatLong(l / 1000L) + " B";
    }

    public static String getId(Fluid fluid) {
        return ((IFluid)((Object)fluid)).gtolib$getIdString();
    }

    public static ResourceLocation getIdLocation(Fluid fluid) {
        return ((IFluid)((Object)fluid)).gtolib$getIdLocation();
    }

    public static Fluid getFluid(String string) {
        Fluid fluid = (Fluid)ForgeRegistries.FLUIDS.getValue(RLUtils.parse(string));
        return fluid == null ? Fluids.f_76191_ : fluid;
    }
}

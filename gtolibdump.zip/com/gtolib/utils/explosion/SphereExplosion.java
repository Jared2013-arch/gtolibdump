package com.gtolib.utils.explosion;

import com.gregtechceu.gtceu.utils.TaskHandler;
import com.gtolib.d;
import com.lowdragmc.lowdraglib.syncdata.ISubscription;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class SphereExplosion {
    private final BlockPos center;
    private final ServerLevel level;
    private final int radius;
    private final boolean breakBedrock;
    private ISubscription subscription;
    private int currentLayer = -1;
    private int currentY;
    private int currentX;
    private int currentZ;
    private boolean layerInitialized = false;
    private static final int MAX_BLOCKS_PER_TICK = 50000;

    private SphereExplosion(BlockPos blockPos, ServerLevel serverLevel, int n, boolean bl, boolean bl2, boolean bl3) {
        float f;
        this.center = blockPos;
        this.level = serverLevel;
        this.radius = n;
        this.breakBedrock = bl;
        int n2 = blockPos.m_123341_();
        int n3 = blockPos.m_123342_();
        int n4 = blockPos.m_123343_();
        if (this.level.f_46443_) {
            f = (1.0f + (this.level.f_46441_.m_188501_() - this.level.f_46441_.m_188501_()) * 0.2f) * 0.7f;
            this.level.m_7785_(n2, n3, n4, SoundEvents.f_11913_, SoundSource.BLOCKS, 4.0f, f, false);
        }
        if (bl2) {
            this.level.m_7106_(ParticleTypes.f_123812_, n2, n3, n4, 1.0, 0.0, 0.0);
        }
        this.level.m_220400_(null, GameEvent.f_157812_, new Vec3(n2, n3, n4));
        if (bl3) {
            f = (float)this.radius * 2.0f;
            List list = this.level.m_45933_(null, new AABB(Mth.m_14107_((double)((float)n2 - f) - 1.0), Mth.m_14107_((double)((float)n3 - f) - 1.0), Mth.m_14107_((double)((float)n4 - f) - 1.0), Mth.m_14107_((double)((float)n2 + f) + 1.0), Mth.m_14107_((double)((float)n3 + f) + 1.0), Mth.m_14107_((double)((float)n4 + f) + 1.0)));
            Vec3 vec3 = new Vec3(n2, n3, n4);
            double d = f * f;
            double d2 = 1.0 / (double)f;
            for (Entity entity : list) {
                double d3 = entity.m_20238_(vec3);
                if (entity.m_6128_() || d3 > d) continue;
                double d4 = 1.0 - d3 * d2;
                int n5 = (int)((d4 * d4 + d4) / 2.0 * 7.0 * (double)f + 1.0);
                entity.m_6469_(entity.m_269291_().m_287172_(), n5);
                Vec3 vec32 = new Vec3(entity.m_20185_() - (double)n2, entity.m_20186_() - (double)n3, entity.m_20189_() - (double)n4).m_82541_().m_82490_(d4);
                entity.m_20256_(entity.m_20184_().m_82549_(vec32));
            }
        }
        this.subscription = TaskHandler.enqueueServerTick(serverLevel, this::breakBlocksInExplosionArea, () -> {
            this.subscription = null;
        }, 0)::unsubscribe;
    }

    private void breakBlocksInExplosionArea() {
        if (this.currentLayer < 0) {
            this.currentLayer = Math.min(this.radius, 19);
        }
        if (this.currentLayer > this.radius) {
            this.subscription.unsubscribe();
            return;
        }
        int n = this.currentLayer + 1;
        int n2 = n * n;
        int n3 = this.currentLayer > 20 ? (this.currentLayer - 1) * (this.currentLayer - 1) : 0;
        int n4 = this.level.m_151558_();
        int n5 = this.level.m_141937_();
        int n6 = this.center.m_123341_();
        int n7 = this.center.m_123342_();
        int n8 = this.center.m_123343_();
        int n9 = 0;
        if (this.currentLayer <= 50) {
            for (int i = n; i >= -n; --i) {
                int n10;
                int n11 = n7 + i;
                if (n11 < n5 || n11 > n4 || (n10 = i * i) > n2) continue;
                int n12 = n2 - n10;
                int n13 = (int)Math.sqrt(n12);
                for (int j = -n13; j <= n13; ++j) {
                    int n14 = j * j;
                    int n15 = n14 + n10;
                    if (n15 > n2) continue;
                    int n16 = n12 - n14;
                    int n17 = (int)Math.sqrt(n16);
                    for (int k = -n17; k <= n17; ++k) {
                        int n18 = n15 + k * k;
                        if (n18 < n3 || n18 > n2) continue;
                        d.a(this.level, new BlockPos(n6 + j, n7 + i, n8 + k), this.breakBedrock, false);
                    }
                }
            }
            ++this.currentLayer;
            return;
        }
        if (!this.layerInitialized) {
            this.currentY = n;
            this.currentX = Integer.MIN_VALUE;
            this.currentZ = 0;
            this.layerInitialized = true;
        }
        for (int i = this.currentY; i >= -n; --i) {
            int n19;
            int n20;
            int n21 = n7 + i;
            if (n21 < n5 || n21 > n4 || (n20 = i * i) > n2) continue;
            int n22 = n2 - n20;
            int n23 = (int)Math.sqrt(n22);
            for (int j = n19 = this.currentX == Integer.MIN_VALUE ? -n23 : this.currentX; j <= n23; ++j) {
                int n24;
                int n25 = j * j;
                int n26 = n25 + n20;
                if (n26 > n2) continue;
                int n27 = n22 - n25;
                int n28 = (int)Math.sqrt(n27);
                for (int k = n24 = this.currentX == j ? this.currentZ : -n28; k <= n28; ++k) {
                    int n29 = n26 + k * k;
                    if (n29 < n3 || n29 > n2) continue;
                    d.a(this.level, new BlockPos(n6 + j, n7 + i, n8 + k), this.breakBedrock, false);
                    if (++n9 < 50000) continue;
                    this.currentY = i;
                    this.currentX = j;
                    this.currentZ = k + 1;
                    return;
                }
                this.currentZ = -n28;
            }
            this.currentX = Integer.MIN_VALUE;
        }
        ++this.currentLayer;
        this.layerInitialized = false;
    }

    public static void explosion(BlockPos blockPos, Level level, int n, boolean bl, boolean bl2) {
        SphereExplosion.explosion(blockPos, level, n, bl, bl2, true);
    }

    public static void explosion(BlockPos blockPos, Level level, int n, boolean bl, boolean bl2, boolean bl3) {
        if (level instanceof ServerLevel) {
            ServerLevel serverLevel = (ServerLevel)level;
            new SphereExplosion(blockPos, serverLevel, n, bl, bl2, bl3);
        }
    }
}

package com.gtolib.utils.holder;

public class LongHolder {
    public long value;

    public LongHolder(long l) {
        this.value = l;
    }
}

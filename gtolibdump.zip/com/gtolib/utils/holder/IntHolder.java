package com.gtolib.utils.holder;

public class IntHolder {
    public int value;

    public IntHolder(int n) {
        this.value = n;
    }
}

package com.gtolib.utils.holder;

public class LongObjectHolder<T> {
    public long number;
    public T obj;

    public LongObjectHolder(long l, T t) {
        this.number = l;
        this.obj = t;
    }
}

package com.gtolib.utils.holder;

import java.util.Comparator;

public class IntObjectHolder<T> {
    public static final Comparator<IntObjectHolder<?>> PRIORITY_SORTER = (intObjectHolder, intObjectHolder2) -> Integer.compare(intObjectHolder2.number, intObjectHolder.number);
    public int number;
    public T obj;

    public IntObjectHolder(int n, T t) {
        this.number = n;
        this.obj = t;
    }
}

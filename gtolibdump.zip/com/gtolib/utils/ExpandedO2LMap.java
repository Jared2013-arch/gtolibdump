package com.gtolib.utils;

import com.gregtechceu.gtceu.utils.collection.O2LOpenCacheHashMap;
import it.unimi.dsi.fastutil.HashCommon;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import it.unimi.dsi.fastutil.objects.Object2LongOpenHashMap;
import java.util.Iterator;
import org.jetbrains.annotations.NotNull;

public class ExpandedO2LMap<K>
extends O2LOpenCacheHashMap<K>
implements Iterable<Object2LongMap.Entry<K>> {
    public ExpandedO2LMap() {
        super(16, 0.75f);
    }

    public ExpandedO2LMap(int n) {
        super(n, 0.75f);
    }

    public ExpandedO2LMap(Object2LongOpenHashMap<K> object2LongOpenHashMap) {
        super(object2LongOpenHashMap.size(), 0.75f);
        object2LongOpenHashMap.object2LongEntrySet().fastForEach(entry -> this.put(entry.getKey(), entry.getLongValue()));
    }

    @Override
    @NotNull
    public Iterator<Object2LongMap.Entry<K>> iterator() {
        return this.object2LongEntrySet().fastIterator();
    }

    public long addTo(K k, long l) {
        if (k == null) {
            return 0L;
        }
        int n = k.hashCode();
        Object[] objectArray = this.key;
        int[] nArray = this.hash;
        int n2 = HashCommon.mix(n) & this.mask;
        Object object = objectArray[n2];
        if (object != null) {
            do {
                if (nArray[n2] != n || !object.equals(k)) continue;
                long l2 = this.value[n2];
                long l3 = l2 + l;
                this.value[n2] = l3 < 0L && l >= 0L && l2 >= 0L ? Long.MAX_VALUE : l3;
                return l2;
            } while ((object = objectArray[n2 = n2 + 1 & this.mask]) != null);
        }
        objectArray[n2] = k;
        nArray[n2] = n;
        this.value[n2] = l;
        if (this.size++ >= this.maxFill) {
            this.rehash(HashCommon.arraySize(this.size + 1, this.f));
        }
        return 0L;
    }

    public void ensureCapacity(int n) {
        int n2 = (int)Math.min(0x40000000L, Math.max(2L, HashCommon.nextPowerOfTwo((long)Math.ceil((float)(n + this.size) / this.f))));
        if (n2 > this.n) {
            this.rehash(n2);
        }
    }

    public void reset() {
        int n = this.value.length;
        for (int i = 0; i < n; ++i) {
            this.value[i] = 0L;
        }
    }
}

package com.gtolib.utils.register;

import appeng.items.materials.StorageComponentItem;
import com.google.common.collect.ImmutableTable;
import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.GTValues;
import com.gregtechceu.gtceu.api.data.chemical.material.Material;
import com.gregtechceu.gtceu.api.data.tag.TagPrefix;
import com.gregtechceu.gtceu.api.data.tag.TagUtil;
import com.gregtechceu.gtceu.api.item.ComponentItem;
import com.gregtechceu.gtceu.api.item.ITagPrefixItem;
import com.gregtechceu.gtceu.api.item.component.FoodStats;
import com.gregtechceu.gtceu.api.item.component.ICustomRenderer;
import com.gregtechceu.gtceu.api.item.component.IItemComponent;
import com.gregtechceu.gtceu.api.registry.registrate.GTRegistrate;
import com.gregtechceu.gtceu.common.data.GTItems;
import com.gregtechceu.gtceu.common.item.CoverPlaceBehavior;
import com.gregtechceu.gtceu.common.item.TooltipBehavior;
import com.gregtechceu.gtceu.data.recipe.CustomTags;
import com.gregtechceu.gtceu.utils.FormattingUtil;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtocore.common.data.GTOCovers;
import com.gtocore.common.data.GTOEffects;
import com.gtocore.common.item.KineticRotorItem;
import com.gtocore.common.item.misc.MysteriousBoostPotionBehaviour;
import com.gtolib.GTOCore;
import com.gtolib.api.GTOValues;
import com.gtolib.api.data.chemical.material.GTOMaterial;
import com.gtolib.api.registries.GTORegistration;
import com.gtolib.api.registries.ItemBuilder;
import com.gtolib.utils.ColorUtils;
import com.gtolib.utils.TintableModelUtils;
import com.tterrag.registrate.Registrate;
import com.tterrag.registrate.providers.ProviderType;
import com.tterrag.registrate.util.entry.ItemEntry;
import com.tterrag.registrate.util.nullness.NonNullBiConsumer;
import com.tterrag.registrate.util.nullness.NonNullConsumer;
import com.tterrag.registrate.util.nullness.NonNullFunction;
import com.tterrag.registrate.util.nullness.NonNullSupplier;
import java.lang.invoke.LambdaMetafactory;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.ToIntFunction;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import org.jetbrains.annotations.NotNull;

public final class ItemRegisterUtils {
    public static final Map<String, String> LANG = GTCEu.isDataGen() ? new O2OOpenCacheHashMap() : null;

    private ItemRegisterUtils() {
    }

    @NotNull
    public static <T extends Item> ItemBuilder<T, Registrate> item(String string, String string2, NonNullFunction<Item.Properties, T> nonNullFunction) {
        if (LANG != null) {
            if (LANG.containsKey(string)) {
                GTOCore.LOGGER.error("Repetitive Key: {}", (Object)string);
                throw new IllegalStateException();
            }
            if (LANG.containsValue(string2)) {
                GTOCore.LOGGER.error("Repetitive Value: {}", (Object)string2);
                throw new IllegalStateException();
            }
            LANG.put(string, string2);
        }
        return GTORegistration.GTO.item(string, (NonNullFunction)nonNullFunction);
    }

    public static void generateMaterialItem(GTRegistrate gTRegistrate, TagPrefix tagPrefix, Material material, ImmutableTable.Builder<TagPrefix, Material, ItemEntry<Item>> builder) {
        builder.put(tagPrefix, material, ((com.tterrag.registrate.builders.ItemBuilder)((Object)((com.tterrag.registrate.builders.ItemBuilder)((Object)((com.tterrag.registrate.builders.ItemBuilder)((Object)gTRegistrate.item(tagPrefix.idPattern().formatted(new Object[]{material.getName()}), properties -> tagPrefix.itemConstructor().create((Item.Properties)properties, tagPrefix, material)).setData(ProviderType.LANG, NonNullBiConsumer.noop()))).transform(GTItems.unificationItem(tagPrefix, material)))).properties(properties -> {
            GTOMaterial gTOMaterial;
            Rarity rarity;
            int n;
            properties.m_41487_(tagPrefix.maxStackSize() == 1 ? 1 : 64);
            ToIntFunction toIntFunction = tagPrefix.getMaxDamageProvider();
            if (toIntFunction != null && (n = toIntFunction.applyAsInt(material)) > 0) {
                properties.m_41503_(n);
            }
            if (material instanceof GTOMaterial && (rarity = (gTOMaterial = (GTOMaterial)((Object)material)).gtolib$rarity()) != null) {
                properties.m_41497_(rarity);
            }
            return properties;
        }).model(NonNullBiConsumer.noop()).color(() -> () -> ITagPrefixItem.tintColor(material)).onRegister((NonNullConsumer)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, cauldronInteraction(net.minecraft.world.item.Item ), (Lnet/minecraft/world/item/Item;)V)()))).register());
    }

    public static ItemEntry<StorageComponentItem> registerStorageComponentItem(int n) {
        return ItemRegisterUtils.item("cell_component_" + n + "m", n + "M ME存储组件", properties -> new StorageComponentItem((Item.Properties)properties, 0x100000 * n)).register();
    }

    public static ItemEntry<ComponentItem> registerTieredCover(int n) {
        return ((com.tterrag.registrate.builders.ItemBuilder)((Object)ItemRegisterUtils.item(GTValues.VN[14].toLowerCase(Locale.ROOT) + "_" + (String)(n == 1 ? "" : n + "a_") + "wireless_energy_receive_cover", (String)(n == 1 ? "" : n + "安") + GTValues.VN[14] + "无线能源接收器", (NonNullFunction)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, create(net.minecraft.world.item.Item$Properties ), (Lnet/minecraft/world/item/Item$Properties;)Lcom/gregtechceu/gtceu/api/item/ComponentItem;)()).lang(GTValues.VNF[14] + " " + (String)(n == 1 ? "" : n + "A ") + "Wireless Energy Receive Cover").onRegister(GTItems.attach(new IItemComponent[]{new TooltipBehavior(list -> {
            list.add(Component.m_237115_("item.gtmthings.wireless_energy_receive_cover.tooltip.1"));
            list.add(Component.m_237115_("item.gtmthings.wireless_energy_receive_cover.tooltip.2"));
            list.add(Component.m_237110_("item.gtmthings.wireless_energy_receive_cover.tooltip.3", new Object[]{GTValues.V[14] * (long)n}));
        }), new CoverPlaceBehavior(n == 1 ? GTOCovers.MAX_WIRELESS_ENERGY_RECEIVE : GTOCovers.MAX_WIRELESS_ENERGY_RECEIVE_4A)})))).register();
    }

    public static <T extends ComponentItem> NonNullConsumer<T> attachRenderer(ICustomRenderer iCustomRenderer) {
        return !GTCEu.isClientSide() ? NonNullConsumer.noop() : componentItem -> componentItem.attachComponents(iCustomRenderer);
    }

    public static ItemEntry<KineticRotorItem> registerRotor(String string, String string2, int n, int n2, int n3, int n4) {
        return ItemRegisterUtils.item(string, string2 + "动力转子", properties -> new KineticRotorItem((Item.Properties)properties, n, n2, n3, n4)).register();
    }

    public static ItemEntry<Item>[] registerCircuits(String string, String string2, int[] nArray, Function<Integer, Component> function) {
        ItemEntry[] itemEntryArray = new ItemEntry[GTValues.TIER_COUNT];
        for (int n : nArray) {
            ItemEntry itemEntry;
            String string3 = string + "_" + GTValues.VN[n].toLowerCase();
            itemEntryArray[n] = itemEntry = ItemRegisterUtils.item(string3, GTOValues.VOLTAGE_NAMESCN[n] + string2, (NonNullFunction)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, <init>(net.minecraft.world.item.Item$Properties ), (Lnet/minecraft/world/item/Item$Properties;)Lnet/minecraft/world/item/Item;)()).toolTips(() -> Component.m_237115_("gtocore.tooltip.item." + string).m_130940_(ChatFormatting.GRAY), () -> function.apply(n)).model(NonNullBiConsumer.noop()).lang(GTValues.VOLTAGE_NAMES[n] + " " + FormattingUtil.toEnglishName(string)).tag(new TagKey[]{CustomTags.CIRCUITS_ARRAY[n]}).register();
        }
        return itemEntryArray;
    }

    public static ItemEntry<ComponentItem>[] registerMysteriousBoostDrink() {
        ItemEntry[] itemEntryArray = new ItemEntry[GTValues.TIER_COUNT];
        for (int n : GTValues.ALL_TIERS) {
            itemEntryArray[n] = ((com.tterrag.registrate.builders.ItemBuilder)((Object)((com.tterrag.registrate.builders.ItemBuilder)((Object)ItemRegisterUtils.item("gto_overseer_coke_" + GTValues.VN[n].toLowerCase(), "GTO牌 " + GTOValues.VNFR[n] + " 监工可乐", (NonNullFunction)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, create(net.minecraft.world.item.Item$Properties ), (Lnet/minecraft/world/item/Item$Properties;)Lcom/gregtechceu/gtceu/api/item/ComponentItem;)()).model((dataGenContext, registrateItemModelProvider) -> TintableModelUtils.createTintableModel(dataGenContext, registrateItemModelProvider, "item/skill/normal/normal_border", "item/skill/normal/tier_border", "item/skill/mysterious_boost_medicine/0_bottle", "item/skill/mysterious_boost_medicine/1_face", "item/skill/mysterious_boost_medicine/2_liquid1", "item/skill/mysterious_boost_medicine/3_liquid2", "item/skill/mysterious_boost_medicine/4_liquid3", "item/skill/mysterious_boost_medicine/5_gtologo", "item/skill/mysterious_boost_medicine/6_gtologobase", "item/skill/mysterious_boost_medicine/7_straw")).color(() -> () -> (itemStack, n2) -> {
                if (n2 == 1) {
                    float f = 0.3f + (float)(n + 1) * (0.7f / (float)GTValues.TIER_COUNT);
                    int n3 = 255;
                    int n4 = Math.min(255, (int)(97.0f * f));
                    int n5 = Math.min(255, (int)(252.0f * f));
                    int n6 = Math.min(255, (int)(6375932.0f * f));
                    return n3 << 24 | n4 << 16 | n5 << 8 | n6;
                }
                RandomSource randomSource = GTValues.RNG;
                int[] nArray = ColorUtils.generateStepGradient(randomSource.m_188503_(0x1000000), randomSource.m_188503_(0x1000000), 70, 3);
                return switch (n2) {
                    case 4 -> nArray[0];
                    case 5 -> nArray[1];
                    case 6 -> nArray[2];
                    default -> -1;
                };
            }).onRegister(GTItems.attach(new MysteriousBoostPotionBehaviour())))).onRegister(GTItems.attach(new FoodStats(new FoodProperties.Builder().effect(() -> new MobEffectInstance((MobEffect)GTOEffects.MYSTERIOUS_BOOST.get(), 1200 * (5 + n), n), 1.0f).m_38765_().m_38760_(n).m_38758_((float)n / 10.0f).m_38767_(), true, null))))).register();
        }
        return itemEntryArray;
    }

    public static ItemEntry<Item> registerCircuit(String string, String string2, TagKey<Item> tagKey, Supplier<String> supplier) {
        return ItemRegisterUtils.item(string, string2, (NonNullFunction)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, <init>(net.minecraft.world.item.Item$Properties ), (Lnet/minecraft/world/item/Item$Properties;)Lnet/minecraft/world/item/Item;)()).toolTips(() -> Component.m_237113_((String)supplier.get())).model((dataGenContext, registrateItemModelProvider) -> registrateItemModelProvider.generated((NonNullSupplier)dataGenContext, new ResourceLocation[]{GTOCore.id("item/circuit/" + string)})).tag(new TagKey[]{tagKey}).model(NonNullBiConsumer.noop()).register();
    }

    public static ItemEntry<Item> registerEssence(String string, String string2) {
        return ItemRegisterUtils.item(string + "_essence", string2 + "精华", (NonNullFunction)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, <init>(net.minecraft.world.item.Item$Properties ), (Lnet/minecraft/world/item/Item$Properties;)Lnet/minecraft/world/item/Item;)()).model((dataGenContext, registrateItemModelProvider) -> registrateItemModelProvider.generated((NonNullSupplier)dataGenContext, new ResourceLocation[]{GTOCore.id("item/essence/" + string)})).tag(new TagKey[]{TagUtil.optionalTag(BuiltInRegistries.f_257033_, GTOCore.id("vein_essence"))}).register();
    }

    public static ItemEntry<Item> registerAlgae(String string, String string2) {
        return ItemRegisterUtils.item(string + "_algae", string2 + "藻", (NonNullFunction)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, <init>(net.minecraft.world.item.Item$Properties ), (Lnet/minecraft/world/item/Item$Properties;)Lnet/minecraft/world/item/Item;)()).model((dataGenContext, registrateItemModelProvider) -> registrateItemModelProvider.generated((NonNullSupplier)dataGenContext, new ResourceLocation[]{GTOCore.id("item/algae/" + string)})).tag(new TagKey[]{TagUtil.optionalTag(BuiltInRegistries.f_257033_, GTOCore.id("algae"))}).register();
    }

    public static ItemEntry<Item> registerAlgaeFiber(String string, String string2) {
        return ItemRegisterUtils.item(string + "_algae_fiber", string2 + "藻纤维", (NonNullFunction)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, <init>(net.minecraft.world.item.Item$Properties ), (Lnet/minecraft/world/item/Item$Properties;)Lnet/minecraft/world/item/Item;)()).tag(new TagKey[]{TagUtil.optionalTag(BuiltInRegistries.f_257033_, GTOCore.id("algae_fiber"))}).register();
    }

    public static ItemEntry<Item> registerCustomModel(String string, String string2) {
        return ItemRegisterUtils.item(string, string2, (NonNullFunction)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, <init>(net.minecraft.world.item.Item$Properties ), (Lnet/minecraft/world/item/Item$Properties;)Lnet/minecraft/world/item/Item;)()).model(NonNullBiConsumer.noop()).register();
    }

    public static ItemEntry<Item> register(String string, String string2) {
        return ItemRegisterUtils.item(string, string2, (NonNullFunction)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, <init>(net.minecraft.world.item.Item$Properties ), (Lnet/minecraft/world/item/Item$Properties;)Lnet/minecraft/world/item/Item;)()).register();
    }

    public static ItemEntry<Item> registerTexture(String string, String string2, String string3) {
        return ItemRegisterUtils.item(string, string2, (NonNullFunction)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, <init>(net.minecraft.world.item.Item$Properties ), (Lnet/minecraft/world/item/Item$Properties;)Lnet/minecraft/world/item/Item;)()).model((dataGenContext, registrateItemModelProvider) -> registrateItemModelProvider.generated((NonNullSupplier)dataGenContext, new ResourceLocation[]{GTOCore.id("item/" + string3)})).register();
    }

    public static ItemEntry<Item> registerLang(String string, String string2, String string3) {
        return ItemRegisterUtils.item(string, string3, (NonNullFunction)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, <init>(net.minecraft.world.item.Item$Properties ), (Lnet/minecraft/world/item/Item$Properties;)Lnet/minecraft/world/item/Item;)()).lang(string2).register();
    }

    public static ItemEntry<Item> registerTooltip(String string, String string2, Supplier<Component> supplier) {
        return ItemRegisterUtils.item(string, string2, (NonNullFunction)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, <init>(net.minecraft.world.item.Item$Properties ), (Lnet/minecraft/world/item/Item$Properties;)Lnet/minecraft/world/item/Item;)()).toolTips(supplier).register();
    }
}

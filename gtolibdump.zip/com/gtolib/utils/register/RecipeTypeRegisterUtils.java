package com.gtolib.utils.register;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.GTCEuAPI;
import com.gregtechceu.gtceu.api.block.ICoilType;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.registry.GTRegistries;
import com.gregtechceu.gtceu.utils.FormattingUtil;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtolib.api.lang.CNEN;
import com.gtolib.api.recipe.RecipeType;
import com.lowdragmc.lowdraglib.gui.widget.SlotWidget;
import com.lowdragmc.lowdraglib.gui.widget.WidgetGroup;
import com.lowdragmc.lowdraglib.utils.CycleItemStackHandler;
import com.lowdragmc.lowdraglib.utils.LocalizationUtils;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;

public final class RecipeTypeRegisterUtils {
    public static final String MAGIC = "magic";
    public static final Map<String, CNEN> LANG = GTCEu.isDataGen() ? new O2OOpenCacheHashMap() : null;
    public static final Function<CompoundTag, String> TEMPERATURE = compoundTag -> LocalizationUtils.format("gtceu.recipe.temperature", new Object[]{FormattingUtil.formatNumbers(compoundTag.m_128451_("ebf_temp"))});
    public static final Function<CompoundTag, String> COIL = compoundTag -> {
        ICoilType iCoilType = ICoilType.getMinRequiredType(compoundTag.m_128451_("ebf_temp"));
        if (iCoilType != null && iCoilType.getMaterial() != null) {
            return LocalizationUtils.format("gtceu.recipe.coil.tier", new Object[]{I18n.m_118938_(iCoilType.getMaterial().getUnlocalizedName(), new Object[0])});
        }
        return "";
    };
    public static final BiConsumer<GTRecipe, WidgetGroup> COIL_UI = (gTRecipe, widgetGroup) -> {
        int n = gTRecipe.data.m_128451_("ebf_temp");
        ObjectArrayList objectArrayList = new ObjectArrayList();
        objectArrayList.add(GTCEuAPI.HEATING_COILS.entrySet().stream().filter(entry -> ((ICoilType)entry.getKey()).getCoilTemperature() >= n).map(entry -> new ItemStack((ItemLike)((Supplier)entry.getValue()).get())).toList());
        widgetGroup.addWidget(new SlotWidget(new CycleItemStackHandler(objectArrayList), 0, widgetGroup.getSize().width - 50, widgetGroup.getSize().height - 40, false, false));
    };

    private RecipeTypeRegisterUtils() {
    }

    public static RecipeType register(String string, String string2, String string3, String string4) {
        if (LANG != null) {
            LANG.put(string, new CNEN(string3, string2));
        }
        return RecipeTypeRegisterUtils.register(string, string4, new net.minecraft.world.item.crafting.RecipeType[0]);
    }

    public static RecipeType register(String string, String string2, String string3) {
        if (LANG != null) {
            LANG.put(string, new CNEN(string2, FormattingUtil.toEnglishName(string)));
        }
        return RecipeTypeRegisterUtils.register(string, string3, new net.minecraft.world.item.crafting.RecipeType[0]);
    }

    public static RecipeType register(String string, String string2, net.minecraft.world.item.crafting.RecipeType<?> ... recipeTypeArray) {
        RecipeType recipeType = new RecipeType(GTCEu.id(string), string2, recipeTypeArray);
        GTRegistries.RECIPE_TYPES.register(recipeType.registryName, recipeType);
        return recipeType;
    }
}

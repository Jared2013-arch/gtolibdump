package com.gtolib.utils;

import com.gtolib.utils.RLUtils;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;

public final class TagUtils {
    private TagUtils() {
    }

    public static TagKey<Item> createTag(ResourceLocation resourceLocation) {
        return TagKey.m_203882_(BuiltInRegistries.f_257033_.m_123023_(), resourceLocation);
    }

    public static TagKey<Item> createTag(String string) {
        return TagUtils.createTag(RLUtils.parse(string));
    }

    public static TagKey<Item> createForgeTag(String string) {
        return TagUtils.createTag(RLUtils.fromNamespaceAndPath("forge", string));
    }

    public static TagKey<Item> createTGTag(String string) {
        return TagUtils.createTag(RLUtils.fromNamespaceAndPath("gt", string));
    }
}

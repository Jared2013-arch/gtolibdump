package com.gtolib.utils;

import com.gregtechceu.gtceu.api.data.chemical.ChemicalHelper;
import com.gregtechceu.gtceu.api.data.chemical.material.Material;
import com.gregtechceu.gtceu.api.data.chemical.material.stack.MaterialEntry;
import com.gregtechceu.gtceu.api.item.MetaMachineItem;
import com.gregtechceu.gtceu.api.recipe.ingredient.FluidIngredient;
import com.gregtechceu.gtceu.common.data.GTMaterials;
import com.gregtechceu.gtceu.utils.FormattingUtil;
import com.gtolib.api.recipe.ingredient.FastSizedIngredient;
import com.gtolib.utils.FluidUtils;
import com.gtolib.utils.ItemUtils;
import com.gtolib.utils.StringIndex;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.fluids.FluidStack;

public final class StringConverter {
    private StringConverter() {
    }

    public static String fromItem(Ingredient ingredient, int n) {
        Object object;
        if (ingredient.m_43947_() || ingredient.m_43908_().length < 1) {
            return null;
        }
        ItemStack itemStack = ingredient.m_43908_()[0];
        int n2 = itemStack.m_41613_();
        Ingredient ingredient2 = ingredient;
        if (ingredient instanceof FastSizedIngredient) {
            object = (Ingredient.Value[])ingredient;
            n2 = ((FastSizedIngredient)object).getSaturatedAmount();
            ingredient2 = ((FastSizedIngredient)object).getInner();
        }
        object = ingredient2.f_43902_;
        int n3 = ((Ingredient.Value[])object).length;
        for (int i = 0; i < n3; ++i) {
            Object object2;
            Object object32;
            Ingredient.Value value = object[i];
            if (value instanceof Ingredient.ItemValue) {
                Ingredient.ItemValue itemValue = (Ingredient.ItemValue)((Object)value);
                for (Object object32 : itemValue.m_6223_()) {
                    object2 = ChemicalHelper.getMaterialEntry(((ItemStack)object32).m_41720_());
                    if (((MaterialEntry)object2).isEmpty()) continue;
                    Object object4 = StringIndex.MATERIAL_MAP.containsKey(((MaterialEntry)object2).material()) ? StringIndex.MATERIAL_MAP.get(((MaterialEntry)object2).material()) : "GTOMaterials." + FormattingUtil.lowerUnderscoreToUpperCamel(((MaterialEntry)object2).material().getName());
                    Object object5 = StringIndex.TAGPREFIX_MAP.containsKey(((MaterialEntry)object2).tagPrefix()) ? StringIndex.TAGPREFIX_MAP.get(((MaterialEntry)object2).tagPrefix()) : "GTOTagPrefix." + ((MaterialEntry)object2).tagPrefix().name().toUpperCase();
                    if (n == 2) {
                        return "new MaterialEntry(" + (String)object5 + ", " + (String)object4 + (String)(n2 > 1 ? ", " + n2 : "") + ")";
                    }
                    if (n == 1) {
                        return (String)object5 + ", " + (String)object4 + (String)(n2 > 1 ? ", " + n2 : "");
                    }
                    return "ChemicalHelper.get(" + (String)object5 + ", " + (String)object4 + (String)(n2 > 1 ? ", " + n2 : "") + ")";
                }
                continue;
            }
            if (!(value instanceof Ingredient.TagValue)) continue;
            Ingredient.TagValue tagValue = (Ingredient.TagValue)((Object)value);
            TagKey tagKey = tagValue.f_43959_;
            if (StringIndex.TAG_MAP.containsKey(tagKey)) {
                return StringIndex.TAG_MAP.get(tagKey) + (String)(n2 > 1 ? ", " + n2 : "");
            }
            object32 = tagKey.f_203868_();
            object2 = switch (((ResourceLocation)object32).m_135827_()) {
                case "gtocore" -> "GTOCore.id(\"" + ((ResourceLocation)object32).m_135815_() + "\")";
                case "gtceu" -> "GTCEu.id(\"" + ((ResourceLocation)object32).m_135815_() + "\")";
                case "forge" -> "new ResourceLocation(\"forge\", \"" + ((ResourceLocation)object32).m_135815_() + "\")";
                case "minecraft" -> "new ResourceLocation(\"minecraft\", \"" + ((ResourceLocation)object32).m_135815_() + "\")";
                default -> "";
            };
            return "TagUtil.createTag(" + (String)object2 + ")";
        }
        Item item = itemStack.m_41720_();
        if (item instanceof BlockItem && !ItemUtils.getIdLocation(((BlockItem)(object = (BlockItem)((Object)item))).m_40614_()).m_135827_().equals("minecraft")) {
            if (StringIndex.BLOCK_LINK_MAP.containsKey(((BlockItem)object).m_40614_())) {
                return StringIndex.BLOCK_LINK_MAP.get(((BlockItem)object).m_40614_()) + ".asStack(" + String.valueOf(n2 > 1 ? Integer.valueOf(n2) : "") + ")";
            }
            if (StringIndex.BLOCK_MAP.containsKey(((BlockItem)object).m_40614_())) {
                return "new ItemStack(" + StringIndex.BLOCK_MAP.get(((BlockItem)object).m_40614_()) + ".asItem()" + (String)(n2 > 1 ? ", " + n2 : "") + ")";
            }
            if (ItemUtils.getIdLocation(((BlockItem)object).m_40614_()).m_135827_().equals("gtocore")) {
                return (object instanceof MetaMachineItem ? "GTOMachines." : "GTOBlocks.") + ItemUtils.getIdLocation(((BlockItem)object).m_40614_()).m_135815_().toUpperCase() + ".asStack(" + String.valueOf(n2 > 1 ? Integer.valueOf(n2) : "") + ")";
            }
        } else {
            if (StringIndex.ITEM_LINK_MAP.containsKey(itemStack.m_41720_())) {
                return StringIndex.ITEM_LINK_MAP.get(itemStack.m_41720_()) + ".asStack(" + String.valueOf(n2 > 1 ? Integer.valueOf(n2) : "") + ")";
            }
            if (StringIndex.ITEM_MAP.containsKey(itemStack.m_41720_())) {
                return "new ItemStack(" + StringIndex.ITEM_MAP.get(itemStack.m_41720_()) + (String)(n2 > 1 ? ", " + n2 : "") + ")";
            }
            if (ItemUtils.getIdLocation(itemStack.m_41720_()).m_135827_().equals("gtocore")) {
                return "GTOItems." + ItemUtils.getIdLocation(itemStack.m_41720_()).m_135815_().toUpperCase() + (String)(n2 > 1 ? ".asStack(" + n2 + ")" : ".asItem()");
            }
            if (ItemUtils.getIdLocation(itemStack.m_41720_()).m_135827_().equals("minecraft")) {
                return "new ItemStack(Items." + ItemUtils.getIdLocation(itemStack.m_41720_()).m_135815_().toUpperCase() + ".asItem()" + (String)(n2 > 1 ? ", " + n2 : "") + ")";
            }
        }
        if (n == 1) {
            return "\"" + ItemUtils.getId(ingredient.m_43908_()[0]) + (String)(n2 > 1 ? "\", " + n2 : "\"");
        }
        return "RegistriesUtils.getItemStack(\"" + ItemUtils.getId(ingredient.m_43908_()[0]) + (String)(n2 > 1 ? "\", " + n2 : "\"") + ")";
    }

    public static String fromFluid(FluidIngredient fluidIngredient, boolean bl) {
        String string;
        if (fluidIngredient.isEmpty() || fluidIngredient.getStacks().length < 1) {
            return null;
        }
        FluidStack fluidStack = fluidIngredient.getStacks()[0];
        ResourceLocation resourceLocation = FluidUtils.getIdLocation(fluidStack.getFluid());
        boolean bl2 = false;
        boolean bl3 = false;
        boolean bl4 = false;
        Material material = GTMaterials.get(resourceLocation.toString());
        if (material.isNull() && resourceLocation.toString().contains("_plasma") && !(material = GTMaterials.get(resourceLocation.toString().replace("_plasma", ""))).isNull()) {
            bl2 = true;
        }
        if (material.isNull() && resourceLocation.toString().contains("liquid_") && !(material = GTMaterials.get(resourceLocation.toString().replace("liquid_", ""))).isNull()) {
            bl3 = true;
        }
        if (material.isNull() && resourceLocation.toString().contains("molten_") && !(material = GTMaterials.get(resourceLocation.toString().replace("molten_", ""))).isNull()) {
            bl4 = true;
        }
        if (!material.isNull()) {
            String string2 = "";
            if (bl2) {
                string2 = "FluidStorageKeys.PLASMA, ";
            }
            if (bl3) {
                string2 = "FluidStorageKeys.LIQUID, ";
            }
            if (bl4) {
                string2 = "FluidStorageKeys.MOLTEN, ";
            }
            Object object = StringIndex.MATERIAL_MAP.containsKey(material) ? StringIndex.MATERIAL_MAP.get(material) : "GTOMaterials." + FormattingUtil.lowerUnderscoreToUpperCamel(material.getName());
            string = bl && string2.isEmpty() ? (String)object + ", " + fluidStack.getAmount() : (String)object + ".getFluid(" + string2 + fluidStack.getAmount() + ")";
        } else {
            string = "RegistriesUtils.getFluidStack(\"" + String.valueOf(resourceLocation) + "\", " + fluidStack.getAmount() + ")";
        }
        return string;
    }
}

package com.gtolib.utils;

import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import it.unimi.dsi.fastutil.objects.ObjectSet;
import it.unimi.dsi.fastutil.objects.Reference2ObjectMap;
import java.util.Iterator;
import java.util.Map;

public final class MapUtils {
    private MapUtils() {
    }

    public static <K, V> Iterator<Map.Entry<K, V>> fastIterator(Map<K, V> map) {
        if (map instanceof Object2ObjectMap) {
            Object2ObjectMap object2ObjectMap = (Object2ObjectMap)((Object)map);
            ObjectSet objectSet = object2ObjectMap.object2ObjectEntrySet();
            if (objectSet instanceof Object2ObjectMap.FastEntrySet) {
                Object2ObjectMap.FastEntrySet fastEntrySet = (Object2ObjectMap.FastEntrySet)((Object)objectSet);
                return fastEntrySet.fastIterator();
            }
            return objectSet.iterator();
        }
        if (map instanceof Reference2ObjectMap) {
            Reference2ObjectMap reference2ObjectMap = (Reference2ObjectMap)((Object)map);
            ObjectSet objectSet = reference2ObjectMap.reference2ObjectEntrySet();
            if (objectSet instanceof Reference2ObjectMap.FastEntrySet) {
                Reference2ObjectMap.FastEntrySet fastEntrySet = (Reference2ObjectMap.FastEntrySet)((Object)objectSet);
                return fastEntrySet.fastIterator();
            }
            return objectSet.iterator();
        }
        return map.entrySet().iterator();
    }
}

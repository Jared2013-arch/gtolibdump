package com.gtolib.utils;

import com.gregtechceu.gtceu.api.capability.recipe.FluidRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.capability.recipe.IRecipeCapabilityHolder;
import com.gregtechceu.gtceu.api.capability.recipe.IRecipeHandler;
import com.gregtechceu.gtceu.api.capability.recipe.ItemRecipeCapability;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.feature.IComputationContainerMachine;
import com.gregtechceu.gtceu.api.machine.feature.IRecipeLogicMachine;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiController;
import com.gregtechceu.gtceu.api.machine.multiblock.MultiblockDisplayText;
import com.gregtechceu.gtceu.api.machine.multiblock.WorkableElectricMultiblockMachine;
import com.gregtechceu.gtceu.api.machine.multiblock.WorkableMultiblockMachine;
import com.gregtechceu.gtceu.api.machine.trait.CircuitHandler;
import com.gregtechceu.gtceu.api.machine.trait.RecipeLogic;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gregtechceu.gtceu.api.recipe.chance.boost.ChanceBoostFunction;
import com.gregtechceu.gtceu.api.recipe.content.Content;
import com.gregtechceu.gtceu.api.recipe.ingredient.FluidIngredient;
import com.gregtechceu.gtceu.common.data.GTItems;
import com.gregtechceu.gtceu.common.data.GTRecipeTypes;
import com.gregtechceu.gtceu.common.item.IntCircuitBehaviour;
import com.gregtechceu.gtceu.utils.FormattingUtil;
import com.gtocore.common.machine.multiblock.part.ParallelHatchPartMachine;
import com.gtolib.api.annotation.DataGeneratorScanned;
import com.gtolib.api.annotation.language.RegisterLanguage;
import com.gtolib.api.machine.feature.multiblock.IExtendedRecipeCapabilityHolder;
import com.gtolib.api.machine.feature.multiblock.IParallelMachine;
import com.gtolib.api.machine.multiblock.CrossRecipeMultiblockMachine;
import com.gtolib.api.machine.trait.IEnhancedRecipeLogic;
import com.gtolib.api.recipe.ContentBuilder;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.RecipeHelper;
import com.gtolib.api.recipe.RecipeRunner;
import com.gtolib.api.recipe.SeparateContent;
import com.gtolib.api.recipe.ingredient.FastFluidIngredient;
import com.gtolib.api.recipe.ingredient.FastSizedIngredient;
import com.gtolib.utils.FluidUtils;
import com.gtolib.utils.ItemUtils;
import com.gtolib.utils.MathUtil;
import com.gtolib.utils.NumberUtils;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import it.unimi.dsi.fastutil.objects.Object2LongOpenCustomHashMap;
import it.unimi.dsi.fastutil.objects.Object2LongOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Predicate;
import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.fluids.FluidStack;
import org.jetbrains.annotations.NotNull;

@ParametersAreNonnullByDefault
@DataGeneratorScanned
public final class MachineUtils {
    @RegisterLanguage(cn="成型的模块数: %s", en="Formed modules: %s")
    private static final String MODULES_AMOUNT = "gtocore.machine.modules_amount";

    private MachineUtils() {
    }

    public static boolean isUD(Direction direction) {
        return direction == Direction.UP || direction == Direction.DOWN;
    }

    public static BlockPos getOffsetPos(int n, int n2, int n3, Direction direction, BlockPos blockPos) {
        int n4 = 0;
        int n5 = 0;
        switch (direction) {
            case NORTH: {
                n5 = n;
                n4 = n3;
                break;
            }
            case SOUTH: {
                n5 = -n;
                n4 = -n3;
                break;
            }
            case WEST: {
                n4 = n;
                n5 = n3;
                break;
            }
            case EAST: {
                n4 = -n;
                n5 = -n3;
            }
        }
        return blockPos.m_7918_(n4, n2, n5);
    }

    public static BlockPos getOffsetPos(int n, int n2, Direction direction, BlockPos blockPos) {
        int n3 = 0;
        int n4 = 0;
        switch (direction) {
            case NORTH: {
                n4 = n;
                break;
            }
            case SOUTH: {
                n4 = -n;
                break;
            }
            case WEST: {
                n3 = n;
                break;
            }
            case EAST: {
                n3 = -n;
            }
        }
        return blockPos.m_7918_(n3, n2, n4);
    }

    public static BlockPos getOffsetPos(int n, Direction direction, BlockPos blockPos) {
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        switch (direction) {
            case UP: {
                n3 = -n;
                break;
            }
            case DOWN: {
                n3 = n;
                break;
            }
            case NORTH: {
                n4 = n;
                break;
            }
            case SOUTH: {
                n4 = -n;
                break;
            }
            case WEST: {
                n2 = n;
                break;
            }
            case EAST: {
                n2 = -n;
            }
        }
        return blockPos.m_7918_(n2, n3, n4);
    }

    public static void addMachineText(List<Component> list3, WorkableMultiblockMachine workableMultiblockMachine, Consumer<List<Component>> consumer) {
        Object object;
        Object object2;
        if (workableMultiblockMachine.isRemote()) {
            return;
        }
        MultiblockDisplayText.Builder builder = MultiblockDisplayText.builder(list3, workableMultiblockMachine.isFormed()).setWorkingStatus(workableMultiblockMachine.recipeLogic.isWorkingEnabled(), workableMultiblockMachine.recipeLogic.isActive());
        if (!workableMultiblockMachine.isFormed()) {
            return;
        }
        int n = 0;
        long l = workableMultiblockMachine instanceof IParallelMachine && (object2 = (IParallelMachine)((Object)workableMultiblockMachine)).getParallelLong() > 0L ? object2.getParallelLong() : MachineUtils.getHatchParallelLong(workableMultiblockMachine);
        if (workableMultiblockMachine instanceof WorkableElectricMultiblockMachine) {
            object2 = (WorkableElectricMultiblockMachine)workableMultiblockMachine;
            builder.addEnergyUsageLine(((WorkableElectricMultiblockMachine)object2).getEnergyContainer()).addEnergyTierLine(((WorkableElectricMultiblockMachine)object2).getTier());
            if (object2 instanceof CrossRecipeMultiblockMachine) {
                object = (CrossRecipeMultiblockMachine)object2;
                n = ((CrossRecipeMultiblockMachine)object).getThread();
            }
        }
        if (workableMultiblockMachine instanceof IComputationContainerMachine) {
            object2 = (IComputationContainerMachine)((Object)workableMultiblockMachine);
            builder.addComputationUsageLine(object2.getMaxCWU());
        }
        builder.addMachineModeLine(workableMultiblockMachine.getRecipeType(), workableMultiblockMachine.getRecipeTypes().length > 1);
        int n2 = workableMultiblockMachine.getSubFormedAmount();
        if (n2 > 0) {
            builder.addCustom(list2 -> list3.add(Component.m_237110_(MODULES_AMOUNT, new Object[]{n2}).m_130940_(ChatFormatting.GRAY)));
        }
        if (n > 1) {
            object = Component.m_237113_(String.valueOf(n)).m_130940_(ChatFormatting.DARK_AQUA);
            MutableComponent mutableComponent = Component.m_237113_(FormattingUtil.formatNumbers(l)).m_130940_(ChatFormatting.DARK_PURPLE);
            builder.addCustom(arg_0 -> MachineUtils.lambda$addMachineText$1((Component)object, arg_0));
            builder.addCustom(list -> list.add(Component.m_237110_("gtocore.machine.thread.1", new Object[]{mutableComponent}).m_130940_(ChatFormatting.GRAY)));
        } else if (l > 1L) {
            builder.addCustom(list2 -> list3.add(Component.m_237110_("gtceu.multiblock.parallel", new Object[]{Component.m_237113_(FormattingUtil.formatNumbers(l)).m_130940_(ChatFormatting.DARK_PURPLE)}).m_130940_(ChatFormatting.GRAY)));
        }
        builder.addBatchModeLine(workableMultiblockMachine.isBatchEnabled(), ((GTRecipe)Objects.requireNonNullElse((Object)workableMultiblockMachine.recipeLogic.getLastRecipe(), (Object)Recipe.EMPTY)).batchParallels);
        builder.addCustom(consumer);
        builder.addCustom(list -> workableMultiblockMachine.getDefinition().getAdditionalDisplay().accept(workableMultiblockMachine, list));
        builder.addCustom(list2 -> {
            IEnhancedRecipeLogic iEnhancedRecipeLogic;
            RecipeLogic recipeLogic;
            if (workableMultiblockMachine.getRecipeLogic().isIdle() && (recipeLogic = workableMultiblockMachine.getRecipeLogic()) instanceof IEnhancedRecipeLogic && (iEnhancedRecipeLogic = (IEnhancedRecipeLogic)((Object)recipeLogic)).gtolib$getIdleReason() != null) {
                list3.add(iEnhancedRecipeLogic.gtolib$getIdleReason().m_6881_().m_130940_(ChatFormatting.GRAY));
            }
        });
        builder.addWorkingStatusLine();
        builder.addProgressLine(workableMultiblockMachine.recipeLogic.getProgress(), workableMultiblockMachine.recipeLogic.getMaxProgress(), workableMultiblockMachine.recipeLogic.getProgressPercent());
        builder.addCustom(list2 -> {
            GTRecipe gTRecipe;
            if (workableMultiblockMachine.isFormed() && workableMultiblockMachine.isActive() && (gTRecipe = workableMultiblockMachine.recipeLogic.getLastRecipe()) != null) {
                List list3 = gTRecipe.getInputContents(ItemRecipeCapability.CAP);
                List list4 = gTRecipe.getInputContents(FluidRecipeCapability.CAP);
                if (!list3.isEmpty() || !list4.isEmpty()) {
                    list3.add(Component.m_237115_("gtceu.io.import").m_130946_(":"));
                    MachineUtils.addContentText(list3, gTRecipe, list3, list4);
                }
                List list5 = gTRecipe.getOutputContents(ItemRecipeCapability.CAP);
                List list6 = gTRecipe.getOutputContents(FluidRecipeCapability.CAP);
                if (!list5.isEmpty() || !list6.isEmpty()) {
                    list3.add(Component.m_237115_("gtceu.io.export").m_130946_(":"));
                    MachineUtils.addContentText(list3, gTRecipe, list5, list6);
                }
            }
        });
    }

    private static void addContentText(@NotNull List<Component> list, @NotNull GTRecipe gTRecipe, List<Content> list2, List<Content> list3) {
        FluidStack[] fluidStackArray;
        Object object;
        int n = RecipeHelper.getPreOCRecipeEuTier(gTRecipe);
        int n2 = n + gTRecipe.ocLevel;
        ChanceBoostFunction chanceBoostFunction = ChanceBoostFunction.OVERCLOCK;
        double d = (double)gTRecipe.duration / 20.0;
        for (Content content : list2) {
            String string;
            object = (Ingredient)ItemRecipeCapability.CAP.of(content.content);
            fluidStackArray = ItemUtils.getFirstSized((Ingredient)object);
            if (fluidStackArray.m_41619_()) continue;
            long l = ItemUtils.getSizedAmount((Ingredient)object);
            double d2 = l;
            if (content.chance < ContentBuilder.maxChance) {
                long l2 = l = (d2 = d2 * (double)SeparateContent.getParallel(content, RecipeHelper.getParallel(gTRecipe)) * (double)chanceBoostFunction.getBoostedChance(content, n, n2) / (double)ContentBuilder.maxChance) < 1.0 ? 1L : Math.round(d2);
            }
            if ((double)l < d) {
                string = "gtceu.multiblock.output_line." + (content.chance < ContentBuilder.maxChance ? "2" : "0");
                list.add(Component.m_237110_(string, new Object[]{fluidStackArray.m_41786_(), NumberUtils.formatLong(l), NumberUtils.formatLong((long)(d / d2))}));
                continue;
            }
            string = "gtceu.multiblock.output_line." + (content.chance < ContentBuilder.maxChance ? "3" : "1");
            list.add(Component.m_237110_(string, new Object[]{fluidStackArray.m_41786_(), NumberUtils.formatLong(l), NumberUtils.formatLong((long)(d2 / d))}));
        }
        for (Content content : list3) {
            String string;
            object = (FluidIngredient)FluidRecipeCapability.CAP.of(content.content);
            fluidStackArray = FastFluidIngredient.getFluidStack(object);
            if (fluidStackArray.length == 0) continue;
            FluidStack fluidStack = fluidStackArray[0];
            long l = FastFluidIngredient.getAmount((FluidIngredient)object);
            double d3 = l;
            if (content.chance < ContentBuilder.maxChance) {
                long l3 = l = (d3 = d3 * (double)SeparateContent.getParallel(content, RecipeHelper.getParallel(gTRecipe)) * (double)chanceBoostFunction.getBoostedChance(content, n, n2) / (double)ContentBuilder.maxChance) < 1.0 ? 1L : Math.round(d3);
            }
            if ((double)l < d) {
                string = "gtceu.multiblock.output_line." + (content.chance < ContentBuilder.maxChance ? "2" : "0");
                list.add(Component.m_237110_(string, new Object[]{fluidStack.getDisplayName(), FluidUtils.getUnicodeMillibuckets(l), FluidUtils.getUnicodeMillibuckets((long)(d / d3))}));
                continue;
            }
            string = "gtceu.multiblock.output_line." + (content.chance < ContentBuilder.maxChance ? "3" : "1");
            list.add(Component.m_237110_(string, new Object[]{fluidStack.getDisplayName(), FluidUtils.getUnicodeMillibuckets(l), FluidUtils.getUnicodeMillibuckets((long)(d3 / d))}));
        }
    }

    public static void addRecipeTypeText(List<Component> list, IRecipeLogicMachine iRecipeLogicMachine) {
        GTRecipeType gTRecipeType = iRecipeLogicMachine.getRecipeType();
        if (gTRecipeType == GTRecipeTypes.DUMMY_RECIPES) {
            return;
        }
        list.add(Component.m_237110_("gtceu.gui.machinemode", new Object[]{Component.m_237115_(gTRecipeType.registryName.m_214298_())}).m_130940_(ChatFormatting.AQUA));
    }

    public static int getHatchParallel(MetaMachine metaMachine) {
        return MathUtil.saturatedCast(MachineUtils.getHatchParallelLong(metaMachine));
    }

    public static long getHatchParallelLong(MetaMachine metaMachine) {
        Optional optional;
        IMultiController iMultiController;
        if (metaMachine instanceof IMultiController && (iMultiController = (IMultiController)((Object)metaMachine)).isFormed() && (optional = iMultiController.getParallelHatch()).isPresent()) {
            return Math.max(1L, ((ParallelHatchPartMachine)optional.get()).getCurrentParallelLong());
        }
        return 1L;
    }

    public static int checkingCircuit(IRecipeCapabilityHolder iRecipeCapabilityHolder, boolean bl) {
        int n = 0;
        List<IRecipeHandler<?>> list = IExtendedRecipeCapabilityHolder.getInputFlat(iRecipeCapabilityHolder, ItemRecipeCapability.CAP);
        for (int i = list.size() - 1; i >= 0; --i) {
            Object object = list.get(i);
            if (!(object instanceof CircuitHandler)) continue;
            CircuitHandler circuitHandler = (CircuitHandler)object;
            object = circuitHandler.storage.stacks[0];
            if (!((ItemStack)object).m_150930_((Item)GTItems.PROGRAMMED_CIRCUIT.get())) continue;
            n += IntCircuitBehaviour.getCircuitConfiguration((ItemStack)object);
            if (!bl) break;
        }
        return n;
    }

    public static long[] getFluidAmount(IRecipeCapabilityHolder iRecipeCapabilityHolder, Fluid ... fluidArray) {
        long[] lArray = new long[fluidArray.length];
        for (IRecipeHandler<?> iRecipeHandler : IExtendedRecipeCapabilityHolder.getInputFlat(iRecipeCapabilityHolder, FluidRecipeCapability.CAP)) {
            Object2LongOpenHashMap object2LongOpenHashMap;
            if (iRecipeHandler.isNotConsumable() || (object2LongOpenHashMap = iRecipeHandler.getFluidMap()) == null) continue;
            ObjectIterator objectIterator = object2LongOpenHashMap.object2LongEntrySet().fastIterator();
            block1: while (objectIterator.hasNext()) {
                Object2LongMap.Entry entry = (Object2LongMap.Entry)objectIterator.next();
                Fluid fluid = ((FluidStack)entry.getKey()).getFluid();
                for (int i = 0; i < fluidArray.length; ++i) {
                    if (fluidArray[i] != fluid) continue;
                    lArray[i] = entry.getLongValue() + lArray[i];
                    continue block1;
                }
            }
        }
        return lArray;
    }

    public static long[] getItemAmount(IRecipeCapabilityHolder iRecipeCapabilityHolder, Item ... itemArray) {
        long[] lArray = new long[itemArray.length];
        for (IRecipeHandler<?> iRecipeHandler : IExtendedRecipeCapabilityHolder.getInputFlat(iRecipeCapabilityHolder, ItemRecipeCapability.CAP)) {
            Object2LongOpenCustomHashMap object2LongOpenCustomHashMap;
            if (iRecipeHandler.isNotConsumable() || (object2LongOpenCustomHashMap = iRecipeHandler.getItemMap()) == null) continue;
            ObjectIterator objectIterator = object2LongOpenCustomHashMap.object2LongEntrySet().fastIterator();
            block1: while (objectIterator.hasNext()) {
                Object2LongMap.Entry entry = (Object2LongMap.Entry)objectIterator.next();
                Item item = ((ItemStack)entry.getKey()).m_41720_();
                for (int i = 0; i < itemArray.length; ++i) {
                    if (itemArray[i] != item) continue;
                    lArray[i] = entry.getLongValue() + lArray[i];
                    continue block1;
                }
            }
        }
        return lArray;
    }

    public static void forEachInputItems(IRecipeCapabilityHolder iRecipeCapabilityHolder, Predicate<ItemStack> predicate) {
        for (IRecipeHandler<?> iRecipeHandler : IExtendedRecipeCapabilityHolder.getInputFlat(iRecipeCapabilityHolder, ItemRecipeCapability.CAP)) {
            for (Object object : iRecipeHandler.getContents()) {
                ItemStack itemStack;
                if (!(object instanceof ItemStack) || (itemStack = (ItemStack)object).m_41619_() || !predicate.test(itemStack)) continue;
                return;
            }
        }
    }

    public static void forEachInputFluids(IRecipeCapabilityHolder iRecipeCapabilityHolder, Predicate<FluidStack> predicate) {
        for (IRecipeHandler<?> iRecipeHandler : IExtendedRecipeCapabilityHolder.getInputFlat(iRecipeCapabilityHolder, FluidRecipeCapability.CAP)) {
            for (Object object : iRecipeHandler.getContents()) {
                FluidStack fluidStack;
                if (!(object instanceof FluidStack) || (fluidStack = (FluidStack)object).isEmpty() || !predicate.test(fluidStack)) continue;
                return;
            }
        }
    }

    private static List<Ingredient> toIngredient(ItemStack ... itemStackArray) {
        ObjectArrayList objectArrayList = new ObjectArrayList(itemStackArray.length);
        for (ItemStack itemStack : itemStackArray) {
            if (itemStack.m_41619_()) continue;
            objectArrayList.add(FastSizedIngredient.create(itemStack));
        }
        return objectArrayList;
    }

    private static List<FastFluidIngredient> toFluidIngredient(FluidStack ... fluidStackArray) {
        ObjectArrayList objectArrayList = new ObjectArrayList(fluidStackArray.length);
        for (FluidStack fluidStack : fluidStackArray) {
            if (fluidStack.isEmpty()) continue;
            objectArrayList.add(FastFluidIngredient.of(fluidStack));
        }
        return objectArrayList;
    }

    public static boolean inputItem(IRecipeCapabilityHolder iRecipeCapabilityHolder, ItemStack ... itemStackArray) {
        List<Ingredient> list = MachineUtils.toIngredient(itemStackArray);
        ObjectArrayList objectArrayList = new ObjectArrayList(list.size());
        for (Ingredient ingredient : list) {
            objectArrayList.add(ItemRecipeCapability.CAP.copyContent(ingredient));
        }
        return RecipeRunner.handleContent(iRecipeCapabilityHolder, IO.IN, objectArrayList, ItemRecipeCapability.CAP, true, false) && RecipeRunner.handleContent(iRecipeCapabilityHolder, IO.IN, list, ItemRecipeCapability.CAP, false, false);
    }

    public static boolean outputItem(IRecipeCapabilityHolder iRecipeCapabilityHolder, ItemStack ... itemStackArray) {
        return RecipeRunner.handleContent(iRecipeCapabilityHolder, IO.OUT, MachineUtils.toIngredient(itemStackArray), ItemRecipeCapability.CAP, false, false);
    }

    public static boolean notConsumableItem(IRecipeCapabilityHolder iRecipeCapabilityHolder, ItemStack ... itemStackArray) {
        return RecipeRunner.handleContent(iRecipeCapabilityHolder, IO.IN, MachineUtils.toIngredient(itemStackArray), ItemRecipeCapability.CAP, true, true);
    }

    public static boolean notConsumableCircuit(IRecipeCapabilityHolder iRecipeCapabilityHolder, int n) {
        List<IRecipeHandler<?>> list = IExtendedRecipeCapabilityHolder.getInputFlat(iRecipeCapabilityHolder, ItemRecipeCapability.CAP);
        for (int i = list.size() - 1; i >= 0; --i) {
            Object object = list.get(i);
            if (!(object instanceof CircuitHandler)) continue;
            CircuitHandler circuitHandler = (CircuitHandler)object;
            object = circuitHandler.storage.stacks[0];
            if (!((ItemStack)object).m_150930_((Item)GTItems.PROGRAMMED_CIRCUIT.get()) || n != IntCircuitBehaviour.getCircuitConfiguration((ItemStack)object)) continue;
            return true;
        }
        return false;
    }

    public static boolean inputFluid(IRecipeCapabilityHolder iRecipeCapabilityHolder, Fluid fluid, long l) {
        ObjectArrayList objectArrayList = new ObjectArrayList(1);
        objectArrayList.add(FastFluidIngredient.of(l, fluid));
        ObjectArrayList objectArrayList2 = new ObjectArrayList(1);
        for (Object e : objectArrayList) {
            objectArrayList2.add(FluidRecipeCapability.CAP.copyContent(e));
        }
        return RecipeRunner.handleContent(iRecipeCapabilityHolder, IO.IN, objectArrayList2, FluidRecipeCapability.CAP, true, false) && RecipeRunner.handleContent(iRecipeCapabilityHolder, IO.IN, objectArrayList, FluidRecipeCapability.CAP, false, false);
    }

    public static boolean inputFluid(IRecipeCapabilityHolder iRecipeCapabilityHolder, FluidStack ... fluidStackArray) {
        List<FastFluidIngredient> list = MachineUtils.toFluidIngredient(fluidStackArray);
        ObjectArrayList objectArrayList = new ObjectArrayList(list.size());
        for (FastFluidIngredient fastFluidIngredient : list) {
            objectArrayList.add(FluidRecipeCapability.CAP.copyContent(fastFluidIngredient));
        }
        return RecipeRunner.handleContent(iRecipeCapabilityHolder, IO.IN, objectArrayList, FluidRecipeCapability.CAP, true, false) && RecipeRunner.handleContent(iRecipeCapabilityHolder, IO.IN, list, FluidRecipeCapability.CAP, false, false);
    }

    public static boolean outputFluid(IRecipeCapabilityHolder iRecipeCapabilityHolder, Fluid fluid, long l) {
        ObjectArrayList objectArrayList = new ObjectArrayList(1);
        objectArrayList.add(FastFluidIngredient.of(l, fluid));
        return RecipeRunner.handleContent(iRecipeCapabilityHolder, IO.OUT, objectArrayList, FluidRecipeCapability.CAP, false, false);
    }

    public static boolean outputFluid(IRecipeCapabilityHolder iRecipeCapabilityHolder, FluidStack ... fluidStackArray) {
        return RecipeRunner.handleContent(iRecipeCapabilityHolder, IO.OUT, MachineUtils.toFluidIngredient(fluidStackArray), FluidRecipeCapability.CAP, false, false);
    }

    public static boolean notConsumableFluid(IRecipeCapabilityHolder iRecipeCapabilityHolder, FluidStack ... fluidStackArray) {
        return RecipeRunner.handleContent(iRecipeCapabilityHolder, IO.IN, MachineUtils.toFluidIngredient(fluidStackArray), FluidRecipeCapability.CAP, true, true);
    }

    private static void lambda$addMachineText$1(Component component, List list) {
        list.add(Component.m_237110_("gtocore.machine.thread.0", new Object[]{component}).m_130940_(ChatFormatting.GRAY));
    }
}

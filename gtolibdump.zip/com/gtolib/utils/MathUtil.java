package com.gtolib.utils;

public final class MathUtil {
    private static final int INITIAL_TABLE_SIZE = 4096;
    private static float[] trigTable;
    private static float radToIndex;

    private MathUtil() {
    }

    private static void initialize() {
        trigTable = new float[4096];
        radToIndex = 651.8986f;
        for (int i = 0; i < 4096; ++i) {
            MathUtil.trigTable[i] = MathUtil.toFloat(Math.sin((double)i * 2.0 * Math.PI / 4096.0));
        }
    }

    public static long saturatedCast(double d) {
        if (d > 9.223372036854776E18) {
            return Long.MAX_VALUE;
        }
        return (long)d;
    }

    public static int saturatedCast(long l) {
        if (l > Integer.MAX_VALUE) {
            return Integer.MAX_VALUE;
        }
        return (int)l;
    }

    public static float sin(float f) {
        if (trigTable == null) {
            MathUtil.initialize();
        }
        return trigTable[(int)(f * radToIndex) & trigTable.length - 1];
    }

    public static float cos(float f) {
        int n;
        if (trigTable == null) {
            MathUtil.initialize();
        }
        if ((n = (int)(((double)(f * radToIndex) + (double)trigTable.length / 4.0) % (double)trigTable.length)) < 0) {
            n += trigTable.length;
        }
        return trigTable[n];
    }

    private static float toFloat(double d) {
        return (float)((double)Math.round(d * 1.0E8) / 1.0E8);
    }
}

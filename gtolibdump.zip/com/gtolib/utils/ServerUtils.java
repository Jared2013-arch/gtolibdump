package com.gtolib.utils;

import com.gtolib.api.data.GTODimensions;
import com.gtolib.b.b;
import earth.terrarium.adastra.common.utils.ModUtils;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.server.ServerLifecycleHooks;
import org.jetbrains.annotations.NotNull;

public final class ServerUtils {
    public static final String IDENTIFIER_KEY = "server_id";

    private ServerUtils() {
    }

    @NotNull
    public static MinecraftServer getServer() {
        return ServerLifecycleHooks.getCurrentServer();
    }

    @NotNull
    public static CompoundTag getPersistentData() {
        return b.a();
    }

    public static UUID getServerIdentifier() {
        CompoundTag compoundTag = ServerUtils.getPersistentData();
        if (!compoundTag.m_128441_(IDENTIFIER_KEY)) {
            compoundTag.m_128362_(IDENTIFIER_KEY, UUID.randomUUID());
            b.a.m_77762_();
        }
        return compoundTag.m_128342_(IDENTIFIER_KEY);
    }

    public static void runCommandSilent(MinecraftServer minecraftServer, String string) {
        minecraftServer.m_129892_().m_230957_(minecraftServer.m_129893_().m_81324_(), string);
    }

    public static void teleportToDimension(ServerLevel serverLevel, Entity entity, Vec3 vec3) {
        entity.m_20219_(vec3);
        ModUtils.teleportToDimension(entity, serverLevel);
    }

    public static void teleportToDimension(MinecraftServer minecraftServer, Entity entity, ResourceLocation resourceLocation, Vec3 vec3) {
        ServerLevel serverLevel = minecraftServer.m_129880_(GTODimensions.getDimensionKey(resourceLocation));
        if (serverLevel == null) {
            return;
        }
        ServerUtils.teleportToDimension(serverLevel, entity, vec3);
    }
}

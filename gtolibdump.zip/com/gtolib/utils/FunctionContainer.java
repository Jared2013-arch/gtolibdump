package com.gtolib.utils;

import java.util.function.BiFunction;

public class FunctionContainer<T, U> {
    private T value;
    private final BiFunction<T, U, T> function;

    public FunctionContainer(T t, BiFunction<T, U, T> biFunction) {
        this.value = t;
        this.function = biFunction;
    }

    public void apply(U u) {
        this.value = this.function.apply(this.value, u);
    }

    public T getValue() {
        return this.value;
    }
}

package com.gtolib.utils;

public final class ColorUtils {
    private ColorUtils() {
    }

    public static int getInterpolatedColor(int n, int n2, float f) {
        int n3 = n >> 16 & 0xFF;
        int n4 = n >> 8 & 0xFF;
        int n5 = n & 0xFF;
        int n6 = n2 >> 16 & 0xFF;
        int n7 = n2 >> 8 & 0xFF;
        int n8 = n2 & 0xFF;
        int n9 = (int)((float)n3 + f * (float)(n6 - n3));
        int n10 = (int)((float)n4 + f * (float)(n7 - n4));
        int n11 = (int)((float)n5 + f * (float)(n8 - n5));
        return n9 << 16 | n10 << 8 | n11;
    }

    public static int createARGBColor(int n, int n2) {
        int n3 = n >> 16 & 0xFF;
        int n4 = n >> 8 & 0xFF;
        int n5 = n & 0xFF;
        return n2 << 24 | n3 << 16 | n4 << 8 | n5;
    }

    public static int[] generateStepGradient(int n, int n2, int n3, int n4) {
        if (n4 < 2) {
            throw new IllegalArgumentException("阶梯数必须至少为2");
        }
        int[] nArray = new int[n4];
        nArray[0] = n | n3 << 24;
        nArray[n4 - 1] = n2 | n3 << 24;
        int n5 = n >> 16 & 0xFF;
        int n6 = n >> 8 & 0xFF;
        int n7 = n & 0xFF;
        int n8 = n2 >> 16 & 0xFF;
        int n9 = n2 >> 8 & 0xFF;
        int n10 = n2 & 0xFF;
        for (int i = 1; i < n4 - 1; ++i) {
            float f = (float)i / (float)(n4 - 1);
            int n11 = ColorUtils.calculateGradientComponent(n5, n8, f);
            int n12 = ColorUtils.calculateGradientComponent(n6, n9, f);
            int n13 = ColorUtils.calculateGradientComponent(n7, n10, f);
            nArray[i] = n3 << 24 | n11 << 16 | n12 << 8 | n13;
        }
        return nArray;
    }

    private static int calculateGradientComponent(int n, int n2, float f) {
        return Math.round((float)n + (float)(n2 - n) * f);
    }
}

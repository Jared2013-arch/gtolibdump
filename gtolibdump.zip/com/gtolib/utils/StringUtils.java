package com.gtolib.utils;

import java.util.regex.Pattern;
import net.minecraft.ChatFormatting;

public final class StringUtils {
    private static final String[] CHINESE_NUMBERS = new String[]{"零", "一", "二", "三", "四", "五", "六", "七", "八", "九"};

    private StringUtils() {
    }

    public static String numberToChinese(int n) {
        if (n < 0 || n > 9) {
            throw new IllegalArgumentException("Number must be between 0 and 9");
        }
        return CHINESE_NUMBERS[n];
    }

    public static String[] decompose(String string) {
        return StringUtils.decompose(':', string);
    }

    private static String[] decompose(char c, String string) {
        String[] stringArray = new String[]{string, ""};
        int n = string.indexOf(c);
        if (n >= 0) {
            stringArray[1] = string.substring(n + 1);
            if (n >= 1) {
                stringArray[0] = string.substring(0, n);
            }
        }
        return stringArray;
    }

    public static String[] lastDecompose(char c, String string) {
        String[] stringArray = new String[]{string, ""};
        int n = string.lastIndexOf(c);
        if (n >= 0) {
            stringArray[1] = string.substring(n + 1);
            stringArray[0] = string.substring(0, n);
        }
        return stringArray;
    }

    public static boolean containsWithWildcard(String[] stringArray, String string) {
        for (String string2 : stringArray) {
            if (!Pattern.matches(string2, string)) continue;
            return true;
        }
        return false;
    }

    public static String full_color(String string) {
        return StringUtils.formatting(string, new ChatFormatting[]{ChatFormatting.RED, ChatFormatting.GOLD, ChatFormatting.YELLOW, ChatFormatting.GREEN, ChatFormatting.AQUA, ChatFormatting.BLUE, ChatFormatting.LIGHT_PURPLE}, 80.0);
    }

    public static String dark_purplish_red(String string) {
        return StringUtils.formatting(string, new ChatFormatting[]{ChatFormatting.DARK_PURPLE, ChatFormatting.DARK_RED}, 160.0);
    }

    public static String white_blue(String string) {
        return StringUtils.formatting(string, new ChatFormatting[]{ChatFormatting.BLUE, ChatFormatting.BLUE, ChatFormatting.BLUE, ChatFormatting.BLUE, ChatFormatting.WHITE, ChatFormatting.BLUE, ChatFormatting.WHITE, ChatFormatting.WHITE, ChatFormatting.BLUE, ChatFormatting.WHITE, ChatFormatting.WHITE, ChatFormatting.BLUE, ChatFormatting.RED, ChatFormatting.WHITE}, 80.0);
    }

    public static String purplish_red(String string) {
        return StringUtils.formatting(string, new ChatFormatting[]{ChatFormatting.LIGHT_PURPLE, ChatFormatting.DARK_PURPLE}, 160.0);
    }

    public static String golden(String string) {
        return StringUtils.formatting(string, new ChatFormatting[]{ChatFormatting.YELLOW, ChatFormatting.GOLD}, 160.0);
    }

    public static String dark_green(String string) {
        return StringUtils.formatting(string, new ChatFormatting[]{ChatFormatting.GREEN, ChatFormatting.DARK_GREEN}, 160.0);
    }

    private static String formatting(String string, ChatFormatting[] chatFormattingArray, double d) {
        StringBuilder stringBuilder = new StringBuilder(string.length() * 3);
        if (d <= 0.0) {
            d = 0.001;
        }
        int n = (int)Math.floor((double)(System.currentTimeMillis() & 0x3FFFL) / d) % chatFormattingArray.length;
        for (int i = 0; i < string.length(); ++i) {
            char c = string.charAt(i);
            stringBuilder.append(chatFormattingArray[(chatFormattingArray.length + i - n) % chatFormattingArray.length].toString());
            stringBuilder.append(c);
        }
        return stringBuilder.toString();
    }
}

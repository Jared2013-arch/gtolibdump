package com.gtolib.utils;

import com.gregtechceu.gtceu.api.GTValues;
import com.gregtechceu.gtceu.api.data.chemical.material.Material;
import com.gregtechceu.gtceu.api.data.tag.TagPrefix;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gregtechceu.gtceu.common.data.GTRecipeTypes;
import com.gregtechceu.gtceu.utils.GTUtil;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gregtechceu.gtceu.utils.collection.OpenCacheHashSet;
import com.gtocore.common.data.GTORecipeTypes;
import com.gtolib.GTOCore;
import com.gtolib.api.data.GTODimensions;
import com.gtolib.d;
import com.gtolib.utils.FluidUtils;
import committee.nova.mods.avaritia.api.utils.ItemUtils;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.fluids.FluidStack;

public final class GTOUtils {
    private static final Consumer<?> NOOP_CONSUMER = object -> {};

    public static <T> Consumer<T> noopConsumer() {
        return NOOP_CONSUMER;
    }

    private GTOUtils() {
    }

    public static int getGeneratorAmperage(int n) {
        if (n > 0 && n < 4) {
            return 2;
        }
        return 1;
    }

    public static int getGeneratorEfficiency(GTRecipeType gTRecipeType, int n) {
        int n2 = 105 - 5 * n;
        if (gTRecipeType == GTRecipeTypes.STEAM_TURBINE_FUELS) {
            n2 = 135 - 35 * n;
        }
        if (gTRecipeType == GTORecipeTypes.NAQUADAH_REACTOR) {
            n2 = 100 + 50 * (n - 5);
        }
        if (gTRecipeType == GTORecipeTypes.THERMAL_GENERATOR_FUELS) {
            n2 = 100 - 25 * n;
        }
        return n2 + 30 - 15 * GTOCore.difficulty;
    }

    public static boolean isGeneration(TagPrefix tagPrefix, Material material) {
        Predicate predicate = tagPrefix.generationCondition();
        if (predicate == null) {
            return true;
        }
        return predicate.test(material);
    }

    public static boolean probability(double d) {
        return GTValues.RNG.m_188500_() < d;
    }

    public static boolean safe(ServerPlayer serverPlayer) {
        Vec3 vec3 = serverPlayer.m_20182_();
        List list = serverPlayer.m_9236_().m_6443_(Monster.class, new AABB(vec3.m_7096_() - 8.0, vec3.m_7098_() - 5.0, vec3.m_7094_() - 8.0, vec3.m_7096_() + 8.0, vec3.m_7098_() + 5.0, vec3.m_7094_() + 8.0), monster -> true);
        if (!list.isEmpty()) {
            serverPlayer.m_5661_(Component.m_237115_("gtocore.not_safe"), true);
            return false;
        }
        return true;
    }

    public static int adjacentBlock(Function<Direction, Block> function, Block block) {
        int n = 0;
        for (Direction direction : GTUtil.DIRECTIONS) {
            if (function.apply(direction) != block) continue;
            ++n;
        }
        return n;
    }

    public static double calculateDistance(BlockPos blockPos, BlockPos blockPos2) {
        int n = blockPos2.m_123341_() - blockPos.m_123341_();
        int n2 = blockPos2.m_123342_() - blockPos.m_123342_();
        int n3 = blockPos2.m_123343_() - blockPos.m_123343_();
        return Math.sqrt(n * n + n2 * n2 + n3 * n3);
    }

    public static int getVoltageMultiplier(Material material) {
        int n = material.getBlastTemperature();
        if (n > 8460) {
            return GTValues.VA[3];
        }
        if (n > 2700) {
            return GTValues.VA[2];
        }
        if (n > 0) {
            return GTValues.VA[1];
        }
        return GTValues.VA[0];
    }

    public static double getSunIntensity(long l) {
        if ((l %= 24000L) >= 1200L && l < 6000L) {
            double d = (double)(l - 1200L) / 4800.0;
            return Math.pow(d, 2.0) * 100.0;
        }
        if (l >= 6000L && l < 12000L) {
            double d = (double)(12000L - l) / 6000.0;
            return Math.pow(d, 2.0) * 100.0;
        }
        return 0.0;
    }

    public static boolean canSeeSunClearly(Level level, BlockPos blockPos) {
        if (!level.m_45527_(blockPos.m_7494_())) {
            return false;
        }
        if (GTODimensions.isVoid(level.m_46472_().m_135782_())) {
            return true;
        }
        Biome biome = (Biome)level.m_204166_(blockPos.m_7494_()).m_203334_();
        if (level.m_46471_() && (biome.m_198906_(blockPos.m_7494_()) || biome.m_198904_(blockPos.m_7494_()))) {
            return false;
        }
        if (level.m_204166_(blockPos.m_7494_()).m_203656_(BiomeTags.f_215818_)) {
            return false;
        }
        return level.m_46461_();
    }

    public static String[] shapeToPattern(List<String[]> list) {
        ObjectArrayList objectArrayList = new ObjectArrayList();
        for (String[] stringArray : list) {
            objectArrayList.addAll(Arrays.asList(stringArray));
        }
        return objectArrayList.toArray((T[])new String[0]);
    }

    public static Map<String, Ingredient> symbolMapTokeys(Map<Character, Ingredient> map) {
        O2OOpenCacheHashMap o2OOpenCacheHashMap = new O2OOpenCacheHashMap();
        map.forEach((c, ingredient) -> o2OOpenCacheHashMap.put(c.toString(), ingredient));
        o2OOpenCacheHashMap.put(" ", Ingredient.f_43901_);
        return o2OOpenCacheHashMap;
    }

    public static Map<String, Ingredient> reconstructKeys(NonNullList<Ingredient> nonNullList) {
        O2OOpenCacheHashMap o2OOpenCacheHashMap = new O2OOpenCacheHashMap();
        OpenCacheHashSet openCacheHashSet = new OpenCacheHashSet();
        char c = 'A';
        for (Ingredient ingredient : nonNullList) {
            if (ingredient == Ingredient.f_43901_ || openCacheHashSet.contains(ingredient)) continue;
            char c2 = c;
            c = (char)(c + 1);
            String string = String.valueOf(c2);
            o2OOpenCacheHashMap.put(string, ingredient);
            openCacheHashSet.add(ingredient);
        }
        return o2OOpenCacheHashMap;
    }

    public static String[] reconstructPattern(NonNullList<Ingredient> nonNullList, Map<String, Ingredient> map, int n, int n2) {
        String[] stringArray = new String[n2];
        for (int i = 0; i < n2; ++i) {
            StringBuilder stringBuilder = new StringBuilder();
            block1: for (int j = 0; j < n; ++j) {
                Ingredient ingredient = (Ingredient)nonNullList.get(j + n * i);
                if (ingredient == Ingredient.f_43901_) {
                    stringBuilder.append(" ");
                    continue;
                }
                for (Map.Entry<String, Ingredient> entry : map.entrySet()) {
                    if (!entry.getValue().equals(ingredient)) continue;
                    stringBuilder.append(entry.getKey());
                    continue block1;
                }
            }
            stringArray[i] = stringBuilder.toString();
        }
        return stringArray;
    }

    public static GlobalPos readGlobalPos(String string, long l) {
        if (string.isEmpty()) {
            return null;
        }
        if (l == 0L) {
            return null;
        }
        ResourceLocation resourceLocation = ResourceLocation.m_135820_(string);
        if (resourceLocation == null) {
            return null;
        }
        return GlobalPos.m_122643_(GTODimensions.getDimensionKey(resourceLocation), BlockPos.m_122022_(l));
    }

    public static ItemStack loadItemStack(CompoundTag compoundTag) {
        Item item = ItemUtils.getItem(compoundTag.m_128461_("id"));
        ItemStack itemStack = item.m_7968_();
        if (compoundTag.m_128425_("tag", 10)) {
            itemStack.m_41751_(compoundTag.m_128469_("tag"));
            if (itemStack.m_41783_() != null) {
                itemStack.m_41720_().m_142312_(itemStack.m_41783_());
            }
        }
        if (itemStack.m_41720_().m_41465_()) {
            itemStack.m_41721_(itemStack.m_41773_());
        }
        return itemStack;
    }

    public static FluidStack loadFluidStack(CompoundTag compoundTag) {
        Fluid fluid = FluidUtils.getFluid(compoundTag.m_128461_("FluidName"));
        FluidStack fluidStack = new FluidStack(fluid, 1);
        if (compoundTag.m_128425_("Tag", 10)) {
            fluidStack.setTag(compoundTag.m_128469_("Tag"));
        }
        return fluidStack;
    }

    public static void fastRemoveBlock(Level level, BlockPos blockPos, boolean bl, boolean bl2) {
        d.a(level, blockPos, bl, bl2);
    }
}

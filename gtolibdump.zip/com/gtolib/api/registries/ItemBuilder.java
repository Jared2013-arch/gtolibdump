package com.gtolib.api.registries;

import com.gregtechceu.gtceu.GTCEu;
import com.gtolib.IItem;
import com.tterrag.registrate.AbstractRegistrate;
import com.tterrag.registrate.builders.BuilderCallback;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.ProviderType;
import com.tterrag.registrate.providers.RegistrateItemModelProvider;
import com.tterrag.registrate.util.nullness.NonNullBiConsumer;
import com.tterrag.registrate.util.nullness.NonNullFunction;
import java.lang.invoke.LambdaMetafactory;
import java.util.function.Supplier;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import org.jetbrains.annotations.NotNull;

public final class ItemBuilder<T extends Item, P>
extends com.tterrag.registrate.builders.ItemBuilder<T, P> {
    private ItemBuilder(AbstractRegistrate<?> abstractRegistrate, P p, String string, BuilderCallback builderCallback, NonNullFunction<Item.Properties, T> nonNullFunction) {
        super(abstractRegistrate, p, string, builderCallback, nonNullFunction);
    }

    public static <T extends Item, P> ItemBuilder<T, P> c(AbstractRegistrate<?> abstractRegistrate, P p, String string, BuilderCallback builderCallback, NonNullFunction<Item.Properties, T> nonNullFunction) {
        return ((ItemBuilder)new ItemBuilder<T, P>(abstractRegistrate, p, string, builderCallback, nonNullFunction).defaultModel()).defaultLang();
    }

    public ItemBuilder<T, P> toolTips(Component ... componentArray) {
        if (!GTCEu.isClientSide()) {
            return this;
        }
        Supplier[] supplierArray = new Supplier[componentArray.length];
        for (int i = 0; i < componentArray.length; ++i) {
            Component component = componentArray[i];
            supplierArray[i] = () -> component;
        }
        return (ItemBuilder)((Object)this.onRegister(item -> ((IItem)((Object)item)).gtolib$setToolTips(supplierArray)));
    }

    public ItemBuilder<T, P> toolTips(Component component) {
        if (!GTCEu.isClientSide()) {
            return this;
        }
        return (ItemBuilder)((Object)this.onRegister(item -> ((IItem)((Object)item)).gtolib$setToolTips(() -> component)));
    }

    public ItemBuilder<T, P> toolTips(Supplier<Component> supplier) {
        if (!GTCEu.isClientSide()) {
            return this;
        }
        return (ItemBuilder)((Object)this.onRegister(item -> ((IItem)((Object)item)).gtolib$setToolTips(supplier)));
    }

    public ItemBuilder<T, P> toolTips(Supplier ... supplierArray) {
        if (!GTCEu.isClientSide()) {
            return this;
        }
        return (ItemBuilder)((Object)this.onRegister(item -> ((IItem)((Object)item)).gtolib$setToolTips(supplierArray)));
    }

    @NotNull
    public ItemBuilder<T, P> defaultLang() {
        return (ItemBuilder)((Object)this.lang((net.minecraftforge.common.util.NonNullFunction)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, m_5524_(), (Lnet/minecraft/world/item/Item;)Ljava/lang/String;)()));
    }

    @NotNull
    public ItemBuilder<T, P> defaultModel() {
        return this.model((dataGenContext, registrateItemModelProvider) -> registrateItemModelProvider.generated(dataGenContext::getEntry));
    }

    @NotNull
    public ItemBuilder<T, P> model(@NotNull NonNullBiConsumer<DataGenContext<Item, T>, RegistrateItemModelProvider> nonNullBiConsumer) {
        return (ItemBuilder)((Object)this.setData(ProviderType.ITEM_MODEL, nonNullBiConsumer));
    }
}

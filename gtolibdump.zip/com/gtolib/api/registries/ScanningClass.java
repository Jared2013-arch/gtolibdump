package com.gtolib.api.registries;

import com.google.common.collect.ImmutableMap;
import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtolib.GTOCore;
import com.gtolib.api.annotation.DataGeneratorScanned;
import com.gtolib.api.annotation.Scanned;
import com.gtolib.api.annotation.dynamic.DynamicInitialData;
import com.gtolib.api.annotation.dynamic.DynamicInitialValue;
import com.gtolib.api.annotation.language.RegisterEnumLang;
import com.gtolib.api.annotation.language.RegisterLanguage;
import com.gtolib.api.lang.CNEN;
import java.lang.annotation.Annotation;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.forgespi.language.ModFileScanData;
import org.objectweb.asm.Type;

public final class ScanningClass {
    public static final Map<String, CNEN> LANG = GTCEu.isDataGen() ? new O2OOpenCacheHashMap() : null;
    public static ImmutableMap<Class<?>, DynamicInitialData> VALUES;
    public static final ImmutableMap<Class<?>, DynamicInitialData> OBJECT_VALUES;

    public static void init() {
    }

    /*
     * WARNING - void declaration
     */
    static {
        long l = System.currentTimeMillis();
        ImmutableMap.Builder<Class<?>, DynamicInitialData> builder = ImmutableMap.builder();
        ImmutableMap.Builder<Class<?>, DynamicInitialData> builder2 = ImmutableMap.builder();
        Type type = Type.getType(Scanned.class);
        Type type2 = LANG == null ? null : Type.getType(DataGeneratorScanned.class);
        for (ModFileScanData modFileScanData : ModList.get().getAllScanData()) {
            Set set = modFileScanData.getAnnotations();
            for (ModFileScanData.AnnotationData annotationData : set) {
                Type type3 = annotationData.annotationType();
                if (!Objects.equals(type3, type) && (type2 == null || !Objects.equals(type3, type2))) continue;
                try {
                    ?[] objArray;
                    Object object;
                    Class<?> clazz = Class.forName(annotationData.memberName());
                    DynamicInitialData dynamicInitialData = null;
                    DynamicInitialData dynamicInitialData2 = null;
                    Object object2 = clazz.getDeclaredFields();
                    int n = ((Field[])object2).length;
                    for (int i = 0; i < n; ++i) {
                        object = object2[i];
                        if (((AccessibleObject)object).isAnnotationPresent(DynamicInitialValue.class)) {
                            if (dynamicInitialData == null) {
                                dynamicInitialData = new DynamicInitialData();
                            }
                            if ((objArray = dynamicInitialData.add((Field)object)) == null) continue;
                            if (dynamicInitialData2 == null) {
                                dynamicInitialData2 = new DynamicInitialData();
                            }
                            dynamicInitialData2.add(objArray);
                            continue;
                        }
                        if (LANG == null || !((AccessibleObject)object).isAnnotationPresent(RegisterLanguage.class)) continue;
                        objArray = ((Field)object).getAnnotation(RegisterLanguage.class);
                        try {
                            void var20_27;
                            assert (objArray != null);
                            String illegalAccessException = objArray.key();
                            if (illegalAccessException.isEmpty()) {
                                String string = objArray.namePrefix();
                                if (!string.isEmpty()) {
                                    String string2 = string + "." + ((Field)object).getName();
                                } else {
                                    ((AccessibleObject)object).setAccessible(true);
                                    String string3 = (String)((Field)object).get(null);
                                    String string4 = objArray.valuePrefix();
                                    if (!string4.isEmpty()) {
                                        String string5 = string4 + "." + string3;
                                    }
                                }
                            }
                            LANG.put((String)var20_27, new CNEN(objArray.cn(), objArray.en()));
                            continue;
                        }
                        catch (IllegalAccessException illegalAccessException) {
                            throw new RuntimeException(illegalAccessException);
                        }
                    }
                    if (dynamicInitialData != null) {
                        builder.put(clazz, dynamicInitialData);
                        if (dynamicInitialData2 != null) {
                            builder2.put(clazz, dynamicInitialData2);
                        }
                    }
                    if (LANG == null || !clazz.isEnum() || (object2 = clazz.getAnnotation(RegisterEnumLang.class)) == null) continue;
                    O2OOpenCacheHashMap o2OOpenCacheHashMap = new O2OOpenCacheHashMap();
                    O2OOpenCacheHashMap o2OOpenCacheHashMap2 = new O2OOpenCacheHashMap();
                    object = object2.keyPrefix();
                    for (Object obj : objArray = clazz.getEnumConstants()) {
                        String string = ((Enum)obj).name();
                        for (Field field : clazz.getDeclaredFields()) {
                            String string6;
                            String string7;
                            Annotation annotation;
                            if (field.isAnnotationPresent(RegisterEnumLang.EnValue.class)) {
                                annotation = field.getAnnotation(RegisterEnumLang.EnValue.class);
                                field.setAccessible(true);
                                if (annotation == null) continue;
                                try {
                                    string7 = (String)object + "." + annotation.value() + "." + string;
                                    string6 = (String)field.get(obj);
                                    if (o2OOpenCacheHashMap2.containsKey(string7)) {
                                        LANG.put(string7, new CNEN((String)o2OOpenCacheHashMap2.get(string7), string6));
                                        o2OOpenCacheHashMap2.remove(string7);
                                        continue;
                                    }
                                    o2OOpenCacheHashMap.put(string7, string6);
                                    continue;
                                }
                                catch (IllegalAccessException illegalAccessException) {
                                    throw new RuntimeException(illegalAccessException);
                                }
                            }
                            if (!field.isAnnotationPresent(RegisterEnumLang.CnValue.class)) continue;
                            annotation = field.getAnnotation(RegisterEnumLang.CnValue.class);
                            field.setAccessible(true);
                            if (annotation == null) continue;
                            try {
                                string7 = (String)object + "." + annotation.value() + "." + string;
                                string6 = (String)field.get(obj);
                                if (o2OOpenCacheHashMap.containsKey(string7)) {
                                    LANG.put(string7, new CNEN(string6, (String)o2OOpenCacheHashMap.get(string7)));
                                    o2OOpenCacheHashMap.remove(string7);
                                    continue;
                                }
                                o2OOpenCacheHashMap2.put(string7, string6);
                            }
                            catch (IllegalAccessException illegalAccessException) {
                                throw new RuntimeException(illegalAccessException);
                            }
                        }
                    }
                }
                catch (ClassNotFoundException classNotFoundException) {
                }
            }
        }
        VALUES = builder.build();
        OBJECT_VALUES = builder2.build();
        GTOCore.LOGGER.info("ScanningClass init time: {}ms", (Object)(System.currentTimeMillis() - l));
    }
}

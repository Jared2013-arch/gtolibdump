package com.gtolib.api.registries;

import com.gregtechceu.gtceu.GTCEu;
import com.gtolib.IItem;
import com.tterrag.registrate.AbstractRegistrate;
import com.tterrag.registrate.builders.BuilderCallback;
import com.tterrag.registrate.providers.loot.RegistrateBlockLootTables;
import com.tterrag.registrate.util.nullness.NonNullFunction;
import com.tterrag.registrate.util.nullness.NonNullSupplier;
import java.lang.invoke.LambdaMetafactory;
import java.util.function.Supplier;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import org.jetbrains.annotations.NotNull;

public final class BlockBuilder<T extends Block, P>
extends com.tterrag.registrate.builders.BlockBuilder<T, P> {
    private BlockBuilder(AbstractRegistrate<?> abstractRegistrate, P p, String string, BuilderCallback builderCallback, NonNullFunction<BlockBehaviour.Properties, T> nonNullFunction, NonNullSupplier<BlockBehaviour.Properties> nonNullSupplier) {
        super(abstractRegistrate, p, string, builderCallback, nonNullFunction, nonNullSupplier);
    }

    @NotNull
    public static <T extends Block, P> BlockBuilder<T, P> c(@NotNull AbstractRegistrate<?> abstractRegistrate, @NotNull P p, @NotNull String string, @NotNull BuilderCallback builderCallback, @NotNull NonNullFunction<BlockBehaviour.Properties, T> nonNullFunction) {
        return ((BlockBuilder)((BlockBuilder)new BlockBuilder<T, P>(abstractRegistrate, p, string, builderCallback, nonNullFunction, (NonNullSupplier<BlockBehaviour.Properties>)(NonNullSupplier)LambdaMetafactory.metafactory(null, null, null, ()Ljava/lang/Object;, m_284310_(), ()Lnet/minecraft/world/level/block/state/BlockBehaviour$Properties;)()).defaultBlockstate()).defaultLoot()).defaultLang();
    }

    public BlockBuilder<T, P> toolTips(Component ... componentArray) {
        if (!GTCEu.isClientSide()) {
            return this;
        }
        Supplier[] supplierArray = new Supplier[componentArray.length];
        for (int i = 0; i < componentArray.length; ++i) {
            Component component = componentArray[i];
            supplierArray[i] = () -> component;
        }
        return (BlockBuilder)((Object)this.onRegister(block -> ((IItem)((Object)block.m_5456_())).gtolib$setToolTips(supplierArray)));
    }

    public BlockBuilder<T, P> toolTips(Component component) {
        if (!GTCEu.isClientSide()) {
            return this;
        }
        return (BlockBuilder)((Object)this.onRegister(block -> ((IItem)((Object)block.m_5456_())).gtolib$setToolTips(() -> component)));
    }

    public BlockBuilder<T, P> toolTips(Supplier<Component> supplier) {
        if (!GTCEu.isClientSide()) {
            return this;
        }
        return (BlockBuilder)((Object)this.onRegister(block -> ((IItem)((Object)block.m_5456_())).gtolib$setToolTips(supplier)));
    }

    public BlockBuilder<T, P> toolTips(Supplier ... supplierArray) {
        if (!GTCEu.isClientSide()) {
            return this;
        }
        return (BlockBuilder)((Object)this.onRegister(block -> ((IItem)((Object)block.m_5456_())).gtolib$setToolTips(supplierArray)));
    }

    @NotNull
    public BlockBuilder<T, P> defaultBlockstate() {
        return (BlockBuilder)this.blockstate((dataGenContext, registrateBlockstateProvider) -> registrateBlockstateProvider.simpleBlock((Block)dataGenContext.getEntry()));
    }

    @NotNull
    public BlockBuilder<T, P> defaultLoot() {
        return (BlockBuilder)this.loot(RegistrateBlockLootTables::m_245724_);
    }

    @NotNull
    public BlockBuilder<T, P> defaultLang() {
        return (BlockBuilder)((Object)this.lang(Block::m_7705_));
    }
}

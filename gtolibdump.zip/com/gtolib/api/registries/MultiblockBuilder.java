package com.gtolib.api.registries;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.block.IMachineBlock;
import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.data.RotationState;
import com.gregtechceu.gtceu.api.item.MetaMachineItem;
import com.gregtechceu.gtceu.api.machine.MultiblockMachineDefinition;
import com.gregtechceu.gtceu.api.machine.multiblock.MultiblockControllerMachine;
import com.gregtechceu.gtceu.api.pattern.BlockPattern;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gregtechceu.gtceu.api.registry.registrate.MultiblockMachineBuilder;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtocore.common.data.translation.MultiblockSlang;
import com.gtocore.common.machine.multiblock.steam.LargeSteamMultiblockMachine;
import com.gtolib.api.annotation.NewDataAttributes;
import com.gtolib.api.annotation.component_builder.ComponentBuilder;
import com.gtolib.api.annotation.dynamic.DynamicInitialData;
import com.gtolib.api.lang.CNEN;
import com.gtolib.api.lang.TooltipsSortedWrapper;
import com.gtolib.api.recipe.CombinedRecipeType;
import com.gtolib.api.recipe.modifier.RecipeModifierFunction;
import com.tterrag.registrate.Registrate;
import it.unimi.dsi.fastutil.objects.ReferenceLinkedOpenHashSet;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.ChatFormatting;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import org.apache.commons.lang3.function.TriFunction;
import org.jetbrains.annotations.NotNull;

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
public final class MultiblockBuilder
extends MultiblockMachineBuilder {
    public static final Map<String, CNEN> LANG = GTCEu.isDataGen() ? new O2OOpenCacheHashMap() : null;
    private Class<?> clazz;
    private int tooltipsIndex;
    private final Set<GTRecipeType> recipes = new ReferenceLinkedOpenHashSet();
    private final TooltipsSortedWrapper tooltipsWrapper = new TooltipsSortedWrapper();

    MultiblockBuilder(Registrate registrate, String string, Function<MetaMachineBlockEntity, ? extends MultiblockControllerMachine> function, BiFunction<BlockBehaviour.Properties, MultiblockMachineDefinition, IMachineBlock> biFunction, BiFunction<IMachineBlock, Item.Properties, MetaMachineItem> biFunction2, TriFunction<BlockEntityType<?>, BlockPos, BlockState, MetaMachineBlockEntity> triFunction) {
        super(registrate, string, function, biFunction, biFunction2, triFunction);
    }

    @Override
    public MultiblockBuilder langValue(@Nullable String string) {
        return (MultiblockBuilder)super.langValue(string);
    }

    @Override
    public MultiblockBuilder tier(int n) {
        return (MultiblockBuilder)super.tier(n);
    }

    @Override
    public MultiblockBuilder noRecipeModifier() {
        return (MultiblockBuilder)super.noRecipeModifier();
    }

    @Override
    public MultiblockBuilder recipeTypes(GTRecipeType ... gTRecipeTypeArray) {
        for (GTRecipeType gTRecipeType : gTRecipeTypeArray) {
            this.addRecipeType(gTRecipeType);
        }
        return (MultiblockBuilder)super.recipeTypes(gTRecipeTypeArray);
    }

    @Override
    public MultiblockBuilder recipeType(GTRecipeType gTRecipeType) {
        this.addRecipeType(gTRecipeType);
        return (MultiblockBuilder)super.recipeType(gTRecipeType);
    }

    private void addRecipeType(GTRecipeType gTRecipeType) {
        if (gTRecipeType instanceof CombinedRecipeType) {
            CombinedRecipeType combinedRecipeType = (CombinedRecipeType)gTRecipeType;
            this.recipes.addAll(Arrays.asList(combinedRecipeType.getTypes()));
        } else if (!Objects.equals(gTRecipeType.group, "dummy")) {
            this.recipes.add(gTRecipeType);
        }
    }

    public MultiblockBuilder recipeModifier(RecipeModifierFunction recipeModifierFunction) {
        return (MultiblockBuilder)super.recipeModifier(recipeModifierFunction);
    }

    public MultiblockBuilder recipeModifiers(RecipeModifierFunction ... recipeModifierFunctionArray) {
        if (recipeModifierFunctionArray.length == 1) {
            return this.recipeModifier(recipeModifierFunctionArray[0]);
        }
        return (MultiblockBuilder)super.recipeModifiers(recipeModifierFunctionArray);
    }

    public MultiblockBuilder generator() {
        return (MultiblockBuilder)this.generator(true);
    }

    public MultiblockBuilder existingTooltips(String string, int n, Object ... objectArray) {
        return this.tooltipsKey("gtocore.machine." + string + ".tooltip." + n, objectArray);
    }

    public MultiblockBuilder tooltipsKey(String string, Object ... objectArray) {
        return this.tooltips(Component.m_237110_(string, objectArray));
    }

    public MultiblockBuilder tooltipsComponent(Component component) {
        return this.tooltips(component);
    }

    private MultiblockBuilder tooltipsText(CNEN cNEN, Object ... objectArray) {
        String string = "gtocore.machine." + this.name + ".tooltip." + this.tooltipsIndex;
        if (LANG != null) {
            LANG.put(string, cNEN);
        }
        this.tooltipsKey(string, objectArray);
        ++this.tooltipsIndex;
        return this;
    }

    public MultiblockBuilder tooltipsText(String string, String string2, Object ... objectArray) {
        return this.tooltipsText(new CNEN(string, string2), objectArray);
    }

    @Override
    public MultiblockBuilder tooltips(Component ... componentArray) {
        for (Component component : componentArray) {
            this.tooltipsWrapper.addTooltip(ComponentBuilder.create().addLines(new Component[]{component}, styleBuilder -> styleBuilder).build());
        }
        return this;
    }

    public MultiblockBuilder tooltips(Supplier<List<Component>> supplier) {
        return this.tooltipsToTooltipsBuilder(supplier);
    }

    public MultiblockBuilder tooltipsSupplier(Supplier<List<Component>> supplier) {
        this.tooltipsWrapper.addSupplier(supplier);
        return this;
    }

    @NotNull
    private MultiblockBuilder tooltipsToTooltipsBuilder(Supplier<List<Component>> supplier) {
        this.tooltipsWrapper.addTooltip(supplier);
        return this;
    }

    public MultiblockBuilder addTooltipsFromClass(Class<?> clazz) {
        return this.addTooltipsFromClass(clazz, (DynamicInitialData.Value value) -> true);
    }

    private MultiblockBuilder addTooltipsFromClass(Class<?> clazz, Predicate<DynamicInitialData.Value> predicate) {
        this.clazz = clazz;
        return DynamicInitialData.addTooltipsText(this, clazz, predicate);
    }

    public MultiblockBuilder addTooltipsFromClass(Class<?> clazz, String ... stringArray) {
        return this.addTooltipsFromClass(clazz, (DynamicInitialData.Value value) -> Arrays.stream(stringArray).anyMatch(string -> value.field().getName().toLowerCase().contains(string.toLowerCase())));
    }

    @Override
    public MultiblockMachineDefinition register() {
        this.tooltipBuilder((itemStack, list) -> this.tooltipsWrapper.getTooltips().forEach(supplier -> list.addAll((Collection)supplier.get())));
        this.tooltipsWrapper.setInitialized(true);
        return super.register();
    }

    @Override
    public MultiblockBuilder workableTieredHullRenderer(ResourceLocation resourceLocation) {
        return (MultiblockBuilder)super.workableTieredHullRenderer(resourceLocation);
    }

    public MultiblockBuilder pattern(Function<MultiblockMachineDefinition, BlockPattern> function) {
        return (MultiblockBuilder)super.pattern(function);
    }

    public MultiblockBuilder addSubPattern(@NotNull Function<MultiblockMachineDefinition, BlockPattern> function) {
        return (MultiblockBuilder)super.addSubPattern(function);
    }

    @Override
    public MultiblockBuilder workableCasingRenderer(ResourceLocation resourceLocation, ResourceLocation resourceLocation2) {
        return (MultiblockBuilder)super.workableCasingRenderer(resourceLocation, resourceLocation2);
    }

    @Override
    public MultiblockBuilder workableCasingRenderer(ResourceLocation resourceLocation, ResourceLocation resourceLocation2, boolean bl) {
        return (MultiblockBuilder)super.workableCasingRenderer(resourceLocation, resourceLocation2, bl);
    }

    public MultiblockBuilder block(Supplier<? extends Block> supplier) {
        this.addRecipeTypeTooltips();
        return (MultiblockBuilder)this.appearanceBlock(supplier);
    }

    public MultiblockBuilder addRecipeTypeTooltips() {
        if (!this.recipes.isEmpty()) {
            MutableComponent mutableComponent = null;
            for (GTRecipeType gTRecipeType : this.recipes) {
                MutableComponent mutableComponent2 = Component.m_237115_(gTRecipeType.registryName.m_135827_() + "." + gTRecipeType.registryName.m_135815_());
                if (mutableComponent == null) {
                    mutableComponent = mutableComponent2;
                    continue;
                }
                mutableComponent.m_130946_(", ").m_7220_(mutableComponent2);
            }
            mutableComponent.m_130940_(ChatFormatting.WHITE);
            this.tooltips(NewDataAttributes.RECIPES_TYPE.create(mutableComponent).get().toArray(new Component[0]));
        }
        return this;
    }

    public MultiblockBuilder nonYAxisRotation() {
        return (MultiblockBuilder)this.rotationState(RotationState.NON_Y_AXIS).allowExtendedFacing(false);
    }

    public MultiblockBuilder allRotation() {
        return (MultiblockBuilder)this.rotationState(RotationState.ALL);
    }

    public MultiblockBuilder noneRotation() {
        return (MultiblockBuilder)this.rotationState(RotationState.NONE).allowExtendedFacing(false).allowFlip(false);
    }

    public MultiblockBuilder fromSourceTooltips(String string) {
        return this.tooltipsKey("gtocore.source", string);
    }

    public MultiblockBuilder moduleTooltips() {
        this.tooltipsToTooltipsBuilder(NewDataAttributes.ALLOW_MODULE.create());
        return this;
    }

    public MultiblockBuilder combinedRecipeTooltips() {
        this.tooltipsToTooltipsBuilder(NewDataAttributes.COMBINED_RECIPE.create());
        return this;
    }

    public MultiblockBuilder perfectOCTooltips() {
        this.tooltipsToTooltipsBuilder(NewDataAttributes.PREFECT_OVERCLOCK.create());
        return this;
    }

    public MultiblockBuilder laserTooltips() {
        this.tooltipsToTooltipsBuilder(NewDataAttributes.LASER_ENERGY_HATCH.create());
        return this;
    }

    public MultiblockBuilder onlyLaserTooltips() {
        this.tooltipsToTooltipsBuilder(MultiblockSlang.INSTANCE.getNot_allow_standard_energy_hatch().getSupplier());
        return this;
    }

    public MultiblockBuilder multipleRecipesTooltips() {
        this.tooltipsToTooltipsBuilder(NewDataAttributes.ALLOW_MULTI_RECIPE_PARALLEL.create());
        return this;
    }

    public MultiblockBuilder eutMultiplierTooltips(double d) {
        this.tooltipsToTooltipsBuilder(NewDataAttributes.ENERGY_COST_MULTIPLY.create(d));
        return this;
    }

    public MultiblockBuilder durationMultiplierTooltips(double d) {
        this.tooltipsToTooltipsBuilder(NewDataAttributes.TIME_COST_MULTIPLY.create(d));
        return this;
    }

    public MultiblockBuilder coilParallelTooltips() {
        this.specialParallelizableTooltips();
        this.tooltipsToTooltipsBuilder(NewDataAttributes.ALLOW_PARALLEL_NUMBER.create(componentBuilder -> componentBuilder.addLines("线圈温度每高出900K，并行数x2", "For every 900K increase in coil temperature, the parallel number doubles"), componentBuilder -> componentBuilder.addCommentLines("公式 : 2^(向下取整(温度 / 900)), 算去吧", "Formula: 2^(Round down(temperature / 900)), do the math")));
        return this;
    }

    public MultiblockBuilder parallelizableTooltips() {
        return this.tooltipsToTooltipsBuilder(NewDataAttributes.ALLOW_PARALLEL.create());
    }

    public MultiblockBuilder specialParallelizableTooltips() {
        return this.tooltipsToTooltipsBuilder(NewDataAttributes.ALLOW_PARALLEL_SPECIAL.create());
    }

    public MultiblockBuilder overclock() {
        return this.recipeModifier(RecipeModifierFunction.OVERCLOCKING);
    }

    public MultiblockBuilder perfectOverclock() {
        return this.recipeModifier(RecipeModifierFunction.PERFECT_OVERCLOCKING);
    }

    public MultiblockBuilder parallelizableOverclock() {
        return this.recipeModifier(RecipeModifierFunction.PARALLELIZABLE_OVERCLOCK);
    }

    public MultiblockBuilder parallelizablePerfectOverclock() {
        return this.recipeModifier(RecipeModifierFunction.PARALLELIZABLE_PERFECT_OVERCLOCK);
    }

    public MultiblockBuilder parallelizableManaOverclock() {
        return this.recipeModifier(RecipeModifierFunction.PARALLELIZABLE_MANA_OVERCLOCK);
    }

    public MultiblockBuilder steamOverclock() {
        return this.steamOverclock("LV");
    }

    public MultiblockBuilder steamOverclock(String string) {
        this.tooltipsKey("gtocore.machine.steam.tooltip.1", string);
        if (this.clazz == LargeSteamMultiblockMachine.class) {
            this.tooltipsKey("gtocore.machine.steam.tooltip.2", new Object[0]);
        }
        this.specialParallelizableTooltips();
        return this;
    }
}

package com.gtolib.api.misc;

import com.gregtechceu.gtceu.api.capability.GTCapabilityHelper;
import com.gregtechceu.gtceu.api.item.capability.ElectricItem;
import com.gtocore.common.item.DroneBehavior;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

public final class Drone {
    private String workState;
    private int work;
    private final int range;
    private final ElectricItem electricItem;
    private final ItemStack itemStack;
    public int times;

    private Drone(int n, ElectricItem electricItem, ItemStack itemStack) {
        this.range = n;
        this.electricItem = electricItem;
        this.itemStack = itemStack;
    }

    @Nullable
    public static Drone create(ItemStack itemStack) {
        DroneBehavior droneBehavior = DroneBehavior.getDroneBehavior(itemStack);
        if (droneBehavior != null) {
            Drone drone = new Drone(droneBehavior.getRange(), (ElectricItem)((Object)GTCapabilityHelper.getElectricItem(itemStack)), itemStack);
            drone.work = itemStack.m_41784_().m_128451_("work");
            drone.workState = itemStack.m_41784_().m_128461_("workState");
            return drone;
        }
        return null;
    }

    public boolean isWork() {
        return this.work > 0;
    }

    public void work() {
        if (this.isWork()) {
            --this.work;
            this.itemStack.m_41784_().m_128405_("work", this.work);
        } else if (!this.workState.isEmpty()) {
            this.workState = "";
            this.itemStack.m_41784_().m_128359_("workState", "");
        }
    }

    public boolean start(int n, int n2, String string) {
        if ((long)(n2 *= 1 << this.electricItem.getTier()) > this.electricItem.getCharge()) {
            return false;
        }
        this.electricItem.setCharge(this.electricItem.getCharge() - (long)n2);
        this.work = n / (this.electricItem.getTier() - 2);
        this.workState = string;
        this.itemStack.m_41784_().m_128359_("workState", this.workState);
        this.itemStack.m_41784_().m_128405_("work", this.work);
        ++this.times;
        return true;
    }

    public String getWorkState() {
        return this.workState;
    }

    public int getRange() {
        return this.range;
    }
}

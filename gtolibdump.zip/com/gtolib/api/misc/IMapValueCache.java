package com.gtolib.api.misc;

import appeng.api.stacks.AEItemKey;
import com.gtolib.a.a;
import com.gtolib.a.b;
import it.unimi.dsi.fastutil.Hash;
import java.util.function.Function;
import net.minecraft.world.item.ItemStack;

public interface IMapValueCache<K, V> {
    public static final Hash.Strategy STRATEGY = new Hash.Strategy(){

        @Override
        public int hashCode(Object object) {
            return object == null ? 0 : object.hashCode();
        }

        @Override
        public boolean equals(Object object, Object object2) {
            return object == object2 || object != null && object.equals(object2);
        }
    };
    public static final IMapValueCache<ItemStack, AEItemKey> ITEM_KEY_CACHE = new a();

    public V get(K var1);

    public static <K, V> IMapValueCache<K, V> create(Hash.Strategy<K> strategy, Function<K, V> function, boolean bl) {
        return new b<K, V>(strategy, function, bl);
    }

    public static <K, V> IMapValueCache<K, V> create(Hash.Strategy<K> strategy, Function<K, V> function) {
        return IMapValueCache.create(strategy, function, true);
    }

    public static <K, V> IMapValueCache<K, V> create(Function<K, V> function) {
        return IMapValueCache.create(STRATEGY, function);
    }
}

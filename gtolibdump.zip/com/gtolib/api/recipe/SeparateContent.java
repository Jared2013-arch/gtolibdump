package com.gtolib.api.recipe;

import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.gregtechceu.gtceu.api.recipe.content.Content;

public final class SeparateContent
extends Content {
    public final long parallel;

    public SeparateContent(Object object, int n, int n2, int n3, long l) {
        super(object, n, n2, n3);
        this.parallel = l;
    }

    public static long getParallel(Content content, long l) {
        if (content instanceof SeparateContent) {
            SeparateContent separateContent = (SeparateContent)content;
            return separateContent.parallel;
        }
        return l;
    }

    public SeparateContent copy(RecipeCapability<?> recipeCapability) {
        return new SeparateContent(recipeCapability.copyContent(this.content), this.chance, this.maxChance, this.tierChanceBoost, this.parallel);
    }
}

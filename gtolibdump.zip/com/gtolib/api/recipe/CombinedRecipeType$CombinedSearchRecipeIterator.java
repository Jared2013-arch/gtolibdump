package com.gtolib.api.recipe;

import com.gregtechceu.gtceu.api.capability.recipe.IRecipeCapabilityHolder;
import com.gregtechceu.gtceu.api.machine.trait.RecipeHandlerList;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gtolib.api.recipe.CombinedRecipeType;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.RecipeType;
import com.gtolib.api.recipe.lookup.MapIngredient;
import java.util.function.Predicate;

final class CombinedRecipeType$CombinedSearchRecipeIterator
extends RecipeType.SearchRecipeIterator<CombinedRecipeType> {
    private int typeIndex;

    private CombinedRecipeType$CombinedSearchRecipeIterator(IRecipeCapabilityHolder iRecipeCapabilityHolder, CombinedRecipeType combinedRecipeType, Predicate<Recipe> predicate) {
        super(iRecipeCapabilityHolder, combinedRecipeType, predicate);
    }

    @Override
    public Recipe next() {
        Object object;
        while (this.list != null || this.inputList.hasNext()) {
            if (this.list == null) {
                this.list = (RecipeHandlerList)this.inputList.next();
                MapIngredient.convertList(this.holder, this.list);
                if (this.list.intIngredientMap.isEmpty()) {
                    this.list = null;
                    continue;
                }
                this.ingredients = this.list.intIngredientMap.toIntArray();
                this.holder.setCurrentHandlerList(this.list, null);
            }
            while (this.typeIndex < ((CombinedRecipeType)this.recipeType).types.length) {
                object = ((CombinedRecipeType)this.recipeType).types[this.typeIndex];
                while (this.ingredientIndex < this.ingredients.length) {
                    Recipe recipe = ((RecipeType)object).lookup().recurseIngredientTreeFindRecipe(this.ingredients.length, this.ingredients, ((RecipeType)object).lookup().lookup, this.canHandle, this.ingredientIndex, 0, 1 << this.ingredientIndex);
                    ++this.ingredientIndex;
                    if (recipe == null) continue;
                    return recipe;
                }
                this.ingredientIndex = 0;
                ++this.typeIndex;
            }
            this.typeIndex = 0;
            this.list = null;
        }
        while (this.customLogic != null || this.typeIndex < ((CombinedRecipeType)this.recipeType).types.length) {
            if (this.customLogic == null) {
                this.customLogic = ((CombinedRecipeType)this.recipeType).types[this.typeIndex].getCustomRecipeLogicRunners().listIterator(0);
            }
            while (this.customLogic.hasNext()) {
                object = ((GTRecipeType.ICustomRecipeLogic)this.customLogic.next()).createCustomRecipe(this.holder);
                if (object == null) continue;
                return (Recipe)object;
            }
            this.customLogic = null;
            ++this.typeIndex;
        }
        this.hasNext = false;
        return null;
    }
}

package com.gtolib.api.recipe;

import com.gregtechceu.gtceu.api.recipe.content.Content;
import com.gtolib.api.recipe.SeparateContent;
import it.unimi.dsi.fastutil.Hash;

class ContentBuilder$ContentHashStrategy
implements Hash.Strategy<Content> {
    private ContentBuilder$ContentHashStrategy() {
    }

    public int hashCode(Content content) {
        int n = content.chance + 31 * content.tierChanceBoost;
        n = 31 * n + content.content.hashCode();
        if (content instanceof SeparateContent) {
            n = 31 * n;
        }
        return n;
    }

    public boolean equals(Content content, Content content2) {
        if (content instanceof SeparateContent && !(content2 instanceof SeparateContent)) {
            return false;
        }
        return content != null && content2 != null && content.chance == content2.chance && content.tierChanceBoost == content2.tierChanceBoost && content.content.equals(content2.content);
    }
}

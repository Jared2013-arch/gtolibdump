package com.gtolib.api.recipe;

import com.gtolib.api.recipe.Recipe;
import java.util.Iterator;

final class RecipeType$RecipeIterator
implements Iterator<Recipe> {
    private final Recipe recipe;
    private boolean hasNext;

    private RecipeType$RecipeIterator(Recipe recipe) {
        this.recipe = recipe;
        this.hasNext = true;
    }

    @Override
    public boolean hasNext() {
        return this.hasNext;
    }

    @Override
    public Recipe next() {
        this.hasNext = false;
        return this.recipe;
    }
}

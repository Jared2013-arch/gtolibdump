package com.gtolib.api.recipe;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.capability.recipe.CWURecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.EURecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.FluidRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.ItemRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.gregtechceu.gtceu.api.data.chemical.ChemicalHelper;
import com.gregtechceu.gtceu.api.data.chemical.material.ItemMaterialData;
import com.gregtechceu.gtceu.api.data.chemical.material.Material;
import com.gregtechceu.gtceu.api.data.chemical.material.stack.ItemMaterialInfo;
import com.gregtechceu.gtceu.api.data.chemical.material.stack.MaterialEntry;
import com.gregtechceu.gtceu.api.data.chemical.material.stack.MaterialStack;
import com.gregtechceu.gtceu.api.data.tag.TagPrefix;
import com.gregtechceu.gtceu.api.machine.MachineDefinition;
import com.gregtechceu.gtceu.api.machine.multiblock.CleanroomType;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gregtechceu.gtceu.api.recipe.RecipeCondition;
import com.gregtechceu.gtceu.api.recipe.ResearchRecipeBuilder;
import com.gregtechceu.gtceu.api.recipe.category.GTRecipeCategory;
import com.gregtechceu.gtceu.api.recipe.chance.logic.ChanceLogic;
import com.gregtechceu.gtceu.api.recipe.content.Content;
import com.gregtechceu.gtceu.api.recipe.ingredient.FluidIngredient;
import com.gregtechceu.gtceu.api.registry.GTRegistries;
import com.gregtechceu.gtceu.common.data.GTRecipeTypes;
import com.gregtechceu.gtceu.common.recipe.condition.BiomeCondition;
import com.gregtechceu.gtceu.common.recipe.condition.CleanroomCondition;
import com.gregtechceu.gtceu.common.recipe.condition.DaytimeCondition;
import com.gregtechceu.gtceu.common.recipe.condition.DimensionCondition;
import com.gregtechceu.gtceu.common.recipe.condition.PositionYCondition;
import com.gregtechceu.gtceu.common.recipe.condition.RainingCondition;
import com.gregtechceu.gtceu.common.recipe.condition.ThunderCondition;
import com.gregtechceu.gtceu.data.recipe.builder.GTRecipeBuilder;
import com.gregtechceu.gtceu.utils.GTUtil;
import com.gregtechceu.gtceu.utils.collection.O2IOpenCustomCacheHashMap;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtocore.common.recipe.condition.GravityCondition;
import com.gtocore.common.recipe.condition.HeatCondition;
import com.gtocore.common.recipe.condition.ResearchCondition;
import com.gtocore.common.recipe.condition.RestrictedMachineCondition;
import com.gtocore.common.recipe.condition.RunLimitCondition;
import com.gtocore.common.recipe.condition.VacuumCondition;
import com.gtolib.GTOCore;
import com.gtolib.IItem;
import com.gtolib.api.GTOValues;
import com.gtolib.api.capability.recipe.ManaRecipeCapability;
import com.gtolib.api.data.chemical.GTOChemicalHelper;
import com.gtolib.api.data.tag.ITagPrefix;
import com.gtolib.api.item.NBTItem;
import com.gtolib.api.recipe.ContentBuilder;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.RecipeType;
import com.gtolib.api.recipe.ingredient.CircuitIngredient;
import com.gtolib.api.recipe.ingredient.FastFluidIngredient;
import com.gtolib.api.recipe.ingredient.FastSizedIngredient;
import com.gtolib.api.recipe.research.ResearchData;
import com.gtolib.api.recipe.research.ScannerBuilder;
import com.gtolib.api.recipe.research.StationBuilder;
import com.gtolib.utils.ItemUtils;
import com.gtolib.utils.RLUtils;
import com.gtolib.utils.RegistriesUtils;
import it.unimi.dsi.fastutil.objects.Object2BooleanOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenCustomHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.Reference2LongMap;
import it.unimi.dsi.fastutil.objects.Reference2LongOpenHashMap;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.common.crafting.StrictNBTIngredient;
import net.minecraftforge.fluids.FluidStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
public final class RecipeBuilder
extends GTRecipeBuilder {
    public static Map<ResourceLocation, Recipe> RECIPE_MAP;
    private static Map<MaterialEntry, Ingredient> MATERIAL_INGREDIENT_MAP;
    private static Map<NBTItem, Ingredient> ITEM_INGREDIENT_MAP;
    private static Map<TagKey<Item>, Ingredient> TAG_INGREDIENT_MAP;
    private Object2IntOpenCustomHashMap<Ingredient> ingredientInput;
    boolean deleted;
    @Nullable
    private ResearchData researchData;
    private int tier;
    private long eut;
    private long manat;
    private int cwut;
    private int priority;
    private int displayPriority;

    RecipeBuilder(ResourceLocation resourceLocation, GTRecipeType gTRecipeType) {
        super(resourceLocation, gTRecipeType);
    }

    public static void initialization() {
        RECIPE_MAP = new O2OOpenCacheHashMap(4096);
        MATERIAL_INGREDIENT_MAP = new O2OOpenCacheHashMap(1024, 0.25f);
        ITEM_INGREDIENT_MAP = new O2OOpenCacheHashMap(1024, 0.25f);
        TAG_INGREDIENT_MAP = new O2OOpenCacheHashMap(1024, 0.25f);
        GTRegistries.RECIPE_TYPES.forEach(gTRecipeType -> {
            ((RecipeType)gTRecipeType).filter = new Object2BooleanOpenHashMap(16, 0.25f);
        });
    }

    public static void clean() {
        MATERIAL_INGREDIENT_MAP = null;
        ITEM_INGREDIENT_MAP = null;
        TAG_INGREDIENT_MAP = null;
        GTRegistries.RECIPE_TYPES.forEach(gTRecipeType -> {
            ((RecipeType)gTRecipeType).filter.forEach((resourceLocation, bl) -> {
                if (!bl.booleanValue()) {
                    GTOCore.LOGGER.error("Recipe filter [{}] not in use", resourceLocation);
                }
            });
            ((RecipeType)gTRecipeType).filter = null;
        });
    }

    private static FastSizedIngredient createSizedIngredient(Item item, int n) {
        return FastSizedIngredient.create(item, (long)n);
    }

    private static FastSizedIngredient createSizedIngredient(MaterialEntry materialEntry, int n) {
        if (MATERIAL_INGREDIENT_MAP == null) {
            return FastSizedIngredient.create(ChemicalHelper.get(materialEntry, n));
        }
        Ingredient ingredient = MATERIAL_INGREDIENT_MAP.get(materialEntry);
        if (ingredient == null) {
            Item item = GTOChemicalHelper.getItem(materialEntry);
            if (item == Items.f_41852_) {
                GTOCore.LOGGER.error("Tried to set output item stack that doesn't exist, TagPrefix: {}, Material: {}", (Object)materialEntry.tagPrefix(), (Object)materialEntry.material());
            }
            ingredient = ((IItem)((Object)item)).gtolib$getInnerIngredient();
            MATERIAL_INGREDIENT_MAP.put(materialEntry, ingredient);
        }
        return FastSizedIngredient.create(ingredient, (long)n);
    }

    private static FastSizedIngredient createSizedIngredient(ItemStack itemStack) {
        if (ITEM_INGREDIENT_MAP == null) {
            return FastSizedIngredient.create(itemStack);
        }
        NBTItem nBTItem = NBTItem.of(itemStack);
        Ingredient ingredient = ITEM_INGREDIENT_MAP.get(nBTItem);
        if (ingredient == null) {
            ingredient = nBTItem.nbt() == null ? ((IItem)((Object)nBTItem.item())).gtolib$getInnerIngredient() : StrictNBTIngredient.of(itemStack);
            ITEM_INGREDIENT_MAP.put(nBTItem, ingredient);
        }
        return FastSizedIngredient.create(ingredient, (long)itemStack.m_41613_());
    }

    private static FastSizedIngredient createSizedIngredient(TagKey<Item> tagKey, int n) {
        if (TAG_INGREDIENT_MAP == null) {
            return FastSizedIngredient.create(tagKey, (long)n);
        }
        Ingredient ingredient = TAG_INGREDIENT_MAP.get(tagKey);
        if (ingredient == null) {
            ingredient = Ingredient.m_204132_(tagKey);
            TAG_INGREDIENT_MAP.put(tagKey, ingredient);
        }
        return FastSizedIngredient.create(ingredient, (long)n);
    }

    public static RecipeBuilder ofRaw() {
        return new RecipeBuilder(GTCEu.id("raw"), GTRecipeTypes.DUMMY_RECIPES);
    }

    public RecipeBuilder reset() {
        if (!this.input.isEmpty()) {
            this.input.clear();
        }
        if (!this.output.isEmpty()) {
            this.output.clear();
        }
        this.duration = 100;
        this.tier = 0;
        this.eut = 0L;
        this.manat = 0L;
        this.cwut = 0;
        return this;
    }

    public RecipeBuilder copy(String string) {
        return this.copy(GTCEu.id(string));
    }

    public RecipeBuilder copy(ResourceLocation resourceLocation) {
        RecipeBuilder recipeBuilder = new RecipeBuilder(resourceLocation, this.recipeType);
        this.input.forEach((recipeCapability, list) -> recipeBuilder.input.put(recipeCapability, new ObjectArrayList((Collection)list)));
        this.output.forEach((recipeCapability, list) -> recipeBuilder.output.put(recipeCapability, new ObjectArrayList((Collection)list)));
        this.tickInput.forEach((recipeCapability, list) -> recipeBuilder.tickInput.put(recipeCapability, new ObjectArrayList((Collection)list)));
        this.tickOutput.forEach((recipeCapability, list) -> recipeBuilder.tickOutput.put(recipeCapability, new ObjectArrayList((Collection)list)));
        recipeBuilder.conditions.addAll(this.conditions);
        recipeBuilder.addMaterialInfo(this.itemMaterialInfo, this.fluidMaterialInfo);
        recipeBuilder.data = this.data.m_6426_();
        recipeBuilder.duration = this.duration;
        recipeBuilder.chance = this.chance;
        recipeBuilder.perTick = this.perTick;
        recipeBuilder.recipeCategory = this.recipeCategory;
        recipeBuilder.onSave = this.onSave;
        recipeBuilder.eut = this.eut;
        recipeBuilder.manat = this.manat;
        recipeBuilder.cwut = this.cwut;
        recipeBuilder.tier = this.tier;
        return recipeBuilder;
    }

    public RecipeBuilder copyFrom(GTRecipeBuilder gTRecipeBuilder) {
        return ((RecipeBuilder)((RecipeBuilder)gTRecipeBuilder).copy(gTRecipeBuilder.id).onSave((Consumer)null)).recipeType(this.recipeType).category(this.recipeCategory);
    }

    public <T> RecipeBuilder input(RecipeCapability<T> recipeCapability2, T t) {
        if (this.deleted) {
            return this;
        }
        Map map = this.perTick ? this.tickInput : this.input;
        map.computeIfAbsent(recipeCapability2, recipeCapability -> new ObjectArrayList()).add(new Content(recipeCapability2.of(t), this.chance, ContentBuilder.maxChance, this.tierChanceBoost));
        return this;
    }

    @SafeVarargs
    public final <T> RecipeBuilder input(RecipeCapability<T> recipeCapability2, T ... TArray) {
        if (this.deleted) {
            return this;
        }
        Map map = this.perTick ? this.tickInput : this.input;
        map.computeIfAbsent(recipeCapability2, recipeCapability -> new ObjectArrayList()).addAll(Arrays.stream(TArray).map(recipeCapability2::of).map(object -> new Content(object, this.chance, ContentBuilder.maxChance, this.tierChanceBoost)).toList());
        return this;
    }

    public <T> RecipeBuilder output(RecipeCapability<T> recipeCapability2, T t) {
        if (this.deleted) {
            return this;
        }
        Map map = this.perTick ? this.tickOutput : this.output;
        map.computeIfAbsent(recipeCapability2, recipeCapability -> new ObjectArrayList()).add(new Content(recipeCapability2.of(t), this.chance, ContentBuilder.maxChance, this.tierChanceBoost));
        return this;
    }

    @SafeVarargs
    public final <T> RecipeBuilder output(RecipeCapability<T> recipeCapability2, T ... TArray) {
        if (this.deleted) {
            return this;
        }
        Map map = this.perTick ? this.tickOutput : this.output;
        map.computeIfAbsent(recipeCapability2, recipeCapability -> new ObjectArrayList()).addAll(Arrays.stream(TArray).map(recipeCapability2::of).map(object -> new Content(object, this.chance, ContentBuilder.maxChance, this.tierChanceBoost)).toList());
        return this;
    }

    public RecipeBuilder addCondition(RecipeCondition recipeCondition) {
        if (this.deleted) {
            return this;
        }
        this.conditions.add(recipeCondition);
        return this;
    }

    public RecipeBuilder inputEU(long l) {
        return this.input((RecipeCapability)EURecipeCapability.CAP, (Object)l);
    }

    public RecipeBuilder EUt(long l) {
        if (this.recipeType != GTRecipeTypes.DUMMY_RECIPES) {
            if (this.deleted) {
                return this;
            }
            if (l == 0L) {
                GTOCore.LOGGER.error("EUt can't be explicitly set to 0, id: {}", (Object)this.id);
            }
            boolean bl = this.perTick;
            this.perTick = true;
            if (l > 0L) {
                this.tickInput.remove(EURecipeCapability.CAP);
                this.inputEU(l);
            } else if (l < 0L) {
                this.tickOutput.remove(EURecipeCapability.CAP);
                this.outputEU(-l);
            }
            this.perTick = bl;
            this.tier = GTUtil.getTierByVoltage(Math.abs(l));
        }
        this.eut = l;
        return this;
    }

    public RecipeBuilder outputEU(long l) {
        return this.output((RecipeCapability)EURecipeCapability.CAP, (Object)l);
    }

    public RecipeBuilder inputCWU(long l) {
        return this.input((RecipeCapability)CWURecipeCapability.CAP, (Object)l);
    }

    public RecipeBuilder CWUt(int n) {
        if (this.recipeType != GTRecipeTypes.DUMMY_RECIPES) {
            if (this.deleted) {
                return this;
            }
            if (n == 0) {
                GTOCore.LOGGER.error("CWUt can't be explicitly set to 0, id: {}", (Object)this.id);
            }
            boolean bl = this.perTick;
            this.perTick = true;
            if (n > 0) {
                this.tickInput.remove(CWURecipeCapability.CAP);
                this.inputCWU(n);
            } else if (n < 0) {
                throw new IllegalArgumentException("CWUt can't be negative, id: " + String.valueOf(this.id));
            }
            this.perTick = bl;
        }
        this.cwut = n;
        return this;
    }

    public RecipeBuilder totalCWU(int n) {
        this.durationIsTotalCWU(true);
        this.hideDuration(true);
        this.duration(n);
        return this;
    }

    public RecipeBuilder inputItems(Object object) {
        Supplier supplier;
        Object t;
        if (this.deleted) {
            return this;
        }
        if (object instanceof String) {
            String string = (String)object;
            return this.inputItems(string);
        }
        if (object instanceof Item) {
            Item item = (Item)object;
            return this.inputItems(item);
        }
        if (object instanceof Supplier && (t = (supplier = (Supplier)object).get()) instanceof ItemLike) {
            ItemLike itemLike = (ItemLike)t;
            return this.inputItems(itemLike.m_5456_());
        }
        if (object instanceof ItemStack) {
            ItemStack itemStack = (ItemStack)object;
            return this.inputItems(itemStack);
        }
        if (object instanceof Ingredient) {
            Ingredient ingredient = (Ingredient)object;
            return this.inputItems(ingredient);
        }
        if (object instanceof MaterialEntry) {
            MaterialEntry materialEntry = (MaterialEntry)object;
            return this.inputItems(materialEntry);
        }
        if (object instanceof TagKey) {
            TagKey tagKey = (TagKey)object;
            return this.inputItems(tagKey);
        }
        if (object instanceof MachineDefinition) {
            MachineDefinition machineDefinition = (MachineDefinition)object;
            return this.inputItems(machineDefinition);
        }
        throw new IllegalArgumentException("Input: " + String.valueOf(object) + " is not one of: Item, Supplier<Item>, ItemStack, Ingredient, MaterialEntry, TagKey<Item>, MachineDefinition, id: " + String.valueOf(this.id));
    }

    public RecipeBuilder inputItems(Object object, int n) {
        Supplier supplier;
        Object t;
        if (this.deleted) {
            return this;
        }
        if (object instanceof String) {
            String string = (String)object;
            return this.inputItems(string, n);
        }
        if (object instanceof Item) {
            Item item = (Item)object;
            return this.inputItems(item, n);
        }
        if (object instanceof Supplier && (t = (supplier = (Supplier)object).get()) instanceof ItemLike) {
            ItemLike itemLike = (ItemLike)t;
            return this.inputItems(itemLike.m_5456_(), n);
        }
        if (object instanceof ItemStack) {
            ItemStack itemStack = (ItemStack)object;
            return this.inputItems(itemStack.m_255036_(n));
        }
        if (object instanceof Ingredient) {
            Ingredient ingredient = (Ingredient)object;
            return this.inputItems(ingredient, n);
        }
        if (object instanceof MaterialEntry) {
            MaterialEntry materialEntry = (MaterialEntry)object;
            return this.inputItems(materialEntry, n);
        }
        if (object instanceof TagKey) {
            TagKey tagKey = (TagKey)object;
            return this.inputItems(tagKey, n);
        }
        if (object instanceof MachineDefinition) {
            MachineDefinition machineDefinition = (MachineDefinition)object;
            return this.inputItems(machineDefinition, n);
        }
        throw new IllegalArgumentException("Input: " + String.valueOf(object) + " is not one of: Item, Supplier<Item>, ItemStack, Ingredient, MaterialEntry, TagKey<Item>, MachineDefinition, id: " + String.valueOf(this.id));
    }

    public RecipeBuilder inputItems(Block block, int n) {
        return this.inputItems(block.m_5456_(), n);
    }

    public RecipeBuilder inputItems(Ingredient ingredient, int n) {
        Ingredient ingredient2 = FastSizedIngredient.copy(ingredient);
        if (ingredient2 instanceof FastSizedIngredient) {
            FastSizedIngredient fastSizedIngredient = (FastSizedIngredient)ingredient2;
            fastSizedIngredient.setAmount(n);
        }
        return this.inputItems(ingredient2);
    }

    public RecipeBuilder inputIngredient(Ingredient ingredient) {
        if (this.ingredientInput == null) {
            this.ingredientInput = new O2IOpenCustomCacheHashMap(FastSizedIngredient.HASH_STRATEGY);
        }
        this.ingredientInput.addTo((Object)ingredient, 1);
        return this;
    }

    public RecipeBuilder inputItems(FastSizedIngredient fastSizedIngredient) {
        return this.input((RecipeCapability)ItemRecipeCapability.CAP, fastSizedIngredient);
    }

    public RecipeBuilder inputItems(Ingredient ingredient) {
        return this.input((RecipeCapability)ItemRecipeCapability.CAP, FastSizedIngredient.toCompatibleIngredient(ingredient));
    }

    public RecipeBuilder inputItems(ItemStack itemStack) {
        ItemMaterialInfo itemMaterialInfo;
        if (this.deleted) {
            return this;
        }
        if (itemStack.m_41619_()) {
            throw new IllegalArgumentException("Input " + String.valueOf(itemStack) + " is empty, id: " + String.valueOf(this.id));
        }
        if (this.chance == ContentBuilder.maxChance && this.itemMaterialInfo && (itemMaterialInfo = ItemMaterialData.getMaterialInfo(itemStack.m_41720_())) != null) {
            for (MaterialStack materialStack : itemMaterialInfo.getMaterials()) {
                this.tempItemMaterialStacks.add(new MaterialStack(materialStack.material(), materialStack.amount() * (long)itemStack.m_41613_()));
            }
        }
        return this.inputItems(RecipeBuilder.createSizedIngredient(itemStack));
    }

    public RecipeBuilder inputItems(ItemStack ... itemStackArray) {
        if (this.deleted) {
            return this;
        }
        for (ItemStack itemStack : itemStackArray) {
            if (!itemStack.m_41619_()) continue;
            throw new IllegalArgumentException("Input " + Arrays.toString(itemStackArray) + " is empty, id: " + String.valueOf(this.id));
        }
        return this.input((RecipeCapability)ItemRecipeCapability.CAP, (Ingredient[])Arrays.stream(itemStackArray).map(RecipeBuilder::createSizedIngredient).toArray(Ingredient[]::new));
    }

    public RecipeBuilder inputItems(TagKey<Item> tagKey, int n) {
        if (this.deleted) {
            return this;
        }
        if (n == 0) {
            throw new IllegalArgumentException("Input " + String.valueOf(tagKey) + " is empty, id: " + String.valueOf(this.id));
        }
        return this.inputItems(RecipeBuilder.createSizedIngredient(tagKey, n));
    }

    public RecipeBuilder inputItems(TagKey<Item> tagKey) {
        return this.inputItems((TagKey)tagKey, 1);
    }

    public RecipeBuilder inputItems(Item item, int n) {
        ItemMaterialInfo itemMaterialInfo;
        if (this.deleted) {
            return this;
        }
        if (this.chance == ContentBuilder.maxChance && this.itemMaterialInfo && (itemMaterialInfo = ItemMaterialData.getMaterialInfo(item)) != null) {
            for (MaterialStack materialStack : itemMaterialInfo.getMaterials()) {
                this.tempItemMaterialStacks.add(new MaterialStack(materialStack.material(), materialStack.amount() * (long)n));
            }
        }
        return this.inputItems(RecipeBuilder.createSizedIngredient(item, n));
    }

    public RecipeBuilder inputItems(Item item) {
        if (this.deleted) {
            return this;
        }
        return this.inputItems(item, 1);
    }

    public RecipeBuilder inputItems(Supplier<? extends Item> supplier) {
        if (this.deleted) {
            return this;
        }
        return this.inputItems(supplier.get());
    }

    public RecipeBuilder inputItems(Supplier<? extends Item> supplier, int n) {
        if (this.deleted) {
            return this;
        }
        return this.inputItems(supplier.get(), n);
    }

    public RecipeBuilder inputItems(TagPrefix tagPrefix, Material material) {
        return this.inputItems(tagPrefix, material, 1);
    }

    public RecipeBuilder inputItems(MaterialEntry materialEntry) {
        return this.inputItems(materialEntry, 1);
    }

    public RecipeBuilder inputItems(MaterialEntry materialEntry, int n) {
        TagKey tagKey;
        if (this.deleted) {
            return this;
        }
        if (materialEntry.material().isNull()) {
            throw new IllegalArgumentException("Unification Entry material is null, id: " + String.valueOf(this.id) + ", TagPrefix: " + String.valueOf(materialEntry.tagPrefix()));
        }
        if (((ITagPrefix)((Object)materialEntry.tagPrefix())).gtolib$isTagInput() && (tagKey = ChemicalHelper.getTag(materialEntry.tagPrefix(), materialEntry.material())) != null) {
            return this.inputItems(tagKey, n);
        }
        if (this.chance == ContentBuilder.maxChance && this.itemMaterialInfo) {
            this.tempItemMaterialStacks.add(new MaterialStack(materialEntry.material(), materialEntry.tagPrefix().materialAmount() * (long)n));
        }
        return this.inputItems(RecipeBuilder.createSizedIngredient(materialEntry, n));
    }

    public RecipeBuilder inputItems(TagPrefix tagPrefix, Material material, int n) {
        if (this.deleted) {
            return this;
        }
        return this.inputItems(new MaterialEntry(tagPrefix, material), n);
    }

    public RecipeBuilder inputItems(MachineDefinition machineDefinition) {
        return this.inputItems(machineDefinition, 1);
    }

    public RecipeBuilder inputItems(MachineDefinition machineDefinition, int n) {
        return this.inputItems(machineDefinition.asStack(n));
    }

    public RecipeBuilder outputItems(Object object) {
        Supplier supplier;
        Object t;
        if (this.deleted) {
            return this;
        }
        if (object instanceof String) {
            String string = (String)object;
            return this.outputItems(string);
        }
        if (object instanceof Item) {
            Item item = (Item)object;
            return this.outputItems(item);
        }
        if (object instanceof Supplier && (t = (supplier = (Supplier)object).get()) instanceof ItemLike) {
            ItemLike itemLike = (ItemLike)t;
            return this.outputItems(itemLike.m_5456_());
        }
        if (object instanceof ItemStack) {
            ItemStack itemStack = (ItemStack)object;
            return this.outputItems(itemStack);
        }
        if (object instanceof MaterialEntry) {
            MaterialEntry materialEntry = (MaterialEntry)object;
            return this.outputItems(materialEntry);
        }
        if (object instanceof MachineDefinition) {
            MachineDefinition machineDefinition = (MachineDefinition)object;
            return this.outputItems(machineDefinition);
        }
        throw new IllegalArgumentException("Output: " + String.valueOf(object) + " is not one of: Item, Supplier<Item>, ItemStack, Ingredient, MaterialEntry, TagKey<Item>, MachineDefinition, id: " + String.valueOf(this.id));
    }

    public RecipeBuilder outputItems(Object object, int n) {
        Supplier supplier;
        Object t;
        if (this.deleted) {
            return this;
        }
        if (object instanceof String) {
            String string = (String)object;
            return this.outputItems(string, n);
        }
        if (object instanceof Item) {
            Item item = (Item)object;
            return this.outputItems(item, n);
        }
        if (object instanceof Supplier && (t = (supplier = (Supplier)object).get()) instanceof ItemLike) {
            ItemLike itemLike = (ItemLike)t;
            return this.outputItems(itemLike.m_5456_(), n);
        }
        if (object instanceof ItemStack) {
            ItemStack itemStack = (ItemStack)object;
            return this.outputItems(itemStack.m_255036_(n));
        }
        if (object instanceof MaterialEntry) {
            MaterialEntry materialEntry = (MaterialEntry)object;
            return this.outputItems(materialEntry, n);
        }
        if (object instanceof MachineDefinition) {
            MachineDefinition machineDefinition = (MachineDefinition)object;
            return this.outputItems(machineDefinition, n);
        }
        throw new IllegalArgumentException("Output: " + String.valueOf(object) + " is not one of: Item, Supplier<Item>, ItemStack, Ingredient, MaterialEntry, TagKey<Item>, MachineDefinition, id: " + String.valueOf(this.id));
    }

    public RecipeBuilder outputItems(Block block, int n) {
        return this.outputItems(block.m_5456_(), n);
    }

    public RecipeBuilder outputItems(Ingredient ingredient, int n) {
        Ingredient ingredient2 = FastSizedIngredient.copy(ingredient);
        if (ingredient2 instanceof FastSizedIngredient) {
            FastSizedIngredient fastSizedIngredient = (FastSizedIngredient)ingredient2;
            fastSizedIngredient.setAmount(n);
        }
        return this.outputItems(ingredient2);
    }

    public RecipeBuilder outputItems(FastSizedIngredient fastSizedIngredient) {
        return this.output((RecipeCapability)ItemRecipeCapability.CAP, fastSizedIngredient);
    }

    public RecipeBuilder outputItems(Ingredient ingredient) {
        return this.output((RecipeCapability)ItemRecipeCapability.CAP, FastSizedIngredient.toCompatibleIngredient(ingredient));
    }

    public RecipeBuilder outputItems(ItemStack itemStack) {
        if (this.deleted) {
            return this;
        }
        if (itemStack.m_41619_()) {
            throw new IllegalArgumentException("Output " + String.valueOf(itemStack) + " is empty, id: " + String.valueOf(this.id));
        }
        return this.output((RecipeCapability)ItemRecipeCapability.CAP, RecipeBuilder.createSizedIngredient(itemStack));
    }

    public RecipeBuilder outputItems(ItemStack ... itemStackArray) {
        if (this.deleted) {
            return this;
        }
        for (ItemStack itemStack : itemStackArray) {
            if (!itemStack.m_41619_()) continue;
            throw new IllegalArgumentException("Output " + Arrays.toString(itemStackArray) + " is empty, id: " + String.valueOf(this.id));
        }
        return this.output((RecipeCapability)ItemRecipeCapability.CAP, (Ingredient[])Arrays.stream(itemStackArray).map(RecipeBuilder::createSizedIngredient).toArray(Ingredient[]::new));
    }

    public RecipeBuilder outputItems(Item item, int n) {
        if (this.deleted) {
            return this;
        }
        return this.output((RecipeCapability)ItemRecipeCapability.CAP, RecipeBuilder.createSizedIngredient(item, n));
    }

    public RecipeBuilder outputItems(Item item) {
        if (this.deleted) {
            return this;
        }
        return this.outputItems(item, 1);
    }

    public RecipeBuilder outputItems(Supplier<? extends ItemLike> supplier) {
        if (this.deleted) {
            return this;
        }
        return this.outputItems(supplier.get().m_5456_());
    }

    public RecipeBuilder outputItems(Supplier<? extends ItemLike> supplier, int n) {
        if (this.deleted) {
            return this;
        }
        return this.outputItems(supplier.get().m_5456_(), n);
    }

    public RecipeBuilder outputItems(TagPrefix tagPrefix, Material material) {
        return this.outputItems(tagPrefix, material, 1);
    }

    public RecipeBuilder outputItems(TagPrefix tagPrefix, Material material, int n) {
        if (this.deleted) {
            return this;
        }
        return this.outputItems(new MaterialEntry(tagPrefix, material), n);
    }

    public RecipeBuilder outputItems(MaterialEntry materialEntry) {
        return this.outputItems(materialEntry, 1);
    }

    public RecipeBuilder outputItems(MaterialEntry materialEntry, int n) {
        if (this.deleted) {
            return this;
        }
        if (materialEntry.material().isNull()) {
            throw new IllegalArgumentException("Unification Entry material is null, id: " + String.valueOf(this.id) + ", TagPrefix: " + String.valueOf(materialEntry.tagPrefix()));
        }
        return this.output((RecipeCapability)ItemRecipeCapability.CAP, RecipeBuilder.createSizedIngredient(materialEntry, n));
    }

    public RecipeBuilder outputItems(MachineDefinition machineDefinition) {
        return this.outputItems(machineDefinition, 1);
    }

    public RecipeBuilder outputItems(MachineDefinition machineDefinition, int n) {
        return this.outputItems(machineDefinition.asStack(n));
    }

    public RecipeBuilder notConsumable(ItemStack itemStack) {
        if (this.deleted) {
            return this;
        }
        int n = this.chance;
        this.chance = 0;
        this.inputItems(itemStack);
        this.chance = n;
        return this;
    }

    public RecipeBuilder notConsumable(Ingredient ingredient) {
        if (this.deleted) {
            return this;
        }
        int n = this.chance;
        this.chance = 0;
        this.inputItems(ingredient);
        this.chance = n;
        return this;
    }

    public RecipeBuilder notConsumable(Item item) {
        if (this.deleted) {
            return this;
        }
        int n = this.chance;
        this.chance = 0;
        this.inputItems(item);
        this.chance = n;
        return this;
    }

    public RecipeBuilder notConsumable(Supplier<? extends Item> supplier) {
        if (this.deleted) {
            return this;
        }
        int n = this.chance;
        this.chance = 0;
        this.inputItems((Supplier)supplier);
        this.chance = n;
        return this;
    }

    public RecipeBuilder notConsumable(TagPrefix tagPrefix, Material material) {
        if (this.deleted) {
            return this;
        }
        int n = this.chance;
        this.chance = 0;
        this.inputItems(tagPrefix, material);
        this.chance = n;
        return this;
    }

    public RecipeBuilder notConsumable(TagPrefix tagPrefix, Material material, int n) {
        if (this.deleted) {
            return this;
        }
        int n2 = this.chance;
        this.chance = 0;
        this.inputItems(tagPrefix, material, n);
        this.chance = n2;
        return this;
    }

    public RecipeBuilder notConsumableFluid(FluidStack fluidStack) {
        if (this.deleted) {
            return this;
        }
        return this.notConsumableFluid(FastFluidIngredient.of(fluidStack));
    }

    public RecipeBuilder notConsumableFluid(FluidIngredient fluidIngredient) {
        if (this.deleted) {
            return this;
        }
        int n = this.chance;
        this.chance = 0;
        this.inputFluids(fluidIngredient);
        this.chance = n;
        return this;
    }

    public RecipeBuilder circuitMeta(int n) {
        if (this.deleted) {
            return this;
        }
        if (n < 0 || n > 32) {
            GTOCore.LOGGER.error("Circuit configuration must be in the bounds 0 - 32");
        }
        return this.notConsumable(CircuitIngredient.of(n));
    }

    public RecipeBuilder chancedInput(ItemStack itemStack, int n, int n2) {
        if (this.deleted) {
            return this;
        }
        if (0 >= n || n > ChanceLogic.getMaxChancedValue()) {
            GTOCore.LOGGER.error("Chance cannot be less or equal to 0 or more than {}. Actual: {}.", ChanceLogic.getMaxChancedValue(), n, new Throwable());
            return this;
        }
        int n3 = this.chance;
        int n4 = this.tierChanceBoost;
        this.chance = n;
        this.tierChanceBoost = n2;
        this.inputItems(itemStack);
        this.chance = n3;
        this.tierChanceBoost = n4;
        return this;
    }

    public RecipeBuilder chancedInput(FluidStack fluidStack, int n, int n2) {
        if (this.deleted) {
            return this;
        }
        if (0 >= n || n > ChanceLogic.getMaxChancedValue()) {
            GTOCore.LOGGER.error("Chance cannot be less or equal to 0 or more than {}. Actual: {}.", ChanceLogic.getMaxChancedValue(), n, new Throwable());
            return this;
        }
        int n3 = this.chance;
        int n4 = this.tierChanceBoost;
        this.chance = n;
        this.tierChanceBoost = n2;
        this.inputFluids(fluidStack);
        this.chance = n3;
        this.tierChanceBoost = n4;
        return this;
    }

    public RecipeBuilder chancedOutput(ItemStack itemStack, int n, int n2) {
        if (this.deleted) {
            return this;
        }
        if (0 >= n || n > ChanceLogic.getMaxChancedValue()) {
            GTOCore.LOGGER.error("Chance cannot be less or equal to 0 or more than {}. Actual: {}.", ChanceLogic.getMaxChancedValue(), n, new Throwable());
            return this;
        }
        int n3 = this.chance;
        int n4 = this.tierChanceBoost;
        this.chance = n;
        this.tierChanceBoost = n2;
        this.outputItems(itemStack);
        this.chance = n3;
        this.tierChanceBoost = n4;
        return this;
    }

    public RecipeBuilder chancedOutput(FluidStack fluidStack, int n, int n2) {
        if (this.deleted) {
            return this;
        }
        if (0 >= n || n > ChanceLogic.getMaxChancedValue()) {
            GTOCore.LOGGER.error("Chance cannot be less or equal to 0 or more than {}. Actual: {}.", ChanceLogic.getMaxChancedValue(), n, new Throwable());
            return this;
        }
        int n3 = this.chance;
        int n4 = this.tierChanceBoost;
        this.chance = n;
        this.tierChanceBoost = n2;
        this.outputFluids(fluidStack);
        this.chance = n3;
        this.tierChanceBoost = n4;
        return this;
    }

    public RecipeBuilder chancedOutput(TagPrefix tagPrefix, Material material, int n, int n2) {
        if (this.deleted) {
            return this;
        }
        return this.chancedOutput(ChemicalHelper.get(tagPrefix, material), n, n2);
    }

    public RecipeBuilder chancedOutput(TagPrefix tagPrefix, Material material, int n, int n2, int n3) {
        if (this.deleted) {
            return this;
        }
        return this.chancedOutput(ChemicalHelper.get(tagPrefix, material, n), n2, n3);
    }

    public RecipeBuilder inputFluids(Fluid fluid, long l) {
        if (this.deleted) {
            return this;
        }
        return this.input((RecipeCapability)FluidRecipeCapability.CAP, FastFluidIngredient.of(l, fluid));
    }

    public RecipeBuilder inputFluids(@NotNull Material material, int n) {
        if (this.chance == ContentBuilder.maxChance && this.fluidMaterialInfo) {
            this.tempFluidStacks.add(new MaterialStack(material, (long)n * 3628800L / 144L));
        }
        return this.inputFluids(material.getFluid(), (long)n);
    }

    public RecipeBuilder inputFluids(FluidStack fluidStack) {
        if (this.deleted) {
            return this;
        }
        return this.input((RecipeCapability)FluidRecipeCapability.CAP, FastFluidIngredient.of(fluidStack));
    }

    public RecipeBuilder inputFluids(FluidStack ... fluidStackArray) {
        if (this.deleted) {
            return this;
        }
        return this.input((RecipeCapability)FluidRecipeCapability.CAP, (FluidIngredient[])Arrays.stream(fluidStackArray).map(fluidStack -> FastFluidIngredient.of(fluidStack)).toArray(FluidIngredient[]::new));
    }

    public RecipeBuilder inputFluids(FluidIngredient ... fluidIngredientArray) {
        if (this.deleted) {
            return this;
        }
        return this.input((RecipeCapability)FluidRecipeCapability.CAP, fluidIngredientArray);
    }

    public RecipeBuilder outputFluids(@NotNull Material material, int n) {
        return this.outputFluids(material.getFluid(), (long)n);
    }

    public RecipeBuilder outputFluids(@NotNull Fluid fluid, long l) {
        if (this.deleted) {
            return this;
        }
        return this.output((RecipeCapability)FluidRecipeCapability.CAP, FastFluidIngredient.of(l, fluid));
    }

    public RecipeBuilder outputFluids(FluidStack fluidStack) {
        if (this.deleted) {
            return this;
        }
        return this.output((RecipeCapability)FluidRecipeCapability.CAP, FastFluidIngredient.of(fluidStack));
    }

    public RecipeBuilder outputFluids(FluidStack ... fluidStackArray) {
        if (this.deleted) {
            return this;
        }
        return this.output((RecipeCapability)FluidRecipeCapability.CAP, (FluidIngredient[])Arrays.stream(fluidStackArray).map(fluidStack -> FastFluidIngredient.of(fluidStack)).toArray(FluidIngredient[]::new));
    }

    public RecipeBuilder outputFluids(FluidIngredient ... fluidIngredientArray) {
        if (this.deleted) {
            return this;
        }
        return this.output((RecipeCapability)FluidRecipeCapability.CAP, fluidIngredientArray);
    }

    public RecipeBuilder addData(String string, Tag tag) {
        if (this.deleted) {
            return this;
        }
        this.data.m_128365_(string, tag);
        return this;
    }

    public RecipeBuilder addData(String string, int n) {
        if (this.deleted) {
            return this;
        }
        this.data.m_128405_(string, n);
        return this;
    }

    public RecipeBuilder addData(String string, long l) {
        if (this.deleted) {
            return this;
        }
        this.data.m_128356_(string, l);
        return this;
    }

    public RecipeBuilder addData(String string, String string2) {
        if (this.deleted) {
            return this;
        }
        this.data.m_128359_(string, string2);
        return this;
    }

    public RecipeBuilder addData(String string, float f) {
        if (this.deleted) {
            return this;
        }
        this.data.m_128350_(string, f);
        return this;
    }

    public RecipeBuilder addData(String string, boolean bl) {
        if (this.deleted) {
            return this;
        }
        this.data.m_128379_(string, bl);
        return this;
    }

    public RecipeBuilder blastFurnaceTemp(int n) {
        if (this.deleted) {
            return this;
        }
        return this.addData("ebf_temp", n);
    }

    public RecipeBuilder explosivesAmount(int n) {
        if (this.deleted) {
            return this;
        }
        return this.inputItems(new ItemStack(Blocks.f_50077_, n));
    }

    public RecipeBuilder explosivesType(ItemStack itemStack) {
        if (this.deleted) {
            return this;
        }
        return this.inputItems(itemStack);
    }

    public RecipeBuilder solderMultiplier(int n) {
        if (this.deleted) {
            return this;
        }
        return this.addData("solder_multiplier", n);
    }

    public RecipeBuilder disableDistilleryRecipes(boolean bl) {
        if (this.deleted) {
            return this;
        }
        return this.addData("disable_distillery", bl);
    }

    public RecipeBuilder fusionStartEU(long l) {
        if (this.deleted) {
            return this;
        }
        return this.addData("eu_to_start", l);
    }

    public RecipeBuilder researchScan(boolean bl) {
        if (this.deleted) {
            return this;
        }
        return this.addData("scan_for_research", bl);
    }

    public RecipeBuilder durationIsTotalCWU(boolean bl) {
        if (this.deleted) {
            return this;
        }
        return this.addData("duration_is_total_cwu", bl);
    }

    public RecipeBuilder hideDuration(boolean bl) {
        if (this.deleted) {
            return this;
        }
        return this.addData("hide_duration", bl);
    }

    public RecipeBuilder cleanroom(CleanroomType cleanroomType) {
        if (this.deleted) {
            return this;
        }
        return this.addCondition(new CleanroomCondition(cleanroomType));
    }

    public RecipeBuilder dimension(ResourceLocation resourceLocation, boolean bl) {
        if (this.deleted) {
            return this;
        }
        return this.addCondition(new DimensionCondition(resourceLocation).setReverse(bl));
    }

    public RecipeBuilder dimension(ResourceLocation resourceLocation) {
        if (this.deleted) {
            return this;
        }
        return this.dimension(resourceLocation, false);
    }

    public RecipeBuilder biome(ResourceLocation resourceLocation, boolean bl) {
        return this.biome(ResourceKey.m_135785_(Registries.f_256952_, resourceLocation), bl);
    }

    public RecipeBuilder biome(ResourceLocation resourceLocation) {
        return this.biome(resourceLocation, false);
    }

    public RecipeBuilder biome(ResourceKey<Biome> resourceKey, boolean bl) {
        return this.addCondition(new BiomeCondition(resourceKey).setReverse(bl));
    }

    public RecipeBuilder biome(ResourceKey<Biome> resourceKey) {
        return this.biome((ResourceKey)resourceKey, false);
    }

    public RecipeBuilder rain(float f, boolean bl) {
        if (this.deleted) {
            return this;
        }
        return this.addCondition(new RainingCondition(f).setReverse(bl));
    }

    public RecipeBuilder rain(float f) {
        if (this.deleted) {
            return this;
        }
        return this.rain(f, false);
    }

    public RecipeBuilder thunder(float f, boolean bl) {
        if (this.deleted) {
            return this;
        }
        return this.addCondition(new ThunderCondition(f).setReverse(bl));
    }

    public RecipeBuilder thunder(float f) {
        if (this.deleted) {
            return this;
        }
        return this.thunder(f, false);
    }

    public RecipeBuilder posY(int n, int n2, boolean bl) {
        if (this.deleted) {
            return this;
        }
        return this.addCondition(new PositionYCondition(n, n2).setReverse(bl));
    }

    public RecipeBuilder posY(int n, int n2) {
        if (this.deleted) {
            return this;
        }
        return this.posY(n, n2, false);
    }

    public RecipeBuilder daytime(boolean bl) {
        if (this.deleted) {
            return this;
        }
        return this.addCondition(new DaytimeCondition().setReverse(bl));
    }

    public RecipeBuilder daytime() {
        if (this.deleted) {
            return this;
        }
        return this.daytime(false);
    }

    public RecipeBuilder category(@NotNull GTRecipeCategory gTRecipeCategory) {
        this.recipeCategory = gTRecipeCategory;
        return this;
    }

    public Recipe buildRawRecipe() {
        return new Recipe(this.recipeType, this.id.m_246208_(this.recipeType.registryName.m_135815_() + "/"), this.tier, this.eut, this.manat, this.cwut, this.input, this.output, this.tickInput, this.tickOutput, this.data, this.duration);
    }

    public long EUt() {
        return this.eut;
    }

    public RecipeBuilder id(ResourceLocation resourceLocation) {
        this.id = resourceLocation;
        return this;
    }

    public RecipeBuilder recipeType(GTRecipeType gTRecipeType) {
        this.recipeType = gTRecipeType;
        return this;
    }

    public RecipeBuilder duration(int n) {
        this.duration = n;
        return this;
    }

    public RecipeBuilder perTick(boolean bl) {
        this.perTick = bl;
        return this;
    }

    public RecipeBuilder chance(int n) {
        this.chance = n;
        return this;
    }

    public RecipeBuilder maxChance(int n) {
        this.maxChance = n;
        return this;
    }

    public RecipeBuilder tierChanceBoost(int n) {
        this.tierChanceBoost = n;
        return this;
    }

    public RecipeBuilder onSave(@Nullable Consumer<GTRecipeBuilder> consumer) {
        this.onSave = consumer;
        return this;
    }

    public RecipeBuilder addMaterialInfo() {
        return (RecipeBuilder)super.addMaterialInfo(true, true);
    }

    @Override
    public RecipeBuilder addMaterialInfo(boolean bl) {
        return (RecipeBuilder)super.addMaterialInfo(bl);
    }

    @Override
    public RecipeBuilder addMaterialInfo(boolean bl, boolean bl2) {
        return (RecipeBuilder)super.addMaterialInfo(bl, bl2);
    }

    public Recipe save() {
        Object object;
        if (this.deleted) {
            return Recipe.EMPTY;
        }
        ResourceLocation resourceLocation = RecipeBuilder.getTypeID(this.id, this.recipeType);
        if (this.recipeType != GTRecipeTypes.RESEARCH_STATION_RECIPES && this.recipeType != GTRecipeTypes.MACERATOR_RECIPES && RECIPE_MAP.containsKey(resourceLocation)) {
            throw new IllegalStateException("Recipe with id " + String.valueOf(resourceLocation) + " already exists!");
        }
        if (this.ingredientInput != null) {
            object = this.ingredientInput.object2IntEntrySet().iterator();
            while (object.hasNext()) {
                Object2IntMap.Entry entry = (Object2IntMap.Entry)object.next();
                Ingredient ingredient = (Ingredient)entry.getKey();
                this.inputItems(FastSizedIngredient.create(ingredient, (long)entry.getIntValue() * ItemUtils.getSizedAmount(ingredient)));
            }
        }
        if (this.onSave != null) {
            this.onSave.accept(this);
        }
        if (this.itemMaterialInfo) {
            this.addOutputMaterialInfo();
        }
        object = new Recipe(this.recipeType, resourceLocation, this.tier, this.eut, this.manat, this.cwut, this.input, this.output, this.tickInput, this.tickOutput, this.conditions, this.data, this.duration, this.priority, this.recipeCategory);
        if (this.researchData != null) {
            this.recipeType.addDataStickEntry(this.researchData.researchId(), (GTRecipe)object);
            ((Recipe)object).conditions.add(new ResearchCondition(this.researchData));
            ((Recipe)object).researchData = this.researchData;
        }
        ((Recipe)object).displayPriority = this.displayPriority;
        RECIPE_MAP.put(resourceLocation, (Recipe)object);
        return object;
    }

    public static ResourceLocation getTypeID(ResourceLocation resourceLocation, GTRecipeType gTRecipeType) {
        return RLUtils.fromNamespaceAndPath(resourceLocation.m_135827_(), gTRecipeType.registryName.m_135815_() + "/" + resourceLocation.m_135815_());
    }

    public RecipeBuilder notConsumableFluid(@NotNull Material material, int n) {
        return this.notConsumableFluid(material.getFluid(n));
    }

    public RecipeBuilder notConsumable(TagKey<Item> tagKey) {
        int n = this.chance;
        this.chance = 0;
        this.inputItems((TagKey)tagKey);
        this.chance = n;
        return this;
    }

    public RecipeBuilder notConsumable(String string) {
        return this.notConsumable(RegistriesUtils.getItem(string));
    }

    public RecipeBuilder notConsumable(String string, int n) {
        return this.notConsumable(RegistriesUtils.getItemStack(string, n));
    }

    public RecipeBuilder inputItems(String string) {
        return this.inputItems(RegistriesUtils.getItem(string));
    }

    public RecipeBuilder inputItems(String string, int n) {
        return this.inputItems(RegistriesUtils.getItem(string), n);
    }

    public RecipeBuilder chancedInput(String string, int n, int n2) {
        return this.chancedInput(RegistriesUtils.getItemStack(string), n, n2);
    }

    public RecipeBuilder outputItems(String string) {
        return this.outputItems(RegistriesUtils.getItem(string));
    }

    public RecipeBuilder outputItems(String string, int n) {
        return this.outputItems(RegistriesUtils.getItem(string), n);
    }

    public RecipeBuilder vacuum(int n) {
        return this.addCondition(new VacuumCondition(n));
    }

    public RecipeBuilder gravity(boolean bl) {
        return this.addCondition(new GravityCondition(bl));
    }

    public RecipeBuilder heat(int n) {
        return this.addCondition(new HeatCondition(n));
    }

    public RecipeBuilder euVATier(int n) {
        return this.EUt(GTOValues.VAEX[n]);
    }

    public RecipeBuilder MANAt(long l) {
        this.manat = l;
        if (this.recipeType != GTRecipeTypes.DUMMY_RECIPES) {
            boolean bl = this.perTick;
            this.perTick = true;
            if (l > 0L) {
                this.input((RecipeCapability)ManaRecipeCapability.CAP, (Object)l);
            } else {
                this.output((RecipeCapability)ManaRecipeCapability.CAP, (Object)(-l));
            }
            this.perTick = bl;
        }
        return this;
    }

    public RecipeBuilder temperature(int n) {
        return this.addData("temperature", n);
    }

    public RecipeBuilder runLimit(int n) {
        return this.addCondition(new RunLimitCondition(n));
    }

    public RecipeBuilder restrictedMachine(ResourceLocation resourceLocation) {
        return this.addCondition(new RestrictedMachineCondition(resourceLocation));
    }

    public RecipeBuilder researchStation(UnaryOperator<StationBuilder> unaryOperator) {
        this.researchData = ((StationBuilder)unaryOperator.apply(new StationBuilder())).build(this.recipeType);
        return this;
    }

    public RecipeBuilder scanner(UnaryOperator<ScannerBuilder> unaryOperator) {
        this.researchData = ((ScannerBuilder)unaryOperator.apply(new ScannerBuilder())).build(this.recipeType);
        return this;
    }

    public RecipeBuilder scanner(@NotNull ItemStack itemStack) {
        return this.scanner(scannerBuilder -> (ScannerBuilder)scannerBuilder.researchStack(itemStack));
    }

    private void addOutputMaterialInfo() {
        List list = this.output.getOrDefault(ItemRecipeCapability.CAP, new ObjectArrayList());
        if (!(list.size() != 1 || this.tempItemMaterialStacks.isEmpty() && this.tempFluidStacks.isEmpty())) {
            Object object;
            Item item = null;
            long l = 0L;
            Iterator iterator = ((Content)list.get((int)0)).content;
            if (iterator instanceof FastSizedIngredient && !((FastSizedIngredient)(object = (FastSizedIngredient)((Object)iterator))).m_43947_()) {
                item = ((FastSizedIngredient)object).getInner().m_43908_()[0].m_41720_();
                l = ((FastSizedIngredient)object).getAmount();
            }
            if (item == null || item == Items.f_41852_) {
                return;
            }
            object = new Reference2LongOpenHashMap();
            for (MaterialStack materialStack : this.tempItemMaterialStacks) {
                ((Reference2LongOpenHashMap)object).addTo(materialStack.material(), materialStack.amount() / l);
            }
            if (this.fluidMaterialInfo) {
                for (MaterialStack materialStack : this.tempFluidStacks) {
                    ((Reference2LongOpenHashMap)object).addTo(materialStack.material(), materialStack.amount() / l);
                }
            }
            if (!((Reference2LongOpenHashMap)object).isEmpty()) {
                ItemMaterialData.registerMaterialInfo(item, new ItemMaterialInfo((Reference2LongMap)object));
            }
        }
    }

    @Deprecated
    public RecipeBuilder inputItems(Ingredient ... ingredientArray) {
        throw new UnsupportedOperationException("Not supported yet");
    }

    @Deprecated
    public RecipeBuilder chancedOutput(ItemStack itemStack, String string, int n) {
        throw new UnsupportedOperationException("Not supported yet");
    }

    @Deprecated
    public RecipeBuilder chancedOutput(TagPrefix tagPrefix, Material material, int n, String string, int n2) {
        throw new UnsupportedOperationException("Not supported yet");
    }

    @Deprecated
    public RecipeBuilder chancedOutput(TagPrefix tagPrefix, Material material, String string, int n) {
        throw new UnsupportedOperationException("Not supported yet");
    }

    @Deprecated
    public RecipeBuilder chancedOutput(Item item, int n, String string, int n2) {
        throw new UnsupportedOperationException("Not supported yet");
    }

    @Deprecated
    public RecipeBuilder chancedOutput(Item item, String string, int n) {
        throw new UnsupportedOperationException("Not supported yet");
    }

    @Deprecated
    public RecipeBuilder chancedFluidOutput(FluidStack fluidStack, String string, int n) {
        throw new UnsupportedOperationException("Not supported yet");
    }

    @Deprecated
    public RecipeBuilder researchWithoutRecipe(@NotNull String string) {
        throw new UnsupportedOperationException("Not supported yet");
    }

    @Deprecated
    public RecipeBuilder researchWithoutRecipe(@NotNull String string, @NotNull ItemStack itemStack) {
        throw new UnsupportedOperationException("Not supported yet");
    }

    @Deprecated
    public RecipeBuilder scannerResearch(UnaryOperator<ResearchRecipeBuilder.ScannerRecipeBuilder> unaryOperator) {
        throw new UnsupportedOperationException("Not supported yet");
    }

    @Deprecated
    public RecipeBuilder scannerResearch(@NotNull ItemStack itemStack) {
        throw new UnsupportedOperationException("Not supported yet");
    }

    @Deprecated
    public RecipeBuilder stationResearch(UnaryOperator<ResearchRecipeBuilder.StationRecipeBuilder> unaryOperator) {
        throw new UnsupportedOperationException("Not supported yet");
    }

    public RecipeBuilder displayPriority(int n) {
        this.displayPriority = n;
        return this;
    }

    public RecipeBuilder priority(int n) {
        this.priority = n;
        return this;
    }

    public RecipeBuilder tier(int n) {
        this.tier = n;
        return this;
    }
}

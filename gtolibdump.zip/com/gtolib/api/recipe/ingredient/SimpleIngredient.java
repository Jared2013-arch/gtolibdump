package com.gtolib.api.recipe.ingredient;

import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;

public record SimpleIngredient(@NotNull ItemStack stack, int amount) {
}

package com.gtolib.api.recipe.ingredient;

import com.google.gson.JsonObject;
import com.gtolib.api.recipe.ingredient.CircuitIngredient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.common.crafting.IIngredientSerializer;
import org.jetbrains.annotations.NotNull;

class CircuitIngredient$1
implements IIngredientSerializer<CircuitIngredient> {
    CircuitIngredient$1() {
    }

    @NotNull
    public CircuitIngredient parse(FriendlyByteBuf friendlyByteBuf) {
        return CircuitIngredient.of(friendlyByteBuf.m_130242_());
    }

    @NotNull
    public CircuitIngredient parse(JsonObject jsonObject) {
        return CircuitIngredient.of(jsonObject.get("configuration").getAsInt());
    }

    public void write(FriendlyByteBuf friendlyByteBuf, CircuitIngredient circuitIngredient) {
        friendlyByteBuf.m_130130_(circuitIngredient.configuration);
    }
}

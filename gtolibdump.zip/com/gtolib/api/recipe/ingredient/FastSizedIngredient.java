package com.gtolib.api.recipe.ingredient;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.gregtechceu.gtceu.api.recipe.ingredient.SizedIngredient;
import com.gregtechceu.gtceu.core.mixins.StrictNBTIngredientAccessor;
import com.gregtechceu.gtceu.utils.ItemStackHashStrategy;
import com.gtolib.IItem;
import com.gtolib.api.recipe.ingredient.CircuitIngredient;
import com.gtolib.utils.EmptyStream;
import com.gtolib.utils.MathUtil;
import it.unimi.dsi.fastutil.Hash;
import it.unimi.dsi.fastutil.ints.IntList;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;
import net.minecraftforge.common.crafting.IIngredientSerializer;
import net.minecraftforge.common.crafting.StrictNBTIngredient;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class FastSizedIngredient
extends Ingredient {
    private static final ItemStack[] EMPTY_STACKS = new ItemStack[0];
    private static final EmptyStream<Ingredient.Value> EMPTY_STREAM = EmptyStream.create(new Ingredient.Value[0]);
    private static final FastSizedIngredient EMPTY = new FastSizedIngredient(Ingredient.m_151265_(), 0L);
    private long amount;
    private final Ingredient inner;
    private ItemStack[] cachedItemStacks;
    private int hashCode;
    private final boolean isEmpty;
    private final Ingredient.Value value;
    public static final IIngredientSerializer<FastSizedIngredient> SERIALIZER = new IIngredientSerializer<FastSizedIngredient>(){

        @NotNull
        public FastSizedIngredient parse(FriendlyByteBuf friendlyByteBuf) {
            long l = friendlyByteBuf.m_130258_();
            Ingredient ingredient = Ingredient.m_43940_((FriendlyByteBuf)friendlyByteBuf);
            if (ingredient.m_43947_() || l == 0L) {
                return EMPTY;
            }
            return new FastSizedIngredient(ingredient, l);
        }

        @NotNull
        public FastSizedIngredient parse(JsonObject jsonObject) {
            long l = jsonObject.get("count").getAsLong();
            Ingredient ingredient = Ingredient.m_43917_((JsonElement)jsonObject.get("ingredient"));
            if (ingredient.m_43947_() || l == 0L) {
                return EMPTY;
            }
            return new FastSizedIngredient(ingredient, l);
        }

        public void write(FriendlyByteBuf friendlyByteBuf, FastSizedIngredient fastSizedIngredient) {
            friendlyByteBuf.m_130103_(fastSizedIngredient.getAmount());
            fastSizedIngredient.getInner().m_43923_(friendlyByteBuf);
        }
    };
    public static final Hash.Strategy<Ingredient> HASH_STRATEGY = new Hash.Strategy<Ingredient>(){

        private static boolean valueEquals(Ingredient.Value value, Ingredient.Value value2) {
            if (value instanceof Ingredient.TagValue) {
                Ingredient.TagValue tagValue = (Ingredient.TagValue)((Object)value);
                if (!(value2 instanceof Ingredient.TagValue)) {
                    return false;
                }
                Ingredient.TagValue tagValue2 = (Ingredient.TagValue)((Object)value2);
                return tagValue.f_43959_ == tagValue2.f_43959_;
            }
            if (value instanceof Ingredient.ItemValue) {
                Ingredient.ItemValue itemValue = (Ingredient.ItemValue)((Object)value);
                if (!(value2 instanceof Ingredient.ItemValue)) {
                    return false;
                }
                Ingredient.ItemValue itemValue2 = (Ingredient.ItemValue)((Object)value2);
                return itemValue.f_43951_.m_41720_() == itemValue2.f_43951_.m_41720_();
            }
            return true;
        }

        public int hashCode(Ingredient ingredient) {
            int n = 537;
            if (ingredient instanceof StrictNBTIngredientAccessor) {
                StrictNBTIngredientAccessor strictNBTIngredientAccessor = (StrictNBTIngredientAccessor)((Object)ingredient);
                n *= 31 * ItemStackHashStrategy.ITEM_AND_TAG.hashCode(strictNBTIngredientAccessor.getStack());
            } else if (ingredient != null) {
                for (Ingredient.Value value : ingredient.f_43902_) {
                    if (value instanceof Ingredient.TagValue) {
                        Ingredient.TagValue tagValue = (Ingredient.TagValue)((Object)value);
                        n *= 31 * tagValue.f_43959_.hashCode();
                        continue;
                    }
                    if (!(value instanceof Ingredient.ItemValue)) continue;
                    Ingredient.ItemValue itemValue = (Ingredient.ItemValue)((Object)value);
                    n *= 31 * ItemStackHashStrategy.ITEM.hashCode(itemValue.f_43951_);
                }
            }
            return n;
        }

        public boolean equals(Ingredient ingredient, Ingredient ingredient2) {
            if (ingredient == ingredient2) {
                return true;
            }
            if (ingredient instanceof StrictNBTIngredient) {
                StrictNBTIngredient strictNBTIngredient = (StrictNBTIngredient)ingredient;
                if (ingredient2 instanceof StrictNBTIngredientAccessor) {
                    StrictNBTIngredientAccessor strictNBTIngredientAccessor = (StrictNBTIngredientAccessor)((Object)ingredient2);
                    return strictNBTIngredient.test(strictNBTIngredientAccessor.getStack());
                }
                return false;
            }
            if (ingredient == null || ingredient2 == null) {
                return false;
            }
            Ingredient.Value[] valueArray = ingredient.f_43902_;
            Ingredient.Value[] valueArray2 = ingredient2.f_43902_;
            if (valueArray.length != valueArray2.length) {
                return false;
            }
            for (int i = 0; i < valueArray.length; ++i) {
                if (2.valueEquals(valueArray[i], valueArray2[i])) continue;
                return false;
            }
            return true;
        }
    };

    private FastSizedIngredient(Ingredient ingredient, long l) {
        super(EMPTY_STREAM);
        this.amount = l;
        this.inner = ingredient;
        this.isEmpty = ingredient.m_43947_();
        this.value = this.isEmpty ? null : (ingredient.getClass() == Ingredient.class ? ingredient.f_43902_[0] : null);
    }

    private FastSizedIngredient(FastSizedIngredient fastSizedIngredient) {
        super(EMPTY_STREAM);
        this.amount = fastSizedIngredient.amount;
        this.inner = fastSizedIngredient.inner;
        this.isEmpty = fastSizedIngredient.isEmpty;
        this.value = fastSizedIngredient.value;
        this.hashCode = fastSizedIngredient.hashCode;
    }

    public static FastSizedIngredient create(ItemLike itemLike) {
        return FastSizedIngredient.create(itemLike, 1L);
    }

    public static FastSizedIngredient create(ItemLike itemLike, long l) {
        Item item = itemLike.m_5456_();
        if (item == Items.f_41852_ || l == 0L) {
            return EMPTY;
        }
        return new FastSizedIngredient(((IItem)((Object)item)).gtolib$getInnerIngredient(), l);
    }

    public static FastSizedIngredient create(ItemStack itemStack) {
        Item item = itemStack.m_41720_();
        if (item == Items.f_41852_) {
            return EMPTY;
        }
        CompoundTag compoundTag = itemStack.m_41783_();
        boolean bl = compoundTag != null && !compoundTag.m_128456_();
        return new FastSizedIngredient(bl ? StrictNBTIngredient.of(itemStack) : ((IItem)((Object)item)).gtolib$getInnerIngredient(), itemStack.m_41613_());
    }

    public static FastSizedIngredient create(ItemStack itemStack, long l) {
        Item item = itemStack.m_41720_();
        if (item == Items.f_41852_ || l == 0L) {
            return EMPTY;
        }
        CompoundTag compoundTag = itemStack.m_41783_();
        boolean bl = compoundTag != null && !compoundTag.m_128456_();
        return new FastSizedIngredient(bl ? StrictNBTIngredient.of(itemStack) : ((IItem)((Object)item)).gtolib$getInnerIngredient(), l);
    }

    public static FastSizedIngredient create(FastSizedIngredient fastSizedIngredient, long l) {
        FastSizedIngredient fastSizedIngredient2 = new FastSizedIngredient(fastSizedIngredient);
        fastSizedIngredient2.amount = l;
        return fastSizedIngredient2;
    }

    public static FastSizedIngredient create(Ingredient ingredient, long l) {
        if (ingredient.m_43947_() || l == 0L) {
            return EMPTY;
        }
        return new FastSizedIngredient(ingredient, l);
    }

    private static FastSizedIngredient create(Ingredient ingredient) {
        if (ingredient.m_43947_()) {
            return EMPTY;
        }
        return new FastSizedIngredient(ingredient, 1L);
    }

    public static FastSizedIngredient create(TagKey<Item> tagKey, long l) {
        return new FastSizedIngredient(Ingredient.m_204132_(tagKey), l);
    }

    public static Ingredient toCompatibleIngredient(Ingredient ingredient) {
        if (ingredient instanceof FastSizedIngredient) {
            return ingredient;
        }
        if (ingredient instanceof CircuitIngredient) {
            return ingredient;
        }
        if (ingredient.getClass() == Ingredient.class) {
            return FastSizedIngredient.create(ingredient);
        }
        throw new IllegalArgumentException("Unsupported ingredients");
    }

    public static Ingredient copy(Ingredient ingredient) {
        if (ingredient instanceof FastSizedIngredient) {
            FastSizedIngredient fastSizedIngredient = (FastSizedIngredient)ingredient;
            return new FastSizedIngredient(fastSizedIngredient);
        }
        if (ingredient instanceof CircuitIngredient) {
            CircuitIngredient circuitIngredient = (CircuitIngredient)ingredient;
            return circuitIngredient;
        }
        return FastSizedIngredient.create(ingredient);
    }

    public static Ingredient getInner(Ingredient ingredient) {
        if (ingredient instanceof FastSizedIngredient) {
            FastSizedIngredient fastSizedIngredient = (FastSizedIngredient)ingredient;
            return fastSizedIngredient.inner;
        }
        return ingredient;
    }

    public int getSaturatedAmount() {
        return MathUtil.saturatedCast(this.amount);
    }

    @NotNull
    public IIngredientSerializer<? extends Ingredient> getSerializer() {
        return SERIALIZER;
    }

    @Override
    @NotNull
    public JsonElement m_43942_() {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("type", SizedIngredient.TYPE.toString());
        jsonObject.addProperty("count", this.amount);
        jsonObject.add("ingredient", this.inner.m_43942_());
        return jsonObject;
    }

    public boolean testItem(@NotNull Item item) {
        Ingredient.Value value = this.value;
        if (value instanceof Ingredient.TagValue) {
            Ingredient.TagValue tagValue = (Ingredient.TagValue)((Object)value);
            return item.m_204114_().m_203656_(tagValue.f_43959_);
        }
        value = this.value;
        if (value instanceof Ingredient.ItemValue) {
            Ingredient.ItemValue itemValue = (Ingredient.ItemValue)((Object)value);
            return item == itemValue.f_43951_.m_41720_();
        }
        Ingredient.Value value2 = this.inner.f_43902_[0];
        if (value2 instanceof Ingredient.ItemValue) {
            Ingredient.ItemValue itemValue = (Ingredient.ItemValue)((Object)value2);
            return item == itemValue.f_43951_.m_41720_();
        }
        return this.inner.test(((IItem)((Object)item)).gtolib$getReadOnlyStack());
    }

    @Override
    public boolean test(@Nullable ItemStack itemStack) {
        if (itemStack == null) {
            return false;
        }
        Item item = itemStack.m_41720_();
        if (this.isEmpty) {
            return item == Items.f_41852_;
        }
        Ingredient.Value value = this.value;
        if (value instanceof Ingredient.TagValue) {
            Ingredient.TagValue tagValue = (Ingredient.TagValue)((Object)value);
            return item.m_204114_().m_203656_(tagValue.f_43959_);
        }
        value = this.value;
        if (value instanceof Ingredient.ItemValue) {
            Ingredient.ItemValue itemValue = (Ingredient.ItemValue)((Object)value);
            return item == itemValue.f_43951_.m_41720_();
        }
        return this.inner.test(itemStack);
    }

    @Override
    public ItemStack @NotNull [] m_43908_() {
        if (this.cachedItemStacks != null) {
            return this.cachedItemStacks;
        }
        this.cachedItemStacks = this.computeItemsArray();
        return this.cachedItemStacks;
    }

    private ItemStack[] computeItemsArray() {
        ItemStack[] itemStackArray = this.inner.m_43908_();
        if (itemStackArray.length < 1) {
            return EMPTY_STACKS;
        }
        if (itemStackArray.length == 1) {
            ItemStack itemStack = itemStackArray[0];
            ItemStack itemStack2 = itemStack.m_41777_();
            itemStack2.m_41764_(MathUtil.saturatedCast(this.amount));
            return new ItemStack[]{itemStack2};
        }
        ObjectArrayList objectArrayList = new ObjectArrayList(this.inner.m_43908_().length);
        for (ItemStack itemStack : this.inner.m_43908_()) {
            ItemStack itemStack3 = itemStack.m_41777_();
            itemStack3.m_41764_(MathUtil.saturatedCast(this.amount));
            objectArrayList.add(itemStack3);
        }
        return objectArrayList.toArray((T[])new ItemStack[0]);
    }

    public void setAmount(long l) {
        this.amount = l;
        if (this.cachedItemStacks != null) {
            for (ItemStack itemStack : this.cachedItemStacks) {
                itemStack.m_41764_(MathUtil.saturatedCast(l));
            }
        }
    }

    @Override
    @NotNull
    public IntList m_43931_() {
        return this.inner.m_43931_();
    }

    @Override
    public boolean m_43947_() {
        return this.isEmpty;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof FastSizedIngredient)) {
            return false;
        }
        FastSizedIngredient fastSizedIngredient = (FastSizedIngredient)object;
        if (this.inner == fastSizedIngredient.inner) {
            return true;
        }
        return HASH_STRATEGY.equals((Object)this.inner, (Object)fastSizedIngredient.inner);
    }

    public int hashCode() {
        if (this.hashCode == 0) {
            this.hashCode = HASH_STRATEGY.hashCode((Object)this.inner);
        }
        return this.hashCode;
    }

    public long getAmount() {
        return this.amount;
    }

    public Ingredient getInner() {
        return this.inner;
    }
}

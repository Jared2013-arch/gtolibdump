package com.gtolib.api.recipe.ingredient;

import net.minecraftforge.fluids.FluidStack;
import org.jetbrains.annotations.NotNull;

public record SimpleFluidIngredient(@NotNull FluidStack stack, int amount) {
}

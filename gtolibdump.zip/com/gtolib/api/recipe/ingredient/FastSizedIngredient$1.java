package com.gtolib.api.recipe.ingredient;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.gtolib.api.recipe.ingredient.FastSizedIngredient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.common.crafting.IIngredientSerializer;
import org.jetbrains.annotations.NotNull;

class FastSizedIngredient$1
implements IIngredientSerializer<FastSizedIngredient> {
    FastSizedIngredient$1() {
    }

    @NotNull
    public FastSizedIngredient parse(FriendlyByteBuf friendlyByteBuf) {
        long l = friendlyByteBuf.m_130258_();
        Ingredient ingredient = Ingredient.m_43940_((FriendlyByteBuf)friendlyByteBuf);
        if (ingredient.m_43947_() || l == 0L) {
            return EMPTY;
        }
        return new FastSizedIngredient(ingredient, l);
    }

    @NotNull
    public FastSizedIngredient parse(JsonObject jsonObject) {
        long l = jsonObject.get("count").getAsLong();
        Ingredient ingredient = Ingredient.m_43917_((JsonElement)jsonObject.get("ingredient"));
        if (ingredient.m_43947_() || l == 0L) {
            return EMPTY;
        }
        return new FastSizedIngredient(ingredient, l);
    }

    public void write(FriendlyByteBuf friendlyByteBuf, FastSizedIngredient fastSizedIngredient) {
        friendlyByteBuf.m_130103_(fastSizedIngredient.getAmount());
        fastSizedIngredient.getInner().m_43923_(friendlyByteBuf);
    }
}

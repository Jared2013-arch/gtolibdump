package com.gtolib.api.recipe.ingredient;

import com.gregtechceu.gtceu.core.mixins.StrictNBTIngredientAccessor;
import com.gregtechceu.gtceu.utils.ItemStackHashStrategy;
import it.unimi.dsi.fastutil.Hash;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.common.crafting.StrictNBTIngredient;

class FastSizedIngredient$2
implements Hash.Strategy<Ingredient> {
    FastSizedIngredient$2() {
    }

    private static boolean valueEquals(Ingredient.Value value, Ingredient.Value value2) {
        if (value instanceof Ingredient.TagValue) {
            Ingredient.TagValue tagValue = (Ingredient.TagValue)((Object)value);
            if (!(value2 instanceof Ingredient.TagValue)) {
                return false;
            }
            Ingredient.TagValue tagValue2 = (Ingredient.TagValue)((Object)value2);
            return tagValue.f_43959_ == tagValue2.f_43959_;
        }
        if (value instanceof Ingredient.ItemValue) {
            Ingredient.ItemValue itemValue = (Ingredient.ItemValue)((Object)value);
            if (!(value2 instanceof Ingredient.ItemValue)) {
                return false;
            }
            Ingredient.ItemValue itemValue2 = (Ingredient.ItemValue)((Object)value2);
            return itemValue.f_43951_.m_41720_() == itemValue2.f_43951_.m_41720_();
        }
        return true;
    }

    public int hashCode(Ingredient ingredient) {
        int n = 537;
        if (ingredient instanceof StrictNBTIngredientAccessor) {
            StrictNBTIngredientAccessor strictNBTIngredientAccessor = (StrictNBTIngredientAccessor)((Object)ingredient);
            n *= 31 * ItemStackHashStrategy.ITEM_AND_TAG.hashCode(strictNBTIngredientAccessor.getStack());
        } else if (ingredient != null) {
            for (Ingredient.Value value : ingredient.f_43902_) {
                if (value instanceof Ingredient.TagValue) {
                    Ingredient.TagValue tagValue = (Ingredient.TagValue)((Object)value);
                    n *= 31 * tagValue.f_43959_.hashCode();
                    continue;
                }
                if (!(value instanceof Ingredient.ItemValue)) continue;
                Ingredient.ItemValue itemValue = (Ingredient.ItemValue)((Object)value);
                n *= 31 * ItemStackHashStrategy.ITEM.hashCode(itemValue.f_43951_);
            }
        }
        return n;
    }

    public boolean equals(Ingredient ingredient, Ingredient ingredient2) {
        if (ingredient == ingredient2) {
            return true;
        }
        if (ingredient instanceof StrictNBTIngredient) {
            StrictNBTIngredient strictNBTIngredient = (StrictNBTIngredient)ingredient;
            if (ingredient2 instanceof StrictNBTIngredientAccessor) {
                StrictNBTIngredientAccessor strictNBTIngredientAccessor = (StrictNBTIngredientAccessor)((Object)ingredient2);
                return strictNBTIngredient.test(strictNBTIngredientAccessor.getStack());
            }
            return false;
        }
        if (ingredient == null || ingredient2 == null) {
            return false;
        }
        Ingredient.Value[] valueArray = ingredient.f_43902_;
        Ingredient.Value[] valueArray2 = ingredient2.f_43902_;
        if (valueArray.length != valueArray2.length) {
            return false;
        }
        for (int i = 0; i < valueArray.length; ++i) {
            if (FastSizedIngredient$2.valueEquals(valueArray[i], valueArray2[i])) continue;
            return false;
        }
        return true;
    }
}

package com.gtolib.api.recipe.ingredient;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.gregtechceu.gtceu.api.recipe.ingredient.FluidIngredient;
import com.gtolib.IFluid;
import com.gtolib.utils.MathUtil;
import com.gtolib.utils.RLUtils;
import com.mojang.serialization.Codec;
import java.lang.invoke.LambdaMetafactory;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Stream;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import net.minecraftforge.common.crafting.CraftingHelper;
import net.minecraftforge.fluids.FluidStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class FastFluidIngredient
extends FluidIngredient {
    private static final FluidStack[] EMPTY_STACKS = new FluidStack[0];
    public static final Codec<FluidIngredient> CODEC = ExtraCodecs.f_252400_.xmap(FastFluidIngredient::fromJson, (Function<FluidIngredient, JsonElement>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, toJson(), (Lcom/gregtechceu/gtceu/api/recipe/ingredient/FluidIngredient;)Lcom/google/gson/JsonElement;)());
    public static final FluidIngredient.Value[] EMPTY_ARRAY = new FluidIngredient.Value[0];
    public static final FastFluidIngredient EMPTY = new FastFluidIngredient(null, 0L, null);
    private int hashCode;
    private final FluidIngredient.FluidValue value;
    private final boolean isEmpty;

    private FastFluidIngredient(@Nullable FluidIngredient.FluidValue fluidValue, long l, @Nullable CompoundTag compoundTag) {
        super(EMPTY_ARRAY, 0L, compoundTag);
        this.value = fluidValue;
        this.amount = l;
        this.isEmpty = fluidValue == null;
    }

    private static FastFluidIngredient fromValues(FluidIngredient.FluidValue[] fluidValueArray, long l, @Nullable CompoundTag compoundTag) {
        if (fluidValueArray.length == 0) {
            return EMPTY;
        }
        return new FastFluidIngredient(fluidValueArray[0], l, compoundTag);
    }

    public void toNetwork(FriendlyByteBuf friendlyByteBuf) {
        if (this.isEmpty) {
            friendlyByteBuf.writeBoolean(true);
        } else {
            friendlyByteBuf.writeBoolean(false);
            friendlyByteBuf.m_130130_(BuiltInRegistries.f_257020_.m_7447_(this.value.fluid));
            friendlyByteBuf.m_130103_(this.amount);
            friendlyByteBuf.m_130079_(this.nbt);
        }
    }

    public JsonElement toJson() {
        JsonObject jsonObject = new JsonObject();
        if (this.isEmpty) {
            jsonObject.addProperty("empty", true);
        } else {
            jsonObject.addProperty("amount", this.amount);
            if (this.nbt != null) {
                jsonObject.addProperty("nbt", this.nbt.m_7916_());
            }
            jsonObject.addProperty("fluid", ((IFluid)((Object)this.value.fluid)).gtolib$getIdString());
        }
        return jsonObject;
    }

    public FastFluidIngredient copy() {
        if (this.isEmpty) {
            return EMPTY;
        }
        FastFluidIngredient fastFluidIngredient = new FastFluidIngredient(this.value, this.amount, this.nbt);
        fastFluidIngredient.hashCode = this.hashCode;
        if (this.stacks != null) {
            fastFluidIngredient.stacks = this.stacks;
        }
        return fastFluidIngredient;
    }

    public boolean testFluid(@NotNull Fluid fluid) {
        return fluid == this.value.fluid;
    }

    @Override
    public boolean test(@Nullable FluidStack fluidStack) {
        if (fluidStack == null) {
            return false;
        }
        if (this.isEmpty) {
            return fluidStack.isEmpty();
        }
        if (this.nbt != null && !this.nbt.equals(fluidStack.getTag())) {
            return false;
        }
        return fluidStack.getFluid() == this.value.fluid;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof FastFluidIngredient)) {
            return false;
        }
        FastFluidIngredient fastFluidIngredient = (FastFluidIngredient)object;
        if (fastFluidIngredient.isEmpty && !this.isEmpty) {
            return false;
        }
        if (!Objects.equals(this.nbt, fastFluidIngredient.nbt)) {
            return false;
        }
        if (this.value != null) {
            return this.value.fluid == fastFluidIngredient.value.fluid;
        }
        return true;
    }

    public int hashCode() {
        if (this.hashCode == 0) {
            this.hashCode = Objects.hashCode(this.value) + 31 * Objects.hashCode(this.nbt);
        }
        return this.hashCode;
    }

    @Override
    public boolean isEmpty() {
        return this.isEmpty;
    }

    private FluidStack[] getFluidStack() {
        if (this.stacks == null) {
            if (this.isEmpty) {
                this.stacks = EMPTY_STACKS;
            } else {
                this.stacks = new FluidStack[]{new FluidStack(this.value.fluid, this.getAmount(), this.nbt)};
                this.changed = false;
            }
        }
        return this.stacks;
    }

    @Override
    public FluidStack[] getStacks() {
        if (this.changed || this.stacks == null) {
            if (this.isEmpty) {
                this.stacks = EMPTY_STACKS;
            } else {
                this.stacks = new FluidStack[]{new FluidStack(this.value.fluid, this.getAmount(), this.nbt)};
                this.changed = false;
            }
        }
        return this.stacks;
    }

    public int getAmount() {
        return MathUtil.saturatedCast(this.amount);
    }

    public long amount() {
        return this.amount;
    }

    public static void setAmount(FluidIngredient fluidIngredient, long l) {
        fluidIngredient.setAmount(l);
    }

    public static long getAmount(FluidIngredient fluidIngredient) {
        return fluidIngredient.amount;
    }

    @Nullable
    public static Fluid getFluid(FluidIngredient fluidIngredient) {
        if (fluidIngredient.isEmpty()) {
            return null;
        }
        return ((FastFluidIngredient)fluidIngredient).value.fluid;
    }

    public static FluidStack[] getFluidStack(Object object) {
        return ((FastFluidIngredient)object).getFluidStack();
    }

    public static FastFluidIngredient of(int n, Fluid ... fluidArray) {
        return FastFluidIngredient.of((long)n, fluidArray);
    }

    public static FastFluidIngredient of(long l, Fluid ... fluidArray) {
        if (fluidArray.length == 0) {
            return EMPTY;
        }
        Fluid fluid = fluidArray[0];
        if (fluid == null || fluid == Fluids.f_76191_) {
            return EMPTY;
        }
        return new FastFluidIngredient(((IFluid)((Object)fluid)).gtolib$getFluidValue(), l, null);
    }

    public static FastFluidIngredient of(FluidStack ... fluidStackArray) {
        if (fluidStackArray.length == 0) {
            return EMPTY;
        }
        Fluid fluid = fluidStackArray[0].getFluid();
        if (fluid == Fluids.f_76191_) {
            return EMPTY;
        }
        return new FastFluidIngredient(((IFluid)((Object)fluid)).gtolib$getFluidValue(), (long)fluidStackArray[0].getAmount(), fluidStackArray[0].getTag());
    }

    public static FastFluidIngredient of(Stream<Fluid> stream, int n, CompoundTag compoundTag) {
        return FastFluidIngredient.fromValues((FluidIngredient.FluidValue[])stream.filter(fluid -> fluid != null && !fluid.m_6212_(Fluids.f_76191_)).map(fluid -> ((IFluid)((Object)fluid)).gtolib$getFluidValue()).toArray(FluidIngredient.FluidValue[]::new), n, compoundTag);
    }

    public static FastFluidIngredient fromNetwork(FriendlyByteBuf friendlyByteBuf) {
        if (friendlyByteBuf.readBoolean()) {
            return EMPTY;
        }
        Fluid fluid = (Fluid)BuiltInRegistries.f_257020_.m_7942_(friendlyByteBuf.m_130242_());
        if (fluid == Fluids.f_76191_) {
            return EMPTY;
        }
        return new FastFluidIngredient(((IFluid)((Object)fluid)).gtolib$getFluidValue(), friendlyByteBuf.m_130258_(), friendlyByteBuf.m_130260_());
    }

    public static FastFluidIngredient fromJson(@Nullable JsonElement jsonElement) {
        if (jsonElement == null || jsonElement.isJsonNull()) {
            throw new JsonSyntaxException("Fluid ingredient cannot be null");
        }
        if (!jsonElement.isJsonObject()) {
            throw new JsonSyntaxException("Expected fluid ingredient to be object");
        }
        JsonObject jsonObject = GsonHelper.m_13918_(jsonElement, "ingredient");
        if (jsonObject.has("empty")) {
            return EMPTY;
        }
        long l = GsonHelper.m_13828_(jsonObject, "amount", 0L);
        CompoundTag compoundTag = jsonObject.has("nbt") ? CraftingHelper.getNBT(jsonObject.get("nbt")) : null;
        String string = GsonHelper.m_13906_(jsonObject, "fluid");
        Fluid fluid = (Fluid)BuiltInRegistries.f_257020_.m_7745_(RLUtils.parse(string));
        if (fluid == Fluids.f_76191_) {
            return EMPTY;
        }
        return new FastFluidIngredient(((IFluid)((Object)fluid)).gtolib$getFluidValue(), l, compoundTag);
    }
}

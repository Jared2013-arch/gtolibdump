package com.gtolib.api.recipe;

import com.gregtechceu.gtceu.api.GTValues;
import com.gregtechceu.gtceu.api.capability.recipe.FluidRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.capability.recipe.IRecipeCapabilityHolder;
import com.gregtechceu.gtceu.api.capability.recipe.IRecipeHandler;
import com.gregtechceu.gtceu.api.capability.recipe.ItemRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.gregtechceu.gtceu.api.machine.SimpleTieredMachine;
import com.gregtechceu.gtceu.api.machine.feature.IComputationContainerMachine;
import com.gregtechceu.gtceu.api.machine.feature.IRecipeLogicMachine;
import com.gregtechceu.gtceu.api.machine.feature.IVoidable;
import com.gregtechceu.gtceu.api.machine.multiblock.WorkableElectricMultiblockMachine;
import com.gregtechceu.gtceu.api.machine.trait.RecipeHandlerList;
import com.gregtechceu.gtceu.api.machine.trait.RecipeLogic;
import com.gregtechceu.gtceu.api.recipe.ActionResult;
import com.gregtechceu.gtceu.api.recipe.chance.boost.ChanceBoostFunction;
import com.gregtechceu.gtceu.api.recipe.content.Content;
import com.gregtechceu.gtceu.api.recipe.content.ContentModifier;
import com.gtocore.common.machine.trait.InternalSlotRecipeHandler;
import com.gtolib.api.machine.feature.IElectricMachine;
import com.gtolib.api.machine.feature.IEnhancedRecipeLogicMachine;
import com.gtolib.api.machine.feature.multiblock.IExtendedRecipeCapabilityHolder;
import com.gtolib.api.machine.mana.feature.IManaContainerMachine;
import com.gtolib.api.machine.trait.IEnhancedRecipeLogic;
import com.gtolib.api.recipe.ContentBuilder;
import com.gtolib.api.recipe.IdleReason;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.RecipeCapabilityMap;
import com.gtolib.api.recipe.RecipeHelper;
import com.gtolib.api.recipe.SeparateContent;
import com.gtolib.api.recipe.lookup.MapIngredient;
import com.gtolib.utils.holder.LongObjectHolder;
import it.unimi.dsi.fastutil.ints.Int2LongMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.ParametersAreNonnullByDefault;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@ParametersAreNonnullByDefault
public final class RecipeRunner {
    public static boolean checkTier(IRecipeLogicMachine iRecipeLogicMachine, Recipe recipe) {
        int n = recipe.tier;
        if (n > 0) {
            boolean bl = true;
            if (iRecipeLogicMachine instanceof WorkableElectricMultiblockMachine) {
                WorkableElectricMultiblockMachine workableElectricMultiblockMachine = (WorkableElectricMultiblockMachine)((Object)iRecipeLogicMachine);
                bl = n <= workableElectricMultiblockMachine.getOverclockTier();
            } else if (iRecipeLogicMachine instanceof SimpleTieredMachine) {
                SimpleTieredMachine simpleTieredMachine = (SimpleTieredMachine)((Object)iRecipeLogicMachine);
                boolean bl2 = bl = n <= simpleTieredMachine.getOverclockTier();
            }
            if (!bl) {
                IdleReason.setIdleReason(iRecipeLogicMachine, IdleReason.VOLTAGE_TIER_NOT_SATISFIES);
                return false;
            }
        }
        return true;
    }

    public static boolean check(IRecipeLogicMachine iRecipeLogicMachine, @Nullable Recipe recipe) {
        if (recipe == null || !RecipeRunner.matchTickRecipe(iRecipeLogicMachine, recipe)) {
            return false;
        }
        if (recipe.parallels > 1L) {
            return true;
        }
        return RecipeRunner.matchRecipe(iRecipeLogicMachine, recipe);
    }

    public static boolean checkConditions(IRecipeLogicMachine iRecipeLogicMachine, Recipe recipe) {
        ActionResult actionResult = RecipeHelper.checkConditions(recipe, iRecipeLogicMachine.getRecipeLogic());
        if (actionResult.isSuccess()) {
            return true;
        }
        RecipeLogic recipeLogic = iRecipeLogicMachine.getRecipeLogic();
        if (recipeLogic instanceof IEnhancedRecipeLogic) {
            IEnhancedRecipeLogic iEnhancedRecipeLogic = (IEnhancedRecipeLogic)((Object)recipeLogic);
            iEnhancedRecipeLogic.gtolib$setIdleReason(actionResult.reason());
        }
        return false;
    }

    public static boolean fastMatchRecipe(IRecipeCapabilityHolder iRecipeCapabilityHolder, Recipe recipe) {
        RecipeHandlerList recipeHandlerList = iRecipeCapabilityHolder.getCurrentHandlerList();
        if (recipe.mapIngredient == null || recipeHandlerList == null) {
            return RecipeRunner.matchRecipeInput(iRecipeCapabilityHolder, recipe);
        }
        if (iRecipeCapabilityHolder.isChange()) {
            MapIngredient.convertList(iRecipeCapabilityHolder, recipeHandlerList);
        }
        ObjectIterator objectIterator = recipe.mapIngredient.int2LongEntrySet().fastIterator();
        while (objectIterator.hasNext()) {
            Int2LongMap.Entry entry = (Int2LongMap.Entry)objectIterator.next();
            long l = recipeHandlerList.intIngredientMap.get(entry.getIntKey());
            if (l >= entry.getLongValue()) continue;
            iRecipeCapabilityHolder.setCurrentHandlerList(null, null);
            return false;
        }
        iRecipeCapabilityHolder.setCurrentHandlerList(recipeHandlerList, recipe);
        return true;
    }

    public static boolean matchRecipe(IRecipeCapabilityHolder iRecipeCapabilityHolder, Recipe recipe) {
        if (iRecipeCapabilityHolder instanceof IEnhancedRecipeLogicMachine) {
            IEnhancedRecipeLogicMachine iEnhancedRecipeLogicMachine = (IEnhancedRecipeLogicMachine)iRecipeCapabilityHolder;
            return iEnhancedRecipeLogicMachine.matchRecipe(recipe);
        }
        return RecipeRunner.matchRecipeInput(iRecipeCapabilityHolder, recipe) && RecipeRunner.matchRecipeOutput(iRecipeCapabilityHolder, recipe);
    }

    public static boolean matchTickRecipe(IRecipeCapabilityHolder iRecipeCapabilityHolder, Recipe recipe) {
        if (iRecipeCapabilityHolder instanceof IEnhancedRecipeLogicMachine) {
            IEnhancedRecipeLogicMachine iEnhancedRecipeLogicMachine = (IEnhancedRecipeLogicMachine)iRecipeCapabilityHolder;
            return iEnhancedRecipeLogicMachine.matchTickRecipe(recipe);
        }
        return RecipeRunner.handleTickRecipe(iRecipeCapabilityHolder, recipe, true);
    }

    public static boolean matchRecipeInput(IRecipeCapabilityHolder iRecipeCapabilityHolder, Recipe recipe) {
        if (RecipeRunner.handleRecipe(iRecipeCapabilityHolder, recipe, IO.IN, recipe.inputs, Collections.emptyMap(), true)) {
            return true;
        }
        if (iRecipeCapabilityHolder instanceof IRecipeLogicMachine) {
            IRecipeLogicMachine iRecipeLogicMachine = (IRecipeLogicMachine)iRecipeCapabilityHolder;
            IdleReason.setIdleReason(iRecipeLogicMachine, IdleReason.NO_MATCH);
        }
        return false;
    }

    public static boolean matchRecipeOutput(IRecipeCapabilityHolder iRecipeCapabilityHolder, Recipe recipe) {
        IRecipeLogicMachine iRecipeLogicMachine;
        if (iRecipeCapabilityHolder instanceof IExtendedRecipeCapabilityHolder && (iRecipeLogicMachine = (IExtendedRecipeCapabilityHolder)iRecipeCapabilityHolder).isDualMEOutput(recipe)) {
            return true;
        }
        if (RecipeRunner.handleRecipe(iRecipeCapabilityHolder, recipe, IO.OUT, recipe.outputs, Collections.emptyMap(), true)) {
            return true;
        }
        if (iRecipeCapabilityHolder instanceof IRecipeLogicMachine) {
            iRecipeLogicMachine = (IRecipeLogicMachine)iRecipeCapabilityHolder;
            IdleReason.setIdleReason(iRecipeLogicMachine, IdleReason.OUTPUT_FULL);
        }
        return false;
    }

    public static boolean handleRecipeInput(IRecipeLogicMachine iRecipeLogicMachine, Recipe recipe) {
        return RecipeRunner.handleRecipeInput(iRecipeLogicMachine, recipe, iRecipeLogicMachine.getRecipeLogic().getChanceCaches());
    }

    public static boolean handleRecipeOutput(IRecipeLogicMachine iRecipeLogicMachine, Recipe recipe) {
        return RecipeRunner.handleRecipeOutput(iRecipeLogicMachine, recipe, iRecipeLogicMachine.getRecipeLogic().getChanceCaches());
    }

    private static boolean handleRecipeIO(IRecipeLogicMachine iRecipeLogicMachine, Recipe recipe, IO iO) {
        return RecipeRunner.handleRecipeIO(iRecipeLogicMachine, recipe, iO, iRecipeLogicMachine.getRecipeLogic().getChanceCaches());
    }

    public static boolean handleRecipeIO(IRecipeCapabilityHolder iRecipeCapabilityHolder, Recipe recipe, IO iO, Map<RecipeCapability<?>, Object2IntMap<?>> map) {
        if (iRecipeCapabilityHolder instanceof IEnhancedRecipeLogicMachine) {
            IEnhancedRecipeLogicMachine iEnhancedRecipeLogicMachine = (IEnhancedRecipeLogicMachine)iRecipeCapabilityHolder;
            return iEnhancedRecipeLogicMachine.handleRecipeIO(recipe, iO);
        }
        if (iO == IO.IN) {
            return RecipeRunner.handleRecipeInput(iRecipeCapabilityHolder, recipe, map);
        }
        return RecipeRunner.handleRecipeOutput(iRecipeCapabilityHolder, recipe, map);
    }

    public static boolean handleRecipeInput(IRecipeCapabilityHolder iRecipeCapabilityHolder, Recipe recipe, Map<RecipeCapability<?>, Object2IntMap<?>> map) {
        if (RecipeRunner.handleRecipe(iRecipeCapabilityHolder, recipe, IO.IN, recipe.inputs, map, false)) {
            return true;
        }
        if (iRecipeCapabilityHolder instanceof IRecipeLogicMachine) {
            IRecipeLogicMachine iRecipeLogicMachine = (IRecipeLogicMachine)iRecipeCapabilityHolder;
            IdleReason.setIdleReason(iRecipeLogicMachine, IdleReason.INVALID_INPUT);
        }
        return false;
    }

    public static boolean handleRecipeOutput(IRecipeCapabilityHolder iRecipeCapabilityHolder, Recipe recipe, Map<RecipeCapability<?>, Object2IntMap<?>> map) {
        if (RecipeRunner.handleRecipe(iRecipeCapabilityHolder, recipe, IO.OUT, recipe.outputs, map, false)) {
            return true;
        }
        if (iRecipeCapabilityHolder instanceof IRecipeLogicMachine) {
            IRecipeLogicMachine iRecipeLogicMachine = (IRecipeLogicMachine)iRecipeCapabilityHolder;
            IdleReason.setIdleReason(iRecipeLogicMachine, IdleReason.OUTPUT_FULL);
        }
        return false;
    }

    public static boolean handleContent(IRecipeCapabilityHolder iRecipeCapabilityHolder, IO iO, @Nullable List list, RecipeCapability<?> recipeCapability, boolean bl, boolean bl2) {
        if (list == null || list.isEmpty()) {
            return true;
        }
        List list2 = iRecipeCapabilityHolder.getCapabilitiesFlat(iO, recipeCapability);
        if (list2.isEmpty()) {
            return false;
        }
        for (IRecipeHandler iRecipeHandler : list2) {
            if (!bl2 && iRecipeHandler.isRecipeOnly() || (list = iRecipeHandler.handleRecipeInner(iO, Recipe.EMPTY, list, bl)) != null && !list.isEmpty()) continue;
            return true;
        }
        return false;
    }

    public static boolean handleTickRecipe(IRecipeCapabilityHolder iRecipeCapabilityHolder, @Nullable Recipe recipe) {
        if (iRecipeCapabilityHolder instanceof IEnhancedRecipeLogicMachine) {
            IEnhancedRecipeLogicMachine iEnhancedRecipeLogicMachine = (IEnhancedRecipeLogicMachine)iRecipeCapabilityHolder;
            return iEnhancedRecipeLogicMachine.handleTickRecipe(recipe);
        }
        return RecipeRunner.handleTickRecipe(iRecipeCapabilityHolder, recipe, false);
    }

    public static boolean handleTickRecipe(IRecipeCapabilityHolder iRecipeCapabilityHolder, @Nullable Recipe recipe, boolean bl) {
        if (recipe != null) {
            IComputationContainerMachine iComputationContainerMachine;
            IManaContainerMachine iManaContainerMachine;
            IElectricMachine iElectricMachine;
            long l = recipe.eut;
            if (!(l == 0L || iRecipeCapabilityHolder instanceof IElectricMachine && (iElectricMachine = (IElectricMachine)((Object)iRecipeCapabilityHolder)).useEnergy(l, bl))) {
                if (iRecipeCapabilityHolder instanceof IRecipeLogicMachine) {
                    IRecipeLogicMachine iRecipeLogicMachine = (IRecipeLogicMachine)iRecipeCapabilityHolder;
                    IdleReason.setIdleReason(iRecipeLogicMachine, recipe.eut < 0L ? IdleReason.INSUFFICIENT_OUT : IdleReason.NO_EU);
                }
                return false;
            }
            long l2 = recipe.manat;
            if (!(l2 == 0L || iRecipeCapabilityHolder instanceof IManaContainerMachine && (iManaContainerMachine = (IManaContainerMachine)((Object)iRecipeCapabilityHolder)).useMana(l2, bl))) {
                if (iRecipeCapabilityHolder instanceof IRecipeLogicMachine) {
                    IRecipeLogicMachine iRecipeLogicMachine = (IRecipeLogicMachine)iRecipeCapabilityHolder;
                    IdleReason.setIdleReason(iRecipeLogicMachine, recipe.manat < 0L ? IdleReason.INSUFFICIENT_OUT : IdleReason.NO_MANA);
                }
                return false;
            }
            long l3 = recipe.cwut;
            if (l3 != 0L && iRecipeCapabilityHolder instanceof IComputationContainerMachine && (iComputationContainerMachine = (IComputationContainerMachine)((Object)iRecipeCapabilityHolder)).requestCWU(l3, bl) < l3) {
                if (iRecipeCapabilityHolder instanceof IRecipeLogicMachine) {
                    IRecipeLogicMachine iRecipeLogicMachine = (IRecipeLogicMachine)iRecipeCapabilityHolder;
                    IdleReason.setIdleReason(iRecipeLogicMachine, IdleReason.NO_CWU);
                }
                return false;
            }
        }
        return true;
    }

    public static boolean handleRecipe(IRecipeCapabilityHolder iRecipeCapabilityHolder, Recipe recipe, IO iO, Map<RecipeCapability<?>, List<Content>> map, Map<RecipeCapability<?>, Object2IntMap<?>> map2, boolean bl) {
        List object;
        Object object2;
        Object i2;
        Object object4;
        if (map.isEmpty()) {
            return true;
        }
        boolean bl2 = iO == IO.IN;
        RecipeHandlerList recipeHandlerList = bl2 ? iRecipeCapabilityHolder.getCurrentHandlerList() : null;
        IExtendedRecipeCapabilityHolder iExtendedRecipeCapabilityHolder = null;
        Object object5 = null;
        if (iRecipeCapabilityHolder instanceof IExtendedRecipeCapabilityHolder) {
            object4 = (IExtendedRecipeCapabilityHolder)iRecipeCapabilityHolder;
            iExtendedRecipeCapabilityHolder = object4;
            if (bl2) {
                iExtendedRecipeCapabilityHolder.gtolib$setOutputColor(-1);
            }
        }
        if (bl && !bl2 && iRecipeCapabilityHolder instanceof IVoidable) {
            object5 = object4 = (IVoidable)((Object)iRecipeCapabilityHolder);
        }
        boolean bl3 = bl2 && !bl && recipeHandlerList == null && iExtendedRecipeCapabilityHolder != null;
        RecipeCapabilityMap<List<Object>> recipeCapabilityMap = new RecipeCapabilityMap<List<Object>>();
        RecipeCapabilityMap<List<Object>> recipeCapabilityMap2 = bl3 ? new RecipeCapabilityMap<List<Object>>() : recipeCapabilityMap;
        int n = recipe.tier + recipe.ocLevel;
        for (Map.Entry<RecipeCapability<?>, List<Content>> object6 : map.entrySet()) {
            i2 = object6.getKey();
            if (object5 != null && object5.canVoidRecipeOutputs((RecipeCapability)i2) || (object2 = object6.getValue()).isEmpty()) continue;
            ObjectArrayList objectArrayList = new ObjectArrayList(object2.size());
            ObjectArrayList objectArrayList2 = new ObjectArrayList(object2.size());
            ObjectArrayList objectArrayList3 = bl3 ? new ObjectArrayList(object2.size()) : null;
            Iterator iterator = object2.iterator();
            while (iterator.hasNext()) {
                Content content = (Content)iterator.next();
                if (bl) {
                    objectArrayList2.add(content.content);
                    continue;
                }
                if (bl3) {
                    objectArrayList3.add(content.content);
                }
                if (content.chance == 0) continue;
                if (content.chance >= ContentBuilder.maxChance) {
                    objectArrayList2.add(content.content);
                    continue;
                }
                objectArrayList.add(content);
            }
            if (!objectArrayList.isEmpty()) {
                RecipeRunner.roll(i2, objectArrayList2, objectArrayList, recipe.tier, n, map2.get(i2), recipe.parallels);
            }
            if (!objectArrayList2.isEmpty()) {
                recipeCapabilityMap.put((RecipeCapability<?>)i2, objectArrayList2);
            }
            if (!bl3 || objectArrayList3.isEmpty()) continue;
            recipeCapabilityMap2.put((RecipeCapability<?>)i2, objectArrayList3);
        }
        if (recipeCapabilityMap2.isEmpty()) {
            return true;
        }
        if (recipeHandlerList != null) {
            if (RecipeRunner.handleRecipeContent(recipeHandlerList, iO, recipe, recipeCapabilityMap, bl, bl)) {
                if (iExtendedRecipeCapabilityHolder != null) {
                    iExtendedRecipeCapabilityHolder.gtolib$setOutputColor(recipeHandlerList.getColor());
                }
                return true;
            }
            if (!bl) {
                return false;
            }
        }
        if (iExtendedRecipeCapabilityHolder != null) {
            if (bl2) {
                object = iExtendedRecipeCapabilityHolder.gtolib$getInput();
                int n2 = object.size() - 1;
                for (int j = 0; j <= n2; ++j) {
                    object2 = (RecipeHandlerList)object.get(j);
                    if (j == n2) {
                        if (!RecipeRunner.handleRecipeContent((RecipeHandlerList)object2, iO, recipe, recipeCapabilityMap, bl, true)) continue;
                        iExtendedRecipeCapabilityHolder.gtolib$setOutputColor(((RecipeHandlerList)object2).getColor());
                        if (bl) {
                            iExtendedRecipeCapabilityHolder.setCurrentHandlerList((RecipeHandlerList)object2, recipe);
                        }
                        return true;
                    }
                    if (!RecipeRunner.handleRecipeContent((RecipeHandlerList)object2, iO, recipe, recipeCapabilityMap2, true, true)) continue;
                    iExtendedRecipeCapabilityHolder.gtolib$setOutputColor(((RecipeHandlerList)object2).getColor());
                    if (bl) {
                        iExtendedRecipeCapabilityHolder.setCurrentHandlerList((RecipeHandlerList)object2, recipe);
                        return true;
                    }
                    return RecipeRunner.handleRecipeContent((RecipeHandlerList)object2, iO, recipe, recipeCapabilityMap, false, false);
                }
                return false;
            }
            object = iExtendedRecipeCapabilityHolder.gtolib$getOutput();
            int n3 = iExtendedRecipeCapabilityHolder.gtolib$getOutputColor();
            if (n3 != -1 && (i2 = (RecipeHandlerList)iExtendedRecipeCapabilityHolder.gtolib$getOutputColorMap().get(n3)) != null) {
                return RecipeRunner.handleRecipeContent((RecipeHandlerList)i2, iO, recipe, recipeCapabilityMap, bl, false);
            }
        } else {
            List iterator = (List)iRecipeCapabilityHolder.getCapabilitiesProxy().get(iO);
            if (iterator == null) {
                return false;
            }
            object = iterator;
        }
        for (Object i2 : object) {
            if (!RecipeRunner.handleRecipeContent((RecipeHandlerList)i2, iO, recipe, recipeCapabilityMap, bl, false)) continue;
            return true;
        }
        return false;
    }

    private static boolean handleRecipeContent(RecipeHandlerList recipeHandlerList, IO iO, Recipe recipe, RecipeCapabilityMap<List<Object>> recipeCapabilityMap, boolean bl, boolean bl2) {
        List list;
        if (recipeHandlerList instanceof InternalSlotRecipeHandler.AbstractRHL) {
            InternalSlotRecipeHandler.AbstractRHL abstractRHL = (InternalSlotRecipeHandler.AbstractRHL)recipeHandlerList;
            return abstractRHL.handleRecipeContent(recipe, recipeCapabilityMap, bl);
        }
        if (recipeHandlerList.handlerMap.isEmpty()) {
            return false;
        }
        int n = 0;
        if (recipeCapabilityMap.item != null) {
            list = (List)recipeCapabilityMap.item;
            for (IRecipeHandler iRecipeHandler : recipeHandlerList.getCapability(ItemRecipeCapability.CAP)) {
                list = iRecipeHandler.handleRecipe(iO, recipe, list, bl);
                if (list != null) continue;
                if (bl2) {
                    n = (byte)(n + 1);
                    break;
                }
                recipeCapabilityMap.item = null;
                break;
            }
            if (list != null && !bl2) {
                recipeCapabilityMap.item = list;
            }
        }
        if (recipeCapabilityMap.fluid != null) {
            list = (List)recipeCapabilityMap.fluid;
            for (IRecipeHandler iRecipeHandler : recipeHandlerList.getCapability(FluidRecipeCapability.CAP)) {
                list = iRecipeHandler.handleRecipe(iO, recipe, list, bl);
                if (list != null) continue;
                if (bl2) {
                    n = (byte)(n + 1);
                    break;
                }
                recipeCapabilityMap.fluid = null;
                break;
            }
            if (list != null && !bl2) {
                recipeCapabilityMap.fluid = list;
            }
        }
        return n == recipeCapabilityMap.size();
    }

    private static void roll(RecipeCapability<?> recipeCapability, List<Object> list, List<@NotNull Content> list2, int n, int n2, @Nullable Object2IntMap<?> object2IntMap, long l) {
        ObjectArrayList objectArrayList = new ObjectArrayList(list2.size());
        for (Content object : list2) {
            if (object instanceof SeparateContent) {
                SeparateContent separateContent = (SeparateContent)object;
                l = separateContent.parallel;
            }
            int n3 = ChanceBoostFunction.OVERCLOCK.getBoostedChance(object, n, n2);
            long l2 = l * (long)n3;
            long l3 = l2 / (long)ContentBuilder.maxChance;
            n3 = (int)l2 % ContentBuilder.maxChance;
            int n4 = RecipeRunner.getCachedChance(object, object2IntMap);
            int n5 = n3 + n4;
            while (n5 >= ContentBuilder.maxChance) {
                ++l3;
                n5 -= ContentBuilder.maxChance;
                n3 -= ContentBuilder.maxChance;
            }
            if (object2IntMap != null) {
                object2IntMap.put(object.content, n5);
            }
            if (l3 <= 0L) continue;
            objectArrayList.add(new LongObjectHolder<Object>(l3, object.content));
        }
        for (LongObjectHolder longObjectHolder : objectArrayList) {
            if (longObjectHolder.number > 1L) {
                list.add(recipeCapability.copyContent(longObjectHolder.obj, ContentModifier.multiplier(longObjectHolder.number)));
                continue;
            }
            list.add(longObjectHolder.obj);
        }
    }

    private static int getCachedChance(Content content, @Nullable Object2IntMap<?> object2IntMap) {
        if (object2IntMap == null) {
            return GTValues.RNG.m_188503_(ContentBuilder.maxChance);
        }
        int n = object2IntMap.getInt(content.content);
        if (n == 0) {
            return GTValues.RNG.m_188503_(ContentBuilder.maxChance);
        }
        return n;
    }
}

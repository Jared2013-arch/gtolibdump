package com.gtolib.api.recipe;

import com.gregtechceu.gtceu.api.capability.recipe.ItemRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import java.util.Map;

class RecipeCapabilityMap$ItemEntry
implements Map.Entry<RecipeCapability<?>, T> {
    private RecipeCapabilityMap$ItemEntry() {
    }

    @Override
    public RecipeCapability<?> getKey() {
        return ItemRecipeCapability.CAP;
    }

    @Override
    public T getValue() {
        return RecipeCapabilityMap.this.item;
    }

    @Override
    public T setValue(T t) {
        Object t2 = RecipeCapabilityMap.this.item;
        RecipeCapabilityMap.this.item = t;
        return t2;
    }
}

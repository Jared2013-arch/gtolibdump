package com.gtolib.api.recipe.lookup;

import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.lookup.Branch;
import com.gtolib.api.recipe.lookup.Either;
import com.gtolib.api.recipe.lookup.RecipeLookup;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;

final class Either$Left
extends Either {
    private final Recipe value;

    Either$Left(Recipe recipe) {
        this.value = recipe;
    }

    @Override
    Recipe map(RecipeLookup recipeLookup, int n, int[] nArray, Predicate<Recipe> predicate, int n2, int n3, int n4) {
        return predicate.test(this.value) ? this.value : null;
    }

    @Override
    Optional<Recipe> left() {
        return Optional.of(this.value);
    }

    @Override
    Optional<Branch> right() {
        return Optional.empty();
    }

    public String toString() {
        return "Left[" + String.valueOf(this.value) + "]";
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        Either$Left left = (Either$Left)object;
        return Objects.equals(this.value, left.value);
    }

    public int hashCode() {
        return this.value.hashCode();
    }
}

package com.gtolib.api.recipe.lookup;

import com.gregtechceu.gtceu.api.capability.recipe.FluidRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.IRecipeCapabilityHolder;
import com.gregtechceu.gtceu.api.capability.recipe.IRecipeHandler;
import com.gregtechceu.gtceu.api.capability.recipe.ItemRecipeCapability;
import com.gregtechceu.gtceu.api.machine.trait.RecipeHandlerList;
import com.gregtechceu.gtceu.api.recipe.lookup.IntIngredientMap;
import com.gregtechceu.gtceu.core.mixins.StrictNBTIngredientAccessor;
import com.gregtechceu.gtceu.utils.collection.O2IOpenCacheHashMap;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gregtechceu.gtceu.utils.collection.OpenCacheHashSet;
import com.gtocore.common.data.GTOItems;
import com.gtolib.IFluid;
import com.gtolib.IItem;
import com.gtolib.api.recipe.ingredient.CircuitIngredient;
import com.gtolib.api.recipe.ingredient.FastFluidIngredient;
import com.gtolib.api.recipe.ingredient.FastSizedIngredient;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2LongOpenCustomHashMap;
import it.unimi.dsi.fastutil.objects.Object2LongOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.IntTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.fluids.FluidStack;

public final class MapIngredient {
    private static int count = 1;
    public static Object2IntOpenHashMap<Object> COUNT_MAP = new O2IOpenCacheHashMap();
    static Object2ObjectOpenHashMap<IItem, ObjectOpenHashSet<Object>> INGREDIENT_BUILDER = new O2OOpenCacheHashMap();
    private static final int[] CIRCUIT_INPUTS = new int[33];
    private static final Item DATA_DISC;
    private static final Item DIMENSION_DATA;
    private static final Object2IntOpenHashMap<String> NBTS;

    public static synchronized int getCount(Object object2) {
        if (object2 == null) {
            return count++;
        }
        return COUNT_MAP.computeIfAbsent(object2, object -> count++);
    }

    private MapIngredient() {
    }

    public static void add(String string) {
        NBTS.putIfAbsent((Object)string, MapIngredient.getCount(null));
    }

    public static void convertList(IRecipeCapabilityHolder iRecipeCapabilityHolder, RecipeHandlerList recipeHandlerList) {
        Object object;
        recipeHandlerList.intIngredientMap.clear();
        for (IRecipeHandler iRecipeHandler : recipeHandlerList.getCapability(ItemRecipeCapability.CAP)) {
            object = iRecipeHandler.getItemMap();
            if (object == null) continue;
            MapIngredient.convertItems(recipeHandlerList.intIngredientMap, (Object2LongOpenCustomHashMap<ItemStack>)object);
        }
        for (IRecipeHandler iRecipeHandler : recipeHandlerList.getCapability(FluidRecipeCapability.CAP)) {
            object = iRecipeHandler.getFluidMap();
            if (object == null) continue;
            MapIngredient.convertFluids(recipeHandlerList.intIngredientMap, (Object2LongOpenHashMap<FluidStack>)object);
        }
        iRecipeCapabilityHolder.setChange(false);
    }

    public static void convertItems(IntIngredientMap intIngredientMap, Object2LongOpenCustomHashMap<ItemStack> object2LongOpenCustomHashMap) {
        object2LongOpenCustomHashMap.object2LongEntrySet().fastForEach(entry -> {
            long l = entry.getLongValue();
            if (l > 0L) {
                MapIngredient.convertItem(intIngredientMap, (ItemStack)entry.getKey(), l);
            }
        });
    }

    public static void convertFluids(IntIngredientMap intIngredientMap, Object2LongOpenHashMap<FluidStack> object2LongOpenHashMap) {
        object2LongOpenHashMap.object2LongEntrySet().fastForEach(entry -> {
            long l = entry.getLongValue();
            if (l > 0L) {
                intIngredientMap.add(((IFluid)((Object)((FluidStack)entry.getKey()).getFluid())).gtolib$getMapFluid(), l);
            }
        });
    }

    private static void convertItem(IntIngredientMap intIngredientMap, ItemStack itemStack, long l) {
        int[] nArray;
        Item item = itemStack.m_41720_();
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag != null) {
            Object v;
            if (item == CircuitIngredient.PROGRAMMED_CIRCUIT) {
                Object object = compoundTag.f_128329_.get("Configuration");
                if (object instanceof IntTag) {
                    IntTag intTag = (IntTag)object;
                    intIngredientMap.add(CIRCUIT_INPUTS[intTag.m_7047_()], l);
                    return;
                }
            } else if (item == DATA_DISC) {
                Object v2 = compoundTag.f_128329_.get("n");
                if (v2 instanceof StringTag) {
                    StringTag stringTag = (StringTag)v2;
                    intIngredientMap.add(NBTS.getInt((Object)stringTag.m_7916_()), l);
                    return;
                }
            } else if (item == DIMENSION_DATA && (v = compoundTag.f_128329_.get("dim")) instanceof StringTag) {
                StringTag stringTag = (StringTag)v;
                intIngredientMap.add(NBTS.getInt((Object)stringTag.m_7916_()), l);
                return;
            }
        }
        if ((nArray = ((IItem)((Object)item)).gtolib$getMapItem()) != null) {
            for (int n : nArray) {
                intIngredientMap.add(n, l);
            }
        }
    }

    static void convert(IntIngredientMap intIngredientMap, IntIngredientMap intIngredientMap2, IntIngredientMap intIngredientMap3, Object object, boolean bl) {
        if (object instanceof FastFluidIngredient) {
            FastFluidIngredient fastFluidIngredient = (FastFluidIngredient)object;
            Fluid fluid = FastFluidIngredient.getFluid(fastFluidIngredient);
            if (fluid != null) {
                int n = ((IFluid)((Object)fluid)).gtolib$getOrCreateMapFluid();
                intIngredientMap.add(n, fastFluidIngredient.amount);
                if (bl) {
                    intIngredientMap3.add(n, fastFluidIngredient.amount);
                } else {
                    intIngredientMap2.add(n, fastFluidIngredient.amount);
                }
            }
        } else if (object instanceof Ingredient) {
            Ingredient ingredient = (Ingredient)object;
            if (ingredient instanceof FastSizedIngredient) {
                FastSizedIngredient fastSizedIngredient = (FastSizedIngredient)ingredient;
                MapIngredient.convertItem(fastSizedIngredient.getInner(), intIngredientMap, intIngredientMap2, intIngredientMap3, fastSizedIngredient.getAmount(), bl);
            } else if (ingredient instanceof CircuitIngredient) {
                CircuitIngredient circuitIngredient = (CircuitIngredient)ingredient;
                int n = CIRCUIT_INPUTS[circuitIngredient.configuration];
                intIngredientMap.add(n, 1L);
                intIngredientMap2.add(n, 1L);
            } else {
                MapIngredient.convertItem(ingredient, intIngredientMap, intIngredientMap2, intIngredientMap3, 1L, bl);
            }
        }
    }

    private static void convertItem(Ingredient ingredient, IntIngredientMap intIngredientMap, IntIngredientMap intIngredientMap2, IntIngredientMap intIngredientMap3, long l, boolean bl) {
        Object object2;
        if (ingredient instanceof StrictNBTIngredientAccessor) {
            Ingredient.Value[] valueArray = (Ingredient.Value[])ingredient;
            CompoundTag compoundTag = valueArray.getStack().m_41783_();
            Item item = valueArray.getStack().m_41720_();
            if (compoundTag != null) {
                if (item == DATA_DISC) {
                    object2 = compoundTag.f_128329_.get("n");
                    if (object2 instanceof StringTag) {
                        StringTag stringTag = (StringTag)object2;
                        int n = NBTS.getInt((Object)stringTag.m_7916_());
                        intIngredientMap.add(n, l);
                        if (bl) {
                            intIngredientMap3.add(n, l);
                        } else {
                            intIngredientMap2.add(n, l);
                        }
                        return;
                    }
                } else if (item == DIMENSION_DATA && (object2 = compoundTag.f_128329_.get("dim")) instanceof StringTag) {
                    StringTag stringTag = (StringTag)object2;
                    int n = NBTS.getInt((Object)stringTag.m_7916_());
                    intIngredientMap.add(n, l);
                    if (bl) {
                        intIngredientMap3.add(n, l);
                    } else {
                        intIngredientMap2.add(n, l);
                    }
                    return;
                }
            }
        }
        for (Ingredient.Value value : ingredient.f_43902_) {
            int n;
            Object object3;
            if (value instanceof Ingredient.TagValue) {
                object2 = (Ingredient.TagValue)((Object)value);
                object3 = ((Ingredient.TagValue)object2).f_43959_;
                for (Holder holder : BuiltInRegistries.f_257033_.m_206058_((TagKey)object3)) {
                    ((ObjectOpenHashSet)INGREDIENT_BUILDER.computeIfAbsent((Object)((IItem)holder.m_203334_()), object -> new OpenCacheHashSet())).add(object3);
                }
                n = MapIngredient.getCount(object3);
                intIngredientMap.add(n, l);
                if (bl) {
                    intIngredientMap3.add(n, l);
                    continue;
                }
                intIngredientMap2.add(n, l);
                continue;
            }
            if (!(value instanceof Ingredient.ItemValue)) continue;
            Ingredient.ItemValue itemValue = (Ingredient.ItemValue)((Object)value);
            object3 = itemValue.f_43951_.m_41720_();
            ((ObjectOpenHashSet)INGREDIENT_BUILDER.computeIfAbsent((Object)((IItem)object3), object -> new OpenCacheHashSet())).add(object3);
            n = MapIngredient.getCount(object3);
            intIngredientMap.add(n, l);
            if (bl) {
                intIngredientMap3.add(n, l);
                continue;
            }
            intIngredientMap2.add(n, l);
        }
    }

    static {
        for (int i = 0; i < 33; ++i) {
            MapIngredient.CIRCUIT_INPUTS[i] = MapIngredient.getCount(null);
        }
        DATA_DISC = (Item)GTOItems.DATA_DISC.get();
        DIMENSION_DATA = (Item)GTOItems.DIMENSION_DATA.get();
        NBTS = new O2IOpenCacheHashMap();
    }
}

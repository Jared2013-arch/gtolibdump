package com.gtolib.api.recipe.lookup;

import com.gtolib.api.recipe.lookup.Either;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.List;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class Branch {
    static final Branch EMPTY = new Branch();
    static List<Branch> ROOT_BUILDER;
    static List<Either.Right> BRANCH_BUILDER;
    private int a;
    private int b;
    private Either av;
    private Either bv;
    private boolean fast;
    boolean isEmpty;
    private Int2ObjectOpenHashMap<Either> nodes;

    Branch() {
    }

    Branch(boolean bl) {
        ROOT_BUILDER.add(this);
    }

    @Nullable
    Either getNode(int n) {
        if (this.isEmpty) {
            return null;
        }
        if (this.fast) {
            if (n == this.a) {
                return this.av;
            }
            if (n == this.b) {
                return this.bv;
            }
            return null;
        }
        return (Either)this.nodes.get(n);
    }

    boolean isEmptyBranch() {
        return this.nodes == null || this.nodes.isEmpty();
    }

    @NotNull
    Int2ObjectOpenHashMap<Either> getNodes() {
        if (this.nodes == null) {
            this.nodes = new Int2ObjectOpenHashMap(2);
        }
        return this.nodes;
    }

    void builder() {
        if (this.nodes != null) {
            int n = this.nodes.size();
            if (n == 0) {
                this.nodes = null;
                this.isEmpty = true;
            } else if (n == 1) {
                this.fast = true;
                ObjectIterator objectIterator = this.nodes.int2ObjectEntrySet().iterator();
                while (objectIterator.hasNext()) {
                    Int2ObjectMap.Entry entry = (Int2ObjectMap.Entry)objectIterator.next();
                    this.a = entry.getIntKey();
                    this.av = (Either)entry.getValue();
                }
                this.nodes = null;
            } else if (n == 2) {
                this.fast = true;
                boolean bl = false;
                ObjectIterator objectIterator = this.nodes.int2ObjectEntrySet().iterator();
                while (objectIterator.hasNext()) {
                    Int2ObjectMap.Entry entry = (Int2ObjectMap.Entry)objectIterator.next();
                    if (bl) {
                        this.b = entry.getIntKey();
                        this.bv = (Either)entry.getValue();
                        continue;
                    }
                    bl = true;
                    this.a = entry.getIntKey();
                    this.av = (Either)entry.getValue();
                }
                this.nodes = null;
            }
        } else {
            this.isEmpty = true;
        }
    }

    static {
        Branch.EMPTY.isEmpty = true;
        ROOT_BUILDER = new ObjectArrayList();
        BRANCH_BUILDER = new ObjectArrayList();
    }
}

package com.gtolib.api.recipe.lookup;

import com.google.common.collect.Interner;
import com.google.common.collect.Interners;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.lookup.Branch;
import com.gtolib.api.recipe.lookup.RecipeLookup;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;

abstract class Either {
    static Interner<Either> LEFTS = Interners.newStrongInterner();

    private Either() {
    }

    abstract Recipe map(RecipeLookup var1, int var2, int[] var3, Predicate<Recipe> var4, int var5, int var6, int var7);

    abstract Optional<Recipe> left();

    abstract Optional<Branch> right();

    static Either recipe(Recipe recipe) {
        return LEFTS.intern(new Left(recipe));
    }

    static Either branch() {
        Right right = new Right(new Branch());
        Branch.BRANCH_BUILDER.add(right);
        return right;
    }

    private static final class Left
    extends Either {
        private final Recipe value;

        Left(Recipe recipe) {
            this.value = recipe;
        }

        @Override
        Recipe map(RecipeLookup recipeLookup, int n, int[] nArray, Predicate<Recipe> predicate, int n2, int n3, int n4) {
            return predicate.test(this.value) ? this.value : null;
        }

        @Override
        Optional<Recipe> left() {
            return Optional.of(this.value);
        }

        @Override
        Optional<Branch> right() {
            return Optional.empty();
        }

        public String toString() {
            return "Left[" + String.valueOf(this.value) + "]";
        }

        public boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            if (object == null || this.getClass() != object.getClass()) {
                return false;
            }
            Left left = (Left)object;
            return Objects.equals(this.value, left.value);
        }

        public int hashCode() {
            return this.value.hashCode();
        }
    }

    static final class Right
    extends Either {
        private Branch value;

        Right(Branch branch) {
            this.value = branch;
        }

        void builder() {
            this.value.builder();
            if (this.value.isEmpty) {
                this.value = Branch.EMPTY;
            }
        }

        @Override
        Recipe map(RecipeLookup recipeLookup, int n, int[] nArray, Predicate<Recipe> predicate, int n2, int n3, int n4) {
            if (this.value.isEmpty) {
                return null;
            }
            int n5 = (n2 + 1) % n;
            while (n5 != n2) {
                Recipe recipe;
                if (((long)n4 & 1L << n5) == 0L && (recipe = recipeLookup.recurseIngredientTreeFindRecipe(n, nArray, this.value, predicate, n5, n3 + 1, n4 | 1 << n5)) != null) {
                    return recipe;
                }
                n5 = (n5 + 1) % n;
            }
            return null;
        }

        @Override
        Optional<Recipe> left() {
            return Optional.empty();
        }

        @Override
        Optional<Branch> right() {
            return Optional.of(this.value);
        }

        public String toString() {
            return "Right[" + String.valueOf(this.value) + "]";
        }
    }
}

package com.gtolib.api.recipe.lookup;

import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.lookup.Branch;
import com.gtolib.api.recipe.lookup.Either;
import com.gtolib.api.recipe.lookup.RecipeLookup;
import java.util.Optional;
import java.util.function.Predicate;

final class Either$Right
extends Either {
    private Branch value;

    Either$Right(Branch branch) {
        this.value = branch;
    }

    void builder() {
        this.value.builder();
        if (this.value.isEmpty) {
            this.value = Branch.EMPTY;
        }
    }

    @Override
    Recipe map(RecipeLookup recipeLookup, int n, int[] nArray, Predicate<Recipe> predicate, int n2, int n3, int n4) {
        if (this.value.isEmpty) {
            return null;
        }
        int n5 = (n2 + 1) % n;
        while (n5 != n2) {
            Recipe recipe;
            if (((long)n4 & 1L << n5) == 0L && (recipe = recipeLookup.recurseIngredientTreeFindRecipe(n, nArray, this.value, predicate, n5, n3 + 1, n4 | 1 << n5)) != null) {
                return recipe;
            }
            n5 = (n5 + 1) % n;
        }
        return null;
    }

    @Override
    Optional<Recipe> left() {
        return Optional.empty();
    }

    @Override
    Optional<Branch> right() {
        return Optional.of(this.value);
    }

    public String toString() {
        return "Right[" + String.valueOf(this.value) + "]";
    }
}

package com.gtolib.api.recipe.lookup;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.capability.recipe.FluidRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.IRecipeCapabilityHolder;
import com.gregtechceu.gtceu.api.capability.recipe.ItemRecipeCapability;
import com.gregtechceu.gtceu.api.machine.trait.RecipeHandlerList;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gregtechceu.gtceu.api.recipe.content.Content;
import com.gregtechceu.gtceu.api.recipe.lookup.IntIngredientMap;
import com.gtocore.common.data.GTORecipeTypes;
import com.gtolib.GTOCore;
import com.gtolib.IItem;
import com.gtolib.api.machine.feature.multiblock.IExtendedRecipeCapabilityHolder;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.RecipeBuilder;
import com.gtolib.api.recipe.RecipeRunner;
import com.gtolib.api.recipe.RecipeType;
import com.gtolib.api.recipe.lookup.Branch;
import com.gtolib.api.recipe.lookup.Either;
import com.gtolib.api.recipe.lookup.MapIngredient;
import com.gtolib.utils.ServerUtils;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import java.util.Collections;
import java.util.function.Predicate;
import net.minecraft.resources.ResourceLocation;
import vazkii.botania.mixin.RecipeManagerAccessor;

public final class RecipeLookup {
    private static boolean init;
    private final GTRecipeType recipeType;
    public final Branch lookup = new Branch(true);

    public RecipeLookup(GTRecipeType gTRecipeType) {
        this.recipeType = gTRecipeType;
    }

    public static void initLookup() {
        if (init) {
            return;
        }
        init = true;
        long l = System.currentTimeMillis();
        RecipeBuilder.RECIPE_MAP.values().forEach(recipe -> {
            RecipeType recipeType;
            GTRecipeType gTRecipeType = recipe.recipeType;
            if (gTRecipeType instanceof RecipeType && !(recipeType = (RecipeType)gTRecipeType).noSearch()) {
                recipeType.lookup().addRecipe((Recipe)recipe);
            }
        });
        ((RecipeManagerAccessor)((Object)ServerUtils.getServer().m_129894_())).botania_getAll(net.minecraft.world.item.crafting.RecipeType.f_44108_).forEach((resourceLocation, smeltingRecipe) -> GTORecipeTypes.FURNACE_RECIPES.lookup().addRecipe((Recipe)GTORecipeTypes.FURNACE_RECIPES.toGTrecipe((ResourceLocation)resourceLocation, (net.minecraft.world.item.crafting.Recipe)smeltingRecipe)));
        MapIngredient.INGREDIENT_BUILDER.object2ObjectEntrySet().parallelStream().forEach(entry -> ((IItem)entry.getKey()).gtolib$setMapItem(((ObjectOpenHashSet)entry.getValue()).stream().mapToInt(object -> {
            int n = MapIngredient.COUNT_MAP.getInt(object);
            if (n == 0) {
                GTOCore.LOGGER.error("Missing count for {}", object);
            }
            return n;
        }).toArray()));
        Branch.ROOT_BUILDER.parallelStream().forEach(Branch::builder);
        Branch.BRANCH_BUILDER.parallelStream().forEach(Either.Right::builder);
        Branch.ROOT_BUILDER = null;
        Branch.BRANCH_BUILDER = null;
        MapIngredient.COUNT_MAP = null;
        MapIngredient.INGREDIENT_BUILDER = null;
        Either.LEFTS = null;
        GTOCore.LOGGER.info("InitLookup took {}ms", (Object)(System.currentTimeMillis() - l));
    }

    public Recipe findRecipe(IRecipeCapabilityHolder iRecipeCapabilityHolder) {
        for (RecipeHandlerList recipeHandlerList : IExtendedRecipeCapabilityHolder.getInputList(iRecipeCapabilityHolder)) {
            MapIngredient.convertList(iRecipeCapabilityHolder, recipeHandlerList);
            if (recipeHandlerList.intIngredientMap.isEmpty()) continue;
            iRecipeCapabilityHolder.setCurrentHandlerList(recipeHandlerList, null);
            int[] nArray = recipeHandlerList.intIngredientMap.toIntArray();
            int n = nArray.length;
            Predicate<Recipe> predicate = recipe -> RecipeRunner.fastMatchRecipe(iRecipeCapabilityHolder, recipe) && RecipeRunner.matchRecipeOutput(iRecipeCapabilityHolder, recipe);
            for (int i = 0; i < n; ++i) {
                Recipe recipe2 = this.recurseIngredientTreeFindRecipe(n, nArray, this.lookup, predicate, i, 0, 1 << i);
                if (recipe2 == null) continue;
                return recipe2;
            }
        }
        return null;
    }

    public Recipe recurseIngredientTreeFindRecipe(int n, int[] nArray, Branch branch, Predicate<Recipe> predicate, int n2, int n3, int n4) {
        if (n3 == n) {
            return null;
        }
        Either either = branch.getNode(nArray[n2]);
        if (either != null) {
            return either.map(this, n, nArray, predicate, n2, n3, n4);
        }
        return null;
    }

    private void addRecipe(Recipe recipe) {
        if (recipe == null) {
            return;
        }
        IntIngredientMap intIngredientMap = new IntIngredientMap(recipe.inputs.getOrDefault(ItemRecipeCapability.CAP, Collections.emptyList()).size() + recipe.inputs.getOrDefault(FluidRecipeCapability.CAP, Collections.emptyList()).size());
        IntIngredientMap intIngredientMap2 = new IntIngredientMap();
        IntIngredientMap intIngredientMap3 = new IntIngredientMap();
        recipe.inputs.forEach((recipeCapability, list) -> {
            for (Content content : list) {
                MapIngredient.convert(intIngredientMap, intIngredientMap2, intIngredientMap3, content.content, content.chance > 0);
            }
        });
        recipe.mapIngredient = intIngredientMap;
        recipe.mapCountableIngredient = intIngredientMap3;
        recipe.mapNotCountableIngredient = intIngredientMap2;
        this.recurseIngredientTreeAdd(recipe, intIngredientMap.size(), intIngredientMap.toIntArray(), this.lookup, 0, 0);
    }

    private boolean recurseIngredientTreeAdd(Recipe recipe, int n, int[] nArray, Branch branch2, int n2, int n4) {
        if (n4 >= n) {
            return true;
        }
        int n5 = nArray[n2];
        Int2ObjectOpenHashMap<Either> int2ObjectOpenHashMap = branch2.getNodes();
        Either either2 = (Either)int2ObjectOpenHashMap.compute(n5, (n3, either) -> {
            if (n4 == n - 1) {
                if (either != null) {
                    if (either.left().isEmpty() || either.left().get() != recipe) {
                        String string;
                        String string2 = string = either.left().isPresent() ? either.left().get().id.toString() : "unknown";
                        if (!GTCEu.isDev()) {
                            throw new IllegalStateException("Conflicting recipes: " + String.valueOf(recipe.id) + " and: " + string);
                        }
                        GTOCore.LOGGER.error("Conflicting recipes: {} and {}", (Object)recipe.id, (Object)string);
                        return either;
                    }
                    return either;
                }
                return Either.recipe(recipe);
            }
            if (either == null) {
                return Either.branch();
            }
            return either;
        });
        if (either2.left().isPresent()) {
            return either2.left().get() == recipe;
        }
        boolean bl = either2.right().filter(branch -> this.recurseIngredientTreeAdd(recipe, n, nArray, (Branch)branch, (n2 + 1) % nArray.length, n4 + 1)).isPresent();
        if (!bl) {
            if (n4 == n - 1) {
                int2ObjectOpenHashMap.remove(n5);
            } else if (((Either)int2ObjectOpenHashMap.get(n5)).right().isPresent() && ((Either)int2ObjectOpenHashMap.get(n5)).right().get().isEmptyBranch()) {
                int2ObjectOpenHashMap.remove(n5);
            }
            return false;
        }
        return true;
    }
}

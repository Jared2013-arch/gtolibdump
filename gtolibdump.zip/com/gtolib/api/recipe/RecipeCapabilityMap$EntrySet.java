package com.gtolib.api.recipe;

import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.gtolib.api.recipe.RecipeCapabilityMap;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.jetbrains.annotations.NotNull;

class RecipeCapabilityMap$EntrySet
implements Set<Map.Entry<RecipeCapability<?>, T>> {
    private RecipeCapabilityMap$EntrySet() {
    }

    @Override
    public int size() {
        boolean bl;
        boolean bl2 = RecipeCapabilityMap.this.item != null;
        boolean bl3 = bl = RecipeCapabilityMap.this.fluid != null;
        return bl2 && bl ? 2 : (bl2 || bl ? 1 : 0);
    }

    @Override
    public boolean isEmpty() {
        return RecipeCapabilityMap.this.item == null && RecipeCapabilityMap.this.fluid == null;
    }

    @Override
    public boolean contains(Object object) {
        throw new UnsupportedOperationException();
    }

    @Override
    @NotNull
    public Iterator<Map.Entry<RecipeCapability<?>, T>> iterator() {
        boolean bl;
        boolean bl2 = RecipeCapabilityMap.this.item != null;
        boolean bl3 = bl = RecipeCapabilityMap.this.fluid != null;
        if (!bl2 && !bl) {
            return Collections.emptyIterator();
        }
        if (RecipeCapabilityMap.this.entryIterator == null) {
            RecipeCapabilityMap.this.entryIterator = new RecipeCapabilityMap.EntryIterator(RecipeCapabilityMap.this);
        }
        RecipeCapabilityMap.this.entryIterator.hasNext = true;
        RecipeCapabilityMap.this.entryIterator.complete = bl2 && bl;
        return RecipeCapabilityMap.this.entryIterator;
    }

    @Override
    @NotNull
    public @NotNull Object @NotNull [] toArray() {
        throw new UnsupportedOperationException();
    }

    @Override
    @NotNull
    public <O> @NotNull O @NotNull [] toArray(@NotNull @NotNull O @NotNull [] OArray) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean add(Map.Entry<RecipeCapability<?>, T> entry) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean remove(Object object) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean containsAll(@NotNull Collection<?> collection) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean addAll(@NotNull Collection<? extends Map.Entry<RecipeCapability<?>, T>> collection) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean retainAll(@NotNull Collection<?> collection) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean removeAll(@NotNull Collection<?> collection) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void clear() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean equals(Object object) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int hashCode() {
        throw new UnsupportedOperationException();
    }
}

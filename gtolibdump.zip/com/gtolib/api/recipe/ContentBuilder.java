package com.gtolib.api.recipe;

import com.gregtechceu.gtceu.api.recipe.chance.logic.ChanceLogic;
import com.gregtechceu.gtceu.api.recipe.content.Content;
import com.gtolib.api.recipe.SeparateContent;
import com.gtolib.api.recipe.ingredient.FastFluidIngredient;
import com.gtolib.api.recipe.ingredient.FastSizedIngredient;
import it.unimi.dsi.fastutil.Hash;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.fluids.FluidStack;

public final class ContentBuilder {
    public static final int maxChance = ChanceLogic.getMaxChancedValue();
    private final boolean list;
    private Object content;
    private int chance = maxChance;
    private int tierChanceBoost = 0;
    public static final Hash.Strategy<Content> HASH_STRATEGY = new ContentHashStrategy();

    private ContentBuilder(boolean bl) {
        this.list = bl;
        if (bl) {
            this.content = new ObjectArrayList();
        }
    }

    public static ContentBuilder create() {
        return new ContentBuilder(false);
    }

    public static ContentBuilder createList() {
        return new ContentBuilder(true);
    }

    public ContentBuilder EU(long l) {
        if (this.list) {
            ((List)this.content).add(l);
        }
        this.content = l;
        return this;
    }

    public ContentBuilder items(ItemStack ... itemStackArray) {
        for (ItemStack itemStack : itemStackArray) {
            ((List)this.content).add(FastSizedIngredient.create(itemStack));
        }
        return this;
    }

    public ContentBuilder item(ItemStack itemStack) {
        FastSizedIngredient fastSizedIngredient = FastSizedIngredient.create(itemStack);
        if (this.list) {
            ((List)this.content).add(fastSizedIngredient);
        } else {
            this.content = fastSizedIngredient;
        }
        return this;
    }

    public ContentBuilder fluids(FluidStack ... fluidStackArray) {
        for (FluidStack fluidStack : fluidStackArray) {
            ((List)this.content).add(FastFluidIngredient.of(fluidStack));
        }
        return this;
    }

    public ContentBuilder fluid(FluidStack fluidStack) {
        FastFluidIngredient fastFluidIngredient = FastFluidIngredient.of(fluidStack);
        if (this.list) {
            ((List)this.content).add(fastFluidIngredient);
        } else {
            this.content = fastFluidIngredient;
        }
        return this;
    }

    public Content builder() {
        return new Content(this.content, this.chance, maxChance, this.tierChanceBoost);
    }

    public List<Content> buildList() {
        return ((List)this.content).stream().map(object -> new Content(object, this.chance, maxChance, this.tierChanceBoost)).toList();
    }

    public ContentBuilder chance(int n) {
        this.chance = n;
        return this;
    }

    public ContentBuilder tierChanceBoost(int n) {
        this.tierChanceBoost = n;
        return this;
    }

    private static class ContentHashStrategy
    implements Hash.Strategy<Content> {
        private ContentHashStrategy() {
        }

        public int hashCode(Content content) {
            int n = content.chance + 31 * content.tierChanceBoost;
            n = 31 * n + content.content.hashCode();
            if (content instanceof SeparateContent) {
                n = 31 * n;
            }
            return n;
        }

        public boolean equals(Content content, Content content2) {
            if (content instanceof SeparateContent && !(content2 instanceof SeparateContent)) {
                return false;
            }
            return content != null && content2 != null && content.chance == content2.chance && content.tierChanceBoost == content2.tierChanceBoost && content.content.equals(content2.content);
        }
    }
}

package com.gtolib.api.recipe;

import com.gregtechceu.gtceu.api.capability.recipe.IRecipeCapabilityHolder;
import com.gregtechceu.gtceu.api.machine.trait.RecipeHandlerList;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gtolib.api.machine.feature.multiblock.IExtendedRecipeCapabilityHolder;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.RecipeType;
import com.gtolib.api.recipe.lookup.MapIngredient;
import java.util.Iterator;
import java.util.function.Predicate;

class RecipeType$SearchRecipeIterator<T extends RecipeType>
implements Iterator<Recipe> {
    boolean hasNext;
    int[] ingredients;
    RecipeHandlerList list;
    final IRecipeCapabilityHolder holder;
    final Predicate<Recipe> canHandle;
    final Iterator<RecipeHandlerList> inputList;
    int ingredientIndex;
    Iterator<GTRecipeType.ICustomRecipeLogic> customLogic;
    final T recipeType;

    RecipeType$SearchRecipeIterator(IRecipeCapabilityHolder iRecipeCapabilityHolder, T t, Predicate<Recipe> predicate) {
        this.holder = iRecipeCapabilityHolder;
        this.recipeType = t;
        this.canHandle = predicate;
        this.inputList = IExtendedRecipeCapabilityHolder.getInputList(iRecipeCapabilityHolder).listIterator(0);
        this.hasNext = this.inputList.hasNext();
    }

    @Override
    public boolean hasNext() {
        return this.hasNext;
    }

    @Override
    public Recipe next() {
        GTRecipe gTRecipe;
        while (this.list != null || this.inputList.hasNext()) {
            if (this.list == null) {
                this.list = this.inputList.next();
                MapIngredient.convertList(this.holder, this.list);
                if (this.list.intIngredientMap.isEmpty()) {
                    this.list = null;
                    continue;
                }
                this.ingredients = this.list.intIngredientMap.toIntArray();
                this.holder.setCurrentHandlerList(this.list, null);
            }
            while (this.ingredientIndex < this.ingredients.length) {
                gTRecipe = ((RecipeType)this.recipeType).lookup().recurseIngredientTreeFindRecipe(this.ingredients.length, this.ingredients, ((RecipeType)this.recipeType).lookup().lookup, this.canHandle, this.ingredientIndex, 0, 1 << this.ingredientIndex);
                ++this.ingredientIndex;
                if (gTRecipe == null) continue;
                return gTRecipe;
            }
            this.ingredientIndex = 0;
            this.list = null;
        }
        if (this.customLogic == null) {
            this.customLogic = this.recipeType.getCustomRecipeLogicRunners().listIterator(0);
        }
        while (this.customLogic.hasNext()) {
            gTRecipe = this.customLogic.next().createCustomRecipe(this.holder);
            if (gTRecipe == null) continue;
            return (Recipe)gTRecipe;
        }
        this.hasNext = false;
        return null;
    }
}

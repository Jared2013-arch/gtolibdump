package com.gtolib.api.recipe;

import com.google.gson.JsonObject;
import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.recipe.GTRecipeSerializer;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gregtechceu.gtceu.api.recipe.RecipeCondition;
import com.gregtechceu.gtceu.api.recipe.category.GTRecipeCategory;
import com.gregtechceu.gtceu.api.recipe.content.Content;
import com.gregtechceu.gtceu.api.recipe.content.ContentModifier;
import com.gregtechceu.gtceu.api.recipe.lookup.IntIngredientMap;
import com.gtolib.GTOCore;
import com.gtolib.api.recipe.ContentBuilder;
import com.gtolib.api.recipe.RecipeBuilder;
import com.gtolib.api.recipe.RecipeCapabilityMap;
import com.gtolib.api.recipe.research.ResearchData;
import com.gtolib.utils.RLUtils;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.HashCommon;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.util.Tuple;
import net.minecraft.world.item.crafting.RecipeSerializer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
public final class Recipe
extends GTRecipe {
    public static final Serializer SERIALIZER = new Serializer();
    public static final Recipe EMPTY = new Recipe(null, GTOCore.id("empty"), 0, 0L, 0L, 0L, Map.of(), Map.of(), null, null, new CompoundTag(), 0);
    public IntIngredientMap mapIngredient;
    public IntIngredientMap mapNotCountableIngredient;
    public IntIngredientMap mapCountableIngredient;
    @Nullable
    public ResearchData researchData;
    @Nullable
    public Recipe rootRecipe;
    public long eut;
    public long manat;
    public long cwut;
    public boolean perfect;
    public long contentParallel;
    private int hashCode;
    public int displayPriority;
    public final int priority;
    public final int tier;
    public final boolean root;

    Recipe(@Nullable GTRecipeType gTRecipeType, @Nullable ResourceLocation resourceLocation, int n, long l, long l2, long l3, Map<RecipeCapability<?>, List<Content>> map, Map<RecipeCapability<?>, List<Content>> map2, @Nullable Map<RecipeCapability<?>, List<Content>> map3, @Nullable Map<RecipeCapability<?>, List<Content>> map4, @NotNull CompoundTag compoundTag, int n2) {
        super(gTRecipeType, resourceLocation, map, map2, map3, map4, Collections.emptyList(), compoundTag, n2, null);
        this.root = false;
        this.priority = 0;
        this.tier = n;
        this.eut = l;
        this.manat = l2;
        this.cwut = l3;
    }

    Recipe(GTRecipeType gTRecipeType, @NotNull ResourceLocation resourceLocation, int n, long l, long l2, long l3, Map<RecipeCapability<?>, List<Content>> map, Map<RecipeCapability<?>, List<Content>> map2, Map<RecipeCapability<?>, List<Content>> map3, Map<RecipeCapability<?>, List<Content>> map4, List<RecipeCondition> list, @NotNull CompoundTag compoundTag, int n2, int n3, @NotNull GTRecipeCategory gTRecipeCategory) {
        super(gTRecipeType, resourceLocation, map, map2, map3, map4, list, compoundTag, n2, gTRecipeCategory);
        this.root = true;
        this.priority = n3;
        this.tier = n;
        this.eut = l;
        this.manat = l2;
        this.cwut = l3;
        this.rootRecipe = this;
        this.hashCode = resourceLocation.hashCode();
    }

    public static Recipe of(GTRecipe gTRecipe) {
        return (Recipe)gTRecipe;
    }

    public static int hashContent(Recipe recipe) {
        int n = HashCommon.long2int(recipe.eut);
        n = 31 * n + HashCommon.long2int(recipe.manat);
        n = 31 * n + HashCommon.long2int(recipe.cwut);
        for (List list : recipe.inputs.values()) {
            for (Content content : list) {
                n = 31 * n + ContentBuilder.HASH_STRATEGY.hashCode((Object)content);
            }
        }
        for (List list : recipe.outputs.values()) {
            for (Content content : list) {
                n = 31 * n + ContentBuilder.HASH_STRATEGY.hashCode((Object)content);
            }
        }
        return n;
    }

    public boolean hasTick() {
        return false;
    }

    public boolean equals(Object object) {
        if (!(object instanceof GTRecipe)) {
            return false;
        }
        GTRecipe gTRecipe = (GTRecipe)object;
        return gTRecipe.hashCode() == this.hashCode() && this.id.equals(gTRecipe.id);
    }

    @Override
    public int hashCode() {
        if (this.hashCode == 0) {
            this.hashCode = this.id.hashCode();
        }
        return this.hashCode;
    }

    public RecipeSerializer<?> m_7707_() {
        return SERIALIZER;
    }

    public Recipe copy() {
        Recipe recipe = new Recipe(null, this.id, this.tier, this.eut, this.manat, this.cwut, new RecipeCapabilityMap(this.inputs), new RecipeCapabilityMap(this.outputs), null, null, this.data, this.duration);
        recipe.hashCode = this.hashCode;
        recipe.rootRecipe = this.rootRecipe;
        recipe.ocLevel = this.ocLevel;
        recipe.parallels = this.parallels;
        recipe.contentParallel = this.contentParallel;
        return recipe;
    }

    public Recipe copy(ContentModifier contentModifier) {
        throw new UnsupportedOperationException();
    }

    public Recipe copy(ContentModifier contentModifier, boolean bl) {
        throw new UnsupportedOperationException();
    }

    public Recipe modifier(ContentModifier contentModifier, boolean bl) {
        if (contentModifier.multiplier() == 1.0) {
            return this;
        }
        this.parallels = contentModifier.apply(this.parallels);
        Recipe.modifierContents(this.inputs, contentModifier);
        Recipe.modifierContents(this.outputs, contentModifier);
        if (bl) {
            this.eut = contentModifier.apply(this.eut);
            this.manat = contentModifier.apply(this.manat);
            this.cwut = contentModifier.apply(this.cwut);
        }
        return this;
    }

    public long getInputEUt() {
        if (this.eut > 0L) {
            return this.eut;
        }
        return 0L;
    }

    public long getOutputEUt() {
        if (this.eut < 0L) {
            return -this.eut;
        }
        return 0L;
    }

    public void setOutputEUt(long l) {
        this.eut = l > 0L ? -l : 0L;
    }

    public long getInputMANAt() {
        if (this.manat > 0L) {
            return this.manat;
        }
        return 0L;
    }

    public long getOutputMANAt() {
        if (this.manat < 0L) {
            return -this.manat;
        }
        return 0L;
    }

    public void setParallels(long l) {
        this.parallels = l;
    }

    public Tag serializeNBT() {
        CompoundTag compoundTag = new CompoundTag();
        compoundTag.m_128359_("id", this.id.toString());
        if (this.root) {
            compoundTag.m_128379_("root", true);
        } else {
            compoundTag.m_128365_("recipe", Serializer.CODEC.encodeStart((DynamicOps)NbtOps.f_128958_, (Object)this).result().orElse(new CompoundTag()));
            compoundTag.m_128405_("ocLevel", this.ocLevel);
            compoundTag.m_128356_("parallels", this.parallels);
            if (this.rootRecipe != null) {
                compoundTag.m_128359_("rootID", this.rootRecipe.id.toString());
            }
        }
        return compoundTag;
    }

    @Nullable
    public static Recipe deserializeNBT(@Nullable Tag tag) {
        if (tag instanceof CompoundTag) {
            CompoundTag compoundTag = (CompoundTag)tag;
            ResourceLocation resourceLocation = RLUtils.parse(compoundTag.m_128461_("id"));
            if (compoundTag.m_128471_("root")) {
                return RecipeBuilder.RECIPE_MAP.get(resourceLocation);
            }
            Recipe recipe = Serializer.CODEC.parse((DynamicOps)NbtOps.f_128958_, (Object)compoundTag.m_128423_("recipe")).result().orElse(null);
            if (recipe != null) {
                recipe.id = resourceLocation;
                recipe.ocLevel = compoundTag.m_128451_("ocLevel");
                recipe.setParallels(compoundTag.m_128454_("parallels"));
                String string = compoundTag.m_128461_("rootID");
                if (!string.isEmpty()) {
                    recipe.rootRecipe = RecipeBuilder.RECIPE_MAP.get(RLUtils.parse(compoundTag.m_128461_("rootID")));
                }
                return recipe;
            }
        }
        return null;
    }

    private static void modifierContents(Map<RecipeCapability<?>, List<Content>> map, ContentModifier contentModifier) {
        for (Map.Entry<RecipeCapability<?>, List<Content>> entry : map.entrySet()) {
            List<Content> list = entry.getValue();
            if (list == null || list.isEmpty()) continue;
            ObjectArrayList objectArrayList = new ObjectArrayList(list.size());
            for (Content content : list) {
                objectArrayList.add(content.copy(entry.getKey(), contentModifier));
            }
            entry.setValue(objectArrayList);
        }
    }

    public void setEut(long l) {
        this.eut = l;
    }

    public void setManat(long l) {
        this.manat = l;
    }

    private Recipe(int n, long l, long l2, long l3, Map<RecipeCapability<?>, List<Content>> map, Map<RecipeCapability<?>, List<Content>> map2, @NotNull CompoundTag compoundTag, int n2) {
        this(null, null, n, l, l2, l3, map, map2, null, null, compoundTag, n2);
    }

    public static class Serializer
    implements RecipeSerializer<Recipe> {
        private static final Codec<Recipe> CODEC = RecordCodecBuilder.create(instance -> instance.group(ExtraCodecs.f_144628_.optionalFieldOf("tier", 0).forGetter(recipe -> recipe.tier), Codec.LONG.optionalFieldOf("eu", (Object)0L).forGetter(recipe -> recipe.eut), Codec.LONG.optionalFieldOf("mana", (Object)0L).forGetter(recipe -> recipe.manat), Codec.LONG.optionalFieldOf("cwu", (Object)0L).forGetter(recipe -> recipe.cwut), RecipeCapabilityMap.CODEC.optionalFieldOf("inputs", (Object)Map.of()).forGetter(recipe -> recipe.inputs), RecipeCapabilityMap.CODEC.optionalFieldOf("outputs", (Object)Map.of()).forGetter(recipe -> recipe.outputs), CompoundTag.f_128325_.optionalFieldOf("data", new CompoundTag()).forGetter(recipe -> recipe.data), ExtraCodecs.f_144628_.fieldOf("duration").forGetter(recipe -> recipe.duration)).apply((Applicative)instance, Recipe::new));

        @NotNull
        public Recipe fromJson(@NotNull ResourceLocation resourceLocation, @NotNull JsonObject jsonObject) {
            Recipe recipe = (Recipe)CODEC.parse((DynamicOps)JsonOps.INSTANCE, (Object)jsonObject).getOrThrow(false, GTCEu.LOGGER::error);
            recipe.setId(resourceLocation);
            return recipe;
        }

        @NotNull
        public Recipe fromNetwork(@NotNull ResourceLocation resourceLocation, @NotNull FriendlyByteBuf friendlyByteBuf) {
            int n2 = friendlyByteBuf.readInt();
            long l = friendlyByteBuf.readLong();
            long l2 = friendlyByteBuf.readLong();
            long l3 = friendlyByteBuf.readLong();
            int n3 = friendlyByteBuf.readInt();
            RecipeCapabilityMap<List<Content>> recipeCapabilityMap = Serializer.tuplesToMap((List)friendlyByteBuf.m_236838_(n -> new ObjectArrayList(), GTRecipeSerializer::entryReader));
            RecipeCapabilityMap<List<Content>> recipeCapabilityMap2 = Serializer.tuplesToMap((List)friendlyByteBuf.m_236838_(n -> new ObjectArrayList(), GTRecipeSerializer::entryReader));
            CompoundTag compoundTag = friendlyByteBuf.m_130260_();
            if (compoundTag == null) {
                compoundTag = new CompoundTag();
            }
            return new Recipe(null, resourceLocation, n2, l, l2, l3, recipeCapabilityMap, recipeCapabilityMap2, null, null, compoundTag, n3);
        }

        public void toNetwork(FriendlyByteBuf friendlyByteBuf, Recipe recipe) {
            friendlyByteBuf.writeInt(recipe.tier);
            friendlyByteBuf.writeLong(recipe.eut);
            friendlyByteBuf.writeLong(recipe.manat);
            friendlyByteBuf.writeLong(recipe.cwut);
            friendlyByteBuf.writeInt(recipe.duration);
            friendlyByteBuf.m_236828_(recipe.inputs.entrySet(), GTRecipeSerializer::entryWriter);
            friendlyByteBuf.m_236828_(recipe.outputs.entrySet(), GTRecipeSerializer::entryWriter);
            friendlyByteBuf.m_130079_(recipe.data);
        }

        private static RecipeCapabilityMap<List<Content>> tuplesToMap(List<Tuple<RecipeCapability<?>, List<Content>>> list) {
            RecipeCapabilityMap<List<Content>> recipeCapabilityMap = new RecipeCapabilityMap<List<Content>>();
            list.forEach(tuple -> recipeCapabilityMap.put((RecipeCapability)tuple.m_14418_(), (List)tuple.m_14419_()));
            return recipeCapabilityMap;
        }
    }
}

package com.gtolib.api.recipe;

import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.gtolib.api.recipe.RecipeCapabilityMap;
import java.util.Iterator;
import java.util.Map;

class RecipeCapabilityMap$EntryIterator
implements Iterator<Map.Entry<RecipeCapability<?>, T>> {
    private boolean hasNext;
    private boolean complete;

    private RecipeCapabilityMap$EntryIterator() {
    }

    @Override
    public boolean hasNext() {
        return this.hasNext;
    }

    @Override
    public Map.Entry<RecipeCapability<?>, T> next() {
        if (this.complete) {
            this.complete = false;
            if (RecipeCapabilityMap.this.itemEntry == null) {
                RecipeCapabilityMap.this.itemEntry = new RecipeCapabilityMap.ItemEntry(RecipeCapabilityMap.this);
            }
            return RecipeCapabilityMap.this.itemEntry;
        }
        this.hasNext = false;
        if (RecipeCapabilityMap.this.fluid != null) {
            if (RecipeCapabilityMap.this.fluidEntry == null) {
                RecipeCapabilityMap.this.fluidEntry = new RecipeCapabilityMap.FluidEntry(RecipeCapabilityMap.this);
            }
            return RecipeCapabilityMap.this.fluidEntry;
        }
        if (RecipeCapabilityMap.this.itemEntry == null) {
            RecipeCapabilityMap.this.itemEntry = new RecipeCapabilityMap.ItemEntry(RecipeCapabilityMap.this);
        }
        return RecipeCapabilityMap.this.itemEntry;
    }
}

package com.gtolib.api.recipe.research;

import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gregtechceu.gtceu.utils.GTStringUtils;
import com.gtolib.api.recipe.research.ResearchData;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;

public abstract class ResearchBuilder<T extends ResearchBuilder<T>> {
    ItemStack researchStack;
    Item dataItem;
    String researchId;
    long eut;
    int duration;

    public T researchStack(@NotNull Item item) {
        return this.researchStack(item.m_7968_());
    }

    public T researchStack(@NotNull ItemStack itemStack) {
        if (!itemStack.m_41619_()) {
            this.researchStack = itemStack;
        }
        return (T)this;
    }

    public T dataStack(@NotNull ItemStack itemStack) {
        this.dataItem = itemStack.m_41720_();
        return (T)this;
    }

    public T researchId(String string) {
        this.researchId = string;
        return (T)this;
    }

    public T EUt(long l) {
        this.eut = l;
        return (T)this;
    }

    public T duration(int n) {
        this.duration = n;
        return (T)this;
    }

    void validateResearchItem() {
        if (this.researchStack == null) {
            throw new IllegalArgumentException("Research stack cannot be null or empty!");
        }
        if (this.researchId == null) {
            this.researchId = GTStringUtils.itemStackToString(this.researchStack);
        }
        if (this.dataItem == null) {
            this.dataItem = this.getDefaultDataItem();
        }
    }

    abstract Item getDefaultDataItem();

    public abstract ResearchData build(GTRecipeType var1);
}

package com.gtolib.api.recipe.research;

import com.gregtechceu.gtceu.api.GTValues;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gregtechceu.gtceu.common.data.GTItems;
import com.gregtechceu.gtceu.utils.FormattingUtil;
import com.gregtechceu.gtceu.utils.ResearchManager;
import com.gtocore.common.data.GTORecipeTypes;
import com.gtolib.api.recipe.research.ResearchBuilder;
import com.gtolib.api.recipe.research.ResearchData;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public final class ScannerBuilder
extends ResearchBuilder<ScannerBuilder> {
    static final int DEFAULT_SCANNER_DURATION = 1200;
    static final int DEFAULT_SCANNER_EUT = GTValues.VA[3];

    @Override
    Item getDefaultDataItem() {
        return (Item)GTItems.TOOL_DATA_STICK.get();
    }

    @Override
    public ResearchData build(GTRecipeType gTRecipeType) {
        this.validateResearchItem();
        if (this.duration <= 0) {
            this.duration = 1200;
        }
        if (this.eut <= 0L) {
            this.eut = DEFAULT_SCANNER_EUT;
        }
        ItemStack itemStack = this.dataItem.m_7968_();
        ResearchManager.writeResearchToNBT(itemStack.m_41784_(), this.researchId, gTRecipeType);
        GTORecipeTypes.SCANNER_RECIPES.recipeBuilder(FormattingUtil.toLowerCaseUnderscore(this.researchId)).inputItems(this.dataItem).inputItems(this.researchStack).outputItems(itemStack).duration(this.duration).EUt(this.eut).researchScan(true).save();
        return new ResearchData(this.researchId, itemStack);
    }
}

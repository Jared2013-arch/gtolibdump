package com.gtolib.api.recipe.research;

import net.minecraft.world.item.ItemStack;

public record ResearchData(String researchId, ItemStack dataStack) {
}

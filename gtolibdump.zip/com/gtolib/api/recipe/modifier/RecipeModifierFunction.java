package com.gtolib.api.recipe.modifier;

import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.SimpleGeneratorMachine;
import com.gregtechceu.gtceu.api.machine.feature.IOverclockMachine;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.ICoilMachine;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiController;
import com.gregtechceu.gtceu.api.machine.multiblock.WorkableElectricMultiblockMachine;
import com.gregtechceu.gtceu.api.machine.trait.RecipeLogic;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.recipe.OverclockingLogic;
import com.gregtechceu.gtceu.api.recipe.content.ContentModifier;
import com.gregtechceu.gtceu.api.recipe.modifier.ModifierFunction;
import com.gregtechceu.gtceu.api.recipe.modifier.RecipeModifier;
import com.gregtechceu.gtceu.common.machine.multiblock.steam.LargeBoilerMachine;
import com.gtocore.config.GTOConfig;
import com.gtolib.api.machine.feature.IOverclockConfigMachine;
import com.gtolib.api.machine.feature.IPowerAmplifierMachine;
import com.gtolib.api.machine.feature.IUpgradeMachine;
import com.gtolib.api.machine.mana.feature.IManaContainerMachine;
import com.gtolib.api.machine.trait.IEnhancedRecipeLogic;
import com.gtolib.api.recipe.IdleReason;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.modifier.ParallelLogic;
import com.gtolib.api.recipe.modifier.RecipeModifierFunctionList;
import com.gtolib.utils.GTOUtils;
import com.gtolib.utils.MachineUtils;
import com.gtolib.utils.MathUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@FunctionalInterface
public interface RecipeModifierFunction
extends RecipeModifier {
    public static final RecipeModifierFunction PARALLELIZABLE_MANA_OVERCLOCK = new RecipeModifierFunctionList((metaMachine, recipe) -> RecipeModifierFunction.manaOverclocking(metaMachine, RecipeModifierFunction.hatchParallel(metaMachine, recipe)));
    public static final RecipeModifierFunction PARALLELIZABLE_OVERCLOCK = new RecipeModifierFunctionList((metaMachine, recipe) -> RecipeModifierFunction.overclocking(metaMachine, RecipeModifierFunction.hatchParallel(metaMachine, recipe)));
    public static final RecipeModifierFunction PARALLELIZABLE_PERFECT_OVERCLOCK = new RecipeModifierFunctionList((metaMachine, recipe) -> RecipeModifierFunction.perfectOverclocking(metaMachine, RecipeModifierFunction.hatchParallel(metaMachine, recipe)));
    public static final RecipeModifierFunction GCYM_OVERCLOCKING = new RecipeModifierFunctionList((metaMachine, recipe) -> RecipeModifierFunction.overclocking(metaMachine, RecipeModifierFunction.hatchParallel(metaMachine, recipe), false, 0.8, 0.6, 0.5));
    public static final RecipeModifierFunction GENERATOR_OVERCLOCKING = RecipeModifierFunction::generatorOverclocking;
    public static final RecipeModifierFunction PERFECT_OVERCLOCKING = RecipeModifierFunction::perfectOverclocking;
    public static final RecipeModifierFunction OVERCLOCKING = RecipeModifierFunction::overclocking;
    public static final RecipeModifierFunction HATCH_PARALLEL = RecipeModifierFunction::hatchParallel;
    public static final RecipeModifierFunction SIMPLE_GENERATOR_MACHINEMODIFIER = (metaMachine, recipe) -> {
        if (metaMachine instanceof SimpleGeneratorMachine) {
            SimpleGeneratorMachine simpleGeneratorMachine = (SimpleGeneratorMachine)((Object)metaMachine);
            long l = recipe.getOutputEUt();
            if (l > 0L) {
                if ((recipe = ParallelLogic.accurateParallel(metaMachine, recipe, simpleGeneratorMachine.getOverclockVoltage() / l)) == null) {
                    return null;
                }
                recipe.duration = recipe.duration * GTOUtils.getGeneratorEfficiency(simpleGeneratorMachine.getRecipeType(), simpleGeneratorMachine.getTier()) / 100;
                if (recipe.duration < 1) {
                    return null;
                }
                return recipe;
            }
            return recipe;
        }
        return null;
    };
    public static final RecipeModifierFunction LARGE_BOILER_MODIFIER = (metaMachine, recipe) -> {
        if (metaMachine instanceof LargeBoilerMachine) {
            LargeBoilerMachine largeBoilerMachine = (LargeBoilerMachine)((Object)metaMachine);
            int n = recipe.data.m_128451_("temperature");
            if (n > 0 && largeBoilerMachine.getCurrentTemperature() + 274 < n) {
                return null;
            }
            double d = (double)recipe.duration * 1600.0 / (double)largeBoilerMachine.maxTemperature;
            if (d < 1.0 && (recipe = ParallelLogic.accurateParallel(metaMachine, recipe, (long)(1.0 / d))) == null) {
                return null;
            }
            if (largeBoilerMachine.getThrottle() < 100) {
                d = d * 100.0 / (double)largeBoilerMachine.getThrottle();
            }
            recipe.duration = (int)d;
        }
        return recipe;
    };

    @NotNull
    default public ModifierFunction getModifier(@NotNull MetaMachine metaMachine, @NotNull GTRecipe gTRecipe) {
        return ModifierFunction.NULL;
    }

    @Override
    @Nullable
    default public GTRecipe applyModifier(@NotNull MetaMachine metaMachine, @NotNull GTRecipe gTRecipe) {
        return this.apply(metaMachine, (Recipe)gTRecipe);
    }

    @Nullable
    public Recipe apply(@NotNull MetaMachine var1, @NotNull Recipe var2);

    public static RecipeModifierFunction overclocking(double d, double d2, double d3) {
        return (metaMachine, recipe) -> RecipeModifierFunction.overclocking(metaMachine, recipe, false, d2, d3, d);
    }

    public static RecipeModifierFunction accurateParallel(long l) {
        return (metaMachine, recipe) -> ParallelLogic.accurateParallel(metaMachine, recipe, l);
    }

    public static RecipeModifierFunction recipeReduction(double d, double d2) {
        return (metaMachine, recipe) -> RecipeModifierFunction.recipeReduction(recipe, d, d2);
    }

    public static RecipeModifierFunction coilReductionOverclock(double d) {
        return (metaMachine, recipe) -> {
            if (metaMachine instanceof ICoilMachine) {
                ICoilMachine iCoilMachine = (ICoilMachine)((Object)metaMachine);
                return RecipeModifierFunction.overclocking(metaMachine, RecipeModifierFunction.hatchParallel(metaMachine, recipe), false, 1.0 - (double)iCoilMachine.getCoilTier() * 0.05, 1.0 - (double)iCoilMachine.getCoilTier() * 0.05, d);
            }
            return null;
        };
    }

    public static Recipe crackerOverclock(MetaMachine metaMachine, Recipe recipe) {
        if (metaMachine instanceof ICoilMachine) {
            ICoilMachine iCoilMachine = (ICoilMachine)((Object)metaMachine);
            return RecipeModifierFunction.overclocking(metaMachine, recipe, false, Math.max(0.2, 1.0 - (double)iCoilMachine.getCoilTier() * 0.1), 1.0, 0.5);
        }
        return null;
    }

    public static Recipe pyrolyseOvenOverclock(MetaMachine metaMachine, Recipe recipe) {
        if (metaMachine instanceof ICoilMachine) {
            ICoilMachine iCoilMachine = (ICoilMachine)((Object)metaMachine);
            if (iCoilMachine.getCoilTier() == 0) {
                return RecipeModifierFunction.overclocking(metaMachine, recipe, false, 1.0, 1.33, 0.5);
            }
            return RecipeModifierFunction.overclocking(metaMachine, recipe, false, 1.0, 2.0 / (double)(iCoilMachine.getCoilTier() + 1), 0.5);
        }
        return null;
    }

    public static Recipe ebfOverclock(MetaMachine metaMachine, Recipe recipe) {
        if (metaMachine instanceof ICoilMachine) {
            ICoilMachine iCoilMachine = (ICoilMachine)((Object)metaMachine);
            if (metaMachine instanceof IOverclockMachine) {
                long l;
                int n;
                Object object;
                IOverclockMachine iOverclockMachine = (IOverclockMachine)((Object)metaMachine);
                int n2 = iCoilMachine.getCoilType().getCoilTemperature() + 100 * Math.max(0, ((WorkableElectricMultiblockMachine)((Object)iCoilMachine)).getTier() - 2);
                int n3 = recipe.data.m_128451_("ebf_temp");
                if (n3 > n2) {
                    RecipeLogic recipeLogic = ((WorkableElectricMultiblockMachine)((Object)iCoilMachine)).getRecipeLogic();
                    if (recipeLogic instanceof IEnhancedRecipeLogic) {
                        IEnhancedRecipeLogic iEnhancedRecipeLogic = (IEnhancedRecipeLogic)((Object)recipeLogic);
                        iEnhancedRecipeLogic.gtolib$setIdleReason(IdleReason.INSUFFICIENT_TEMPERATURE.reason());
                    }
                    return null;
                }
                long l2 = (long)((double)recipe.getInputEUt() * OverclockingLogic.getCoilEUtDiscount(n3, n2));
                int n4 = recipe.duration;
                if (metaMachine instanceof IUpgradeMachine) {
                    object = (IUpgradeMachine)((Object)metaMachine);
                    l2 = (long)((double)l2 * object.gtolib$getEnergy());
                    n4 = (int)((double)n4 * object.gtolib$getSpeed());
                }
                if (metaMachine instanceof IPowerAmplifierMachine) {
                    object = (IPowerAmplifierMachine)((Object)metaMachine);
                    l2 = (long)((double)l2 * object.gtolib$getPowerAmplifier());
                    n4 = (int)((double)n4 / object.gtolib$getPowerAmplifier());
                }
                if (n4 == 0) {
                    n4 = 1;
                }
                long l3 = iOverclockMachine.getOverclockVoltage();
                int n5 = Math.max(0, (n2 - n3) / 900);
                long l4 = 0L;
                boolean bl = ((IMultiController)((Object)metaMachine)).isBatchEnabled();
                if (metaMachine instanceof IOverclockConfigMachine) {
                    IOverclockConfigMachine iOverclockConfigMachine = (IOverclockConfigMachine)((Object)metaMachine);
                    n = iOverclockConfigMachine.gtolib$getOCLimit();
                } else {
                    n = 5;
                }
                int n6 = n;
                int n7 = 0;
                long l5 = 1L;
                while ((l = l2 << 2) <= l3 && l >= 0L) {
                    int n8 = n4 >> (n5 > 0 ? 2 : 1);
                    if (n8 < n6) {
                        if (l4 == 0L && (l4 = ParallelLogic.getContentMultiplier(metaMachine, recipe)) == 0L) {
                            return null;
                        }
                        long l6 = l5 << 1;
                        if (l6 > l4) break;
                        l5 = l6;
                    } else {
                        n4 = n8;
                    }
                    --n5;
                    l2 = l;
                    ++n7;
                }
                recipe.ocLevel = n7 / 2;
                recipe.duration = n4;
                recipe.setEut(l2);
                if (bl && l4 == 0L && (l4 = ParallelLogic.getContentMultiplier(metaMachine, recipe)) == 0L) {
                    return null;
                }
                if (bl && l4 > 1L || l5 > 1L) {
                    if (bl) {
                        if (l5 < l4) {
                            int n9 = Math.min(MathUtil.saturatedCast(l4 / l5), Math.max(1, GTOConfig.INSTANCE.batchProcessingMaxDuration / recipe.duration));
                            recipe.duration *= n9;
                            l5 *= (long)n9;
                        }
                        recipe.batchParallels = MathUtil.saturatedCast(l5);
                    }
                    return recipe.modifier(ContentModifier.multiplier(l5), false);
                }
            }
        }
        return recipe;
    }

    public static Recipe multiSmelterParallel(MetaMachine metaMachine, Recipe recipe) {
        if (metaMachine instanceof ICoilMachine) {
            ICoilMachine iCoilMachine = (ICoilMachine)((Object)metaMachine);
            int n = 32 * iCoilMachine.getCoilType().getLevel();
            if ((recipe = ParallelLogic.accurateParallel(metaMachine, recipe, n)) == null) {
                return null;
            }
            recipe.setEut(Math.max(1L, 4L * (long)((double)recipe.parallels / (8.0 * (double)iCoilMachine.getCoilType().getEnergyDiscount()))));
            recipe.duration = (int)(256.0 * (double)recipe.parallels / (double)n);
            return RecipeModifierFunction.overclocking(metaMachine, recipe);
        }
        return null;
    }

    @Nullable
    public static Recipe hatchParallel(MetaMachine metaMachine, Recipe recipe) {
        return ParallelLogic.accurateParallel(metaMachine, recipe, MachineUtils.getHatchParallel(metaMachine));
    }

    public static Recipe recipeReduction(Recipe recipe, double d, double d2) {
        if (d != 1.0) {
            long l = (long)Math.max(1.0, (double)recipe.getInputEUt() * d);
            recipe.setEut(l);
        }
        if (d2 != 1.0) {
            recipe.duration = (int)Math.max(1.0, (double)recipe.duration * d2);
        }
        return recipe;
    }

    @Nullable
    public static Recipe laserLossOverclocking(MetaMachine metaMachine, @Nullable Recipe recipe) {
        return RecipeModifierFunction.overclocking(metaMachine, recipe, false, 1.0, 1.0, 0.65);
    }

    @Nullable
    public static Recipe generatorOverclocking(MetaMachine metaMachine, @Nullable Recipe recipe) {
        return RecipeModifierFunction.overclocking(metaMachine, recipe, true, 1.0, 1.0, 0.2);
    }

    @Nullable
    public static Recipe perfectOverclocking(MetaMachine metaMachine, @Nullable Recipe recipe) {
        return RecipeModifierFunction.overclocking(metaMachine, recipe, false, 1.0, 1.0, 0.25);
    }

    @Nullable
    public static Recipe overclocking(MetaMachine metaMachine, @Nullable Recipe recipe) {
        return RecipeModifierFunction.overclocking(metaMachine, recipe, false, 1.0, 1.0, 0.5);
    }

    @Nullable
    public static Recipe overclocking(MetaMachine metaMachine, @Nullable Recipe recipe, boolean bl, double d, double d2, double d3) {
        if (recipe != null && metaMachine instanceof IOverclockMachine) {
            Object object;
            IOverclockMachine iOverclockMachine = (IOverclockMachine)((Object)metaMachine);
            if (metaMachine instanceof IPowerAmplifierMachine) {
                object = (IPowerAmplifierMachine)((Object)metaMachine);
                d *= object.gtolib$getPowerAmplifier();
                d2 /= object.gtolib$getPowerAmplifier();
            }
            if (metaMachine instanceof IUpgradeMachine) {
                object = (IUpgradeMachine)((Object)metaMachine);
                d *= object.gtolib$getEnergy();
                d2 *= object.gtolib$getSpeed();
            }
            return RecipeModifierFunction.overclocking(metaMachine, recipe, (long)((double)(bl ? recipe.getOutputEUt() : recipe.getInputEUt()) * d), iOverclockMachine.getOverclockVoltage(), bl, d2, d3);
        }
        return recipe;
    }

    @Nullable
    private static Recipe overclocking(MetaMachine metaMachine, @NotNull Recipe recipe, long l, long l2, boolean bl, double d, double d2) {
        long l3;
        int n;
        IMultiController iMultiController;
        boolean bl2;
        long l4 = 0L;
        double d3 = (double)recipe.duration * d;
        if (d3 == 0.0) {
            d3 = 1.0;
        }
        d2 = recipe.perfect ? 0.25 : d2;
        boolean bl3 = bl2 = metaMachine instanceof IMultiController && (iMultiController = (IMultiController)((Object)metaMachine)).isBatchEnabled();
        if (metaMachine instanceof IOverclockConfigMachine) {
            IOverclockConfigMachine iOverclockConfigMachine = (IOverclockConfigMachine)((Object)metaMachine);
            n = iOverclockConfigMachine.gtolib$getOCLimit();
        } else {
            n = 5;
        }
        int n2 = n;
        int n3 = bl ? 5 : 2;
        int n4 = 0;
        long l5 = 1L;
        while ((l3 = l << 2) <= l2 && l3 >= 0L) {
            double d4 = d3 * d2;
            if (d4 < (double)n2) {
                if (l4 == 0L && (l4 = ParallelLogic.getContentMultiplier(metaMachine, recipe)) == 0L) {
                    return null;
                }
                long l6 = l5 * (long)n3;
                if (l6 > l4) break;
                l5 = l6;
            } else {
                d3 = d4;
            }
            l = l3;
            ++n4;
        }
        recipe.ocLevel = n4;
        recipe.duration = (int)Math.ceil(d3);
        recipe.setEut(bl ? -l : l);
        if (bl2 && l4 == 0L && (l4 = ParallelLogic.getContentMultiplier(metaMachine, recipe)) == 0L) {
            return null;
        }
        if (bl2 && l4 > 1L || l5 > 1L) {
            if (bl2) {
                if (l5 < l4) {
                    int n5 = Math.min(MathUtil.saturatedCast(l4 / l5), Math.max(1, GTOConfig.INSTANCE.batchProcessingMaxDuration / recipe.duration));
                    recipe.duration *= n5;
                    l5 *= (long)n5;
                }
                recipe.batchParallels = MathUtil.saturatedCast(l5);
            }
            return recipe.modifier(ContentModifier.multiplier(l5), false);
        }
        return recipe;
    }

    @Nullable
    public static Recipe externalEnergyOverclocking(MetaMachine metaMachine, Recipe recipe, long l, long l2, boolean bl, double d, double d2) {
        return RecipeModifierFunction.overclocking(metaMachine, recipe, l, (long)((double)l2 * d), false, d2, bl ? 0.25 : 0.5);
    }

    @Nullable
    private static Recipe manaOverclocking(MetaMachine metaMachine, @Nullable Recipe recipe) {
        if (metaMachine instanceof IManaContainerMachine) {
            IManaContainerMachine iManaContainerMachine = (IManaContainerMachine)((Object)metaMachine);
            return RecipeModifierFunction.manaOverclocking(metaMachine, recipe, iManaContainerMachine.getManaContainer().getMaxIORate());
        }
        return recipe;
    }

    @Nullable
    public static Recipe manaOverclocking(MetaMachine metaMachine, @Nullable Recipe recipe, long l) {
        if (recipe != null) {
            long l2;
            int n;
            IMultiController iMultiController;
            boolean bl;
            long l3 = recipe.getInputMANAt();
            int n2 = recipe.duration;
            if (n2 == 0) {
                n2 = 1;
            }
            boolean bl2 = bl = metaMachine instanceof IMultiController && (iMultiController = (IMultiController)((Object)metaMachine)).isBatchEnabled();
            if (metaMachine instanceof IOverclockConfigMachine) {
                IOverclockConfigMachine iOverclockConfigMachine = (IOverclockConfigMachine)((Object)metaMachine);
                n = iOverclockConfigMachine.gtolib$getOCLimit();
            } else {
                n = 5;
            }
            int n3 = n;
            long l4 = 0L;
            long l5 = 1L;
            int n4 = 0;
            while ((l2 = l3 << 2) <= l && l2 >= 0L) {
                int n5 = n2 >> 2;
                if (n5 < n3) {
                    if (l4 == 0L && (l4 = ParallelLogic.getContentMultiplier(metaMachine, recipe)) == 0L) {
                        return null;
                    }
                    long l6 = l5 << 1;
                    if (l6 > l4) break;
                    l5 = l6;
                } else {
                    n2 = n5;
                }
                l3 = l2;
                ++n4;
            }
            recipe.ocLevel = n4 / 2;
            recipe.duration = n2;
            recipe.setManat(l3);
            if (bl && l4 == 0L && (l4 = ParallelLogic.getContentMultiplier(metaMachine, recipe)) == 0L) {
                return null;
            }
            if (bl && l4 > 1L || l5 > 1L) {
                if (bl) {
                    if (l5 < l4) {
                        int n6 = Math.min(MathUtil.saturatedCast(l4 / l5), Math.max(1, GTOConfig.INSTANCE.batchProcessingMaxDuration / recipe.duration));
                        recipe.duration *= n6;
                        l5 *= (long)n6;
                    }
                    recipe.batchParallels = MathUtil.saturatedCast(l5);
                }
                return recipe.modifier(ContentModifier.multiplier(l5), false);
            }
        }
        return recipe;
    }

    public static class Overclocking
    implements OverclockingLogic {
        private final int factor;

        public Overclocking(boolean bl) {
            this.factor = bl ? 2 : 1;
        }

        public OverclockingLogic.OCResult runOverclockingLogic(OverclockingLogic.OCParams oCParams, long l) {
            long l2;
            int n = oCParams.duration();
            long l3 = oCParams.eut();
            int n2 = 0;
            while (n > 2 && (l2 = l3 << 2) <= l) {
                l3 = l2;
                n >>= this.factor;
                ++n2;
            }
            return new OverclockingLogic.OCResult((double)l3 / (double)oCParams.eut(), (double)n / (double)oCParams.duration(), n2, 1);
        }
    }
}

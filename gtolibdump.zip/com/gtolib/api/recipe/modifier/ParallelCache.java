package com.gtolib.api.recipe.modifier;

import com.gregtechceu.gtceu.utils.ItemStackHashStrategy;
import com.gregtechceu.gtceu.utils.collection.O2LOpenCustomCacheHashMap;
import com.gtolib.api.recipe.ingredient.FastFluidIngredient;
import it.unimi.dsi.fastutil.objects.Object2LongOpenCustomHashMap;
import it.unimi.dsi.fastutil.objects.Reference2LongOpenHashMap;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.material.Fluid;

public final class ParallelCache {
    private Object2LongOpenCustomHashMap<ItemStack> itemTemporaryMap;
    private Object2LongOpenCustomHashMap<ItemStack> itemIngredientMap;
    private Reference2LongOpenHashMap<Ingredient> itemConsumableMap;
    private ReferenceOpenHashSet<Ingredient> itemNotConsumableMap;
    private Reference2LongOpenHashMap<Fluid> fluidTemporaryMap;
    private Reference2LongOpenHashMap<Fluid> fluidIngredientMap;
    private Reference2LongOpenHashMap<FastFluidIngredient> fluidConsumableMap;
    private ReferenceOpenHashSet<FastFluidIngredient> fluidNotConsumableMap;

    Object2LongOpenCustomHashMap<ItemStack> getItemTemporaryMap() {
        if (this.itemTemporaryMap == null) {
            this.itemTemporaryMap = new O2LOpenCustomCacheHashMap(ItemStackHashStrategy.ITEM_AND_TAG);
        }
        return this.itemTemporaryMap;
    }

    Object2LongOpenCustomHashMap<ItemStack> getItemIngredientMap() {
        if (this.itemIngredientMap == null) {
            this.itemIngredientMap = new O2LOpenCustomCacheHashMap(ItemStackHashStrategy.ITEM_AND_TAG);
        }
        return this.itemIngredientMap;
    }

    Reference2LongOpenHashMap<Ingredient> getItemConsumableMap() {
        if (this.itemConsumableMap == null) {
            this.itemConsumableMap = new Reference2LongOpenHashMap();
        }
        return this.itemConsumableMap;
    }

    ReferenceOpenHashSet<Ingredient> getItemNotConsumableMap() {
        if (this.itemNotConsumableMap == null) {
            this.itemNotConsumableMap = new ReferenceOpenHashSet();
        }
        return this.itemNotConsumableMap;
    }

    Reference2LongOpenHashMap<Fluid> getFluidTemporaryMap() {
        if (this.fluidTemporaryMap == null) {
            this.fluidTemporaryMap = new Reference2LongOpenHashMap();
        }
        return this.fluidTemporaryMap;
    }

    Reference2LongOpenHashMap<Fluid> getFluidIngredientMap() {
        if (this.fluidIngredientMap == null) {
            this.fluidIngredientMap = new Reference2LongOpenHashMap();
        }
        return this.fluidIngredientMap;
    }

    Reference2LongOpenHashMap<FastFluidIngredient> getFluidConsumableMap() {
        if (this.fluidConsumableMap == null) {
            this.fluidConsumableMap = new Reference2LongOpenHashMap();
        }
        return this.fluidConsumableMap;
    }

    ReferenceOpenHashSet<FastFluidIngredient> getFluidNotConsumableMap() {
        if (this.fluidNotConsumableMap == null) {
            this.fluidNotConsumableMap = new ReferenceOpenHashSet();
        }
        return this.fluidNotConsumableMap;
    }

    void cleanItemMap() {
        if (this.itemTemporaryMap != null && !this.itemTemporaryMap.isEmpty()) {
            this.itemTemporaryMap.clear();
        }
        if (this.itemIngredientMap != null && !this.itemIngredientMap.isEmpty()) {
            this.itemIngredientMap.clear();
        }
        if (this.itemConsumableMap != null && !this.itemConsumableMap.isEmpty()) {
            this.itemConsumableMap.clear();
        }
        if (this.itemNotConsumableMap != null && !this.itemNotConsumableMap.isEmpty()) {
            this.itemNotConsumableMap.clear();
        }
    }

    void cleanFluidMap() {
        if (this.fluidTemporaryMap != null && !this.fluidTemporaryMap.isEmpty()) {
            this.fluidTemporaryMap.clear();
        }
        if (this.fluidIngredientMap != null && !this.fluidIngredientMap.isEmpty()) {
            this.fluidIngredientMap.clear();
        }
        if (this.fluidConsumableMap != null && !this.fluidConsumableMap.isEmpty()) {
            this.fluidConsumableMap.clear();
        }
        if (this.fluidNotConsumableMap != null && !this.fluidNotConsumableMap.isEmpty()) {
            this.fluidNotConsumableMap.clear();
        }
    }
}

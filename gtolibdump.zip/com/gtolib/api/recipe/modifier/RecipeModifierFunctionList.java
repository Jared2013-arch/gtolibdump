package com.gtolib.api.recipe.modifier;

import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.recipe.modifier.RecipeModifier;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.modifier.RecipeModifierFunction;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class RecipeModifierFunctionList
implements RecipeModifierFunction {
    private final RecipeModifier[] modifiers;

    public RecipeModifierFunctionList(RecipeModifier ... recipeModifierArray) {
        this.modifiers = recipeModifierArray;
    }

    public RecipeModifierFunctionList(RecipeModifierFunction ... recipeModifierFunctionArray) {
        this.modifiers = recipeModifierFunctionArray;
    }

    @Override
    @Nullable
    public GTRecipe applyModifier(@NotNull MetaMachine metaMachine, @NotNull GTRecipe gTRecipe) {
        for (RecipeModifier recipeModifier : this.modifiers) {
            if ((gTRecipe = recipeModifier.applyModifier(metaMachine, gTRecipe)) != null) continue;
            return null;
        }
        return gTRecipe;
    }

    @Override
    @Nullable
    public Recipe apply(@NotNull MetaMachine metaMachine, @NotNull Recipe recipe) {
        return null;
    }
}

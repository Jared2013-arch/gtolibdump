package com.gtolib.api.recipe.modifier;

import com.gregtechceu.gtceu.api.recipe.OverclockingLogic;

public class RecipeModifierFunction$Overclocking
implements OverclockingLogic {
    private final int factor;

    public RecipeModifierFunction$Overclocking(boolean bl) {
        this.factor = bl ? 2 : 1;
    }

    public OverclockingLogic.OCResult runOverclockingLogic(OverclockingLogic.OCParams oCParams, long l) {
        long l2;
        int n = oCParams.duration();
        long l3 = oCParams.eut();
        int n2 = 0;
        while (n > 2 && (l2 = l3 << 2) <= l) {
            l3 = l2;
            n >>= this.factor;
            ++n2;
        }
        return new OverclockingLogic.OCResult((double)l3 / (double)oCParams.eut(), (double)n / (double)oCParams.duration(), n2, 1);
    }
}

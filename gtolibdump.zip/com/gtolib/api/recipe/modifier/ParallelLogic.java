package com.gtolib.api.recipe.modifier;

import com.gregtechceu.gtceu.api.capability.recipe.FluidRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.capability.recipe.IRecipeHandler;
import com.gregtechceu.gtceu.api.capability.recipe.ItemRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.feature.IComputationContainerMachine;
import com.gregtechceu.gtceu.api.machine.feature.IOverclockMachine;
import com.gregtechceu.gtceu.api.machine.feature.IRecipeLogicMachine;
import com.gregtechceu.gtceu.api.machine.trait.RecipeHandlerList;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.recipe.content.Content;
import com.gregtechceu.gtceu.api.recipe.content.ContentModifier;
import com.gregtechceu.gtceu.api.recipe.ingredient.FluidIngredient;
import com.gtocore.config.GTOConfig;
import com.gtolib.api.machine.feature.multiblock.IExtendedRecipeCapabilityHolder;
import com.gtolib.api.machine.feature.multiblock.IParallelMachine;
import com.gtolib.api.machine.mana.feature.IManaContainerMachine;
import com.gtolib.api.machine.trait.IEnhancedRecipeLogic;
import com.gtolib.api.recipe.IdleReason;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.ingredient.FastFluidIngredient;
import com.gtolib.api.recipe.ingredient.FastSizedIngredient;
import com.gtolib.api.recipe.lookup.MapIngredient;
import com.gtolib.api.recipe.modifier.ParallelCache;
import it.unimi.dsi.fastutil.ints.Int2LongMap;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import it.unimi.dsi.fastutil.objects.Object2LongOpenCustomHashMap;
import it.unimi.dsi.fastutil.objects.Object2LongOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.Reference2LongMap;
import it.unimi.dsi.fastutil.objects.Reference2LongOpenHashMap;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.fluids.FluidStack;

public final class ParallelLogic {
    static long getContentMultiplier(MetaMachine metaMachine, Recipe recipe) {
        long l = 1L;
        if (recipe.contentParallel > 0L) {
            l = recipe.contentParallel / recipe.parallels;
        } else if (metaMachine instanceof IRecipeLogicMachine) {
            IRecipeLogicMachine iRecipeLogicMachine = (IRecipeLogicMachine)((Object)metaMachine);
            l = ParallelLogic.getMaxContentParallel(iRecipeLogicMachine, recipe);
        }
        return l;
    }

    public static Recipe accurateParallel(MetaMachine metaMachine, Recipe recipe, long l) {
        if (l > 1L && metaMachine instanceof IRecipeLogicMachine) {
            IRecipeLogicMachine iRecipeLogicMachine = (IRecipeLogicMachine)((Object)metaMachine);
            long l2 = ParallelLogic.getMaxContentParallel(iRecipeLogicMachine, recipe);
            if (l2 == 0L) {
                return null;
            }
            recipe.contentParallel = l2;
            if ((l = Math.min(l2, ParallelLogic.getTickParallelAmount(iRecipeLogicMachine, recipe, l))) == 0L) {
                return null;
            }
            recipe.modifier(ContentModifier.multiplier(l), true);
            return recipe;
        }
        return recipe;
    }

    private static long getTickParallelAmount(IRecipeLogicMachine iRecipeLogicMachine, Recipe recipe, long l) {
        if (l > 1L) {
            Object object;
            long l2 = recipe.eut;
            long l3 = recipe.manat;
            long l4 = recipe.cwut;
            if (l2 != 0L && iRecipeLogicMachine instanceof IOverclockMachine) {
                object = (IOverclockMachine)((Object)iRecipeLogicMachine);
                if (l2 < 0L) {
                    l2 = -l2;
                }
                if ((l = Math.min(l, object.getOverclockVoltage() / l2)) == 0L) {
                    IdleReason.setIdleReason(iRecipeLogicMachine, recipe.eut < 0L ? IdleReason.INSUFFICIENT_OUT : IdleReason.NO_EU);
                    return 0L;
                }
            }
            if (l > 1L && l3 != 0L && iRecipeLogicMachine instanceof IManaContainerMachine) {
                object = (IManaContainerMachine)((Object)iRecipeLogicMachine);
                if (l3 < 0L) {
                    l3 = -l3;
                }
                if ((l = Math.min(l, object.getManaContainer().getMaxIORate() / l3)) == 0L) {
                    IdleReason.setIdleReason(iRecipeLogicMachine, recipe.manat < 0L ? IdleReason.INSUFFICIENT_OUT : IdleReason.NO_MANA);
                    return 0L;
                }
            }
            if (l > 1L && l4 != 0L && iRecipeLogicMachine instanceof IComputationContainerMachine && (l = Math.min(l, (object = (IComputationContainerMachine)((Object)iRecipeLogicMachine)).requestCWU(Long.MAX_VALUE, true) / l4)) == 0L) {
                IdleReason.setIdleReason(iRecipeLogicMachine, IdleReason.NO_CWU);
                return 0L;
            }
        }
        return l;
    }

    public static long getMaxContentParallel(IRecipeLogicMachine iRecipeLogicMachine, Recipe recipe) {
        RecipeCapability recipeCapability;
        long l = IParallelMachine.MAX_PARALLEL;
        RecipeHandlerList recipeHandlerList = iRecipeLogicMachine.getCurrentHandlerList();
        if (GTOConfig.INSTANCE.fastParallelcalculate && recipeHandlerList != null && recipe.rootRecipe != null) {
            if ((l = ParallelLogic.fastCurrentInputParallel(iRecipeLogicMachine, recipe.rootRecipe, recipeHandlerList, l)) == 0L) {
                return 0L;
            }
        } else {
            for (Map.Entry entry : recipe.inputs.entrySet()) {
                recipeCapability = (RecipeCapability)entry.getKey();
                if (recipeCapability == ItemRecipeCapability.CAP) {
                    if ((l = Math.min(l, ParallelLogic.getInputItemParallel(iRecipeLogicMachine, recipeHandlerList, (List)entry.getValue(), l))) != 0L) continue;
                    IdleReason.setIdleReason(iRecipeLogicMachine, IdleReason.LACK_MATERIAL);
                    return 0L;
                }
                if (recipeCapability != FluidRecipeCapability.CAP || (l = Math.min(l, ParallelLogic.getInputFluidParallel(iRecipeLogicMachine, recipeHandlerList, (List)entry.getValue(), l))) != 0L) continue;
                IdleReason.setIdleReason(iRecipeLogicMachine, IdleReason.LACK_MATERIAL);
                return 0L;
            }
        }
        for (Map.Entry entry : recipe.outputs.entrySet()) {
            recipeCapability = (RecipeCapability)entry.getKey();
            if (!(recipeCapability == ItemRecipeCapability.CAP && !iRecipeLogicMachine.canVoidRecipeOutputs(recipeCapability) ? (l = Math.min(l, ParallelLogic.getOutputItemParallel(iRecipeLogicMachine, recipe, (List)entry.getValue(), l))) == 0L : recipeCapability == FluidRecipeCapability.CAP && !iRecipeLogicMachine.canVoidRecipeOutputs(recipeCapability) && (l = Math.min(l, ParallelLogic.getOutputFluidParallel(iRecipeLogicMachine, recipe, (List)entry.getValue(), l))) == 0L)) continue;
            return 0L;
        }
        return l;
    }

    private static long fastCurrentInputParallel(IRecipeLogicMachine iRecipeLogicMachine, Recipe recipe, RecipeHandlerList recipeHandlerList, long l) {
        long l2;
        Iterator iterator;
        Object object3;
        boolean bl = true;
        if (iRecipeLogicMachine.isChange()) {
            Object object2;
            recipeHandlerList.intIngredientMap.clear();
            for (Object object3 : recipeHandlerList.getCapability(ItemRecipeCapability.CAP)) {
                if (object3.skipParallelComputing()) {
                    bl = false;
                    continue;
                }
                object2 = object3.getItemMap();
                if (object2 == null) continue;
                MapIngredient.convertItems(recipeHandlerList.intIngredientMap, (Object2LongOpenCustomHashMap<ItemStack>)object2);
            }
            for (Object object3 : recipeHandlerList.getCapability(FluidRecipeCapability.CAP)) {
                if (object3.skipParallelComputing()) {
                    bl = false;
                    continue;
                }
                object2 = object3.getFluidMap();
                if (object2 == null) continue;
                MapIngredient.convertFluids(recipeHandlerList.intIngredientMap, (Object2LongOpenHashMap<FluidStack>)object2);
            }
        }
        if (bl) {
            iterator = recipe.mapNotCountableIngredient.int2LongEntrySet().fastIterator();
            while (iterator.hasNext()) {
                object3 = (Int2LongMap.Entry)iterator.next();
                long l3 = recipeHandlerList.intIngredientMap.get(object3.getIntKey());
                if (l3 >= (l2 = object3.getLongValue())) continue;
                return 0L;
            }
        }
        iterator = recipe.mapCountableIngredient.int2LongEntrySet().fastIterator();
        while (iterator.hasNext()) {
            object3 = (Int2LongMap.Entry)iterator.next();
            long l4 = recipeHandlerList.intIngredientMap.get(object3.getIntKey());
            if (l4 < (l2 = object3.getLongValue())) {
                return 0L;
            }
            l = Math.min(l, l4 / l2);
        }
        return l;
    }

    public static long getInputItemParallel(IRecipeLogicMachine iRecipeLogicMachine, RecipeHandlerList recipeHandlerList, List<Content> list, long l) {
        if (l > 1L) {
            Object object;
            Reference2LongOpenHashMap<Ingredient> reference2LongOpenHashMap;
            Object object422;
            if (list.isEmpty()) {
                return l;
            }
            ParallelCache parallelCache = IEnhancedRecipeLogic.of(iRecipeLogicMachine.getRecipeLogic()).gtolib$getParallelCache();
            boolean bl = true;
            Object2LongOpenCustomHashMap<ItemStack> object2LongOpenCustomHashMap = parallelCache.getItemIngredientMap();
            if (recipeHandlerList != null) {
                for (Object object422 : recipeHandlerList.getCapability(ItemRecipeCapability.CAP)) {
                    if (object422.skipParallelComputing()) {
                        bl = false;
                        continue;
                    }
                    Object2LongOpenCustomHashMap object32 = object422.getItemMap();
                    if (object32 == null) continue;
                    object32.object2LongEntrySet().fastForEach(entry -> object2LongOpenCustomHashMap.addTo((ItemStack)entry.getKey(), entry.getLongValue()));
                }
            } else {
                reference2LongOpenHashMap = parallelCache.getItemTemporaryMap();
                for (IRecipeHandler iRecipeHandler : IExtendedRecipeCapabilityHolder.getInputFlat(iRecipeLogicMachine, ItemRecipeCapability.CAP)) {
                    Object2LongOpenCustomHashMap object2LongOpenCustomHashMap2 = iRecipeHandler.getItemMap();
                    if (object2LongOpenCustomHashMap2 == null) continue;
                    if (iRecipeHandler.isDistinct()) {
                        object2LongOpenCustomHashMap2.object2LongEntrySet().fastForEach(entry -> object2LongOpenCustomHashMap.computeLong((ItemStack)entry.getKey(), (itemStack, l) -> l == null ? entry.getLongValue() : Math.max(l, entry.getLongValue())));
                        continue;
                    }
                    object2LongOpenCustomHashMap2.object2LongEntrySet().fastForEach(entry -> reference2LongOpenHashMap.addTo((ItemStack)entry.getKey(), entry.getLongValue()));
                }
                ((Object2LongOpenCustomHashMap)((Object)reference2LongOpenHashMap)).object2LongEntrySet().fastForEach(entry -> object2LongOpenCustomHashMap.computeLong((ItemStack)entry.getKey(), (itemStack, l) -> l == null ? entry.getLongValue() : Math.max(l, entry.getLongValue())));
            }
            reference2LongOpenHashMap = parallelCache.getItemConsumableMap();
            object422 = bl ? parallelCache.getItemNotConsumableMap() : null;
            for (Content content : list) {
                if (content.chance > 0) {
                    object = content.content;
                    if (!(object instanceof FastSizedIngredient)) continue;
                    FastSizedIngredient fastSizedIngredient = (FastSizedIngredient)object;
                    reference2LongOpenHashMap.addTo((Object)fastSizedIngredient, fastSizedIngredient.getAmount());
                    continue;
                }
                if (!bl) continue;
                ((ReferenceOpenHashSet)object422).add((Ingredient)content.content);
            }
            if (bl) {
                ObjectIterator objectIterator = ((ReferenceOpenHashSet)object422).iterator();
                while (objectIterator.hasNext()) {
                    Ingredient ingredient = (Ingredient)objectIterator.next();
                    boolean bl2 = true;
                    object = object2LongOpenCustomHashMap.object2LongEntrySet().fastIterator();
                    while (object.hasNext()) {
                        if (!ingredient.test((ItemStack)((Object2LongMap.Entry)object.next()).getKey())) continue;
                        bl2 = false;
                        break;
                    }
                    if (!bl2) continue;
                    l = 0L;
                    break;
                }
            }
            if (l > 0L) {
                ObjectIterator objectIterator = reference2LongOpenHashMap.reference2LongEntrySet().fastIterator();
                while (objectIterator.hasNext()) {
                    Reference2LongMap.Entry entry2 = (Reference2LongMap.Entry)objectIterator.next();
                    long l2 = entry2.getLongValue();
                    long l3 = 0L;
                    ObjectIterator objectIterator2 = object2LongOpenCustomHashMap.object2LongEntrySet().fastIterator();
                    while (objectIterator2.hasNext()) {
                        Object2LongMap.Entry entry3 = (Object2LongMap.Entry)objectIterator2.next();
                        if (!((Ingredient)entry2.getKey()).test((ItemStack)entry3.getKey())) continue;
                        l3 += entry3.getLongValue();
                        break;
                    }
                    if (l3 >= l2) {
                        l = Math.min(l, l3 / l2);
                        continue;
                    }
                    l = 0L;
                    break;
                }
            }
            parallelCache.cleanItemMap();
            return l;
        }
        return l;
    }

    public static long getInputFluidParallel(IRecipeLogicMachine iRecipeLogicMachine, RecipeHandlerList recipeHandlerList, List<Content> list, long l) {
        if (l > 1L) {
            Object object;
            Reference2LongOpenHashMap<FastFluidIngredient> reference2LongOpenHashMap;
            Object object422;
            if (list.isEmpty()) {
                return l;
            }
            ParallelCache parallelCache = IEnhancedRecipeLogic.of(iRecipeLogicMachine.getRecipeLogic()).gtolib$getParallelCache();
            boolean bl = true;
            Reference2LongOpenHashMap<Fluid> reference2LongOpenHashMap2 = parallelCache.getFluidIngredientMap();
            if (recipeHandlerList != null) {
                for (Object object422 : recipeHandlerList.getCapability(FluidRecipeCapability.CAP)) {
                    if (object422.skipParallelComputing()) {
                        bl = false;
                        continue;
                    }
                    Object2LongOpenHashMap object32 = object422.getFluidMap();
                    if (object32 == null) continue;
                    object32.object2LongEntrySet().fastForEach(entry -> reference2LongOpenHashMap2.addTo(((FluidStack)entry.getKey()).getFluid(), entry.getLongValue()));
                }
            } else {
                reference2LongOpenHashMap = parallelCache.getFluidTemporaryMap();
                for (IRecipeHandler iRecipeHandler : IExtendedRecipeCapabilityHolder.getInputFlat(iRecipeLogicMachine, FluidRecipeCapability.CAP)) {
                    Object2LongOpenHashMap object2LongOpenHashMap = iRecipeHandler.getFluidMap();
                    if (object2LongOpenHashMap == null) continue;
                    if (iRecipeHandler.isDistinct()) {
                        object2LongOpenHashMap.object2LongEntrySet().fastForEach(entry -> reference2LongOpenHashMap2.computeLong(((FluidStack)entry.getKey()).getFluid(), (fluid, l) -> l == null ? entry.getLongValue() : Math.max(l, entry.getLongValue())));
                        continue;
                    }
                    object2LongOpenHashMap.object2LongEntrySet().fastForEach(entry -> reference2LongOpenHashMap.addTo(((FluidStack)entry.getKey()).getFluid(), entry.getLongValue()));
                }
                reference2LongOpenHashMap.reference2LongEntrySet().fastForEach(entry -> reference2LongOpenHashMap2.computeLong((Fluid)entry.getKey(), (fluid, l) -> l == null ? entry.getLongValue() : Math.max(l, entry.getLongValue())));
            }
            reference2LongOpenHashMap = parallelCache.getFluidConsumableMap();
            object422 = bl ? parallelCache.getFluidNotConsumableMap() : null;
            for (Content content : list) {
                object = content.content;
                if (!(object instanceof FastFluidIngredient)) continue;
                FastFluidIngredient fastFluidIngredient = (FastFluidIngredient)object;
                if (content.chance > 0) {
                    reference2LongOpenHashMap.addTo((Object)fastFluidIngredient, fastFluidIngredient.amount());
                    continue;
                }
                if (!bl) continue;
                ((ReferenceOpenHashSet)object422).add(fastFluidIngredient);
            }
            if (bl) {
                ObjectIterator objectIterator = ((ReferenceOpenHashSet)object422).iterator();
                while (objectIterator.hasNext()) {
                    FastFluidIngredient fastFluidIngredient = (FastFluidIngredient)objectIterator.next();
                    boolean bl2 = true;
                    object = reference2LongOpenHashMap2.reference2LongEntrySet().fastIterator();
                    while (object.hasNext()) {
                        if (!fastFluidIngredient.testFluid((Fluid)((Reference2LongMap.Entry)object.next()).getKey())) continue;
                        bl2 = false;
                        break;
                    }
                    if (!bl2) continue;
                    l = 0L;
                    break;
                }
            }
            if (l > 0L) {
                ObjectIterator objectIterator = reference2LongOpenHashMap.reference2LongEntrySet().fastIterator();
                while (objectIterator.hasNext()) {
                    Reference2LongMap.Entry entry2 = (Reference2LongMap.Entry)objectIterator.next();
                    long l2 = entry2.getLongValue();
                    long l3 = 0L;
                    ObjectIterator objectIterator2 = reference2LongOpenHashMap2.reference2LongEntrySet().fastIterator();
                    while (objectIterator2.hasNext()) {
                        Reference2LongMap.Entry entry3 = (Reference2LongMap.Entry)objectIterator2.next();
                        if (!((FastFluidIngredient)entry2.getKey()).testFluid((Fluid)entry3.getKey())) continue;
                        l3 += entry3.getLongValue();
                        break;
                    }
                    if (l3 >= l2) {
                        l = Math.min(l, l3 / l2);
                        continue;
                    }
                    l = 0L;
                    break;
                }
            }
            parallelCache.cleanFluidMap();
            return l;
        }
        return l;
    }

    private static long getOutputItemParallel(IRecipeLogicMachine iRecipeLogicMachine, GTRecipe gTRecipe, List<Content> list, long object) {
        if (object > 1L) {
            Object object22;
            Object object3;
            if (list.isEmpty()) {
                return object;
            }
            Object object4 = 0L;
            Object object5 = object;
            long l = 0L;
            ObjectArrayList objectArrayList = new ObjectArrayList(list.size());
            Object object6 = list.iterator();
            while (object6.hasNext()) {
                object3 = object6.next();
                Ingredient ingredient = (Ingredient)ItemRecipeCapability.CAP.of(((Content)object3).content);
                if (ingredient instanceof FastSizedIngredient) {
                    object22 = (FastSizedIngredient)ingredient;
                    l = Math.max(l, ((FastSizedIngredient)object22).getAmount());
                }
                objectArrayList.add(ingredient);
            }
            if (l == 0L) {
                return object;
            }
            if (object > IParallelMachine.MAX_PARALLEL / l) {
                object5 = object = IParallelMachine.MAX_PARALLEL / l;
            }
            if ((object6 = iRecipeLogicMachine.getCapabilitiesFlat(IO.OUT, ItemRecipeCapability.CAP)).isEmpty()) {
                return 0L;
            }
            while (object4 != object5) {
                object3 = new ObjectArrayList(objectArrayList.size());
                for (Object object22 : objectArrayList) {
                    object3.add(ItemRecipeCapability.CAP.copyWithModifier((Ingredient)object22, ContentModifier.multiplier(object)));
                }
                boolean bl = false;
                object22 = object6.iterator();
                while (object22.hasNext()) {
                    IRecipeHandler iRecipeHandler = (IRecipeHandler)object22.next();
                    object3 = iRecipeHandler.handleRecipe(IO.OUT, gTRecipe, (List)object3, true);
                    if (object3 != null && !object3.isEmpty()) continue;
                    bl = true;
                    break;
                }
                if (!bl && object == 1L) {
                    IdleReason.setIdleReason(iRecipeLogicMachine, IdleReason.OUTPUT_FULL);
                    return 0L;
                }
                object22 = ParallelLogic.adjustMultiplier(bl, object4, object, object5);
                object4 = object22[0];
                object = object22[1];
                object5 = object22[2];
            }
            return object;
        }
        return object;
    }

    private static long getOutputFluidParallel(IRecipeLogicMachine iRecipeLogicMachine, GTRecipe gTRecipe, List<Content> list, long object) {
        if (object > 1L) {
            Object object2;
            if (list.isEmpty()) {
                return object;
            }
            Object object3 = 0L;
            Object object4 = object;
            long l = 0L;
            ObjectArrayList objectArrayList = new ObjectArrayList(list.size());
            Object object5 = list.iterator();
            while (object5.hasNext()) {
                object2 = object5.next();
                FluidIngredient fluidIngredient = (FluidIngredient)FluidRecipeCapability.CAP.of(((Content)object2).content);
                l = Math.max(l, FastFluidIngredient.getAmount(fluidIngredient));
                objectArrayList.add(fluidIngredient);
            }
            if (l == 0L) {
                return object;
            }
            if (object > IParallelMachine.MAX_PARALLEL / l) {
                object4 = object = IParallelMachine.MAX_PARALLEL / l;
            }
            if ((object5 = iRecipeLogicMachine.getCapabilitiesFlat(IO.OUT, FluidRecipeCapability.CAP)).isEmpty()) {
                return 0L;
            }
            while (object3 != object4) {
                Object object62;
                object2 = new ObjectArrayList(objectArrayList.size());
                for (Object object62 : objectArrayList) {
                    object2.add(FluidRecipeCapability.CAP.copyWithModifier((FluidIngredient)object62, ContentModifier.multiplier(object)));
                }
                boolean bl = false;
                object62 = object5.iterator();
                while (object62.hasNext()) {
                    IRecipeHandler iRecipeHandler = (IRecipeHandler)object62.next();
                    object2 = iRecipeHandler.handleRecipe(IO.OUT, gTRecipe, (List)object2, true);
                    if (object2 != null && !object2.isEmpty()) continue;
                    bl = true;
                    break;
                }
                if (!bl && object == 1L) {
                    IdleReason.setIdleReason(iRecipeLogicMachine, IdleReason.OUTPUT_FULL);
                    return 0L;
                }
                object62 = ParallelLogic.adjustMultiplier(bl, object3, object, object4);
                object3 = object62[0];
                object = object62[1];
                object4 = object62[2];
            }
            return object;
        }
        return object;
    }

    private static long[] adjustMultiplier(boolean bl, long l, long l2, long l3) {
        if (bl) {
            l = l2;
            long l4 = (l3 - l2) % 2L;
            l2 = l2 + l4 + (l3 - l2) / 2L;
        } else {
            l3 = l2;
            l2 = (l2 + l) / 2L;
        }
        if (l3 - l <= 1L) {
            l2 = l3 = l;
        }
        return new long[]{l, l2, l3};
    }
}

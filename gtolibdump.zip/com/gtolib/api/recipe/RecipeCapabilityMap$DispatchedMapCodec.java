package com.gtolib.api.recipe;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.gtolib.api.recipe.RecipeCapabilityMap;
import com.mojang.datafixers.util.Pair;
import com.mojang.datafixers.util.Unit;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.Lifecycle;
import com.mojang.serialization.RecordBuilder;
import java.lang.invoke.LambdaMetafactory;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Stream;

record RecipeCapabilityMap$DispatchedMapCodec<V>(Codec<RecipeCapability<?>> keyCodec, Function<RecipeCapability<?>, Codec<? extends V>> valueCodecFunction) implements Codec<Map<RecipeCapability<?>, V>>
{
    public <T> DataResult<T> encode(Map<RecipeCapability<?>, V> map, DynamicOps<T> dynamicOps, T t) {
        RecordBuilder recordBuilder = dynamicOps.mapBuilder();
        for (Map.Entry<RecipeCapability<?>, V> entry : map.entrySet()) {
            recordBuilder.add(this.keyCodec.encodeStart(dynamicOps, entry.getKey()), this.encodeValue(this.valueCodecFunction.apply(entry.getKey()), entry.getValue(), dynamicOps));
        }
        return recordBuilder.build(t);
    }

    private <T, V2 extends V> DataResult<T> encodeValue(Codec<V2> codec, V v, DynamicOps<T> dynamicOps) {
        return codec.encodeStart(dynamicOps, v);
    }

    public <T> DataResult<Pair<Map<RecipeCapability<?>, V>, T>> decode(DynamicOps<T> dynamicOps, T t) {
        return dynamicOps.getMap(t).flatMap(mapLike -> {
            RecipeCapabilityMap recipeCapabilityMap = new RecipeCapabilityMap();
            Stream.Builder builder = Stream.builder();
            DataResult dataResult3 = mapLike.entries().reduce(DataResult.success((Object)Unit.INSTANCE, (Lifecycle)Lifecycle.stable()), (dataResult, pair) -> this.parseEntry((DataResult<Unit>)dataResult, dynamicOps, (Pair)pair, recipeCapabilityMap, builder), (dataResult, dataResult2) -> dataResult.apply2stable((unit, unit2) -> unit, dataResult2));
            Pair pair2 = Pair.of(new RecipeCapabilityMap(recipeCapabilityMap), (Object)t);
            Object object2 = dynamicOps.createMap(builder.build());
            return dataResult3.map(unit -> pair2).setPartial(pair2).mapError(string -> string + " missed input: " + String.valueOf(object2));
        });
    }

    private <T> DataResult<Unit> parseEntry(DataResult<Unit> dataResult, DynamicOps<T> dynamicOps, Pair<T, T> pair2, Map<RecipeCapability<?>, V> map, Stream.Builder<Pair<T, T>> builder) {
        Object object2;
        RecipeCapability recipeCapability;
        DataResult dataResult2 = this.keyCodec.parse(dynamicOps, pair2.getFirst());
        DataResult dataResult3 = dataResult2.map(this.valueCodecFunction).flatMap(codec -> codec.parse(dynamicOps, pair2.getSecond()).map(Function.identity()));
        DataResult dataResult4 = dataResult2.apply2stable((BiFunction<RecipeCapability, Object, Pair>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;, of(java.lang.Object java.lang.Object ), (Lcom/gregtechceu/gtceu/api/capability/recipe/RecipeCapability;Ljava/lang/Object;)Lcom/mojang/datafixers/util/Pair;)(), dataResult3);
        Optional optional = dataResult4.resultOrPartial(GTCEu.LOGGER::error);
        if (optional.isPresent() && map.putIfAbsent(recipeCapability = (RecipeCapability)((Pair)optional.get()).getFirst(), object2 = ((Pair)optional.get()).getSecond()) != null) {
            builder.add(pair2);
            return dataResult.apply2stable((unit, object) -> unit, DataResult.error(() -> "Duplicate entry for key: '" + String.valueOf(recipeCapability) + "'"));
        }
        if (dataResult4.error().isPresent()) {
            builder.add(pair2);
        }
        return dataResult.apply2stable((unit, pair) -> unit, dataResult4);
    }
}

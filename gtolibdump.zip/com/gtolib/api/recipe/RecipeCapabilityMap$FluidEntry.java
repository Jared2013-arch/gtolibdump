package com.gtolib.api.recipe;

import com.gregtechceu.gtceu.api.capability.recipe.FluidRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import java.util.Map;

class RecipeCapabilityMap$FluidEntry
implements Map.Entry<RecipeCapability<?>, T> {
    private RecipeCapabilityMap$FluidEntry() {
    }

    @Override
    public RecipeCapability<?> getKey() {
        return FluidRecipeCapability.CAP;
    }

    @Override
    public T getValue() {
        return RecipeCapabilityMap.this.fluid;
    }

    @Override
    public T setValue(T t) {
        Object t2 = RecipeCapabilityMap.this.fluid;
        RecipeCapabilityMap.this.fluid = t;
        return t2;
    }
}

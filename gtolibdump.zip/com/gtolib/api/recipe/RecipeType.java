package com.gtolib.api.recipe;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.GTValues;
import com.gregtechceu.gtceu.api.capability.recipe.EURecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.FluidRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.capability.recipe.IRecipeCapabilityHolder;
import com.gregtechceu.gtceu.api.capability.recipe.ItemRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.gregtechceu.gtceu.api.gui.SteamTexture;
import com.gregtechceu.gtceu.api.machine.feature.IRecipeLogicMachine;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiController;
import com.gregtechceu.gtceu.api.machine.trait.RecipeHandlerList;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gregtechceu.gtceu.api.recipe.chance.boost.ChanceBoostFunction;
import com.gregtechceu.gtceu.api.recipe.ui.GTRecipeTypeUI;
import com.gregtechceu.gtceu.api.sound.SoundEntry;
import com.gregtechceu.gtceu.data.recipe.builder.GTRecipeBuilder;
import com.gregtechceu.gtceu.utils.FormattingUtil;
import com.gtolib.api.capability.recipe.ManaRecipeCapability;
import com.gtolib.api.machine.feature.multiblock.IExtendedRecipeCapabilityHolder;
import com.gtolib.api.machine.trait.IEnhancedRecipeLogic;
import com.gtolib.api.recipe.IdleReason;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.RecipeBuilder;
import com.gtolib.api.recipe.lookup.MapIngredient;
import com.gtolib.api.recipe.lookup.RecipeLookup;
import com.gtolib.utils.MapUtils;
import com.lowdragmc.lowdraglib.gui.texture.IGuiTexture;
import com.lowdragmc.lowdraglib.gui.texture.ProgressTexture;
import com.lowdragmc.lowdraglib.gui.texture.ResourceTexture;
import com.lowdragmc.lowdraglib.gui.widget.WidgetGroup;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.SmeltingRecipe;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class RecipeType
extends GTRecipeType {
    Map<ResourceLocation, Boolean> filter;
    SearchFunction searchFunction = (iRecipeCapabilityHolder, predicate) -> new SearchRecipeIterator<RecipeType>(iRecipeCapabilityHolder, this, predicate);
    private boolean noSearch;
    private final RecipeLookup recipeLookup = new RecipeLookup(this);

    public RecipeType(ResourceLocation resourceLocation, String string, net.minecraft.world.item.crafting.RecipeType<?> ... recipeTypeArray) {
        super(resourceLocation, string, recipeTypeArray);
        this.setRecipeBuilder(new RecipeBuilder(resourceLocation, this));
    }

    public void prioritySearch() {
        this.searchFunction = (iRecipeCapabilityHolder, predicate) -> {
            SearchRecipeIterator<RecipeType> searchRecipeIterator = new SearchRecipeIterator<RecipeType>(iRecipeCapabilityHolder, this, predicate);
            ObjectArrayList objectArrayList = new ObjectArrayList();
            while (searchRecipeIterator.hasNext()) {
                Recipe recipe2 = searchRecipeIterator.next();
                if (recipe2 == null) continue;
                objectArrayList.add(recipe2);
            }
            objectArrayList.sort(Comparator.comparingInt(recipe -> -Recipe.of((GTRecipe)recipe).priority));
            return objectArrayList.listIterator(0);
        };
    }

    public RecipeLookup lookup() {
        return this.recipeLookup;
    }

    public static Iterator<Recipe> searchIterator(GTRecipeType gTRecipeType, IRecipeCapabilityHolder iRecipeCapabilityHolder, Predicate<Recipe> predicate) {
        IRecipeLogicMachine iRecipeLogicMachine;
        Object object;
        if (iRecipeCapabilityHolder instanceof IRecipeLogicMachine && (object = (iRecipeLogicMachine = (IRecipeLogicMachine)iRecipeCapabilityHolder).getRecipeLogic()) instanceof IEnhancedRecipeLogic) {
            IEnhancedRecipeLogic iEnhancedRecipeLogic = (IEnhancedRecipeLogic)object;
            iEnhancedRecipeLogic.gtolib$setIdleReason(IdleReason.NO_MATCH.reason());
            if (iRecipeCapabilityHolder.hasCapabilityProxies()) {
                object = MapUtils.fastIterator(iEnhancedRecipeLogic.gtolib$getRecipeCache());
                while (object.hasNext()) {
                    Map.Entry entry = (Map.Entry)object.next();
                    iRecipeCapabilityHolder.setCurrentHandlerList((RecipeHandlerList)entry.getValue(), null);
                    Recipe recipe = (Recipe)entry.getKey();
                    object.remove();
                    if (recipe.recipeType != null && recipe.recipeType != gTRecipeType || !predicate.test(recipe)) continue;
                    return new RecipeIterator(recipe);
                }
                return ((RecipeType)gTRecipeType).searchFunction.createIterator(iRecipeCapabilityHolder, predicate);
            }
        }
        return Collections.emptyIterator();
    }

    @NotNull
    public final Iterator<GTRecipe> searchRecipe(IRecipeCapabilityHolder iRecipeCapabilityHolder, Predicate<GTRecipe> predicate) {
        return RecipeType.searchIterator(this, iRecipeCapabilityHolder, predicate::test);
    }

    public Recipe toGTrecipe(ResourceLocation resourceLocation, net.minecraft.world.item.crafting.Recipe<?> recipe) {
        RecipeBuilder recipeBuilder = this.recipeBuilder(resourceLocation);
        for (Ingredient ingredient : recipe.m_7527_()) {
            recipeBuilder.inputItems(ingredient);
        }
        recipeBuilder.outputItems(recipe.m_8043_((RegistryAccess)RegistryAccess.m_206165_(BuiltInRegistries.f_257047_)));
        if (recipe instanceof SmeltingRecipe) {
            SmeltingRecipe smeltingRecipe = (SmeltingRecipe)recipe;
            recipeBuilder.duration(smeltingRecipe.m_43753_() / 4);
            recipeBuilder.EUt(GTValues.VA[1]);
        }
        return recipeBuilder.buildRawRecipe();
    }

    public RecipeBuilder recipeBuilder(ResourceLocation resourceLocation) {
        RecipeBuilder recipeBuilder = this.getRecipeBuilder().copy(resourceLocation);
        if (this.filter != null && this.filter.containsKey(resourceLocation)) {
            recipeBuilder.deleted = true;
            this.filter.put(resourceLocation, true);
        }
        return recipeBuilder;
    }

    public RecipeBuilder recipeBuilder(ResourceLocation resourceLocation, Object ... objectArray) {
        if (objectArray.length > 0) {
            String string3 = Arrays.stream(objectArray).map(Object::toString).map(FormattingUtil::toLowerCaseUnderscore).reduce("", (string, string2) -> string + "_" + string2);
            resourceLocation = resourceLocation.m_266382_(string3);
        }
        return this.recipeBuilder(resourceLocation);
    }

    public RecipeBuilder recipeBuilder(String string) {
        return this.recipeBuilder(GTCEu.id(string));
    }

    public RecipeBuilder recipeBuilder(String string, Object ... objectArray) {
        return this.recipeBuilder(GTCEu.id(string), objectArray);
    }

    public RecipeBuilder copyFrom(GTRecipeBuilder gTRecipeBuilder) {
        return this.getRecipeBuilder().copyFrom(gTRecipeBuilder);
    }

    public RecipeType onRecipeBuild(Consumer<GTRecipeBuilder> consumer) {
        this.getRecipeBuilder().onSave((Consumer)consumer);
        return this;
    }

    public RecipeType setMaxIOSize(int n, int n2, int n3, int n4) {
        return ((RecipeType)((RecipeType)((RecipeType)this.setMaxSize(IO.IN, (RecipeCapability)ItemRecipeCapability.CAP, n)).setMaxSize(IO.IN, (RecipeCapability)FluidRecipeCapability.CAP, n3)).setMaxSize(IO.OUT, (RecipeCapability)ItemRecipeCapability.CAP, n2)).setMaxSize(IO.OUT, (RecipeCapability)FluidRecipeCapability.CAP, n4);
    }

    public RecipeType setEUIO(IO iO) {
        if (iO.support(IO.IN)) {
            this.setMaxSize(IO.IN, (RecipeCapability)EURecipeCapability.CAP, 1);
        }
        if (iO.support(IO.OUT)) {
            this.setMaxSize(IO.OUT, (RecipeCapability)EURecipeCapability.CAP, 1);
        }
        return this;
    }

    public RecipeType setMaxSize(IO iO, RecipeCapability<?> recipeCapability, int n) {
        if (iO == IO.IN || iO == IO.BOTH) {
            this.maxInputs.put(recipeCapability, n);
        }
        if (iO == IO.OUT || iO == IO.BOTH) {
            this.maxOutputs.put(recipeCapability, n);
        }
        return this;
    }

    @Override
    public RecipeType setSlotOverlay(boolean bl, boolean bl2, IGuiTexture iGuiTexture) {
        return (RecipeType)super.setSlotOverlay(bl, bl2, iGuiTexture);
    }

    @Override
    public RecipeType setSlotOverlay(boolean bl, boolean bl2, boolean bl3, IGuiTexture iGuiTexture) {
        return (RecipeType)super.setSlotOverlay(bl, bl2, bl3, iGuiTexture);
    }

    @Override
    public RecipeType setProgressBar(ResourceTexture resourceTexture, ProgressTexture.FillDirection fillDirection) {
        return (RecipeType)super.setProgressBar(resourceTexture, fillDirection);
    }

    @Override
    public RecipeType setSteamProgressBar(SteamTexture steamTexture, ProgressTexture.FillDirection fillDirection) {
        return (RecipeType)super.setSteamProgressBar(steamTexture, fillDirection);
    }

    public RecipeType setUiBuilder(BiConsumer<GTRecipe, WidgetGroup> biConsumer) {
        return (RecipeType)super.setUiBuilder(biConsumer);
    }

    @Override
    public RecipeType setMaxTooltips(int n) {
        return (RecipeType)super.setMaxTooltips(n);
    }

    @Override
    public RecipeType setXEIVisible(boolean bl) {
        return (RecipeType)super.setXEIVisible(bl);
    }

    public RecipeType addDataInfo(Function<CompoundTag, String> function) {
        this.dataInfos.add(function);
        return this;
    }

    @Override
    public RecipeType addCustomRecipeLogic(GTRecipeType.ICustomRecipeLogic iCustomRecipeLogic) {
        return (RecipeType)super.addCustomRecipeLogic(iCustomRecipeLogic);
    }

    public RecipeType prepareBuilder(Consumer<GTRecipeBuilder> consumer) {
        return (RecipeType)super.prepareBuilder(consumer);
    }

    @Override
    public RecipeType setRecipeBuilder(GTRecipeBuilder gTRecipeBuilder) {
        return (RecipeType)super.setRecipeBuilder(gTRecipeBuilder);
    }

    @Override
    public RecipeType setChanceFunction(ChanceBoostFunction chanceBoostFunction) {
        return (RecipeType)super.setChanceFunction(chanceBoostFunction);
    }

    @Override
    public RecipeType setRecipeUI(GTRecipeTypeUI gTRecipeTypeUI) {
        return (RecipeType)super.setRecipeUI(gTRecipeTypeUI);
    }

    @Override
    public RecipeType setSmallRecipeMap(GTRecipeType gTRecipeType) {
        return (RecipeType)super.setSmallRecipeMap(gTRecipeType);
    }

    @Override
    public RecipeType getSmallRecipeMap() {
        return (RecipeType)super.getSmallRecipeMap();
    }

    public RecipeType setIconSupplier(@Nullable Supplier<ItemStack> supplier) {
        return (RecipeType)super.setIconSupplier(supplier);
    }

    public RecipeType setSound(@Nullable SoundEntry soundEntry) {
        this.sound = soundEntry;
        return this;
    }

    public RecipeType setScanner(boolean bl) {
        this.isScanner = bl;
        return this;
    }

    public RecipeType setHasResearchSlot(boolean bl) {
        this.hasResearchSlot = bl;
        return this;
    }

    @Override
    public RecipeType setOffsetVoltageText(boolean bl) {
        return (RecipeType)super.setOffsetVoltageText(bl);
    }

    @Override
    public RecipeType setVoltageTextOffset(int n) {
        return (RecipeType)super.setVoltageTextOffset(n);
    }

    public RecipeType setMANAIO(IO iO) {
        if (iO.support(IO.IN)) {
            this.setMaxSize(IO.IN, (RecipeCapability)ManaRecipeCapability.CAP, 1);
        }
        if (iO.support(IO.OUT)) {
            this.setMaxSize(IO.OUT, (RecipeCapability)ManaRecipeCapability.CAP, 1);
        }
        return this;
    }

    public RecipeBuilder builder(String string, Object ... objectArray) {
        return this.recipeBuilder(string, objectArray);
    }

    public void addFilter(String string) {
        this.filter.put(GTCEu.id(string), false);
    }

    public RecipeType noSearch(boolean bl) {
        this.noSearch = bl;
        return this;
    }

    public boolean noSearch() {
        return this.noSearch;
    }

    private RecipeBuilder getRecipeBuilder() {
        return (RecipeBuilder)this.recipeBuilder;
    }

    static {
        RecipeHandlerList.NOTIFY = multiblockPartMachine -> {
            for (IMultiController iMultiController : multiblockPartMachine.getControllers()) {
                if (!(iMultiController instanceof IExtendedRecipeCapabilityHolder)) continue;
                IExtendedRecipeCapabilityHolder iExtendedRecipeCapabilityHolder = (IExtendedRecipeCapabilityHolder)((Object)iMultiController);
                iExtendedRecipeCapabilityHolder.arrangeDistinct();
            }
        };
    }

    static interface SearchFunction {
        public Iterator<Recipe> createIterator(IRecipeCapabilityHolder var1, Predicate<Recipe> var2);
    }

    private static final class RecipeIterator
    implements Iterator<Recipe> {
        private final Recipe recipe;
        private boolean hasNext;

        private RecipeIterator(Recipe recipe) {
            this.recipe = recipe;
            this.hasNext = true;
        }

        @Override
        public boolean hasNext() {
            return this.hasNext;
        }

        @Override
        public Recipe next() {
            this.hasNext = false;
            return this.recipe;
        }
    }

    static class SearchRecipeIterator<T extends RecipeType>
    implements Iterator<Recipe> {
        boolean hasNext;
        int[] ingredients;
        RecipeHandlerList list;
        final IRecipeCapabilityHolder holder;
        final Predicate<Recipe> canHandle;
        final Iterator<RecipeHandlerList> inputList;
        int ingredientIndex;
        Iterator<GTRecipeType.ICustomRecipeLogic> customLogic;
        final T recipeType;

        SearchRecipeIterator(IRecipeCapabilityHolder iRecipeCapabilityHolder, T t, Predicate<Recipe> predicate) {
            this.holder = iRecipeCapabilityHolder;
            this.recipeType = t;
            this.canHandle = predicate;
            this.inputList = IExtendedRecipeCapabilityHolder.getInputList(iRecipeCapabilityHolder).listIterator(0);
            this.hasNext = this.inputList.hasNext();
        }

        @Override
        public boolean hasNext() {
            return this.hasNext;
        }

        @Override
        public Recipe next() {
            GTRecipe gTRecipe;
            while (this.list != null || this.inputList.hasNext()) {
                if (this.list == null) {
                    this.list = this.inputList.next();
                    MapIngredient.convertList(this.holder, this.list);
                    if (this.list.intIngredientMap.isEmpty()) {
                        this.list = null;
                        continue;
                    }
                    this.ingredients = this.list.intIngredientMap.toIntArray();
                    this.holder.setCurrentHandlerList(this.list, null);
                }
                while (this.ingredientIndex < this.ingredients.length) {
                    gTRecipe = ((RecipeType)this.recipeType).lookup().recurseIngredientTreeFindRecipe(this.ingredients.length, this.ingredients, ((RecipeType)this.recipeType).lookup().lookup, this.canHandle, this.ingredientIndex, 0, 1 << this.ingredientIndex);
                    ++this.ingredientIndex;
                    if (gTRecipe == null) continue;
                    return gTRecipe;
                }
                this.ingredientIndex = 0;
                this.list = null;
            }
            if (this.customLogic == null) {
                this.customLogic = this.recipeType.getCustomRecipeLogicRunners().listIterator(0);
            }
            while (this.customLogic.hasNext()) {
                gTRecipe = this.customLogic.next().createCustomRecipe(this.holder);
                if (gTRecipe == null) continue;
                return (Recipe)gTRecipe;
            }
            this.hasNext = false;
            return null;
        }
    }
}

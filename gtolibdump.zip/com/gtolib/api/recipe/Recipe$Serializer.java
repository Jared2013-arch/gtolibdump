package com.gtolib.api.recipe;

import com.google.gson.JsonObject;
import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.gregtechceu.gtceu.api.recipe.GTRecipeSerializer;
import com.gregtechceu.gtceu.api.recipe.content.Content;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.RecipeCapabilityMap;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.util.Tuple;
import net.minecraft.world.item.crafting.RecipeSerializer;
import org.jetbrains.annotations.NotNull;

public class Recipe$Serializer
implements RecipeSerializer<Recipe> {
    private static final Codec<Recipe> CODEC = RecordCodecBuilder.create(instance -> instance.group(ExtraCodecs.f_144628_.optionalFieldOf("tier", 0).forGetter(recipe -> recipe.tier), Codec.LONG.optionalFieldOf("eu", (Object)0L).forGetter(recipe -> recipe.eut), Codec.LONG.optionalFieldOf("mana", (Object)0L).forGetter(recipe -> recipe.manat), Codec.LONG.optionalFieldOf("cwu", (Object)0L).forGetter(recipe -> recipe.cwut), RecipeCapabilityMap.CODEC.optionalFieldOf("inputs", (Object)Map.of()).forGetter(recipe -> recipe.inputs), RecipeCapabilityMap.CODEC.optionalFieldOf("outputs", (Object)Map.of()).forGetter(recipe -> recipe.outputs), CompoundTag.f_128325_.optionalFieldOf("data", new CompoundTag()).forGetter(recipe -> recipe.data), ExtraCodecs.f_144628_.fieldOf("duration").forGetter(recipe -> recipe.duration)).apply((Applicative)instance, Recipe::new));

    @NotNull
    public Recipe fromJson(@NotNull ResourceLocation resourceLocation, @NotNull JsonObject jsonObject) {
        Recipe recipe = (Recipe)CODEC.parse((DynamicOps)JsonOps.INSTANCE, (Object)jsonObject).getOrThrow(false, GTCEu.LOGGER::error);
        recipe.setId(resourceLocation);
        return recipe;
    }

    @NotNull
    public Recipe fromNetwork(@NotNull ResourceLocation resourceLocation, @NotNull FriendlyByteBuf friendlyByteBuf) {
        int n2 = friendlyByteBuf.readInt();
        long l = friendlyByteBuf.readLong();
        long l2 = friendlyByteBuf.readLong();
        long l3 = friendlyByteBuf.readLong();
        int n3 = friendlyByteBuf.readInt();
        RecipeCapabilityMap<List<Content>> recipeCapabilityMap = Recipe$Serializer.tuplesToMap((List)friendlyByteBuf.m_236838_(n -> new ObjectArrayList(), GTRecipeSerializer::entryReader));
        RecipeCapabilityMap<List<Content>> recipeCapabilityMap2 = Recipe$Serializer.tuplesToMap((List)friendlyByteBuf.m_236838_(n -> new ObjectArrayList(), GTRecipeSerializer::entryReader));
        CompoundTag compoundTag = friendlyByteBuf.m_130260_();
        if (compoundTag == null) {
            compoundTag = new CompoundTag();
        }
        return new Recipe(null, resourceLocation, n2, l, l2, l3, recipeCapabilityMap, recipeCapabilityMap2, null, null, compoundTag, n3);
    }

    public void toNetwork(FriendlyByteBuf friendlyByteBuf, Recipe recipe) {
        friendlyByteBuf.writeInt(recipe.tier);
        friendlyByteBuf.writeLong(recipe.eut);
        friendlyByteBuf.writeLong(recipe.manat);
        friendlyByteBuf.writeLong(recipe.cwut);
        friendlyByteBuf.writeInt(recipe.duration);
        friendlyByteBuf.m_236828_(recipe.inputs.entrySet(), GTRecipeSerializer::entryWriter);
        friendlyByteBuf.m_236828_(recipe.outputs.entrySet(), GTRecipeSerializer::entryWriter);
        friendlyByteBuf.m_130079_(recipe.data);
    }

    private static RecipeCapabilityMap<List<Content>> tuplesToMap(List<Tuple<RecipeCapability<?>, List<Content>>> list) {
        RecipeCapabilityMap<List<Content>> recipeCapabilityMap = new RecipeCapabilityMap<List<Content>>();
        list.forEach(tuple -> recipeCapabilityMap.put((RecipeCapability)tuple.m_14418_(), (List)tuple.m_14419_()));
        return recipeCapabilityMap;
    }
}

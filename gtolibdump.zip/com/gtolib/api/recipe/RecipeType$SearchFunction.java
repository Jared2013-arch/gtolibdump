package com.gtolib.api.recipe;

import com.gregtechceu.gtceu.api.capability.recipe.IRecipeCapabilityHolder;
import com.gtolib.api.recipe.Recipe;
import java.util.Iterator;
import java.util.function.Predicate;

interface RecipeType$SearchFunction {
    public Iterator<Recipe> createIterator(IRecipeCapabilityHolder var1, Predicate<Recipe> var2);
}

package com.gtolib.api.recipe;

import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.gregtechceu.gtceu.api.recipe.content.Content;
import com.gtolib.api.recipe.ingredient.FastFluidIngredient;
import com.gtolib.api.recipe.ingredient.FastSizedIngredient;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenCustomHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;

public final class ContentList
extends ObjectArrayList<Content> {
    private final Object2ObjectOpenCustomHashMap<Content, Content> map;

    public ContentList(int n, Object2ObjectOpenCustomHashMap<Content, Content> object2ObjectOpenCustomHashMap) {
        super(n);
        this.map = object2ObjectOpenCustomHashMap;
        object2ObjectOpenCustomHashMap.clear();
    }

    public boolean add(RecipeCapability<?> recipeCapability, Content content, boolean bl) {
        Content content2 = (Content)this.map.get((Object)content);
        if (content2 != null) {
            Object object = content2.content;
            if (object instanceof FastSizedIngredient) {
                FastSizedIngredient fastSizedIngredient = (FastSizedIngredient)object;
                long l = ((FastSizedIngredient)content.content).getAmount() + fastSizedIngredient.getAmount();
                if (l < 1L) {
                    fastSizedIngredient.setAmount(Long.MAX_VALUE);
                } else {
                    fastSizedIngredient.setAmount(l);
                }
            } else {
                object = content2.content;
                if (object instanceof FastFluidIngredient) {
                    FastFluidIngredient fastFluidIngredient = (FastFluidIngredient)object;
                    long l = fastFluidIngredient.amount() + ((FastFluidIngredient)content.content).amount();
                    if (l < 1L) {
                        fastFluidIngredient.setAmount(Long.MAX_VALUE);
                    } else {
                        fastFluidIngredient.setAmount(l);
                    }
                }
            }
        } else {
            if (bl) {
                content = content.copy(recipeCapability);
            }
            this.map.put((Object)content, (Object)content);
            super.add(content);
        }
        return true;
    }

    @Override
    public boolean add(Content content) {
        Content content2 = (Content)this.map.get((Object)content);
        if (content2 != null) {
            Object object = content2.content;
            if (object instanceof FastSizedIngredient) {
                FastSizedIngredient fastSizedIngredient = (FastSizedIngredient)object;
                fastSizedIngredient.setAmount(((FastSizedIngredient)content.content).getAmount() + fastSizedIngredient.getAmount());
            } else {
                object = content2.content;
                if (object instanceof FastFluidIngredient) {
                    FastFluidIngredient fastFluidIngredient = (FastFluidIngredient)object;
                    fastFluidIngredient.setAmount(fastFluidIngredient.amount() + ((FastFluidIngredient)content.content).amount());
                }
            }
        } else {
            this.map.put((Object)content, (Object)content);
            super.add(content);
        }
        return true;
    }
}

package com.gtolib.api.wireless;

import com.gregtechceu.gtceu.api.GTValues;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.utils.FormattingUtil;
import com.gregtechceu.gtceu.utils.GTUtil;
import com.hepdd.gtmthings.api.misc.ITransferData;
import com.hepdd.gtmthings.utils.TeamUtil;
import com.lowdragmc.lowdraglib.gui.widget.ComponentPanelWidget;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.Style;

public record ExtendTransferData(UUID UUID, long Throughput, long loss, MetaMachine machine) implements ITransferData
{
    public Component getInfo() {
        MetaMachine metaMachine = this.machine();
        if (metaMachine.getLevel() == null) {
            return Component.m_237119_();
        }
        long l = this.Throughput();
        String string = metaMachine.getPos().m_123344_();
        if (l > 0L) {
            return Component.m_237115_(metaMachine.getBlockState().m_60734_().m_7705_()).m_130948_(Style.f_131099_.m_131144_(new HoverEvent(HoverEvent.Action.f_130831_, Component.m_237110_("recipe.condition.dimension.tooltip", new Object[]{metaMachine.getLevel().m_46472_().m_135782_()}).m_130946_(" [").m_130946_(string).m_130946_("] ").m_7220_(Component.m_237110_("gtmthings.machine.wireless_energy_monitor.tooltip.0", new Object[]{TeamUtil.GetName(metaMachine.getLevel(), this.UUID())}))))).m_130946_(" +").m_130946_(FormattingUtil.formatNumbers(l)).m_130946_(" EU/t (").m_130946_(GTValues.VNF[GTUtil.getFloorTierByVoltage(l)]).m_130946_(") ").m_7220_(Component.m_237110_("gtocore.machine.energy_loss", new Object[]{Component.m_237113_(FormattingUtil.formatNumbers(this.loss())).m_130946_(" EU/t (").m_130946_(GTValues.VNF[GTUtil.getFloorTierByVoltage(this.loss())]).m_130946_(")")})).m_7220_(ComponentPanelWidget.withButton(Component.m_237113_(" [ ] "), string));
        }
        return Component.m_237115_(metaMachine.getBlockState().m_60734_().m_7705_()).m_130948_(Style.f_131099_.m_131144_(new HoverEvent(HoverEvent.Action.f_130831_, Component.m_237110_("recipe.condition.dimension.tooltip", new Object[]{metaMachine.getLevel().m_46472_().m_135782_()}).m_130946_(" [").m_130946_(string).m_130946_("] ").m_7220_(Component.m_237110_("gtmthings.machine.wireless_energy_monitor.tooltip.0", new Object[]{TeamUtil.GetName(metaMachine.getLevel(), this.UUID())}))))).m_130946_(" -").m_130946_(FormattingUtil.formatNumbers(-l)).m_130946_(" EU/t (").m_130946_(GTValues.VNF[GTUtil.getFloorTierByVoltage(-l)]).m_130946_(")").m_7220_(ComponentPanelWidget.withButton(Component.m_237113_(" [ ] "), string));
    }
}

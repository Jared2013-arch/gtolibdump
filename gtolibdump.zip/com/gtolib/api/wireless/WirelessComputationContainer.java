package com.gtolib.api.wireless;

import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.hepdd.gtmthings.utils.TeamUtil;
import java.util.Map;
import java.util.UUID;

public final class WirelessComputationContainer {
    private static final Map<UUID, WirelessComputationContainer> MAP = new O2OOpenCacheHashMap();
    private long capacity = 102400L;
    private long storage;
    private final UUID uuid;

    public static WirelessComputationContainer getOrCreateContainer(UUID uUID) {
        return MAP.computeIfAbsent(TeamUtil.getTeamUUID(uUID), WirelessComputationContainer::new);
    }

    private WirelessComputationContainer(UUID uUID) {
        this.uuid = uUID;
    }

    public long free() {
        return this.capacity - this.storage;
    }

    public long getCache() {
        return this.storage;
    }

    public void shrink(long l) {
        this.storage -= l;
    }

    public long getCapacity() {
        return this.capacity;
    }

    public long getStorage() {
        return this.storage;
    }

    public UUID getUuid() {
        return this.uuid;
    }

    public void setCapacity(long l) {
        this.capacity = l;
    }

    public void setStorage(long l) {
        this.storage = l;
    }
}

package com.gtolib.api.wireless;

import com.gtolib.b.d;
import com.hepdd.gtmthings.utils.TeamUtil;
import java.math.BigInteger;
import java.util.UUID;

public final class WirelessManaContainer {
    private BigInteger storage;
    private final UUID uuid;

    public static WirelessManaContainer getOrCreateContainer(UUID uUID) {
        return d.a.b.computeIfAbsent(TeamUtil.getTeamUUID(uUID), WirelessManaContainer::new);
    }

    private WirelessManaContainer(UUID uUID) {
        this.uuid = uUID;
        this.storage = BigInteger.ZERO;
    }

    public WirelessManaContainer(UUID uUID, BigInteger bigInteger) {
        this(uUID);
        this.storage = bigInteger;
    }

    public BigInteger getStorage() {
        return this.storage;
    }

    public UUID getUuid() {
        return this.uuid;
    }

    public void setStorage(BigInteger bigInteger) {
        this.storage = bigInteger;
        d.a.m_77762_();
    }
}

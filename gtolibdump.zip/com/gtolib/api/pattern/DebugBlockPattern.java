package com.gtolib.api.pattern;

import com.gregtechceu.gtceu.api.pattern.util.RelativeDirection;
import it.unimi.dsi.fastutil.objects.Reference2CharLinkedOpenHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

public final class DebugBlockPattern {
    private RelativeDirection[] structureDir;
    public String[][] pattern;
    public boolean hasAir;
    public final Reference2CharLinkedOpenHashMap<Block> legend = new Reference2CharLinkedOpenHashMap();

    public DebugBlockPattern(Level level, int n, int n2, int n3, int n4, int n5, int n6) {
        this.structureDir = new RelativeDirection[]{RelativeDirection.LEFT, RelativeDirection.UP, RelativeDirection.FRONT};
        this.pattern = new String[1 + n4 - n][1 + n5 - n2];
        this.legend.put((Object)Blocks.f_50016_, ' ');
        char c = 'A';
        for (int i = n; i <= n4; ++i) {
            for (int j = n2; j <= n5; ++j) {
                StringBuilder stringBuilder = new StringBuilder();
                for (int k = n3; k <= n6; ++k) {
                    Block block = level.m_8055_(new BlockPos(i, j, k)).m_60734_();
                    if (block == Blocks.f_50016_) {
                        this.hasAir = true;
                    }
                    if (!this.legend.containsKey((Object)block)) {
                        this.legend.put((Object)block, c);
                        c = (char)(c + '');
                    }
                    stringBuilder.append(this.legend.getChar((Object)block));
                }
                this.pattern[i - n][j - n2] = stringBuilder.toString();
            }
        }
        RelativeDirection[] relativeDirectionArray = DebugBlockPattern.getDir(Direction.NORTH);
        this.changeDir(relativeDirectionArray[0], relativeDirectionArray[1], relativeDirectionArray[2]);
    }

    public static RelativeDirection[] getDir(Direction direction) {
        if (direction == Direction.WEST) {
            return new RelativeDirection[]{RelativeDirection.LEFT, RelativeDirection.UP, RelativeDirection.BACK};
        }
        if (direction == Direction.EAST) {
            return new RelativeDirection[]{RelativeDirection.RIGHT, RelativeDirection.UP, RelativeDirection.FRONT};
        }
        if (direction == Direction.NORTH) {
            return new RelativeDirection[]{RelativeDirection.BACK, RelativeDirection.UP, RelativeDirection.RIGHT};
        }
        if (direction == Direction.SOUTH) {
            return new RelativeDirection[]{RelativeDirection.FRONT, RelativeDirection.UP, RelativeDirection.LEFT};
        }
        if (direction == Direction.DOWN) {
            return new RelativeDirection[]{RelativeDirection.RIGHT, RelativeDirection.BACK, RelativeDirection.UP};
        }
        return new RelativeDirection[]{RelativeDirection.LEFT, RelativeDirection.FRONT, RelativeDirection.UP};
    }

    public void changeDir(RelativeDirection relativeDirection, RelativeDirection relativeDirection2, RelativeDirection relativeDirection3) {
        int n;
        int n2;
        if (relativeDirection.isSameAxis(relativeDirection2) || relativeDirection2.isSameAxis(relativeDirection3) || relativeDirection3.isSameAxis(relativeDirection)) {
            return;
        }
        char[][][] cArray = new char[this.structureDir[0].isSameAxis(relativeDirection3) ? this.pattern[0][0].length() : (this.structureDir[1].isSameAxis(relativeDirection3) ? this.pattern[0].length : this.pattern.length)][this.structureDir[0].isSameAxis(relativeDirection2) ? this.pattern[0][0].length() : (this.structureDir[1].isSameAxis(relativeDirection2) ? this.pattern[0].length : this.pattern.length)][this.structureDir[0].isSameAxis(relativeDirection) ? this.pattern[0][0].length() : (this.structureDir[1].isSameAxis(relativeDirection) ? this.pattern[0].length : this.pattern.length)];
        for (n2 = 0; n2 < this.pattern.length; ++n2) {
            for (n = 0; n < this.pattern[0].length; ++n) {
                int n3 = this.pattern[0][0].length();
                for (int i = 0; i < n3; ++i) {
                    int n4 = this.pattern[n2][n].charAt(i);
                    int n5 = 0;
                    int n6 = 0;
                    int n7 = 0;
                    if (this.structureDir[2].isSameAxis(relativeDirection3)) {
                        n5 = this.structureDir[2] == relativeDirection3 ? n2 : this.pattern.length - n2 - 1;
                    } else if (this.structureDir[2].isSameAxis(relativeDirection2)) {
                        n6 = this.structureDir[2] == relativeDirection2 ? n2 : this.pattern.length - n2 - 1;
                    } else if (this.structureDir[2].isSameAxis(relativeDirection)) {
                        n7 = this.structureDir[2] == relativeDirection ? n2 : this.pattern.length - n2 - 1;
                    }
                    if (this.structureDir[1].isSameAxis(relativeDirection3)) {
                        n5 = this.structureDir[1] == relativeDirection3 ? n : this.pattern[0].length - n - 1;
                    } else if (this.structureDir[1].isSameAxis(relativeDirection2)) {
                        n6 = this.structureDir[1] == relativeDirection2 ? n : this.pattern[0].length - n - 1;
                    } else if (this.structureDir[1].isSameAxis(relativeDirection)) {
                        n7 = this.structureDir[1] == relativeDirection ? n : this.pattern[0].length - n - 1;
                    }
                    if (this.structureDir[0].isSameAxis(relativeDirection3)) {
                        n5 = this.structureDir[0] == relativeDirection3 ? i : this.pattern[0][0].length() - i - 1;
                    } else if (this.structureDir[0].isSameAxis(relativeDirection2)) {
                        n6 = this.structureDir[0] == relativeDirection2 ? i : this.pattern[0][0].length() - i - 1;
                    } else if (this.structureDir[0].isSameAxis(relativeDirection)) {
                        n7 = this.structureDir[0] == relativeDirection ? i : this.pattern[0][0].length() - i - 1;
                    }
                    cArray[n5][n6][n7] = n4;
                }
            }
        }
        this.pattern = new String[cArray.length][cArray[0].length];
        for (n2 = 0; n2 < this.pattern.length; ++n2) {
            for (n = 0; n < this.pattern[0].length; ++n) {
                StringBuilder stringBuilder = new StringBuilder();
                for (char c : cArray[n2][n]) {
                    stringBuilder.append(c);
                }
                this.pattern[n2][n] = stringBuilder.toString();
            }
        }
        this.structureDir = new RelativeDirection[]{relativeDirection, relativeDirection2, relativeDirection3};
    }
}

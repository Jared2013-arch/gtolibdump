package com.gtolib.api.blockentity;

import com.gregtechceu.gtceu.utils.cache.BlockEntityDirectionCache;
import net.minecraft.world.level.block.entity.BlockEntity;

public interface IDirectionCacheBlockEntity {
    public BlockEntityDirectionCache gtolib$getDirectionCache();

    public static BlockEntityDirectionCache getBlockEntityDirectionCache(BlockEntity blockEntity) {
        if (blockEntity instanceof IDirectionCacheBlockEntity) {
            IDirectionCacheBlockEntity iDirectionCacheBlockEntity = (IDirectionCacheBlockEntity)((Object)blockEntity);
            return iDirectionCacheBlockEntity.gtolib$getDirectionCache();
        }
        return null;
    }
}

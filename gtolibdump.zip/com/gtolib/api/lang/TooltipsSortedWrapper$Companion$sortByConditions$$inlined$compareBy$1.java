// ERROR: Unable to apply inner class name fixup
package com.gtolib.api.lang;

import java.util.Comparator;
import kotlin.Metadata;
import kotlin.comparisons.ComparisonsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.SourceDebugExtension;

@Metadata(mv={2, 1, 0}, k=3, xi=48)
@SourceDebugExtension(value={"SMAP\nComparisons.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Comparisons.kt\nkotlin/comparisons/ComparisonsKt__ComparisonsKt$compareBy$2\n+ 2 TooltipsSortedWrapper.kt\ncom/gtolib/api/lang/TooltipsSortedWrapper$Companion\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,102:1\n22#2:103\n1790#3,6:104\n1#4:110\n*S KotlinDebug\n*F\n+ 1 TooltipsSortedWrapper.kt\ncom/gtolib/api/lang/TooltipsSortedWrapper$Companion\n*L\n22#1:104,6\n*E\n"})
public static final class TooltipsSortedWrapper$Companion$sortByConditions$.inlined.compareBy.1<T>
implements Comparator {
    final Function1[] $conditions$inlined;

    public TooltipsSortedWrapper$Companion$sortByConditions$.inlined.compareBy.1(Function1[] function1Array) {
        this.$conditions$inlined = function1Array;
    }

    @Override
    public final int compare(T t, T t2) {
        Comparable comparable;
        int n;
        Comparable comparable2;
        int n2;
        int n3;
        int n4;
        Object object;
        block9: {
            Comparable comparable3;
            int n5;
            boolean bl;
            Function1 function1;
            boolean bl2;
            T t3;
            block8: {
                t3 = t;
                bl2 = false;
                object = this.$conditions$inlined;
                n4 = 0;
                n3 = ((Function1[])object).length + -1;
                if (0 <= n3) {
                    do {
                        n2 = n3--;
                        function1 = object[n2];
                        bl = false;
                        if (!((Boolean)function1.invoke(t3)).booleanValue()) continue;
                        n5 = n2;
                        break block8;
                    } while (0 <= n3);
                }
                n5 = -1;
            }
            object = n5;
            n4 = ((Number)object).intValue();
            n3 = 0;
            Object object2 = n4 >= 0 ? object : null;
            if (object2 != null) {
                n3 = ((Number)object2).intValue();
                n2 = 0;
                comparable3 = Integer.valueOf(n3 + 1);
            } else {
                comparable3 = Integer.valueOf(0);
            }
            t3 = t2;
            comparable2 = comparable3;
            bl2 = false;
            object = this.$conditions$inlined;
            n4 = 0;
            n3 = ((Function1[])object).length + -1;
            if (0 <= n3) {
                do {
                    n2 = n3--;
                    function1 = object[n2];
                    bl = false;
                    if (!((Boolean)function1.invoke(t3)).booleanValue()) continue;
                    n = n2;
                    break block9;
                } while (0 <= n3);
            }
            n = -1;
        }
        object = n;
        n4 = ((Number)object).intValue();
        n3 = 0;
        Object object3 = n4 >= 0 ? object : null;
        if (object3 != null) {
            n3 = ((Number)object3).intValue();
            n2 = 0;
            comparable = Integer.valueOf(n3 + 1);
        } else {
            comparable = Integer.valueOf(0);
        }
        return ComparisonsKt.compareValues((Comparable)comparable2, (Comparable)comparable);
    }
}

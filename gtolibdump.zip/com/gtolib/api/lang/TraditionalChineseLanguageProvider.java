package com.gtolib.api.lang;

import com.tterrag.registrate.AbstractRegistrate;
import com.tterrag.registrate.providers.ProviderType;
import com.tterrag.registrate.providers.RegistrateProvider;
import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.LanguageProvider;
import net.minecraftforge.fml.LogicalSide;

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
public final class TraditionalChineseLanguageProvider
extends LanguageProvider
implements RegistrateProvider {
    public static final ProviderType<TraditionalChineseLanguageProvider> LANG = ProviderType.register("tw_lang", (abstractRegistrate, gatherDataEvent) -> new TraditionalChineseLanguageProvider((AbstractRegistrate<?>)abstractRegistrate, gatherDataEvent.getGenerator().getPackOutput()));
    private final AbstractRegistrate<?> owner;

    private TraditionalChineseLanguageProvider(AbstractRegistrate<?> abstractRegistrate, PackOutput packOutput) {
        super(packOutput, abstractRegistrate.getModid(), "zh_tw");
        this.owner = abstractRegistrate;
    }

    public LogicalSide getSide() {
        return LogicalSide.CLIENT;
    }

    public String m_6055_() {
        return "Lang (zh_tw)";
    }

    protected void addTranslations() {
        this.owner.genData(LANG, (RegistrateProvider)this);
    }
}

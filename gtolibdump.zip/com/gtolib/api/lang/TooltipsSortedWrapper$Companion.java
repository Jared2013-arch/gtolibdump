package com.gtolib.api.lang;

import java.util.Comparator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(mv={2, 1, 0}, k=1, xi=48, d1={"\u0000(\n\n\u0000\n\b\n\n\u0000\n!\n\u0000\n\n\n\n\b\b\u000020B\t\b¢\bJI0\"\b\u0000*\bH02*\b\bH00\n0\t\"H00\nH¢\f¨\r"}, d2={"Lcom/gtolib/api/lang/TooltipsSortedWrapper$Companion;", "", "<init>", "()V", "sortByConditions", "", "T", "", "conditions", "", "Lkotlin/Function1;", "", "(Ljava/util/List;[Lkotlin/jvm/functions/Function1;)V", "gtolib"})
public static final class TooltipsSortedWrapper$Companion {
    private TooltipsSortedWrapper$Companion() {
    }

    private final <T> void sortByConditions(List<T> list, Function1<? super T, Boolean> ... function1Array) {
        CollectionsKt.sortWith(list, (Comparator)new Comparator(function1Array){
            final Function1[] $conditions$inlined;
            {
                this.$conditions$inlined = function1Array;
            }

            public final int compare(T t, T t2) {
                Comparable comparable;
                int n;
                Comparable comparable2;
                int n2;
                int n3;
                int n4;
                Object object;
                block9: {
                    Comparable comparable3;
                    int n5;
                    boolean bl;
                    Function1 function1;
                    boolean bl2;
                    T t3;
                    block8: {
                        t3 = t;
                        bl2 = false;
                        object = this.$conditions$inlined;
                        n4 = 0;
                        n3 = ((Function1[])object).length + -1;
                        if (0 <= n3) {
                            do {
                                n2 = n3--;
                                function1 = object[n2];
                                bl = false;
                                if (!((Boolean)function1.invoke(t3)).booleanValue()) continue;
                                n5 = n2;
                                break block8;
                            } while (0 <= n3);
                        }
                        n5 = -1;
                    }
                    object = n5;
                    n4 = ((Number)object).intValue();
                    n3 = 0;
                    Object object2 = n4 >= 0 ? object : null;
                    if (object2 != null) {
                        n3 = ((Number)object2).intValue();
                        n2 = 0;
                        comparable3 = Integer.valueOf(n3 + 1);
                    } else {
                        comparable3 = Integer.valueOf(0);
                    }
                    t3 = t2;
                    comparable2 = comparable3;
                    bl2 = false;
                    object = this.$conditions$inlined;
                    n4 = 0;
                    n3 = ((Function1[])object).length + -1;
                    if (0 <= n3) {
                        do {
                            n2 = n3--;
                            function1 = object[n2];
                            bl = false;
                            if (!((Boolean)function1.invoke(t3)).booleanValue()) continue;
                            n = n2;
                            break block9;
                        } while (0 <= n3);
                    }
                    n = -1;
                }
                object = n;
                n4 = ((Number)object).intValue();
                n3 = 0;
                Object object3 = n4 >= 0 ? object : null;
                if (object3 != null) {
                    n3 = ((Number)object3).intValue();
                    n2 = 0;
                    comparable = Integer.valueOf(n3 + 1);
                } else {
                    comparable = Integer.valueOf(0);
                }
                return ComparisonsKt.compareValues((Comparable)comparable2, (Comparable)comparable);
            }
        });
    }

    public static final void access$sortByConditions(TooltipsSortedWrapper$Companion companion, List list, Function1 ... function1Array) {
        companion.sortByConditions(list, function1Array);
    }

    public TooltipsSortedWrapper$Companion(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }
}

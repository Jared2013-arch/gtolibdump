package com.gtolib.api.lang;

import java.util.Arrays;

public record CNENS(String[] cns, String[] ens) {
    public boolean equals(Object object) {
        if (object instanceof CNENS) {
            CNENS cNENS = (CNENS)object;
            return Arrays.equals(cNENS.ens, this.ens) && Arrays.equals(cNENS.cns, this.cns);
        }
        return false;
    }

    public int length() {
        return this.ens.length;
    }
}

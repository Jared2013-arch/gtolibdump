package com.gtolib.api.lang;

import com.gtocore.common.data.translation.MultiblockSlang;
import com.gtolib.api.annotation.NewDataAttributes;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.function.Supplier;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.StringsKt;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={2, 1, 0}, k=1, xi=48, d1={"\u0000.\n\n\u0000\n\b\n\n\n\u0000\n\n\b\n\n \n\n\b\b\u0000 20:B¢\bJ(\f0\u00002\r\f00020\bHJ0\u00002\f000J0\u00002\f\b00J0\u00002\r0J0\u00002\r\f000J\f0000R\b00X¢\n\u0000R0\bX¢\n\u0000\b\t\"\b\n¨"}, d2={"Lcom/gtolib/api/lang/TooltipsSortedWrapper;", "", "<init>", "()V", "tooltips", "Lit/unimi/dsi/fastutil/objects/ObjectArrayList;", "Lcom/gtolib/api/lang/TooltipsSortedWrapper$SupplierWrapper;", "isInitialized", "", "()Z", "setInitialized", "(Z)V", "add", "component", "Ljava/util/function/Supplier;", "", "Lnet/minecraft/network/chat/Component;", "supplier", "addTooltip", "components", "addSupplier", "getTooltips", "Companion", "SupplierWrapper", "gtolib"})
@SourceDebugExtension(value={"SMAP\nTooltipsSortedWrapper.kt\nKotlin\n*S Kotlin\n*F\n+ 1 TooltipsSortedWrapper.kt\ncom/gtolib/api/lang/TooltipsSortedWrapper\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,68:1\n1761#2,3:69\n1761#2,3:72\n1761#2,3:75\n1761#2,3:78\n1761#2,3:81\n1761#2,3:84\n1761#2,3:87\n1761#2,3:90\n1761#2,3:93\n1761#2,3:96\n1761#2,3:99\n*S KotlinDebug\n*F\n+ 1 TooltipsSortedWrapper.kt\ncom/gtolib/api/lang/TooltipsSortedWrapper\n*L\n32#1:69,3\n33#1:72,3\n34#1:75,3\n35#1:78,3\n36#1:81,3\n37#1:84,3\n38#1:87,3\n39#1:90,3\n40#1:93,3\n41#1:96,3\n42#1:99,3\n*E\n"})
public final class TooltipsSortedWrapper {
    @NotNull
    public static final Companion Companion = new Companion(null);
    @NotNull
    private final ObjectArrayList<SupplierWrapper> tooltips = new ObjectArrayList();
    private boolean isInitialized;

    public final boolean isInitialized() {
        return this.isInitialized;
    }

    public final void setInitialized(boolean bl) {
        this.isInitialized = bl;
    }

    private final TooltipsSortedWrapper add(Supplier<List<Component>> supplier, boolean bl) {
        this.tooltips.add((Object)new SupplierWrapper(this, supplier, bl));
        Function1[] function1Array = new Function1[]{TooltipsSortedWrapper::add$lambda$1, TooltipsSortedWrapper::add$lambda$3, TooltipsSortedWrapper::add$lambda$5, TooltipsSortedWrapper::add$lambda$7, TooltipsSortedWrapper::add$lambda$9, TooltipsSortedWrapper::add$lambda$11, TooltipsSortedWrapper::add$lambda$13, TooltipsSortedWrapper::add$lambda$15, TooltipsSortedWrapper::add$lambda$17, TooltipsSortedWrapper::add$lambda$19, TooltipsSortedWrapper::add$lambda$21};
        Function1[] function1Array2 = function1Array;
        TooltipsSortedWrapper.Companion.sortByConditions(this.tooltips, Arrays.copyOf(function1Array2, function1Array2.length));
        return this;
    }

    @NotNull
    public final TooltipsSortedWrapper addTooltip(@NotNull Supplier<List<Component>> supplier) {
        Intrinsics.checkNotNullParameter(supplier, "");
        return this.add(supplier, false);
    }

    @NotNull
    public final TooltipsSortedWrapper addTooltip(@NotNull List<? extends Component> list) {
        Intrinsics.checkNotNullParameter(list, "");
        return this.addTooltip(() -> TooltipsSortedWrapper.addTooltip$lambda$22(list));
    }

    @NotNull
    public final TooltipsSortedWrapper addTooltip(@NotNull Component component) {
        Intrinsics.checkNotNullParameter(component, "");
        return this.addTooltip(CollectionsKt.listOf(component));
    }

    @NotNull
    public final TooltipsSortedWrapper addSupplier(@NotNull Supplier<List<Component>> supplier) {
        Intrinsics.checkNotNullParameter(supplier, "");
        return this.add(supplier, true);
    }

    @NotNull
    public final List<Supplier<List<Component>>> getTooltips() {
        return this.tooltips;
    }

    private static final boolean add$lambda$1(Supplier supplier) {
        boolean bl;
        block5: {
            Intrinsics.checkNotNullParameter(supplier, "");
            List list = (List)supplier.get();
            if (list != null) {
                Iterable iterable = list;
                boolean bl2 = false;
                if (iterable instanceof Collection && ((Collection)iterable).isEmpty()) {
                    bl = false;
                } else {
                    for (Object t : iterable) {
                        Component component = (Component)t;
                        boolean bl3 = false;
                        Object object = component;
                        if (!(object != null && (object = object.getString()) != null ? StringsKt.contains$default((CharSequence)object, "gtocore.difficulty_config", false, 2, null) : false)) continue;
                        bl = true;
                        break block5;
                    }
                    bl = false;
                }
            } else {
                bl = false;
            }
        }
        return bl;
    }

    private static final boolean add$lambda$3(Supplier supplier) {
        boolean bl;
        block5: {
            Intrinsics.checkNotNullParameter(supplier, "");
            List list = (List)supplier.get();
            if (list != null) {
                Iterable iterable = list;
                boolean bl2 = false;
                if (iterable instanceof Collection && ((Collection)iterable).isEmpty()) {
                    bl = false;
                } else {
                    for (Object t : iterable) {
                        Component component = (Component)t;
                        boolean bl3 = false;
                        Object object = component;
                        if (!(object != null && (object = object.getString()) != null ? StringsKt.contains$default((CharSequence)object, "gtocore.lang.template", false, 2, null) : false)) continue;
                        bl = true;
                        break block5;
                    }
                    bl = false;
                }
            } else {
                bl = false;
            }
        }
        return bl;
    }

    private static final boolean add$lambda$5(Supplier supplier) {
        boolean bl;
        block5: {
            Intrinsics.checkNotNullParameter(supplier, "");
            List list = (List)supplier.get();
            if (list != null) {
                Iterable iterable = list;
                boolean bl2 = false;
                if (iterable instanceof Collection && ((Collection)iterable).isEmpty()) {
                    bl = false;
                } else {
                    for (Object t : iterable) {
                        Component component = (Component)t;
                        boolean bl3 = false;
                        Object object = component;
                        if (!(object != null && (object = object.getString()) != null ? StringsKt.contains$default((CharSequence)object, "gtocore.lang.template." + NewDataAttributes.ALLOW_PARALLEL_SPECIAL.getKey(), false, 2, null) : false)) continue;
                        bl = true;
                        break block5;
                    }
                    bl = false;
                }
            } else {
                bl = false;
            }
        }
        return bl;
    }

    private static final boolean add$lambda$7(Supplier supplier) {
        boolean bl;
        block5: {
            Intrinsics.checkNotNullParameter(supplier, "");
            List list = (List)supplier.get();
            if (list != null) {
                Iterable iterable = list;
                boolean bl2 = false;
                if (iterable instanceof Collection && ((Collection)iterable).isEmpty()) {
                    bl = false;
                } else {
                    for (Object t : iterable) {
                        Component component = (Component)t;
                        boolean bl3 = false;
                        Object object = component;
                        if (!(object != null && (object = object.getString()) != null ? StringsKt.contains$default((CharSequence)object, "gtocore.lang.template." + NewDataAttributes.ALLOW_PARALLEL.getKey(), false, 2, null) : false)) continue;
                        bl = true;
                        break block5;
                    }
                    bl = false;
                }
            } else {
                bl = false;
            }
        }
        return bl;
    }

    private static final boolean add$lambda$9(Supplier supplier) {
        boolean bl;
        block5: {
            Intrinsics.checkNotNullParameter(supplier, "");
            List list = (List)supplier.get();
            if (list != null) {
                Iterable iterable = list;
                boolean bl2 = false;
                if (iterable instanceof Collection && ((Collection)iterable).isEmpty()) {
                    bl = false;
                } else {
                    for (Object t : iterable) {
                        Component component = (Component)t;
                        boolean bl3 = false;
                        Object object = component;
                        if (!(object != null && (object = object.getString()) != null ? StringsKt.contains$default((CharSequence)object, "gtocore.lang.template." + NewDataAttributes.ALLOW_PARALLEL_NUMBER.getKey(), false, 2, null) : false)) continue;
                        bl = true;
                        break block5;
                    }
                    bl = false;
                }
            } else {
                bl = false;
            }
        }
        return bl;
    }

    private static final boolean add$lambda$11(Supplier supplier) {
        boolean bl;
        block5: {
            Intrinsics.checkNotNullParameter(supplier, "");
            List list = (List)supplier.get();
            if (list != null) {
                Iterable iterable = list;
                boolean bl2 = false;
                if (iterable instanceof Collection && ((Collection)iterable).isEmpty()) {
                    bl = false;
                } else {
                    for (Object t : iterable) {
                        Component component = (Component)t;
                        boolean bl3 = false;
                        Object object = component;
                        if (!(object != null && (object = object.getString()) != null ? StringsKt.contains$default((CharSequence)object, "gtocore.lang.template." + NewDataAttributes.LASER_ENERGY_HATCH.getKey(), false, 2, null) : false)) continue;
                        bl = true;
                        break block5;
                    }
                    bl = false;
                }
            } else {
                bl = false;
            }
        }
        return bl;
    }

    private static final boolean add$lambda$13(Supplier supplier) {
        boolean bl;
        block5: {
            Intrinsics.checkNotNullParameter(supplier, "");
            List list = (List)supplier.get();
            if (list != null) {
                Iterable iterable = list;
                boolean bl2 = false;
                if (iterable instanceof Collection && ((Collection)iterable).isEmpty()) {
                    bl = false;
                } else {
                    for (Object t : iterable) {
                        Component component = (Component)t;
                        boolean bl3 = false;
                        Object object = component;
                        if (!(object != null && (object = object.getString()) != null ? StringsKt.contains$default((CharSequence)object, MultiblockSlang.INSTANCE.getNot_allow_standard_energy_hatch().getTranslationPrefix(), false, 2, null) : false)) continue;
                        bl = true;
                        break block5;
                    }
                    bl = false;
                }
            } else {
                bl = false;
            }
        }
        return bl;
    }

    private static final boolean add$lambda$15(Supplier supplier) {
        boolean bl;
        block5: {
            Intrinsics.checkNotNullParameter(supplier, "");
            List list = (List)supplier.get();
            if (list != null) {
                Iterable iterable = list;
                boolean bl2 = false;
                if (iterable instanceof Collection && ((Collection)iterable).isEmpty()) {
                    bl = false;
                } else {
                    for (Object t : iterable) {
                        Component component = (Component)t;
                        boolean bl3 = false;
                        Object object = component;
                        if (!(object != null && (object = object.getString()) != null ? StringsKt.contains$default((CharSequence)object, "gtocore.lang.template." + NewDataAttributes.PREFECT_OVERCLOCK.getKey(), false, 2, null) : false)) continue;
                        bl = true;
                        break block5;
                    }
                    bl = false;
                }
            } else {
                bl = false;
            }
        }
        return bl;
    }

    private static final boolean add$lambda$17(Supplier supplier) {
        boolean bl;
        block5: {
            Intrinsics.checkNotNullParameter(supplier, "");
            List list = (List)supplier.get();
            if (list != null) {
                Iterable iterable = list;
                boolean bl2 = false;
                if (iterable instanceof Collection && ((Collection)iterable).isEmpty()) {
                    bl = false;
                } else {
                    for (Object t : iterable) {
                        Component component = (Component)t;
                        boolean bl3 = false;
                        Object object = component;
                        if (!(object != null && (object = object.getString()) != null ? StringsKt.contains$default((CharSequence)object, "gtocore.lang.template." + NewDataAttributes.ALLOW_MULTI_RECIPE_PARALLEL.getKey(), false, 2, null) : false)) continue;
                        bl = true;
                        break block5;
                    }
                    bl = false;
                }
            } else {
                bl = false;
            }
        }
        return bl;
    }

    private static final boolean add$lambda$19(Supplier supplier) {
        boolean bl;
        block5: {
            Intrinsics.checkNotNullParameter(supplier, "");
            List list = (List)supplier.get();
            if (list != null) {
                Iterable iterable = list;
                boolean bl2 = false;
                if (iterable instanceof Collection && ((Collection)iterable).isEmpty()) {
                    bl = false;
                } else {
                    for (Object t : iterable) {
                        Component component = (Component)t;
                        boolean bl3 = false;
                        Object object = component;
                        if (!(object != null && (object = object.getString()) != null ? StringsKt.contains$default((CharSequence)object, "gtocore.lang.template." + NewDataAttributes.NOT_ALLOW_SHARED.getKey(), false, 2, null) : false)) continue;
                        bl = true;
                        break block5;
                    }
                    bl = false;
                }
            } else {
                bl = false;
            }
        }
        return bl;
    }

    private static final boolean add$lambda$21(Supplier supplier) {
        boolean bl;
        block5: {
            Intrinsics.checkNotNullParameter(supplier, "");
            List list = (List)supplier.get();
            if (list != null) {
                Iterable iterable = list;
                boolean bl2 = false;
                if (iterable instanceof Collection && ((Collection)iterable).isEmpty()) {
                    bl = false;
                } else {
                    for (Object t : iterable) {
                        Component component = (Component)t;
                        boolean bl3 = false;
                        Object object = component;
                        if (!(object != null && (object = object.getString()) != null ? StringsKt.contains$default((CharSequence)object, "gtocore.lang.template." + NewDataAttributes.RECIPES_TYPE.getKey(), false, 2, null) : false)) continue;
                        bl = true;
                        break block5;
                    }
                    bl = false;
                }
            } else {
                bl = false;
            }
        }
        return bl;
    }

    private static final List addTooltip$lambda$22(List list) {
        return list;
    }

    @Metadata(mv={2, 1, 0}, k=1, xi=48, d1={"\u0000(\n\n\u0000\n\b\n\n\u0000\n!\n\u0000\n\n\n\n\b\b\u000020B\t\b¢\bJI0\"\b\u0000*\bH02*\b\bH00\n0\t\"H00\nH¢\f¨\r"}, d2={"Lcom/gtolib/api/lang/TooltipsSortedWrapper$Companion;", "", "<init>", "()V", "sortByConditions", "", "T", "", "conditions", "", "Lkotlin/Function1;", "", "(Ljava/util/List;[Lkotlin/jvm/functions/Function1;)V", "gtolib"})
    public static final class Companion {
        private Companion() {
        }

        private final <T> void sortByConditions(List<T> list, Function1<? super T, Boolean> ... function1Array) {
            CollectionsKt.sortWith(list, (Comparator)new Comparator(function1Array){
                final Function1[] $conditions$inlined;
                {
                    this.$conditions$inlined = function1Array;
                }

                public final int compare(T t, T t2) {
                    Comparable comparable;
                    int n;
                    Comparable comparable2;
                    int n2;
                    int n3;
                    int n4;
                    Object object;
                    block9: {
                        Comparable comparable3;
                        int n5;
                        boolean bl;
                        Function1 function1;
                        boolean bl2;
                        T t3;
                        block8: {
                            t3 = t;
                            bl2 = false;
                            object = this.$conditions$inlined;
                            n4 = 0;
                            n3 = ((Function1[])object).length + -1;
                            if (0 <= n3) {
                                do {
                                    n2 = n3--;
                                    function1 = object[n2];
                                    bl = false;
                                    if (!((Boolean)function1.invoke(t3)).booleanValue()) continue;
                                    n5 = n2;
                                    break block8;
                                } while (0 <= n3);
                            }
                            n5 = -1;
                        }
                        object = n5;
                        n4 = ((Number)object).intValue();
                        n3 = 0;
                        Object object2 = n4 >= 0 ? object : null;
                        if (object2 != null) {
                            n3 = ((Number)object2).intValue();
                            n2 = 0;
                            comparable3 = Integer.valueOf(n3 + 1);
                        } else {
                            comparable3 = Integer.valueOf(0);
                        }
                        t3 = t2;
                        comparable2 = comparable3;
                        bl2 = false;
                        object = this.$conditions$inlined;
                        n4 = 0;
                        n3 = ((Function1[])object).length + -1;
                        if (0 <= n3) {
                            do {
                                n2 = n3--;
                                function1 = object[n2];
                                bl = false;
                                if (!((Boolean)function1.invoke(t3)).booleanValue()) continue;
                                n = n2;
                                break block9;
                            } while (0 <= n3);
                        }
                        n = -1;
                    }
                    object = n;
                    n4 = ((Number)object).intValue();
                    n3 = 0;
                    Object object3 = n4 >= 0 ? object : null;
                    if (object3 != null) {
                        n3 = ((Number)object3).intValue();
                        n2 = 0;
                        comparable = Integer.valueOf(n3 + 1);
                    } else {
                        comparable = Integer.valueOf(0);
                    }
                    return ComparisonsKt.compareValues((Comparable)comparable2, (Comparable)comparable);
                }
            });
        }

        public Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    @Metadata(mv={2, 1, 0}, k=1, xi=48, d1={"\u0000\"\n\n\n \n\n\u0000\n\n\b\n\n\b\b\u00002\f000B/0\f0000\b¢\b\t\nJ\f00HR0X¢\n\u0000R\f000X¢\n\u0000R0\bX¢\n\u0000¨\f"}, d2={"Lcom/gtolib/api/lang/TooltipsSortedWrapper$SupplierWrapper;", "Ljava/util/function/Supplier;", "", "Lnet/minecraft/network/chat/Component;", "wrapper", "Lcom/gtolib/api/lang/TooltipsSortedWrapper;", "components", "supplier", "", "<init>", "(Lcom/gtolib/api/lang/TooltipsSortedWrapper;Ljava/util/function/Supplier;Z)V", "get", "gtolib"})
    private static final class SupplierWrapper
    implements Supplier<List<? extends Component>> {
        @NotNull
        private final TooltipsSortedWrapper wrapper;
        @NotNull
        private final Supplier<List<Component>> components;
        private final boolean supplier;

        public SupplierWrapper(@NotNull TooltipsSortedWrapper tooltipsSortedWrapper, @NotNull Supplier<List<Component>> supplier, boolean bl) {
            Intrinsics.checkNotNullParameter(tooltipsSortedWrapper, "");
            Intrinsics.checkNotNullParameter(supplier, "");
            this.wrapper = tooltipsSortedWrapper;
            this.components = supplier;
            this.supplier = bl;
        }

        @Override
        @Nullable
        public List<Component> get() {
            if (this.wrapper.isInitialized()) {
                return this.components.get();
            }
            if (this.supplier) {
                return CollectionsKt.emptyList();
            }
            return this.components.get();
        }
    }
}

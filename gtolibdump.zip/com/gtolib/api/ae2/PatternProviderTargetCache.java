package com.gtolib.api.ae2;

import appeng.api.config.Actionable;
import appeng.api.crafting.IPatternDetails;
import appeng.api.networking.security.IActionSource;
import appeng.api.stacks.AEKey;
import appeng.api.stacks.KeyCounter;
import appeng.api.storage.MEStorage;
import appeng.capabilities.Capabilities;
import appeng.helpers.patternprovider.PatternProviderTarget;
import appeng.me.storage.CompositeStorage;
import appeng.me.storage.ExternalStorageFacade;
import com.gtolib.api.ae2.AEKeyTypeMap;
import com.gtolib.api.ae2.IPatternProviderLogic;
import com.gtolib.api.blockentity.IDirectionCacheBlockEntity;
import com.gtolib.utils.BlockCapabilityCache;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import java.util.Iterator;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.items.IItemHandler;
import org.jetbrains.annotations.Nullable;

public final class PatternProviderTargetCache {
    private final BlockEntity blockEntity;
    private final IPatternProviderLogic logic;
    private final BlockCapabilityCache<MEStorage> cache;
    private final BlockPos pos;
    private final Direction side;
    private final Direction oppositeSide;
    private final IActionSource src;

    public PatternProviderTargetCache(BlockEntity blockEntity, IPatternProviderLogic iPatternProviderLogic, Direction direction, IActionSource iActionSource) {
        this.blockEntity = blockEntity;
        this.logic = iPatternProviderLogic;
        this.cache = BlockCapabilityCache.create(Capabilities.STORAGE, blockEntity);
        this.pos = blockEntity.m_58899_().m_121945_(direction);
        this.side = direction;
        this.oppositeSide = direction.m_122424_();
        this.src = iActionSource;
    }

    public static PatternProviderTarget find(@Nullable BlockEntity blockEntity, IPatternProviderLogic iPatternProviderLogic, Direction direction, IActionSource iActionSource, long l) {
        IItemHandler iItemHandler;
        if (blockEntity == null) {
            return null;
        }
        ExternalStorageFacade externalStorageFacade = null;
        ExternalStorageFacade externalStorageFacade2 = null;
        IFluidHandler iFluidHandler = (IFluidHandler)blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, direction).orElse(null);
        if (iFluidHandler != null) {
            externalStorageFacade = ExternalStorageFacade.of(iFluidHandler);
        }
        if ((iItemHandler = (IItemHandler)blockEntity.getCapability(ForgeCapabilities.ITEM_HANDLER, direction).orElse(null)) != null) {
            externalStorageFacade2 = ExternalStorageFacade.of(iItemHandler);
        }
        if (externalStorageFacade == null && externalStorageFacade2 == null) {
            return null;
        }
        if (externalStorageFacade == null) {
            return new WrapMeStorage(externalStorageFacade2, iActionSource, iPatternProviderLogic, l, direction.m_122424_().m_122411_());
        }
        if (externalStorageFacade2 == null) {
            return new WrapMeStorage(externalStorageFacade, iActionSource, iPatternProviderLogic, l, direction.m_122424_().m_122411_());
        }
        return new WrapMeStorage(new CompositeStorage(new AEKeyTypeMap<ExternalStorageFacade>(externalStorageFacade2, externalStorageFacade)), iActionSource, iPatternProviderLogic, l, direction.m_122424_().m_122411_());
    }

    @Nullable
    public PatternProviderTarget find(int n) {
        MEStorage mEStorage = this.cache.find(this.pos, this.side, this.oppositeSide);
        if (mEStorage != null) {
            return new WrapMeStorage(mEStorage, this.src, this.logic, 0L, n);
        }
        return PatternProviderTargetCache.find(IDirectionCacheBlockEntity.getBlockEntityDirectionCache(this.blockEntity).getAdjacentBlockEntity(this.blockEntity.m_58904_(), this.blockEntity.m_58899_(), this.side), this.logic, this.oppositeSide, this.src, 0L);
    }

    public record WrapMeStorage(MEStorage storage, IActionSource src, IPatternProviderLogic logic, long pos, int dir) implements PatternProviderTarget
    {
        public long insert(AEKey aEKey, long l, Actionable actionable) {
            return this.storage.insert(aEKey, l, actionable, this.src);
        }

        public boolean containsPatternInput(Set<AEKey> set) {
            switch (this.logic.gtolib$getBlocking()) {
                case ALL: {
                    return this.isNonEmpty(null);
                }
                case NON_CONTAIN: {
                    IPatternDetails iPatternDetails = this.logic.gtolib$getCachePattern(this.pos, this.dir);
                    if (iPatternDetails == null) {
                        return false;
                    }
                    IPatternDetails iPatternDetails2 = this.logic.gtolib$getCurrentPattern();
                    return iPatternDetails2 != null && !iPatternDetails2.equals(iPatternDetails) && this.isNonEmpty(set);
                }
                case PARALLEL: 
                case CONTAIN: {
                    return this.isNonEmpty(set);
                }
                case NONE: {
                    return false;
                }
            }
            return false;
        }

        private boolean isNonEmpty(@Nullable Set<AEKey> set) {
            KeyCounter keyCounter = this.storage.getAvailableStacks();
            keyCounter.removeZeros();
            if (keyCounter.isEmpty()) {
                return false;
            }
            if (set == null) {
                return true;
            }
            Iterator iterator = keyCounter.iterator();
            while (iterator.hasNext()) {
                Object2LongMap.Entry entry = (Object2LongMap.Entry)iterator.next();
                if (!set.contains(((AEKey)entry.getKey()).dropSecondary())) continue;
                return true;
            }
            return false;
        }
    }
}

package com.gtolib.api.ae2;

import appeng.api.networking.IGrid;
import appeng.api.stacks.AEFluidKey;
import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import com.google.common.base.Preconditions;
import com.gtocore.common.machine.multiblock.part.ae.MEPatternContentSortMachine;
import java.util.Objects;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;

class ProcessingPatternEncoding {
    private static final String NBT_INPUTS = "in";
    private static final String NBT_OUTPUTS = "out";

    ProcessingPatternEncoding() {
    }

    public static GenericStack[] getProcessingInputs(CompoundTag compoundTag, IGrid iGrid) {
        return ProcessingPatternEncoding.getMixedList(compoundTag, NBT_INPUTS, 81, iGrid);
    }

    public static GenericStack[] getProcessingOutputs(CompoundTag compoundTag) {
        return ProcessingPatternEncoding.getMixedList(compoundTag, NBT_OUTPUTS, 27, null);
    }

    public static GenericStack[] getMixedList(CompoundTag compoundTag, String string, int n, IGrid iGrid) {
        Objects.requireNonNull(compoundTag, "Pattern must have a tag.");
        ListTag listTag = compoundTag.m_128437_(string, 10);
        Preconditions.checkArgument(listTag.size() <= n, "Cannot use more than " + n + " ingredients");
        GenericStack[] genericStackArray = new GenericStack[listTag.size()];
        for (int i = 0; i < listTag.size(); ++i) {
            CompoundTag compoundTag2 = listTag.m_128728_(i);
            if (compoundTag2.m_128456_()) continue;
            GenericStack genericStack = GenericStack.readTag(compoundTag2);
            if (genericStack == null) {
                throw new IllegalArgumentException("Pattern references missing stack: " + String.valueOf(compoundTag2));
            }
            if (string.equals(NBT_INPUTS) && iGrid != null && (genericStack.what() instanceof AEItemKey || genericStack.what() instanceof AEFluidKey)) {
                for (MEPatternContentSortMachine mEPatternContentSortMachine : iGrid.getMachines(MEPatternContentSortMachine.class)) {
                    AEKey aEKey;
                    if (mEPatternContentSortMachine == null || (aEKey = mEPatternContentSortMachine.getExternalLogic().getAEKeyReplaced(genericStack.what())) == genericStack.what()) continue;
                    genericStack = new GenericStack(aEKey, genericStack.amount());
                    break;
                }
            }
            genericStackArray[i] = genericStack;
        }
        return genericStackArray;
    }

    public static void encodeProcessingPattern(CompoundTag compoundTag, GenericStack[] genericStackArray, GenericStack[] genericStackArray2) {
        compoundTag.m_128365_(NBT_INPUTS, ProcessingPatternEncoding.encodeStackList(genericStackArray));
        compoundTag.m_128365_(NBT_OUTPUTS, ProcessingPatternEncoding.encodeStackList(genericStackArray2));
    }

    private static ListTag encodeStackList(GenericStack[] genericStackArray) {
        ListTag listTag = new ListTag();
        boolean bl = false;
        for (GenericStack genericStack : genericStackArray) {
            listTag.add(GenericStack.writeTag(genericStack));
            if (genericStack == null || genericStack.amount() <= 0L) continue;
            bl = true;
        }
        Preconditions.checkArgument(bl, "List passed to pattern must contain at least one stack.");
        return listTag;
    }
}

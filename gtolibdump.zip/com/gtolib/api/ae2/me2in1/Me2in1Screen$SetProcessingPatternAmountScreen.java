package com.gtolib.api.ae2.me2in1;

import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import appeng.client.gui.AEBaseScreen;
import appeng.client.gui.AESubScreen;
import appeng.client.gui.NumberEntryType;
import appeng.client.gui.me.common.ClientDisplaySlot;
import appeng.client.gui.widgets.AECheckbox;
import appeng.client.gui.widgets.AETextField;
import appeng.client.gui.widgets.NumberEntryWidget;
import appeng.client.gui.widgets.TabButton;
import appeng.core.definitions.AEItems;
import appeng.core.localization.GuiText;
import appeng.menu.SlotSemantics;
import com.google.common.primitives.Longs;
import com.gtocore.client.ClientCache;
import com.gtocore.config.GTOConfig;
import com.gtolib.api.ae2.me2in1.Me2in1Menu;
import com.gtolib.api.ae2.me2in1.Me2in1Screen;
import dev.toma.configuration.config.ConfigHolder;
import dev.toma.configuration.config.io.ConfigIO;
import dev.toma.configuration.config.value.StringValue;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

public class Me2in1Screen$SetProcessingPatternAmountScreen<C extends Me2in1Menu>
extends AESubScreen<C, AEBaseScreen<C>> {
    private final NumberEntryWidget amount;
    private final GenericStack currentStack;
    private final Consumer<GenericStack> setter;
    private final AETextField rename;
    private final AETextField defaultRename;
    private final AECheckbox checkBox;
    @Nullable
    private String changedName;

    public Me2in1Screen$SetProcessingPatternAmountScreen(Me2in1Screen<C> me2in1Screen, GenericStack genericStack, Consumer<GenericStack> consumer) {
        super(me2in1Screen, "/screens/set_rename_pattern_amount.json");
        this.currentStack = genericStack;
        this.setter = consumer;
        this.changedName = null;
        this.widgets.addButton("save", GuiText.Set.text(), this::confirm);
        ItemStack itemStack = AEItems.PROCESSING_PATTERN.stack();
        TabButton tabButton = new TabButton(itemStack, (Component)Component.m_237115_("gtceu.gui.title_bar.back"), button -> this.returnToParent());
        this.widgets.add("back", tabButton);
        this.amount = this.widgets.addNumberEntryWidget("amountToStock", NumberEntryType.of((AEKey)genericStack.what()));
        this.amount.setLongValue(genericStack.amount());
        this.amount.setMaxValue(this.getMaxAmount());
        this.amount.setTextFieldStyle(this.style.getWidget("amountToStockInput"));
        this.amount.setMinValue(0L);
        this.amount.setHideValidationIcon(true);
        this.amount.setOnConfirm(this::confirm);
        this.rename = this.widgets.addTextField("rename");
        AEKey aEKey = genericStack.what();
        if (aEKey instanceof AEItemKey) {
            AEItemKey aEItemKey = (AEItemKey)aEKey;
            this.rename.m_94144_(aEItemKey.toStack().m_41786_().getString());
            this.rename.m_94151_(this::setChangedName);
            this.rename.setTooltipMessage(List.of((Object)Component.m_237115_("gui.expatternprovider.renamer")));
        }
        this.defaultRename = this.widgets.addTextField("defaultRename");
        this.defaultRename.m_94144_(ClientCache.autoRenameName.equals("{}") ? "" : ClientCache.autoRenameName);
        this.defaultRename.m_94151_(string -> {
            ClientCache.autoRenameName = string;
        });
        this.defaultRename.setTooltipMessage(List.of((Object)Component.m_237115_("gtocore.ae.appeng.me2in1.save_default_rename_pattern")));
        this.checkBox = this.widgets.addCheckbox("autoEncodeRenamePatternCheckbox", Component.m_237115_("gtocore.ae.appeng.me2in1.auto_encode_rename_pattern"), this::onCheckBoxChanged);
        this.checkBox.setSelected(((Me2in1Menu)this.getParent().m_6262_()).getEncoding().isAutoEncodeRenaming());
        this.checkBox.m_257544_(Tooltip.m_257550_(Component.m_237115_("gtocore.ae.appeng.me2in1.auto_encode_rename_pattern.1")));
        this.addClientSideSlot(new ClientDisplaySlot(genericStack), SlotSemantics.MACHINE_OUTPUT);
    }

    private void onCheckBoxChanged() {
        ((Me2in1Menu)this.getParent().m_6262_()).getEncoding().setAutoEncodeRenaming(this.checkBox.isSelected());
    }

    public boolean m_6375_(double d2, double d3, int n) {
        if (n == 1 && this.rename.m_5953_(d2, d3)) {
            this.rename.m_94144_("");
        }
        return super.m_6375_(d2, d3, n);
    }

    protected void m_7856_() {
        super.m_7856_();
        this.setSlotsHidden(SlotSemantics.TOOLBOX, true);
    }

    private void confirm() {
        this.amount.getLongValue().ifPresent(l -> {
            if ((l = Longs.constrainToRange(l, 0L, this.getMaxAmount())) <= 0L) {
                this.setter.accept(null);
            } else {
                this.setter.accept(this.getSetterStack(l));
            }
            if (!Objects.equals(GTOConfig.INSTANCE.renamePatternDefaultString, ClientCache.autoRenameName)) {
                ConfigHolder.getConfig((String)"gtocore").ifPresent(configHolder -> {
                    ((StringValue)configHolder.getValueMap().get("renamePatternDefaultString")).set((Object)ClientCache.autoRenameName);
                    ConfigIO.saveClientValues((ConfigHolder)configHolder);
                    ConfigIO.reloadClientValues((ConfigHolder)configHolder);
                });
            }
            this.returnToParent();
        });
    }

    private GenericStack getSetterStack(long l) {
        Object object;
        if (this.changedName != null && (object = this.currentStack.what()) instanceof AEItemKey) {
            AEItemKey aEItemKey = (AEItemKey)object;
            object = aEItemKey.toStack();
            if (this.changedName.isEmpty()) {
                object.m_41749_("display");
            } else {
                ((ItemStack)object).m_41714_(Component.m_237113_(this.changedName));
            }
            return new GenericStack(AEItemKey.of((ItemStack)object), l);
        }
        return new GenericStack(this.currentStack.what(), l);
    }

    private long getMaxAmount() {
        return 999999L * (long)this.currentStack.what().getAmountPerUnit();
    }

    public void setChangedName(@Nullable String string) {
        this.changedName = string;
    }
}

package com.gtolib.api.ae2.me2in1;

import appeng.api.config.Settings;
import appeng.api.config.ShowPatternProviders;
import appeng.api.config.SortDir;
import appeng.api.config.SortOrder;
import appeng.api.config.TypeFilter;
import appeng.api.config.ViewItems;
import appeng.api.implementations.menuobjects.ItemMenuHost;
import appeng.api.networking.IGridNode;
import appeng.api.util.IConfigManager;
import appeng.client.gui.style.ScreenStyle;
import appeng.core.AEConfig;
import appeng.items.tools.powered.WirelessTerminalItem;
import appeng.menu.ISubMenu;
import appeng.menu.ToolboxMenu;
import appeng.menu.implementations.MenuTypeBuilder;
import appeng.menu.slot.RestrictedInputSlot;
import appeng.util.ConfigManager;
import com.gtocore.common.data.GTOItems;
import com.gtolib.ae2.me2in1.a;
import com.gtolib.api.ae2.GTOSettings;
import com.gtolib.api.ae2.ShiftTransferTo;
import com.gtolib.api.ae2.ShowMolecularAssembler;
import com.gtolib.api.ae2.gui.widgets.AESlotWidget;
import com.gtolib.api.ae2.me2in1.ExtendedEncodingLogic;
import com.gtolib.api.ae2.me2in1.Me2in1Menu;
import com.gtolib.api.ae2.me2in1.Me2in1Screen;
import com.gtolib.api.ae2.me2in1.UtilsMiscs;
import de.mari_023.ae2wtlib.AE2wtlibSlotSemantics;
import de.mari_023.ae2wtlib.terminal.IUniversalWirelessTerminalItem;
import de.mari_023.ae2wtlib.terminal.WTMenuHost;
import de.mari_023.ae2wtlib.wct.WCTMenuHost;
import de.mari_023.ae2wtlib.wut.CycleTerminalButton;
import de.mari_023.ae2wtlib.wut.IUniversalTerminalCapable;
import de.mari_023.ae2wtlib.wut.ItemWUT;
import java.util.List;
import java.util.function.BiConsumer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class Wireless
extends Me2in1Menu {
    public static final String ID = "me2in1_wireless";
    public static final MenuType<Wireless> TYPE = MenuTypeBuilder.create(Wireless::new, Host.class).build("me2in1_wireless");
    private final Host host;
    private final ToolboxMenu toolboxMenu;
    private final RestrictedInputSlot singularitySlot;

    public Wireless(int n, Inventory inventory, Host host) {
        super(TYPE, n, inventory, host, true);
        this.host = host;
        this.toolboxMenu = new ToolboxMenu(this);
        this.singularitySlot = new RestrictedInputSlot(RestrictedInputSlot.PlacableItemType.QE_SINGULARITY, this.host.getSubInventory(WCTMenuHost.INV_SINGULARITY), 0);
        this.addSlot(this.singularitySlot, AE2wtlibSlotSemantics.SINGULARITY);
    }

    public ToolboxMenu getToolbox() {
        return this.toolboxMenu;
    }

    @Override
    public IGridNode getNetworkNode() {
        return this.host.getActionableNode();
    }

    private boolean isWUT() {
        return this.host.getItemStack().m_41720_() instanceof ItemWUT;
    }

    public static class Host
    extends WTMenuHost
    implements a {
        private final ExtendedEncodingLogic logic = new ExtendedEncodingLogic(this);

        public Host(Player player, @Nullable Integer n, ItemStack itemStack, BiConsumer<Player, ISubMenu> biConsumer) {
            super(player, n, itemStack, biConsumer);
            this.readFromNbt();
        }

        public ItemStack getMainMenuIcon() {
            return GTOItems.WIRELESS_ME2IN1.asStack();
        }

        protected void readFromNbt() {
            super.readFromNbt();
            this.logic.readFromNBT(this.getItemStack().m_41784_());
        }

        public void saveChanges() {
            super.saveChanges();
            this.logic.writeToNBT(this.getItemStack().m_41784_());
        }

        @Override
        public ExtendedEncodingLogic getLogic() {
            return this.logic;
        }

        @Override
        public Level getLevel() {
            return this.getPlayer().m_9236_();
        }

        @Override
        public void markForSave() {
            this.saveChanges();
        }
    }

    public static class Item
    extends WirelessTerminalItem
    implements IUniversalWirelessTerminalItem {
        public Item(Item.Properties properties) {
            super(AEConfig.instance().getWirelessTerminalBattery(), properties.m_41487_(1));
        }

        @NotNull
        public MenuType<?> getMenuType(@NotNull ItemStack itemStack) {
            return TYPE;
        }

        @NotNull
        public IConfigManager getConfigManager(ItemStack itemStack) {
            ConfigManager configManager = new ConfigManager((iConfigManager, setting) -> iConfigManager.writeToNBT(itemStack.m_41784_()));
            configManager.registerSetting(Settings.SORT_BY, SortOrder.NAME);
            configManager.registerSetting(Settings.VIEW_MODE, ViewItems.ALL);
            configManager.registerSetting(Settings.TYPE_FILTER, TypeFilter.ALL);
            configManager.registerSetting(Settings.SORT_DIRECTION, SortDir.ASCENDING);
            configManager.registerSetting(Settings.TERMINAL_SHOW_PATTERN_PROVIDERS, ShowPatternProviders.VISIBLE);
            configManager.registerSetting(GTOSettings.TERMINAL_SHOW_MOLECULAR_ASSEMBLERS, ShowMolecularAssembler.ALL);
            configManager.registerSetting(GTOSettings.ME2IN1_SHIFT_TRANSFER_TO, ShiftTransferTo.INVENTORY_OR_BUFFER);
            configManager.readFromNBT(itemStack.m_41784_().m_6426_());
            return configManager;
        }

        public MenuType<?> getMenuType() {
            return TYPE;
        }

        @Nullable
        public ItemMenuHost getMenuHost(Player player2, int n, ItemStack itemStack, @Nullable BlockPos blockPos) {
            return new Host(player2, n, itemStack, (player, iSubMenu) -> this.openFromInventory((Player)player, n, true));
        }
    }

    public static class Screen
    extends Me2in1Screen<Wireless>
    implements IUniversalTerminalCapable {
        public Screen(Wireless wireless, Inventory inventory, Component component, ScreenStyle screenStyle) {
            super(wireless, inventory, component, screenStyle);
            if (((Wireless)this.m_6262_()).isWUT()) {
                this.addToLeftToolbar(new CycleTerminalButton(button -> this.cycleTerminal()));
            }
            this.widgets.add("quantumSlot", new AESlotWidget(wireless.singularitySlot, this));
            wireless.singularitySlot.setEmptyTooltip(() -> List.of((Object)Component.m_237115_("gtocore.ae.appeng.me2in1.quantum_bridge"), (Object)Component.m_237115_("gtocore.ae.appeng.me2in1.quantum_bridge.info")));
        }

        @Override
        public void updateBeforeRender() {
            super.updateBeforeRender();
            UtilsMiscs.setSlotPos(((Wireless)this.f_97732_).singularitySlot, 140, 8);
        }
    }
}

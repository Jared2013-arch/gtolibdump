package com.gtolib.api.ae2.me2in1;

import com.gtolib.api.ae2.me2in1.SeenProviderSlots;

public class ExtendedEncodingMenu$SeenProviderSlotsWithSlotId {
    private SeenProviderSlots seenProviderSlots;
    private int slotId;

    public ExtendedEncodingMenu$SeenProviderSlotsWithSlotId(SeenProviderSlots seenProviderSlots, int n) {
        this.seenProviderSlots = seenProviderSlots;
        this.slotId = n;
    }

    public ExtendedEncodingMenu$SeenProviderSlotsWithSlotId() {
    }

    public SeenProviderSlots getSeenProviderSlots() {
        return this.seenProviderSlots;
    }

    public void setSeenProviderSlots(SeenProviderSlots seenProviderSlots) {
        this.seenProviderSlots = seenProviderSlots;
    }

    public int getSlotId() {
        return this.slotId;
    }

    public void setSlotId(int n) {
        this.slotId = n;
    }
}

package com.gtolib.api.ae2.me2in1;

import net.minecraft.world.inventory.ClickType;

class Me2in1Screen$2 {
    static final int[] $SwitchMap$net$minecraft$world$inventory$ClickType;

    static {
        $SwitchMap$net$minecraft$world$inventory$ClickType = new int[ClickType.values().length];
        try {
            Me2in1Screen$2.$SwitchMap$net$minecraft$world$inventory$ClickType[ClickType.PICKUP.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Me2in1Screen$2.$SwitchMap$net$minecraft$world$inventory$ClickType[ClickType.QUICK_MOVE.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Me2in1Screen$2.$SwitchMap$net$minecraft$world$inventory$ClickType[ClickType.CLONE.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Me2in1Screen$2.$SwitchMap$net$minecraft$world$inventory$ClickType[ClickType.THROW.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

package com.gtolib.api.ae2.me2in1;

import appeng.menu.SlotSemantic;
import appeng.menu.SlotSemantics;

public class GTOSlotSemantics {
    public static final SlotSemantic BATCH_FILTER = SlotSemantics.register("GTO_BATCH_FILTER", false);
    public static final SlotSemantic BATCH_PINPUT = SlotSemantics.register("GTO_BATCH_PINPUT", false);
    public static final SlotSemantic BATCH_POUTPUT = SlotSemantics.register("GTO_BATCH_POUTPUT", false);
}

package com.gtolib.api.ae2.me2in1;

import appeng.api.behaviors.ContainerItemStrategies;
import appeng.api.behaviors.EmptyingAction;
import appeng.api.config.Actionable;
import appeng.api.config.Setting;
import appeng.api.config.Settings;
import appeng.api.config.SortDir;
import appeng.api.config.SortOrder;
import appeng.api.config.TypeFilter;
import appeng.api.config.ViewItems;
import appeng.api.inventories.InternalInventory;
import appeng.api.networking.IGridNode;
import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import appeng.api.util.IConfigManager;
import appeng.api.util.IConfigurableObject;
import appeng.client.Point;
import appeng.client.gui.me.patternaccess.PatternSlot;
import appeng.client.gui.widgets.ISortSource;
import appeng.helpers.IMenuCraftingPacket;
import appeng.helpers.InventoryAction;
import appeng.helpers.externalstorage.GenericStackInv;
import appeng.menu.SlotSemantic;
import appeng.menu.guisync.GuiSync;
import appeng.menu.implementations.MenuTypeBuilder;
import appeng.menu.locator.MenuLocator;
import appeng.menu.me.common.IMEInteractionHandler;
import appeng.menu.slot.AppEngSlot;
import appeng.menu.slot.CraftingTermSlot;
import appeng.menu.slot.FakeSlot;
import appeng.util.ConfigMenuInventory;
import com.glodblock.github.extendedae.container.ContainerExPatternTerminal;
import com.gtocore.integration.ae.client.PanelMapPosSyncable;
import com.gtolib.ae2.me2in1.panel.PanelPosMap;
import com.gtolib.ae2.me2in1.panel.d;
import com.gtolib.api.ae2.GTOSettings;
import com.gtolib.api.ae2.IPatterEncodingTermMenu;
import com.gtolib.api.ae2.ShiftTransferTo;
import com.gtolib.api.ae2.gui.hooks.IExtendedGuiEx;
import com.gtolib.api.ae2.me2in1.ExtendedEncodingMenu;
import com.gtolib.api.ae2.me2in1.IExtendedPatternMenuHost;
import com.gtolib.api.ae2.me2in1.SeenProviderSlots;
import java.util.Collection;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class Me2in1Menu
extends ContainerExPatternTerminal
implements IConfigurableObject,
ISortSource,
IMenuCraftingPacket,
IMEInteractionHandler,
IPatterEncodingTermMenu {
    private static final String RECORD_PANEL_POS = "recordPanelPos";
    public static final MenuType<Me2in1Menu> TYPE = MenuTypeBuilder.create(Me2in1Menu::new, IExtendedPatternMenuHost.class).build("me2in1");
    private final ExtendedEncodingMenu encoding;
    private final IExtendedPatternMenuHost host;
    private IExtendedGuiEx screen;
    @GuiSync(value=79)
    public ShiftTransferTo shiftTransferTo = ShiftTransferTo.INVENTORY_OR_BUFFER;
    @GuiSync(value=78)
    public SortOrder sortBy = SortOrder.NAME;
    @GuiSync(value=77)
    public SortDir sortDir = SortDir.ASCENDING;
    @GuiSync(value=76)
    public ViewItems sortDisplay = ViewItems.ALL;
    @GuiSync(value=75)
    public TypeFilter typeFilter = TypeFilter.ALL;
    @GuiSync(value=74)
    public PanelMapPosSyncable panelPosMap;
    private Runnable posSyncedListener;

    public Me2in1Menu(int n, Inventory inventory, IExtendedPatternMenuHost iExtendedPatternMenuHost) {
        this(TYPE, n, inventory, iExtendedPatternMenuHost, true);
    }

    public Me2in1Menu(MenuType<?> menuType, int n, Inventory inventory, IExtendedPatternMenuHost iExtendedPatternMenuHost, boolean bl) {
        super(menuType, n, inventory, iExtendedPatternMenuHost, bl);
        this.encoding = new ExtendedEncodingMenu(this, n, inventory, iExtendedPatternMenuHost, false);
        this.host = iExtendedPatternMenuHost;
        this.registerClientAction(RECORD_PANEL_POS, PanelPosMap.a.class, this::updateC2SPanelPos);
    }

    @Override
    public void setLocator(MenuLocator menuLocator) {
        super.setLocator(menuLocator);
        this.encoding.setLocator(menuLocator);
    }

    public ExtendedEncodingMenu getEncoding() {
        return this.encoding;
    }

    @Override
    public Slot addSlot(Slot slot, SlotSemantic slotSemantic) {
        return super.addSlot(slot, slotSemantic);
    }

    @Override
    public void m_182406_(int n, int n2, @NotNull ItemStack itemStack) {
        super.m_182406_(n, n2, itemStack);
        this.encoding.m_182406_(n, n2, itemStack);
    }

    public void updateC2SPanelPos(PanelPosMap.a a2) {
        if (this.isClientSide()) {
            this.sendClientAction(RECORD_PANEL_POS, a2);
        }
        this.host.getLogic().updatePanelPos(a2);
        this.m_38946_();
    }

    public void updateC2SPanelPos(d d2) {
        this.updateC2SPanelPos(new PanelPosMap.a(d2.f(), d2.g(), d2.h()));
    }

    public void receiveS2CPanelUpdate(d d2) {
        java.awt.Point point = this.panelPosMap.map().getPanelPos(d2.f());
        if (point != null) {
            d2.setPosition(new Point(point.x, point.y));
        }
    }

    @Override
    public void m_38946_() {
        if (this.isClientSide()) {
            return;
        }
        this.shiftTransferTo = (ShiftTransferTo)this.host.getConfigManager().getSetting(GTOSettings.ME2IN1_SHIFT_TRANSFER_TO);
        this.sortBy = (SortOrder)this.host.getConfigManager().getSetting(Settings.SORT_BY);
        this.sortDir = (SortDir)this.host.getConfigManager().getSetting(Settings.SORT_DIRECTION);
        this.sortDisplay = (ViewItems)this.host.getConfigManager().getSetting(Settings.VIEW_MODE);
        this.typeFilter = (TypeFilter)this.host.getConfigManager().getSetting(Settings.TYPE_FILTER);
        this.panelPosMap = this.host.getLogic().getPanelPosMap().syncable();
        super.m_38946_();
        this.encoding.m_38946_();
    }

    public SeenProviderSlots getVisibleEmptyPatternSlots() {
        return this.f_38839_.stream().filter(PatternSlot.class::isInstance).map(PatternSlot.class::cast).filter(patternSlot -> !patternSlot.m_6657_() && patternSlot.m_6659_()).collect(SeenProviderSlots::new, SeenProviderSlots::add, SeenProviderSlots::combine);
    }

    @Override
    public void onServerDataSync() {
        super.onServerDataSync();
        this.encoding.onServerDataSync();
        for (Setting setting : this.getConfigManager().getSettings()) {
            setting.copy(this.getEncoding().getConfigManager(), this.getConfigManager());
        }
        this.encoding.onSettingChanged(this.getConfigManager(), GTOSettings.ME2IN1_SHIFT_TRANSFER_TO);
        this.sendSubmenuAction("clearUsedVisibleSlot");
        if (this.posSyncedListener != null) {
            this.posSyncedListener.run();
        }
    }

    @Override
    public void onSlotChange(Slot slot) {
        super.onSlotChange(slot);
        this.encoding.onSlotChange(slot);
    }

    protected ItemStack transferStackToMenu(ItemStack itemStack) {
        return this.encoding.transferStackToMenu(itemStack);
    }

    public void registerSubmenuAction(String string, Runnable runnable) {
        this.registerClientAction(string, runnable);
    }

    public <T> void registerSubmenuAction(String string, Class<T> clazz, Consumer<T> consumer) {
        this.registerClientAction(string, clazz, consumer);
    }

    public void sendSubmenuAction(String string) {
        this.sendClientAction(string, null);
    }

    public <T> void sendSubmenuAction(String string, T t) {
        this.sendClientAction(string, t);
    }

    public IExtendedPatternMenuHost getHost() {
        return this.host;
    }

    @Nullable
    public IGridNode getNetworkNode() {
        return this.getHost().getActionableNode();
    }

    public InternalInventory getCraftingMatrix() {
        return this.getEncoding().getCraftingMatrix();
    }

    public boolean useRealItems() {
        return false;
    }

    public List<ItemStack> getViewCells() {
        return List.of();
    }

    public void handleInteraction(long l, InventoryAction inventoryAction) {
        this.getEncoding().handleInteraction(l, inventoryAction);
    }

    public void doPatternAction(ServerPlayer serverPlayer, InventoryAction inventoryAction, int n, long l) {
        super.doAction(serverPlayer, inventoryAction, n, l);
    }

    @Override
    public void doAction(ServerPlayer serverPlayer, InventoryAction inventoryAction, int n, long l) {
        Object object;
        Object object2;
        Object object3;
        if (n >= this.f_38839_.size()) {
            return;
        }
        if (n < 0) {
            super.doAction(serverPlayer, inventoryAction, -n, l);
            return;
        }
        Slot slot = this.m_38853_(n);
        if (slot instanceof CraftingTermSlot) {
            object3 = (CraftingTermSlot)((Object)slot);
            switch (inventoryAction) {
                case CRAFT_SHIFT: 
                case CRAFT_ALL: 
                case CRAFT_ITEM: 
                case CRAFT_STACK: {
                    ((CraftingTermSlot)object3).doClick(inventoryAction, serverPlayer);
                }
            }
        }
        if (slot instanceof FakeSlot) {
            object3 = (FakeSlot)slot;
            this.handleFakeSlotAction((FakeSlot)object3, inventoryAction);
            return;
        }
        if (slot instanceof AppEngSlot && (object2 = ((AppEngSlot)(object3 = (AppEngSlot)((Object)slot))).getInventory()) instanceof ConfigMenuInventory && ((ConfigMenuInventory)(object = (ConfigMenuInventory)object2)).getDelegate().getMode() == GenericStackInv.Mode.STORAGE) {
            object2 = ((ConfigMenuInventory)object).getDelegate();
            int n2 = ((AppEngSlot)object3).getSlotIndex();
            if (inventoryAction == InventoryAction.FILL_ITEM) {
                AEKey aEKey = ((GenericStackInv)object2).getKey(n2);
                this.handleFillingHeldItem((arg_0, arg_1) -> Me2in1Menu.lambda$doAction$1((GenericStackInv)object2, n2, aEKey, arg_0, arg_1), aEKey);
            } else if (inventoryAction == InventoryAction.EMPTY_ITEM) {
                this.handleEmptyHeldItem((arg_0, arg_1, arg_2) -> Me2in1Menu.lambda$doAction$2((GenericStackInv)object2, n2, arg_0, arg_1, arg_2));
            }
        }
        if (inventoryAction == InventoryAction.MOVE_REGION) {
            object3 = this.getSlotSemantic(slot);
            if (object3 != null) {
                object = List.copyOf((Collection)this.getSlots((SlotSemantic)object3));
                object2 = object.iterator();
                while (object2.hasNext()) {
                    Slot slot2 = (Slot)object2.next();
                    this.m_7648_(serverPlayer, slot2.f_40219_);
                }
            } else {
                this.m_7648_(serverPlayer, slot.f_40219_);
            }
        }
        super.doAction(serverPlayer, inventoryAction, n, l);
    }

    private void handleFakeSlotAction(FakeSlot fakeSlot, InventoryAction inventoryAction) {
        ItemStack itemStack = this.m_142621_();
        switch (inventoryAction) {
            case PICKUP_OR_SET_DOWN: {
                fakeSlot.increase(itemStack);
                break;
            }
            case PLACE_SINGLE: {
                if (itemStack.m_41619_()) break;
                ItemStack itemStack2 = itemStack.m_41777_();
                itemStack2.m_41764_(1);
                fakeSlot.increase(itemStack2);
                break;
            }
            case SPLIT_OR_PLACE_SINGLE: {
                ItemStack itemStack3 = fakeSlot.m_7993_();
                if (!itemStack3.m_41619_()) {
                    fakeSlot.decrease(itemStack);
                    break;
                }
                if (itemStack.m_41619_()) break;
                itemStack3 = itemStack.m_41777_();
                itemStack3.m_41764_(1);
                fakeSlot.m_5852_(itemStack3);
                break;
            }
            case EMPTY_ITEM: {
                EmptyingAction emptyingAction = ContainerItemStrategies.getEmptyingAction(itemStack);
                if (emptyingAction == null) break;
                fakeSlot.m_5852_(GenericStack.wrapInItemStack(emptyingAction.what(), emptyingAction.maxAmount()));
                break;
            }
        }
    }

    @Override
    @NotNull
    public ItemStack m_7648_(Player player, int n) {
        return super.m_7648_(player, n);
    }

    public void quickMoveToProvider(int n) {
        SeenProviderSlots seenProviderSlots = this.getVisibleEmptyPatternSlots();
        this.encoding.quickMoveToProvider(new ExtendedEncodingMenu.SeenProviderSlotsWithSlotId(seenProviderSlots, n));
    }

    @Override
    public void gtolib$modifyPatter(Integer n) {
        this.getEncoding().gtolib$modifyPatter(n);
    }

    @Override
    public void gtolib$clearSecOutput() {
        this.getEncoding().gtolib$clearSecOutput();
    }

    @Override
    public void gtolib$addRecipe(String string) {
        this.getEncoding().gtolib$addRecipe(string);
    }

    public IConfigManager getConfigManager() {
        return this.host.getConfigManager();
    }

    public ShiftTransferTo getShiftTransferTo() {
        return this.shiftTransferTo;
    }

    public SortOrder getSortBy() {
        return this.sortBy;
    }

    public SortDir getSortDir() {
        return this.sortDir;
    }

    public ViewItems getSortDisplay() {
        return this.sortDisplay;
    }

    public TypeFilter getTypeFilter() {
        return this.typeFilter;
    }

    public void setPosSyncedListener(Runnable runnable) {
        this.posSyncedListener = runnable;
    }

    public IExtendedGuiEx getScreen() {
        return this.screen;
    }

    public void setScreen(IExtendedGuiEx iExtendedGuiEx) {
        this.screen = iExtendedGuiEx;
    }

    private static long lambda$doAction$2(GenericStackInv genericStackInv, int n, AEKey aEKey, long l, Actionable actionable) {
        return genericStackInv.insert(n, aEKey, l, actionable);
    }

    private static long lambda$doAction$1(GenericStackInv genericStackInv, int n, AEKey aEKey, long l, Actionable actionable) {
        return genericStackInv.extract(n, aEKey, l, actionable);
    }
}

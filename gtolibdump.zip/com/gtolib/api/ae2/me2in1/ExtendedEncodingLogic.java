package com.gtolib.api.ae2.me2in1;

import appeng.api.crafting.IPatternDetails;
import appeng.api.crafting.PatternDetailsHelper;
import appeng.api.inventories.InternalInventory;
import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.GenericStack;
import appeng.crafting.pattern.AECraftingPattern;
import appeng.crafting.pattern.AEProcessingPattern;
import appeng.crafting.pattern.AESmithingTablePattern;
import appeng.crafting.pattern.AEStonecuttingPattern;
import appeng.util.ConfigInventory;
import appeng.util.inv.AppEngInternalInventory;
import appeng.util.inv.InternalInventoryHost;
import com.gtolib.ae2.me2in1.a;
import com.gtolib.ae2.me2in1.panel.PanelPosMap;
import com.gtolib.api.ae2.me2in1.MaterialConfigInventory;
import com.gtolib.api.ae2.me2in1.encoding.ExtendedEncodingMode;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

public class ExtendedEncodingLogic
implements InternalInventoryHost {
    private final a host;
    private static final int MAX_INPUT_SLOTS = Math.max(9, 81);
    private static final int MAX_OUTPUT_SLOTS = 27;
    private final ConfigInventory encodedInputInv = ConfigInventory.configStacks(null, MAX_INPUT_SLOTS, this::onEncodedInputChanged, true);
    private final ConfigInventory encodedOutputInv = ConfigInventory.configStacks(null, 27, this::onEncodedOutputChanged, true);
    private final MaterialConfigInventory materialInv = MaterialConfigInventory.create(9, this::onEncodedInputChanged);
    private final AppEngInternalInventory encodedPatternInv = new AppEngInternalInventory(this, 36);
    private ExtendedEncodingMode mode = ExtendedEncodingMode.CRAFTING;
    private boolean substitute = false;
    private boolean substituteFluids = true;
    private boolean autoEncodeRenamePatterns = false;
    private boolean autoSearchProviders = false;
    private boolean isLoading = false;
    private boolean isEncoding = false;
    @Nullable
    private ResourceLocation stonecuttingRecipeId;
    private final PanelPosMap panelPosMap = new PanelPosMap();

    public ExtendedEncodingLogic(a a2) {
        this.host = a2;
    }

    public void onChangeInventory(InternalInventory internalInventory, int n) {
        if (internalInventory == this.encodedPatternInv && !this.isLoading && !this.isEncoding) {
            this.loadEncodedPattern(this.encodedPatternInv.getStackInSlot(n));
        }
        this.saveChanges();
    }

    public void saveChanges() {
        if (!this.isLoading) {
            this.host.markForSave();
        }
    }

    public boolean isClientSide() {
        return this.host.getLevel().m_5776_();
    }

    private void onEncodedInputChanged() {
        this.fixCraftingRecipes();
        this.saveChanges();
    }

    private void onEncodedOutputChanged() {
        this.saveChanges();
    }

    private void loadEncodedPattern(ItemStack itemStack) {
        if (itemStack.m_41619_()) {
            return;
        }
        IPatternDetails iPatternDetails = PatternDetailsHelper.decodePattern(itemStack, this.host.getLevel());
        if (iPatternDetails instanceof AECraftingPattern) {
            AECraftingPattern aECraftingPattern = (AECraftingPattern)((Object)iPatternDetails);
            this.loadCraftingPattern(aECraftingPattern);
        } else if (iPatternDetails instanceof AEProcessingPattern) {
            AEProcessingPattern aEProcessingPattern = (AEProcessingPattern)iPatternDetails;
            this.loadProcessingPattern(aEProcessingPattern);
        } else if (iPatternDetails instanceof AESmithingTablePattern) {
            AESmithingTablePattern aESmithingTablePattern = (AESmithingTablePattern)((Object)iPatternDetails);
            this.loadSmithingTablePattern(aESmithingTablePattern);
        } else if (iPatternDetails instanceof AEStonecuttingPattern) {
            AEStonecuttingPattern aEStonecuttingPattern = (AEStonecuttingPattern)((Object)iPatternDetails);
            this.loadStonecuttingPattern(aEStonecuttingPattern);
        }
        this.saveChanges();
    }

    private void loadCraftingPattern(AECraftingPattern aECraftingPattern) {
        this.setMode(ExtendedEncodingMode.CRAFTING);
        this.substitute = aECraftingPattern.canSubstitute();
        this.substituteFluids = aECraftingPattern.canSubstituteFluids();
        ExtendedEncodingLogic.fillInventoryFromSparseStacks(this.encodedInputInv, aECraftingPattern.getSparseInputs());
        ExtendedEncodingLogic.fillInventoryFromSparseStacks(this.encodedOutputInv, aECraftingPattern.getSparseOutputs());
    }

    private void loadProcessingPattern(AEProcessingPattern aEProcessingPattern) {
        if (this.getMode() != ExtendedEncodingMode.BATCH) {
            this.setMode(ExtendedEncodingMode.PROCESSING);
        }
        ExtendedEncodingLogic.fillInventoryFromSparseStacks(this.encodedInputInv, aEProcessingPattern.getSparseInputs());
        ExtendedEncodingLogic.fillInventoryFromSparseStacks(this.encodedOutputInv, aEProcessingPattern.getSparseOutputs());
    }

    private void loadSmithingTablePattern(AESmithingTablePattern aESmithingTablePattern) {
        this.setMode(ExtendedEncodingMode.SMITHING_TABLE);
        this.substitute = aESmithingTablePattern.canSubstitute();
        this.encodedInputInv.clear();
        this.encodedInputInv.setStack(0, new GenericStack(aESmithingTablePattern.getTemplate(), 1L));
        this.encodedInputInv.setStack(1, new GenericStack(aESmithingTablePattern.getBase(), 1L));
        this.encodedInputInv.setStack(2, new GenericStack(aESmithingTablePattern.getAddition(), 1L));
        this.encodedOutputInv.clear();
    }

    private void loadStonecuttingPattern(AEStonecuttingPattern aEStonecuttingPattern) {
        this.setMode(ExtendedEncodingMode.STONECUTTING);
        this.stonecuttingRecipeId = aEStonecuttingPattern.getRecipeId();
        this.substitute = aEStonecuttingPattern.canSubstitute;
        this.encodedInputInv.clear();
        this.encodedInputInv.setStack(0, new GenericStack(aEStonecuttingPattern.getInput(), 1L));
        this.encodedOutputInv.clear();
    }

    private static void fillInventoryFromSparseStacks(ConfigInventory configInventory, GenericStack[] genericStackArray) {
        configInventory.beginBatch();
        try {
            for (int i = 0; i < configInventory.size(); ++i) {
                configInventory.setStack(i, i < genericStackArray.length ? genericStackArray[i] : null);
            }
        }
        finally {
            configInventory.endBatch();
        }
    }

    public ExtendedEncodingMode getMode() {
        return this.mode;
    }

    public void setMode(ExtendedEncodingMode extendedEncodingMode) {
        this.mode = extendedEncodingMode;
        this.fixCraftingRecipes();
        this.saveChanges();
    }

    public boolean isSubstitution() {
        return this.substitute;
    }

    public void setSubstitution(boolean bl) {
        this.substitute = bl;
        this.saveChanges();
    }

    public boolean isFluidSubstitution() {
        return this.substituteFluids;
    }

    public void setEncoding(boolean bl) {
        this.isEncoding = bl;
    }

    public void setFluidSubstitution(boolean bl) {
        this.substituteFluids = bl;
        this.saveChanges();
    }

    @Nullable
    public ResourceLocation getStonecuttingRecipeId() {
        return this.stonecuttingRecipeId;
    }

    public void setStonecuttingRecipeId(ResourceLocation resourceLocation) {
        this.stonecuttingRecipeId = resourceLocation;
        this.saveChanges();
    }

    public ConfigInventory getEncodedInputInv() {
        return this.encodedInputInv;
    }

    public ConfigInventory getEncodedOutputInv() {
        return this.encodedOutputInv;
    }

    public InternalInventory getEncodedPatternInv() {
        return this.encodedPatternInv;
    }

    public PanelPosMap getPanelPosMap() {
        return this.panelPosMap;
    }

    public void readFromNBT(CompoundTag compoundTag) {
        this.isLoading = true;
        try {
            try {
                this.mode = ExtendedEncodingMode.valueOf(compoundTag.m_128461_("mode"));
            }
            catch (IllegalArgumentException illegalArgumentException) {
                this.mode = ExtendedEncodingMode.CRAFTING;
            }
            this.setSubstitution(compoundTag.m_128471_("substitute"));
            this.setFluidSubstitution(compoundTag.m_128471_("substituteFluids"));
            this.setAutoEncodeRenamePatterns(compoundTag.m_128471_("autoEncodeRenamePatterns"));
            this.setAutoSearchProviders(compoundTag.m_128471_("autoSearchProviders"));
            this.stonecuttingRecipeId = compoundTag.m_128425_("stonecuttingRecipeId", 8) ? ResourceLocation.parse(compoundTag.m_128461_("stonecuttingRecipeId")) : null;
            this.encodedPatternInv.readFromNBT(compoundTag, "encodedPattern");
            this.encodedInputInv.readFromChildTag(compoundTag, "encodedInputs");
            this.encodedOutputInv.readFromChildTag(compoundTag, "encodedOutputs");
            this.materialInv.readFromChildTag(compoundTag, "materialInv");
            this.panelPosMap.readFromNbt(compoundTag, "panelPosMap");
        }
        finally {
            this.isLoading = false;
        }
    }

    public void writeToNBT(CompoundTag compoundTag) {
        compoundTag.m_128359_("mode", this.mode.name());
        compoundTag.m_128379_("substitute", this.substitute);
        compoundTag.m_128379_("substituteFluids", this.substituteFluids);
        compoundTag.m_128379_("autoEncodeRenamePatterns", this.autoEncodeRenamePatterns);
        compoundTag.m_128379_("autoSearchProviders", this.autoSearchProviders);
        if (this.stonecuttingRecipeId != null) {
            compoundTag.m_128359_("stonecuttingRecipeId", this.stonecuttingRecipeId.toString());
        }
        this.encodedPatternInv.writeToNBT(compoundTag, "encodedPattern");
        this.encodedInputInv.writeToChildTag(compoundTag, "encodedInputs");
        this.encodedOutputInv.writeToChildTag(compoundTag, "encodedOutputs");
        this.materialInv.writeToChildTag(compoundTag, "materialInv");
        this.panelPosMap.writeToNbt(compoundTag, "panelPosMap");
    }

    private void fixCraftingRecipes() {
        if (this.host.getLevel() == null || this.host.getLevel().m_5776_()) {
            return;
        }
        if (this.getMode().certernRecipe) {
            ConfigInventory configInventory = this.getEncodedInputInv();
            for (int i = 0; i < configInventory.size(); ++i) {
                GenericStack genericStack = configInventory.getStack(i);
                if (genericStack == null) continue;
                if (!AEItemKey.is(genericStack.what())) {
                    configInventory.setStack(i, null);
                    continue;
                }
                if (genericStack.amount() == 1L) continue;
                configInventory.setStack(i, new GenericStack(genericStack.what(), 1L));
            }
        }
    }

    public MaterialConfigInventory getMaterialInv() {
        return this.materialInv;
    }

    public void updatePanelPos(PanelPosMap.a a2) {
        this.panelPosMap.updatePanelPos(a2);
        this.saveChanges();
    }

    public boolean isAutoEncodeRenamePatterns() {
        return this.autoEncodeRenamePatterns;
    }

    public void setAutoEncodeRenamePatterns(boolean bl) {
        this.autoEncodeRenamePatterns = bl;
    }

    public void setAutoSearchProviders(Boolean bl) {
        this.autoSearchProviders = bl;
    }

    public boolean isAutoSearchProviders() {
        return this.autoSearchProviders;
    }
}

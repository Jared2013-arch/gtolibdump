package com.gtolib.api.ae2.me2in1;

import appeng.client.gui.style.ScreenStyle;
import com.gtolib.api.ae2.gui.widgets.AESlotWidget;
import com.gtolib.api.ae2.me2in1.Me2in1Screen;
import com.gtolib.api.ae2.me2in1.UtilsMiscs;
import com.gtolib.api.ae2.me2in1.Wireless;
import de.mari_023.ae2wtlib.wut.CycleTerminalButton;
import de.mari_023.ae2wtlib.wut.IUniversalTerminalCapable;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

public class Wireless$Screen
extends Me2in1Screen<Wireless>
implements IUniversalTerminalCapable {
    public Wireless$Screen(Wireless wireless, Inventory inventory, Component component, ScreenStyle screenStyle) {
        super(wireless, inventory, component, screenStyle);
        if (((Wireless)this.m_6262_()).isWUT()) {
            this.addToLeftToolbar(new CycleTerminalButton(button -> this.cycleTerminal()));
        }
        this.widgets.add("quantumSlot", new AESlotWidget(wireless.singularitySlot, this));
        wireless.singularitySlot.setEmptyTooltip(() -> List.of((Object)Component.m_237115_("gtocore.ae.appeng.me2in1.quantum_bridge"), (Object)Component.m_237115_("gtocore.ae.appeng.me2in1.quantum_bridge.info")));
    }

    @Override
    public void updateBeforeRender() {
        super.updateBeforeRender();
        UtilsMiscs.setSlotPos(((Wireless)this.f_97732_).singularitySlot, 140, 8);
    }
}

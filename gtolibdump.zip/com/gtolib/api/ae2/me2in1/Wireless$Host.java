package com.gtolib.api.ae2.me2in1;

import appeng.menu.ISubMenu;
import com.gtocore.common.data.GTOItems;
import com.gtolib.ae2.me2in1.a;
import com.gtolib.api.ae2.me2in1.ExtendedEncodingLogic;
import de.mari_023.ae2wtlib.terminal.WTMenuHost;
import java.util.function.BiConsumer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class Wireless$Host
extends WTMenuHost
implements a {
    private final ExtendedEncodingLogic logic = new ExtendedEncodingLogic(this);

    public Wireless$Host(Player player, @Nullable Integer n, ItemStack itemStack, BiConsumer<Player, ISubMenu> biConsumer) {
        super(player, n, itemStack, biConsumer);
        this.readFromNbt();
    }

    public ItemStack getMainMenuIcon() {
        return GTOItems.WIRELESS_ME2IN1.asStack();
    }

    protected void readFromNbt() {
        super.readFromNbt();
        this.logic.readFromNBT(this.getItemStack().m_41784_());
    }

    public void saveChanges() {
        super.saveChanges();
        this.logic.writeToNBT(this.getItemStack().m_41784_());
    }

    @Override
    public ExtendedEncodingLogic getLogic() {
        return this.logic;
    }

    @Override
    public Level getLevel() {
        return this.getPlayer().m_9236_();
    }

    @Override
    public void markForSave() {
        this.saveChanges();
    }
}

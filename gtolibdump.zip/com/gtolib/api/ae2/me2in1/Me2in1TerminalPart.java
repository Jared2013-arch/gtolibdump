package com.gtolib.api.ae2.me2in1;

import appeng.api.config.Settings;
import appeng.api.config.ShowPatternProviders;
import appeng.api.config.SortDir;
import appeng.api.config.SortOrder;
import appeng.api.config.TypeFilter;
import appeng.api.config.ViewItems;
import appeng.api.inventories.InternalInventory;
import appeng.api.networking.IGrid;
import appeng.api.parts.IPartItem;
import appeng.api.parts.IPartModel;
import appeng.api.storage.MEStorage;
import appeng.menu.ISubMenu;
import appeng.menu.MenuOpener;
import appeng.menu.locator.MenuLocators;
import appeng.parts.PartModel;
import appeng.util.ConfigManager;
import appeng.util.inv.AppEngInternalInventory;
import com.glodblock.github.extendedae.common.parts.PartExPatternAccessTerminal;
import com.gtolib.GTOCore;
import com.gtolib.ae2.me2in1.a;
import com.gtolib.api.ae2.GTOSettings;
import com.gtolib.api.ae2.ShiftTransferTo;
import com.gtolib.api.ae2.ShowMolecularAssembler;
import com.gtolib.api.ae2.me2in1.ExtendedEncodingLogic;
import com.gtolib.api.ae2.me2in1.Me2in1Menu;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public class Me2in1TerminalPart
extends PartExPatternAccessTerminal
implements a {
    public static List<ResourceLocation> MODELS = Arrays.asList(GTOCore.id("part/me2in1_off"), GTOCore.id("part/me2in1_on"));
    public static final IPartModel MODELS_OFF = new PartModel(new ResourceLocation[]{MODEL_BASE, MODELS.get(0), MODEL_STATUS_OFF});
    public static final IPartModel MODELS_ON = new PartModel(new ResourceLocation[]{MODEL_BASE, MODELS.get(1), MODEL_STATUS_ON});
    public static final IPartModel MODELS_HAS_CHANNEL = new PartModel(new ResourceLocation[]{MODEL_BASE, MODELS.get(1), MODEL_STATUS_HAS_CHANNEL});
    private final ExtendedEncodingLogic logic = new ExtendedEncodingLogic(this);
    private final AppEngInternalInventory viewCell = new AppEngInternalInventory(this, 5);
    private final ConfigManager configManager = new ConfigManager(this::saveChanges);

    public Me2in1TerminalPart(IPartItem<?> iPartItem) {
        super(iPartItem);
        this.configManager.registerSetting(Settings.SORT_BY, SortOrder.NAME);
        this.configManager.registerSetting(Settings.VIEW_MODE, ViewItems.ALL);
        this.configManager.registerSetting(Settings.TYPE_FILTER, TypeFilter.ALL);
        this.configManager.registerSetting(Settings.SORT_DIRECTION, SortDir.ASCENDING);
        this.configManager.registerSetting(Settings.TERMINAL_SHOW_PATTERN_PROVIDERS, ShowPatternProviders.VISIBLE);
        this.configManager.registerSetting(GTOSettings.TERMINAL_SHOW_MOLECULAR_ASSEMBLERS, ShowMolecularAssembler.ALL);
        this.configManager.registerSetting(GTOSettings.ME2IN1_SHIFT_TRANSFER_TO, ShiftTransferTo.INVENTORY_OR_BUFFER);
    }

    @Override
    public ExtendedEncodingLogic getLogic() {
        return this.logic;
    }

    @Override
    public MEStorage getInventory() {
        IGrid iGrid = this.getMainNode().getGrid();
        if (iGrid != null) {
            return iGrid.getStorageService().getInventory();
        }
        return null;
    }

    @Override
    public ConfigManager getConfigManager() {
        return this.configManager;
    }

    public ItemStack getMainMenuIcon() {
        return this.getPartItem().m_5456_().m_7968_();
    }

    public InternalInventory getViewCellStorage() {
        return this.viewCell;
    }

    public void saveChanges() {
        this.getHost().markForSave();
    }

    public void onChangeInventory(InternalInventory internalInventory, int n) {
        this.getHost().markForSave();
    }

    @Override
    public void m_6211_() {
        super.m_6211_();
        this.viewCell.clear();
        this.logic.getEncodedPatternInv().clear();
    }

    @Override
    public void readFromNBT(CompoundTag compoundTag) {
        super.readFromNBT(compoundTag);
        this.configManager.readFromNBT(compoundTag);
        this.viewCell.readFromNBT(compoundTag, "viewCell");
        this.logic.readFromNBT(compoundTag);
    }

    @Override
    public void writeToNBT(CompoundTag compoundTag) {
        super.writeToNBT(compoundTag);
        this.configManager.writeToNBT(compoundTag);
        this.viewCell.writeToNBT(compoundTag, "viewCell");
        this.logic.writeToNBT(compoundTag);
    }

    public void addAdditionalDrops(List<ItemStack> list, boolean bl) {
        super.addAdditionalDrops(list, bl);
        Iterator iterator = this.logic.getEncodedPatternInv().iterator();
        while (iterator.hasNext()) {
            ItemStack itemStack = (ItemStack)iterator.next();
            list.add(itemStack);
        }
    }

    @Override
    public void markForSave() {
        this.getHost().markForSave();
    }

    public MenuType<?> getMenuType(Player player) {
        return Me2in1Menu.TYPE;
    }

    public boolean onPartActivate(Player player, InteractionHand interactionHand, Vec3 vec3) {
        if (!player.m_9236_().f_46443_) {
            MenuOpener.open(this.getMenuType(player), player, MenuLocators.forPart(this));
        }
        return true;
    }

    public void returnToMainMenu(Player player, ISubMenu iSubMenu) {
        MenuOpener.open(this.getMenuType(player), player, iSubMenu.getLocator(), true);
    }

    public IPartModel getStaticModels() {
        return this.selectModel(MODELS_OFF, MODELS_ON, MODELS_HAS_CHANNEL);
    }
}

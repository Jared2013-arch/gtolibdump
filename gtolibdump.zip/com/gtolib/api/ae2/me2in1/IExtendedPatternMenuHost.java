package com.gtolib.api.ae2.me2in1;

import appeng.api.networking.security.IActionHost;
import appeng.api.storage.ITerminalHost;
import com.gtolib.api.ae2.me2in1.ExtendedEncodingLogic;

public interface IExtendedPatternMenuHost
extends IActionHost,
ITerminalHost {
    public ExtendedEncodingLogic getLogic();
}

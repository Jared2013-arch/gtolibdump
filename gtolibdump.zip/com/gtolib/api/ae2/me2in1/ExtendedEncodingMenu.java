package com.gtolib.api.ae2.me2in1;

import appeng.api.config.Actionable;
import appeng.api.config.Settings;
import appeng.api.config.ShowPatternProviders;
import appeng.api.crafting.IPatternDetails;
import appeng.api.crafting.PatternDetailsHelper;
import appeng.api.inventories.InternalInventory;
import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import appeng.client.gui.Icon;
import appeng.client.gui.me.common.Repo;
import appeng.core.definitions.AEItems;
import appeng.crafting.pattern.AECraftingPattern;
import appeng.helpers.IMenuCraftingPacket;
import appeng.helpers.InventoryAction;
import appeng.menu.SlotSemantics;
import appeng.menu.guisync.GuiSync;
import appeng.menu.me.common.MEStorageMenu;
import appeng.menu.slot.FakeSlot;
import appeng.menu.slot.PatternTermSlot;
import appeng.menu.slot.RestrictedInputSlot;
import appeng.util.ConfigInventory;
import appeng.util.ConfigMenuInventory;
import com.google.common.base.Preconditions;
import com.gregtechceu.gtceu.api.data.chemical.material.Material;
import com.gtocore.config.GTOConfig;
import com.gtocore.mixin.ae2.menu.MEStorageMenuAccessor;
import com.gtolib.GTOCore;
import com.gtolib.ae2.me2in1.b;
import com.gtolib.api.ae2.GTOSettings;
import com.gtolib.api.ae2.ShiftTransferTo;
import com.gtolib.api.ae2.ShowMolecularAssembler;
import com.gtolib.api.ae2.me2in1.ExtendedEncodingLogic;
import com.gtolib.api.ae2.me2in1.GTOSlotSemantics;
import com.gtolib.api.ae2.me2in1.IExtendedPatternMenuHost;
import com.gtolib.api.ae2.me2in1.MaterialConfigInventory;
import com.gtolib.api.ae2.me2in1.Me2in1Menu;
import com.gtolib.api.ae2.me2in1.SeenProviderSlots;
import com.gtolib.api.ae2.me2in1.encoding.ExtendedEncodingMode;
import com.gtolib.api.ae2.pattern.GridPatternsRemover;
import com.gtolib.api.ae2.pattern.PatternUtils;
import com.gtolib.utils.AEChemicalHelper;
import com.mojang.datafixers.util.Pair;
import it.unimi.dsi.fastutil.ints.IntArraySet;
import it.unimi.dsi.fastutil.ints.IntIterator;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.ints.IntSet;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.TransientCraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SmithingRecipe;
import net.minecraft.world.item.crafting.StonecutterRecipe;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Unique;

public class ExtendedEncodingMenu
extends MEStorageMenu
implements IMenuCraftingPacket,
b {
    private static final int CRAFTING_GRID_WIDTH = 3;
    private static final int CRAFTING_GRID_HEIGHT = 3;
    private static final int CRAFTING_GRID_SLOTS = 9;
    private static final String ACTION_SET_MODE = "setMode";
    private static final String ACTION_ENCODE = "encode";
    private static final String ACTION_ENCODING_TO_PROVIDER = "encodingToProvider";
    private static final String ACTION_QUICK_MOVE_TO_PROVIDER = "quickMoveToProvider";
    private static final String ACTION_CLEAR = "clear";
    private static final String ACTION_MODIFY_PATTER = "modifyPatter";
    private static final String ACTION_CLEAR_FILTER = "clearFilter";
    private static final String ACTION_CLEAR_PATTERN = "clearPattern";
    private static final String ACTION_SET_SUBSTITUTION = "setSubstitution";
    private static final String ACTION_SET_FLUID_SUBSTITUTION = "setFluidSubstitution";
    private static final String ACTION_SET_AUTO_RENAMING = "setAutoRenaming";
    private static final String ACTION_SET_AUTO_SEARCH_PROVIDERS = "setAutoSearchProviders";
    private static final String ACTION_SET_STONECUTTING_RECIPE_ID = "setStonecuttingRecipeId";
    private static final String ACTION_CYCLE_PROCESSING_OUTPUT = "cycleProcessingOutput";
    private static final String ACTION_CYCLE_PROCESSING_INPUT = "cycleProcessingInput";
    private static final String ACTION_QUICK_REMOVE_PATTERN = "quickRemovePattern";
    public static final String ACTION_CLEAR_USED_VISIBLE_SLOT = "clearUsedVisibleSlot";
    public static final String ACTION_CLEAR_SEC_OUTPUT = "clearSecOutput";
    public static final String ACTION_ADD_RECIPE = "addRecipe";
    private final ExtendedEncodingLogic encodingLogic;
    private final FakeSlot[] craftingGridSlots = new FakeSlot[9];
    private final FakeSlot[] processingInputSlots = new FakeSlot[81];
    private final FakeSlot[] processingOutputSlots = new FakeSlot[27];
    private final FakeSlot[] materialSlots;
    private final FakeSlot stonecuttingInputSlot;
    private final FakeSlot smithingTableTemplateSlot;
    private final FakeSlot smithingTableBaseSlot;
    private final FakeSlot smithingTableAdditionSlot;
    private final PatternTermSlot craftOutputSlot;
    private final FakeSlot quickRemovePatternFilterSlot;
    private final RestrictedInputSlot[] encodedPatternSlots;
    private final ConfigInventory encodedInputsInv;
    private final ConfigInventory encodedOutputsInv;
    private final MaterialConfigInventory materialsInv;
    private final ConfigInventory quickRemovePatternFilterInv;
    private CraftingRecipe currentRecipe;
    private ExtendedEncodingMode currentMode;
    @GuiSync(value=87)
    public ExtendedEncodingMode mode = ExtendedEncodingMode.CRAFTING;
    @GuiSync(value=86)
    public boolean substitute = false;
    @GuiSync(value=85)
    public boolean substituteFluids = true;
    @GuiSync(value=84)
    @Nullable
    public ResourceLocation stonecuttingRecipeId;
    @GuiSync(value=83)
    public boolean autoEncodeRenaming = false;
    @GuiSync(value=82)
    public boolean autoSearchProviders = false;
    private final List<StonecutterRecipe> stonecuttingRecipes = new ObjectArrayList();
    private final Me2in1Menu menu;
    private final IntSet usedVisibleSlotIds = new IntOpenHashSet();
    private String recipe;
    public IntSet slotsSupportingFluidSubstitution = new IntArraySet();

    @Override
    public void gtolib$addRecipe(String string) {
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_ADD_RECIPE, string);
        } else {
            this.recipe = string;
        }
    }

    @Override
    @Unique
    public void gtolib$clearSecOutput() {
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_CLEAR_SEC_OUTPUT);
        } else {
            for (int i = 1; i <= 8; ++i) {
                this.encodedOutputsInv.setStack(i, null);
            }
        }
    }

    public ExtendedEncodingMenu(Me2in1Menu me2in1Menu, int n, Inventory inventory, IExtendedPatternMenuHost iExtendedPatternMenuHost, boolean bl) {
        super(me2in1Menu.m_6772_(), n, inventory, iExtendedPatternMenuHost, bl);
        int n2;
        Object object;
        this.menu = me2in1Menu;
        this.encodingLogic = iExtendedPatternMenuHost.getLogic();
        this.encodedInputsInv = this.encodingLogic.getEncodedInputInv();
        this.encodedOutputsInv = this.encodingLogic.getEncodedOutputInv();
        this.materialsInv = this.encodingLogic.getMaterialInv();
        if (this.isServerSide()) {
            object = ((MEStorageMenuAccessor)((Object)this)).getClientCM();
            object.registerSetting(Settings.TERMINAL_SHOW_PATTERN_PROVIDERS, ShowPatternProviders.VISIBLE);
            object.registerSetting(GTOSettings.TERMINAL_SHOW_MOLECULAR_ASSEMBLERS, ShowMolecularAssembler.ALL);
            object.registerSetting(GTOSettings.ME2IN1_SHIFT_TRANSFER_TO, ShiftTransferTo.INVENTORY_OR_BUFFER);
        }
        object = this.encodedInputsInv.createMenuWrapper();
        ConfigMenuInventory configMenuInventory = this.encodedOutputsInv.createMenuWrapper();
        ConfigMenuInventory configMenuInventory2 = this.materialsInv.createMenuWrapper();
        for (n2 = 0; n2 < 9; ++n2) {
            FakeSlot fakeSlot = new FakeSlot((InternalInventory)object, n2);
            fakeSlot.setHideAmount(true);
            this.craftingGridSlots[n2] = fakeSlot;
            me2in1Menu.addSlot(this.craftingGridSlots[n2], SlotSemantics.CRAFTING_GRID);
        }
        this.craftOutputSlot = new PatternTermSlot(inventory.f_35978_, this.getActionSource(), this.powerSource, iExtendedPatternMenuHost.getInventory(), (InternalInventory)object, this);
        me2in1Menu.addSlot(this.craftOutputSlot, SlotSemantics.CRAFTING_RESULT);
        this.craftOutputSlot.setIcon(null);
        for (n2 = 0; n2 < this.processingInputSlots.length; ++n2) {
            this.processingInputSlots[n2] = new FakeSlot((InternalInventory)object, n2);
            me2in1Menu.addSlot(this.processingInputSlots[n2], SlotSemantics.PROCESSING_INPUTS);
        }
        for (n2 = 0; n2 < this.processingOutputSlots.length; ++n2) {
            this.processingOutputSlots[n2] = new FakeSlot(configMenuInventory, n2);
            me2in1Menu.addSlot(this.processingOutputSlots[n2], SlotSemantics.PROCESSING_OUTPUTS);
        }
        this.processingOutputSlots[0].setIcon(Icon.BACKGROUND_PRIMARY_OUTPUT);
        for (n2 = 0; n2 < this.processingOutputSlots.length; ++n2) {
            this.processingOutputSlots[n2] = new FakeSlot(configMenuInventory, n2);
            me2in1Menu.addSlot(this.processingOutputSlots[n2], SlotSemantics.PROCESSING_OUTPUTS);
        }
        this.materialSlots = new FakeSlot[this.materialsInv.size()];
        for (n2 = 0; n2 < this.materialsInv.size(); ++n2) {
            this.materialSlots[n2] = new FakeSlot(configMenuInventory2, n2);
            me2in1Menu.addSlot(this.materialSlots[n2], GTOSlotSemantics.BATCH_FILTER);
            this.materialSlots[n2].setEmptyTooltip(() -> List.of((Object)Component.m_237115_("gtocore.ae.appeng.me2in1.material_slot"), (Object)Component.m_237115_("gtocore.ae.appeng.me2in1.material_slot.1").m_130940_(ChatFormatting.GRAY), (Object)Component.m_237115_("gtocore.ae.appeng.me2in1.material_slot.2").m_130940_(ChatFormatting.GRAY)));
            this.materialSlots[n2].setHideAmount(true);
        }
        InternalInventory internalInventory = this.encodingLogic.getEncodedPatternInv();
        this.encodedPatternSlots = new RestrictedInputSlot[internalInventory.size()];
        for (int i = 0; i < internalInventory.size(); ++i) {
            this.encodedPatternSlots[i] = new RestrictedInputSlot(RestrictedInputSlot.PlacableItemType.ENCODED_PATTERN, this.encodingLogic.getEncodedPatternInv(), i);
            me2in1Menu.addSlot(this.encodedPatternSlots[i], SlotSemantics.ENCODED_PATTERN);
            this.encodedPatternSlots[i].setStackLimit(1);
        }
        this.stonecuttingInputSlot = new FakeSlot((InternalInventory)object, 0);
        me2in1Menu.addSlot(this.stonecuttingInputSlot, SlotSemantics.STONECUTTING_INPUT);
        this.stonecuttingInputSlot.setHideAmount(true);
        this.smithingTableTemplateSlot = new FakeSlot((InternalInventory)object, 0);
        me2in1Menu.addSlot(this.smithingTableTemplateSlot, SlotSemantics.SMITHING_TABLE_TEMPLATE);
        this.smithingTableTemplateSlot.setHideAmount(true);
        this.smithingTableBaseSlot = new FakeSlot((InternalInventory)object, 1);
        me2in1Menu.addSlot(this.smithingTableBaseSlot, SlotSemantics.SMITHING_TABLE_BASE);
        this.smithingTableBaseSlot.setHideAmount(true);
        this.smithingTableAdditionSlot = new FakeSlot((InternalInventory)object, 2);
        me2in1Menu.addSlot(this.smithingTableAdditionSlot, SlotSemantics.SMITHING_TABLE_ADDITION);
        this.smithingTableAdditionSlot.setHideAmount(true);
        this.quickRemovePatternFilterInv = ConfigInventory.configTypes(1, null);
        this.quickRemovePatternFilterSlot = new FakeSlot(this.quickRemovePatternFilterInv.createMenuWrapper(), 0);
        me2in1Menu.addSlot(this.quickRemovePatternFilterSlot, SlotSemantics.CONFIG);
        this.quickRemovePatternFilterSlot.setHideAmount(true);
        me2in1Menu.registerSubmenuAction(ACTION_ENCODE, Boolean.class, this::encode);
        me2in1Menu.registerSubmenuAction(ACTION_ENCODING_TO_PROVIDER, SeenProviderSlots.class, this::encodeAndTransferToProvider);
        me2in1Menu.registerSubmenuAction(ACTION_QUICK_MOVE_TO_PROVIDER, SeenProviderSlotsWithSlotId.class, this::quickMoveToProvider);
        me2in1Menu.registerSubmenuAction(ACTION_SET_STONECUTTING_RECIPE_ID, ResourceLocation.class, this.encodingLogic::setStonecuttingRecipeId);
        me2in1Menu.registerSubmenuAction(ACTION_CLEAR, this::clear);
        me2in1Menu.registerSubmenuAction(ACTION_CLEAR_FILTER, this::clearFilter);
        me2in1Menu.registerSubmenuAction(ACTION_CLEAR_PATTERN, this::clearPattern);
        me2in1Menu.registerSubmenuAction(ACTION_SET_MODE, ExtendedEncodingMode.class, this.encodingLogic::setMode);
        me2in1Menu.registerSubmenuAction(ACTION_SET_SUBSTITUTION, Boolean.class, this.encodingLogic::setSubstitution);
        me2in1Menu.registerSubmenuAction(ACTION_SET_FLUID_SUBSTITUTION, Boolean.class, this.encodingLogic::setFluidSubstitution);
        me2in1Menu.registerSubmenuAction(ACTION_SET_AUTO_RENAMING, Boolean.class, this.encodingLogic::setAutoEncodeRenamePatterns);
        me2in1Menu.registerSubmenuAction(ACTION_SET_AUTO_SEARCH_PROVIDERS, Boolean.class, this.encodingLogic::setAutoSearchProviders);
        me2in1Menu.registerSubmenuAction(ACTION_CYCLE_PROCESSING_INPUT, this::cycleProcessingInput);
        me2in1Menu.registerSubmenuAction(ACTION_CYCLE_PROCESSING_OUTPUT, this::cycleProcessingOutput);
        me2in1Menu.registerSubmenuAction(ACTION_MODIFY_PATTER, Integer.class, this::gtolib$modifyPatter);
        me2in1Menu.registerSubmenuAction(ACTION_QUICK_REMOVE_PATTERN, Boolean.class, this::quickRemovePattern);
        me2in1Menu.registerSubmenuAction(ACTION_CLEAR_USED_VISIBLE_SLOT, () -> this.usedVisibleSlotIds.clear());
        me2in1Menu.registerSubmenuAction(ACTION_CLEAR_SEC_OUTPUT, this::gtolib$clearSecOutput);
        me2in1Menu.registerSubmenuAction(ACTION_ADD_RECIPE, String.class, this::gtolib$addRecipe);
        this.updateStonecuttingRecipes();
    }

    public void quickRemovePattern(boolean bl) {
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_QUICK_REMOVE_PATTERN, bl);
            return;
        }
        if (this.quickRemovePatternFilterInv.getStack(0) == null || this.menu.getNetworkNode() == null) {
            return;
        }
        List<GridPatternsRemover.PatternLocator> list = GridPatternsRemover.collectPatternToRemove(this.menu.getNetworkNode().getGrid(), this.getPlayerInventory().f_35978_.m_9236_(), this.quickRemovePatternFilterInv.getStack(0).what(), bl);
        int n2 = list.size();
        if (n2 == 0) {
            return;
        }
        AtomicInteger atomicInteger = new AtomicInteger(0);
        this.findEncodedPatternSlots(n2, itemStack -> itemStack.m_41619_() || AEItems.BLANK_PATTERN.isSameAs((ItemStack)itemStack)).forEach(n -> {
            GridPatternsRemover.PatternLocator patternLocator = (GridPatternsRemover.PatternLocator)list.get(atomicInteger.getAndIncrement());
            ItemStack itemStack = patternLocator.container().getTerminalPatternInventory().getStackInSlot(patternLocator.slot());
            this.encodedPatternSlots[n].m_5852_(itemStack);
            patternLocator.container().getTerminalPatternInventory().setItemDirect(patternLocator.slot(), ItemStack.f_41583_);
        });
    }

    public void quickMoveToProvider(SeenProviderSlotsWithSlotId seenProviderSlotsWithSlotId) {
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_QUICK_MOVE_TO_PROVIDER, seenProviderSlotsWithSlotId);
            return;
        }
        int n = seenProviderSlotsWithSlotId.getSlotId();
        if (n < 0 || n >= this.menu.f_38839_.size()) {
            if (GTOConfig.INSTANCE.aeLog) {
                GTOCore.LOGGER.warn("Invalid slot ID: {} while trying to quick move to pattern accessor", (Object)n);
            }
            return;
        }
        ItemStack itemStack = this.menu.m_38853_(n).m_7993_();
        if (PatternDetailsHelper.isEncodedPattern(itemStack)) {
            SeenProviderSlots seenProviderSlots = seenProviderSlotsWithSlotId.getSeenProviderSlots();
            List<Integer> list = seenProviderSlots.getMachineSlotIndex();
            if (list.isEmpty()) {
                return;
            }
            List<Long> list2 = seenProviderSlots.getMachineSlotServerId();
            Preconditions.checkArgument(list.size() == list2.size());
            for (int i = 0; i < list.size(); ++i) {
                if (!this.usedVisibleSlotIds.add(list.get(i))) continue;
                ItemStack itemStack2 = this.m_142621_();
                this.m_142503_(itemStack);
                this.menu.doPatternAction((ServerPlayer)this.getPlayer(), InventoryAction.PICKUP_OR_SET_DOWN, list.get(i), list2.get(i));
                this.m_142503_(itemStack2);
                this.menu.m_38853_(n).m_5852_(ItemStack.f_41583_);
                return;
            }
        }
    }

    @Override
    public void m_182406_(int n, int n2, @NotNull ItemStack itemStack) {
        super.m_182406_(n, n2, itemStack);
        this.getAndUpdateOutput();
    }

    @NotNull
    public Slot m_38853_(int n) {
        return this.menu.m_38853_(n);
    }

    @Override
    public RestrictedInputSlot[] getEncodedPatternSlots() {
        return this.encodedPatternSlots;
    }

    private ItemStack getAndUpdateOutput() {
        Level level = this.getPlayerInventory().f_35978_.m_9236_();
        TransientCraftingContainer transientCraftingContainer = new TransientCraftingContainer(this.menu, 3, 3);
        boolean bl = false;
        for (int i = 0; i < transientCraftingContainer.m_6643_(); ++i) {
            ItemStack itemStack = this.getEncodedCraftingIngredient(i);
            if (itemStack != null) {
                transientCraftingContainer.m_6836_(i, itemStack);
                continue;
            }
            bl = true;
        }
        if (this.currentRecipe == null || !this.currentRecipe.m_5818_(transientCraftingContainer, level)) {
            this.currentRecipe = bl ? null : (CraftingRecipe)level.m_7465_().m_44015_(RecipeType.f_44107_, transientCraftingContainer, level).orElse(null);
            this.currentMode = this.mode;
            this.checkFluidSubstitutionSupport();
        }
        ItemStack itemStack = this.currentRecipe == null ? ItemStack.f_41583_ : this.currentRecipe.m_5874_(transientCraftingContainer, level.m_9598_());
        this.craftOutputSlot.setDisplayedCraftingOutput(itemStack);
        return itemStack;
    }

    private void checkFluidSubstitutionSupport() {
        IPatternDetails iPatternDetails;
        this.slotsSupportingFluidSubstitution.clear();
        if (this.currentRecipe == null) {
            return;
        }
        ItemStack[] itemStackArray = this.encodePattern();
        if (itemStackArray != null && itemStackArray.length > 0 && (iPatternDetails = PatternDetailsHelper.decodePattern(itemStackArray[0], this.getPlayerInventory().f_35978_.m_9236_())) instanceof AECraftingPattern) {
            AECraftingPattern aECraftingPattern = (AECraftingPattern)((Object)iPatternDetails);
            for (int i = 0; i < aECraftingPattern.getSparseInputs().length; ++i) {
                if (aECraftingPattern.getValidFluid(i) == null) continue;
                this.slotsSupportingFluidSubstitution.add(i);
            }
        }
    }

    private IntSet findEncodedPatternSlots(int n, Predicate<ItemStack> predicate) {
        IntArraySet intArraySet = new IntArraySet();
        for (int i = 0; i < this.encodedPatternSlots.length; ++i) {
            if (!predicate.test(this.encodedPatternSlots[i].m_7993_())) continue;
            intArraySet.add(i);
            if (intArraySet.size() >= n) break;
        }
        return intArraySet;
    }

    @Override
    public void encode(boolean bl) {
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_ENCODE, bl);
            return;
        }
        this.encodingLogic.setEncoding(true);
        ItemStack[] itemStackArray = this.encodePattern();
        if (bl) {
            this.transferToPlayerInventory(itemStackArray);
        } else {
            this.transferToBufferSlots(itemStackArray);
        }
        this.encodingLogic.setEncoding(false);
    }

    private void transferToPlayerInventory(ItemStack ... itemStackArray) {
        for (ItemStack itemStack : itemStackArray) {
            if (!this.drawBlankPattern() || this.getPlayerInventory().m_36054_(itemStack)) continue;
            this.getPlayer().m_36176_(itemStack, false);
        }
    }

    private boolean drawBlankPattern() {
        return this.storage != null && this.storage.extract(AEItemKey.of(AEItems.BLANK_PATTERN.m_5456_()), 1L, Actionable.MODULATE, this.getActionSource()) == 1L;
    }

    private void transferToBufferSlots(ItemStack ... itemStackArray) {
        IntIterator intIterator = this.findEncodedPatternSlots(itemStackArray.length, itemStack -> itemStack.m_41619_() || AEItems.BLANK_PATTERN.isSameAs((ItemStack)itemStack)).iterator();
        for (ItemStack itemStack2 : itemStackArray) {
            if (itemStack2 == null) continue;
            int n = intIterator.hasNext() ? intIterator.next() : 0;
            ItemStack itemStack3 = this.encodedPatternSlots[n].m_7993_();
            if (itemStack3.m_41619_() && !this.drawBlankPattern()) {
                return;
            }
            this.encodedPatternSlots[n].m_5852_(itemStack2);
        }
    }

    public void encodeAndTransferToProvider(SeenProviderSlots seenProviderSlots) {
        int n;
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_ENCODING_TO_PROVIDER, seenProviderSlots);
            return;
        }
        this.encodingLogic.setEncoding(true);
        ItemStack[] itemStackArray = this.encodePattern();
        List<Integer> list = seenProviderSlots.getMachineSlotIndex();
        List<Long> list2 = seenProviderSlots.getMachineSlotServerId();
        Preconditions.checkArgument(list.size() == list2.size());
        ItemStack itemStack = this.m_142621_();
        if (itemStackArray.length > list.size()) {
            this.transferToBufferSlots(Arrays.copyOfRange(itemStackArray, list.size(), itemStackArray.length));
            n = list.size();
        } else {
            n = itemStackArray.length;
        }
        for (int i = 0; i < n; ++i) {
            if (!this.drawBlankPattern()) {
                this.m_142503_(itemStack);
                return;
            }
            this.m_142503_(itemStackArray[i]);
            this.menu.doPatternAction((ServerPlayer)this.getPlayer(), InventoryAction.PICKUP_OR_SET_DOWN, list.get(i), list2.get(i));
        }
        this.m_142503_(itemStack);
        this.encodingLogic.setEncoding(false);
    }

    @Override
    public void encodeAndTransferToProvider() {
        SeenProviderSlots seenProviderSlots = this.menu.getVisibleEmptyPatternSlots();
        this.encodeAndTransferToProvider(seenProviderSlots);
    }

    @Override
    public void clearPattern() {
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_CLEAR_PATTERN);
            return;
        }
        int n = 0;
        for (RestrictedInputSlot restrictedInputSlot : this.encodedPatternSlots) {
            ItemStack itemStack = restrictedInputSlot.m_7993_();
            if (!PatternDetailsHelper.isEncodedPattern(itemStack)) continue;
            ++n;
            restrictedInputSlot.m_5852_(ItemStack.f_41583_);
        }
        if (n == 0) {
            return;
        }
        ItemStack itemStack = AEItems.BLANK_PATTERN.stack(n);
        if (this.storage != null) {
            itemStack.m_41774_((int)this.storage.insert(AEItemKey.of(itemStack), itemStack.m_41613_(), Actionable.MODULATE, this.getActionSource()));
        }
        if (itemStack.m_41613_() > 0 && !this.getPlayerInventory().m_36054_(itemStack)) {
            this.getPlayerInventory().f_35978_.m_36176_(itemStack, false);
        }
    }

    @Nullable
    private ItemStack[] encodePattern() {
        ItemStack[] itemStackArray;
        ItemStack itemStack;
        ObjectArrayList objectArrayList = new ObjectArrayList();
        switch (this.mode) {
            default: {
                throw new IncompatibleClassChangeError();
            }
            case CRAFTING: {
                ItemStack itemStack2 = this.encodeCraftingPattern();
                break;
            }
            case PROCESSING: {
                ItemStack itemStack2 = this.encodeProcessingPattern();
                break;
            }
            case SMITHING_TABLE: {
                ItemStack itemStack2 = this.encodeSmithingTablePattern();
                break;
            }
            case STONECUTTING: {
                ItemStack itemStack2 = this.encodeStonecuttingPattern();
                break;
            }
            case BATCH: {
                ItemStack itemStack2 = itemStack = null;
            }
        }
        if (itemStack != null) {
            objectArrayList.add(itemStack);
        }
        ItemStack[] itemStackArray2 = itemStackArray = this.mode == ExtendedEncodingMode.BATCH ? this.batchEncodingPattern() : null;
        if (itemStackArray != null && itemStackArray.length > 0) {
            objectArrayList.addAll(Arrays.asList(itemStackArray));
        }
        if (!this.mode.certernRecipe && this.isAutoEncodeRenaming()) {
            ItemStack itemStack3;
            int n;
            for (n = 0; n < this.encodedInputsInv.size(); ++n) {
                ItemStack itemStack4 = itemStack3 = this.encodedInputsInv.getStack(n) == null ? null : PatternUtils.encodeProcessRenamedItemPattern(this.encodedInputsInv.getStack(n));
                if (itemStack3 == null) continue;
                objectArrayList.add(itemStack3);
            }
            for (n = 0; n < this.encodedOutputsInv.size(); ++n) {
                ItemStack itemStack5 = itemStack3 = this.encodedOutputsInv.getStack(n) == null ? null : PatternUtils.encodeProcessRenamedItemPattern(this.encodedOutputsInv.getStack(n));
                if (itemStack3 == null) continue;
                objectArrayList.add(itemStack3);
            }
        }
        return objectArrayList.isEmpty() ? null : (ItemStack[])objectArrayList.toArray(new ItemStack[0]);
    }

    private ItemStack[] batchEncodingPattern() {
        if (!this.isEncodingAreaValid()) {
            return new ItemStack[0];
        }
        ObjectArrayList objectArrayList = new ObjectArrayList();
        GenericStack[] genericStackArray = new GenericStack[this.encodedInputsInv.size()];
        GenericStack[] genericStackArray2 = new GenericStack[this.encodedOutputsInv.size()];
        Set<Material> set = this.materialsInv.materialSet();
        for (Material material : set) {
            int n;
            for (n = 0; n < this.encodedInputsInv.size(); ++n) {
                genericStackArray[n] = this.encodedInputsInv.getStack(n) == null ? null : new GenericStack(AEChemicalHelper.getKey(material, this.encodedInputsInv.getKey(n)), this.encodedInputsInv.getStack(n).amount());
            }
            for (n = 0; n < this.encodedOutputsInv.size(); ++n) {
                genericStackArray2[n] = this.encodedOutputsInv.getStack(n) == null ? null : new GenericStack(AEChemicalHelper.getKey(material, this.encodedOutputsInv.getKey(n)), this.encodedOutputsInv.getStack(n).amount());
            }
            objectArrayList.add(PatternDetailsHelper.encodeProcessingPattern(genericStackArray, genericStackArray2));
        }
        return (ItemStack[])objectArrayList.toArray(new ItemStack[0]);
    }

    @Nullable
    private ItemStack encodeCraftingPattern() {
        ItemStack[] itemStackArray = new ItemStack[9];
        boolean bl = false;
        for (int i = 0; i < itemStackArray.length; ++i) {
            itemStackArray[i] = this.getEncodedCraftingIngredient(i);
            if (itemStackArray[i] == null) {
                return null;
            }
            if (itemStackArray[i].m_41619_()) continue;
            bl = true;
        }
        if (!bl) {
            return null;
        }
        ItemStack itemStack = this.getAndUpdateOutput();
        if (itemStack.m_41619_() || this.currentRecipe == null) {
            return null;
        }
        return PatternDetailsHelper.encodeCraftingPattern(this.currentRecipe, itemStackArray, itemStack, this.isSubstitute(), this.isSubstituteFluids());
    }

    private boolean isEncodingAreaValid() {
        boolean bl = false;
        for (int i = 0; i < this.encodedInputsInv.size(); ++i) {
            if (this.encodedInputsInv.getStack(i) == null) continue;
            bl = true;
        }
        if (!bl) {
            return false;
        }
        return this.encodedOutputsInv.getStack(0) != null;
    }

    @Nullable
    private ItemStack encodeProcessingPattern() {
        GenericStack[] genericStackArray = new GenericStack[this.encodedInputsInv.size()];
        boolean bl = false;
        for (int i = 0; i < this.encodedInputsInv.size(); ++i) {
            genericStackArray[i] = this.encodedInputsInv.getStack(i);
            if (genericStackArray[i] == null) continue;
            bl = true;
        }
        if (!bl) {
            return null;
        }
        GenericStack[] genericStackArray2 = new GenericStack[this.encodedOutputsInv.size()];
        for (int i = 0; i < this.encodedOutputsInv.size(); ++i) {
            genericStackArray2[i] = this.encodedOutputsInv.getStack(i);
        }
        if (genericStackArray2[0] == null) {
            return null;
        }
        ItemStack itemStack = PatternDetailsHelper.encodeProcessingPattern(genericStackArray, genericStackArray2);
        if (this.recipe != null && !this.recipe.isEmpty()) {
            itemStack.m_41784_().m_128359_("recipe", this.recipe);
        }
        return itemStack;
    }

    @Nullable
    private ItemStack encodeSmithingTablePattern() {
        AEItemKey aEItemKey;
        AEItemKey aEItemKey2;
        Object object;
        block6: {
            block5: {
                object = this.encodedInputsInv.getKey(0);
                if (!(object instanceof AEItemKey)) break block5;
                aEItemKey2 = (AEItemKey)object;
                object = this.encodedInputsInv.getKey(1);
                if (!(object instanceof AEItemKey)) break block5;
                aEItemKey = (AEItemKey)object;
                object = this.encodedInputsInv.getKey(2);
                if (object instanceof AEItemKey) break block6;
            }
            return null;
        }
        AEItemKey aEItemKey3 = (AEItemKey)object;
        object = new SimpleContainer(3);
        ((SimpleContainer)object).m_6836_(0, aEItemKey2.toStack());
        ((SimpleContainer)object).m_6836_(1, aEItemKey.toStack());
        ((SimpleContainer)object).m_6836_(2, aEItemKey3.toStack());
        Level level = this.getPlayer().m_9236_();
        SmithingRecipe smithingRecipe = level.m_7465_().m_44015_(RecipeType.f_44113_, (Container)object, level).orElse(null);
        if (smithingRecipe == null) {
            return null;
        }
        AEItemKey aEItemKey4 = AEItemKey.of(smithingRecipe.m_5874_((Container)object, level.m_9598_()));
        if (aEItemKey4 != null) {
            return PatternDetailsHelper.encodeSmithingTablePattern(smithingRecipe, aEItemKey2, aEItemKey, aEItemKey3, aEItemKey4, this.encodingLogic.isSubstitution());
        }
        throw new IllegalStateException("Smithing recipe returned null output: " + String.valueOf(smithingRecipe.m_6423_()));
    }

    @Nullable
    private ItemStack encodeStonecuttingPattern() {
        if (this.stonecuttingRecipeId == null) {
            return null;
        }
        Object object = this.encodedInputsInv.getKey(0);
        if (!(object instanceof AEItemKey)) {
            return null;
        }
        AEItemKey aEItemKey = (AEItemKey)object;
        object = new SimpleContainer(1);
        ((SimpleContainer)object).m_6836_(0, aEItemKey.toStack());
        Level level = this.getPlayer().m_9236_();
        StonecutterRecipe stonecutterRecipe = level.m_7465_().m_220248_(RecipeType.f_44112_, (Container)object, level, this.stonecuttingRecipeId).map(Pair::getSecond).orElse(null);
        if (stonecutterRecipe == null) {
            return null;
        }
        AEItemKey aEItemKey2 = AEItemKey.of(stonecutterRecipe.m_8043_(level.m_9598_()));
        if (aEItemKey2 != null) {
            return PatternDetailsHelper.encodeStonecuttingPattern(stonecutterRecipe, aEItemKey, aEItemKey2, this.encodingLogic.isSubstitution());
        }
        throw new IllegalStateException("Stonecutting recipe returned null output: " + String.valueOf(stonecutterRecipe.m_6423_()));
    }

    @Nullable
    private ItemStack getEncodedCraftingIngredient(int n) {
        AEKey aEKey = this.encodedInputsInv.getKey(n);
        if (aEKey == null) {
            return ItemStack.f_41583_;
        }
        if (aEKey instanceof AEItemKey) {
            AEItemKey aEItemKey = (AEItemKey)aEKey;
            return aEItemKey.toStack(1);
        }
        return null;
    }

    @Override
    public void m_38946_() {
        super.m_38946_();
        if (this.isServerSide()) {
            if (this.mode != this.encodingLogic.getMode()) {
                this.setMode(this.encodingLogic.getMode());
            }
            this.substitute = this.encodingLogic.isSubstitution();
            this.substituteFluids = this.encodingLogic.isFluidSubstitution();
            this.stonecuttingRecipeId = this.encodingLogic.getStonecuttingRecipeId();
            this.autoEncodeRenaming = this.encodingLogic.isAutoEncodeRenamePatterns();
            this.autoSearchProviders = this.encodingLogic.isAutoSearchProviders();
        }
    }

    @Override
    public void onServerDataSync() {
        super.onServerDataSync();
        for (FakeSlot fakeSlot : this.craftingGridSlots) {
            fakeSlot.setActive(this.mode == ExtendedEncodingMode.CRAFTING);
        }
        this.craftOutputSlot.setActive(this.mode == ExtendedEncodingMode.CRAFTING);
        for (FakeSlot fakeSlot : this.processingInputSlots) {
            fakeSlot.setActive(this.mode == ExtendedEncodingMode.PROCESSING);
        }
        for (FakeSlot fakeSlot : this.processingOutputSlots) {
            fakeSlot.setActive(this.mode == ExtendedEncodingMode.PROCESSING);
        }
        if (this.currentMode != this.mode) {
            this.encodingLogic.setMode(this.mode);
            this.getAndUpdateOutput();
            this.updateStonecuttingRecipes();
        }
    }

    public void m_142503_(@NotNull ItemStack itemStack) {
        this.menu.m_142503_(itemStack);
    }

    @Override
    @NotNull
    public ItemStack m_142621_() {
        return this.menu.m_142621_();
    }

    @Override
    public FakeSlot getQuickRemovePatternFilterSlot() {
        return this.quickRemovePatternFilterSlot;
    }

    public void onSlotChange(Slot slot) {
        if (Stream.of(this.encodedPatternSlots).anyMatch(restrictedInputSlot -> restrictedInputSlot == slot) && this.isServerSide()) {
            this.m_38946_();
        }
        if (this.isClientSide()) {
            this.getAndUpdateOutput();
        }
        if (slot == this.stonecuttingInputSlot) {
            this.updateStonecuttingRecipes();
        }
    }

    private void updateStonecuttingRecipes() {
        this.stonecuttingRecipes.clear();
        Object object = this.encodedInputsInv.getKey(0);
        if (object instanceof AEItemKey) {
            AEItemKey aEItemKey = (AEItemKey)object;
            object = this.getPlayer().m_9236_();
            RecipeManager recipeManager = ((Level)object).m_7465_();
            SimpleContainer simpleContainer = new SimpleContainer(1);
            simpleContainer.m_6836_(0, aEItemKey.toStack());
            this.stonecuttingRecipes.addAll(recipeManager.m_44056_(RecipeType.f_44112_, simpleContainer, (Level)object));
        }
        if (this.stonecuttingRecipeId != null && this.stonecuttingRecipes.stream().noneMatch(stonecutterRecipe -> stonecutterRecipe.m_6423_().equals(this.stonecuttingRecipeId))) {
            this.stonecuttingRecipeId = null;
        }
    }

    @Override
    public void clear() {
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_CLEAR);
            return;
        }
        this.encodedInputsInv.clear();
        this.encodedOutputsInv.clear();
        this.m_38946_();
        this.getAndUpdateOutput();
    }

    public InternalInventory getCraftingMatrix() {
        return this.encodedInputsInv.createMenuWrapper().getSubInventory(0, 9);
    }

    public boolean useRealItems() {
        return false;
    }

    @Override
    public ExtendedEncodingMode getMode() {
        return this.mode;
    }

    @Override
    public void setMode(ExtendedEncodingMode extendedEncodingMode) {
        if (this.mode != extendedEncodingMode && extendedEncodingMode == ExtendedEncodingMode.STONECUTTING) {
            this.updateStonecuttingRecipes();
        }
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_SET_MODE, extendedEncodingMode);
        } else {
            this.mode = extendedEncodingMode;
        }
    }

    @Override
    public void setSubstitute(boolean bl) {
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_SET_SUBSTITUTION, bl);
        } else {
            this.substitute = bl;
        }
    }

    public void setAutoSearchProviders(boolean bl) {
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_SET_AUTO_SEARCH_PROVIDERS, bl);
        } else {
            this.autoSearchProviders = bl;
        }
    }

    @Override
    public boolean isSubstituteFluids() {
        return this.substituteFluids;
    }

    @Override
    public boolean isAutoEncodeRenaming() {
        return this.autoEncodeRenaming;
    }

    @Override
    public void setAutoEncodeRenaming(boolean bl) {
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_SET_AUTO_RENAMING, bl);
        } else {
            this.autoEncodeRenaming = bl;
        }
    }

    @Override
    public void setSubstituteFluids(boolean bl) {
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_SET_FLUID_SUBSTITUTION, bl);
        } else {
            this.substituteFluids = bl;
        }
    }

    @Override
    public boolean isSubstitute() {
        return this.substitute;
    }

    @Override
    public IntSet slotsSupportingFluidSubstitution() {
        return this.slotsSupportingFluidSubstitution;
    }

    @Override
    @Nullable
    public ResourceLocation getStonecuttingRecipeId() {
        return this.stonecuttingRecipeId;
    }

    @Override
    public FakeSlot getStonecuttingInputSlot() {
        return this.stonecuttingInputSlot;
    }

    @Override
    public void setStonecuttingRecipeId(ResourceLocation resourceLocation) {
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_SET_STONECUTTING_RECIPE_ID, resourceLocation);
        } else {
            this.encodingLogic.setStonecuttingRecipeId(resourceLocation);
        }
    }

    @Override
    protected ItemStack transferStackToMenu(ItemStack itemStack) {
        if (itemStack.m_150930_(AEItems.BLANK_PATTERN.m_5456_())) {
            return super.transferStackToMenu(itemStack);
        }
        if (PatternDetailsHelper.isEncodedPattern(itemStack)) {
            return this.transferPatternToBuffer(itemStack);
        }
        return super.transferStackToMenu(itemStack);
    }

    public ItemStack transferPatternToBuffer(ItemStack itemStack) {
        if (itemStack.m_41619_()) {
            return ItemStack.f_41583_;
        }
        IntSet intSet = this.findEncodedPatternSlots(1, ItemStack::m_41619_);
        if (intSet.isEmpty()) {
            return itemStack;
        }
        RestrictedInputSlot restrictedInputSlot = this.encodedPatternSlots[intSet.iterator().next()];
        if (restrictedInputSlot.m_5857_(itemStack) && (itemStack = restrictedInputSlot.m_150659_(itemStack)).m_41619_()) {
            return ItemStack.f_41583_;
        }
        return itemStack;
    }

    @Override
    @Contract(value="null -> false")
    public boolean canModifyAmountForSlot(@Nullable Slot slot) {
        return this.isProcessingPatternSlot(slot) && slot.m_6657_();
    }

    @Override
    @Contract(value="null -> false")
    public boolean isProcessingPatternSlot(@Nullable Slot slot) {
        if (slot == null || this.mode.certernRecipe) {
            return false;
        }
        for (FakeSlot fakeSlot : this.processingOutputSlots) {
            if (fakeSlot != slot) continue;
            return true;
        }
        for (FakeSlot fakeSlot : this.processingInputSlots) {
            if (fakeSlot != slot) continue;
            return true;
        }
        return false;
    }

    @Override
    public Repo getRepo() {
        return (Repo)this.getClientRepo();
    }

    @Override
    public FakeSlot[] getCraftingGridSlots() {
        return this.craftingGridSlots;
    }

    @Override
    public FakeSlot[] getProcessingInputSlots() {
        return this.processingInputSlots;
    }

    @Override
    public FakeSlot[] getProcessingOutputSlots() {
        return this.processingOutputSlots;
    }

    @Override
    public FakeSlot[] getMaterialSlots() {
        return this.materialSlots;
    }

    @Override
    public FakeSlot getSmithingTableTemplateSlot() {
        return this.smithingTableTemplateSlot;
    }

    @Override
    public FakeSlot getSmithingTableBaseSlot() {
        return this.smithingTableBaseSlot;
    }

    @Override
    public FakeSlot getSmithingTableAdditionSlot() {
        return this.smithingTableAdditionSlot;
    }

    @Override
    public void cycleProcessingOutput() {
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_CYCLE_PROCESSING_OUTPUT);
        } else {
            if (this.mode.certernRecipe) {
                return;
            }
            PatternUtils.cyclePatternEncodingArea(this.encodedOutputsInv);
        }
    }

    @Override
    public boolean canCycleProcessingOutputs() {
        return !this.mode.certernRecipe && Arrays.stream(this.processingOutputSlots).filter(fakeSlot -> !fakeSlot.m_7993_().m_41619_()).count() > 1L;
    }

    @Override
    public void cycleProcessingInput() {
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_CYCLE_PROCESSING_INPUT);
        } else {
            if (this.mode.certernRecipe) {
                return;
            }
            PatternUtils.cyclePatternEncodingArea(this.encodedInputsInv);
        }
    }

    @Override
    public boolean canCycleProcessingInputs() {
        return !this.mode.certernRecipe && Arrays.stream(this.processingInputSlots).filter(fakeSlot -> !fakeSlot.m_7993_().m_41619_()).count() > 1L;
    }

    @Override
    public Slot getCraftingResultSlot() {
        return this.craftOutputSlot;
    }

    @Override
    public List<StonecutterRecipe> getStonecuttingRecipes() {
        return this.stonecuttingRecipes;
    }

    @Override
    public void gtolib$modifyPatter(Integer n) {
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_MODIFY_PATTER, n);
        } else {
            PatternUtils.mulPatternEncodingArea(this.encodedInputsInv, this.encodedOutputsInv, n);
        }
    }

    @Override
    public void clearFilter() {
        if (this.isClientSide()) {
            this.menu.sendSubmenuAction(ACTION_CLEAR_FILTER);
            return;
        }
        this.materialsInv.clear();
        this.m_38946_();
        this.getAndUpdateOutput();
    }

    public static class SeenProviderSlotsWithSlotId {
        private SeenProviderSlots seenProviderSlots;
        private int slotId;

        public SeenProviderSlotsWithSlotId(SeenProviderSlots seenProviderSlots, int n) {
            this.seenProviderSlots = seenProviderSlots;
            this.slotId = n;
        }

        public SeenProviderSlotsWithSlotId() {
        }

        public SeenProviderSlots getSeenProviderSlots() {
            return this.seenProviderSlots;
        }

        public void setSeenProviderSlots(SeenProviderSlots seenProviderSlots) {
            this.seenProviderSlots = seenProviderSlots;
        }

        public int getSlotId() {
            return this.slotId;
        }

        public void setSlotId(int n) {
            this.slotId = n;
        }
    }
}

package com.gtolib.api.ae2.me2in1;

import appeng.client.gui.Icon;
import appeng.client.gui.widgets.IconButton;
import net.minecraft.client.gui.components.Button;

class UtilsMiscs$1
extends IconButton {
    final Icon val$icon;

    UtilsMiscs$1(Button.OnPress onPress, Icon icon) {
        this.val$icon = icon;
        super(onPress);
    }

    public Icon getIcon() {
        return this.val$icon;
    }
}

package com.gtolib.api.ae2.me2in1.encoding;

import appeng.api.config.ActionItems;
import appeng.client.Point;
import appeng.client.gui.style.Blitter;
import appeng.client.gui.widgets.ActionButton;
import appeng.menu.SlotSemantics;
import appeng.menu.slot.FakeSlot;
import com.gtocore.common.data.GTOMachines;
import com.gtolib.api.ae2.ModifyIconButton;
import com.gtolib.api.ae2.me2in1.GTOSlotSemantics;
import com.gtolib.api.ae2.me2in1.Me2in1Screen;
import com.gtolib.api.ae2.me2in1.UtilsMiscs;
import com.gtolib.api.ae2.me2in1.encoding.ProcessingEncodingPanel;
import com.gtolib.api.annotation.DataGeneratorScanned;
import com.gtolib.api.annotation.language.RegisterLanguage;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

@DataGeneratorScanned
public class BatchEncodingPanel
extends ProcessingEncodingPanel {
    private static final Blitter FILTER_SLOTS = Blitter.texture("guis/encoding_module.png").src(0, 112, 180, 50);
    @RegisterLanguage(cn="批量编码", en="Batch Encoding")
    private static final String BATCH_ENCODING_TAB_TOOLTIP = "gtocore.machine.batch_encoding_tab_tooltip";
    private final ActionButton clearFilterBtn = new ActionButton(ActionItems.CLOSE, actionItems -> this.encodingMenu.clearFilter());
    private static final int BG_X_OFFSET = -49;
    private static final int BG_Y_OFFSET = 62;
    private static final int FILTER_SLOT_X = -39;
    private static final int FLITER_SLOT_Y = 77;
    private static final int CLEAR_FILTER_BTN_X = 110;
    private static final int CLEAR_FILTER_BTN_Y = 96;

    public BatchEncodingPanel(Me2in1Screen<?> me2in1Screen) {
        super(me2in1Screen);
        this.clearFilterBtn.setHalfSize(true);
        me2in1Screen.getSubWidgets().put("clearFilterBtn", (AbstractWidget)((Object)this.clearFilterBtn));
    }

    @Override
    public void drawBackgroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
        super.drawBackgroundLayer(guiGraphics, rect2i, point);
        FILTER_SLOTS.dest(this.x + rect2i.m_110085_() + -49, this.y + rect2i.m_110086_() + 62).blit(guiGraphics);
    }

    @Override
    public void updateBeforeRender() {
        super.updateBeforeRender();
        for (int i = 0; i < this.encodingMenu.getMaterialSlots().length; ++i) {
            FakeSlot fakeSlot = this.encodingMenu.getMaterialSlots()[i];
            UtilsMiscs.setSlotPos(fakeSlot, this.x + i * 18 + -39, this.y + 77);
        }
        this.clearFilterBtn.m_264152_(this.x + this.getGuiLeft() + 110, this.y + this.getGuiTop() + 96);
    }

    @Override
    public void setVisible(boolean bl) {
        this.visible = bl;
        this.scrollbar.setVisible(bl);
        this.clearBtn.setVisibility(bl);
        this.clearSecOutput.setVisibility(bl && this.encodingMenu.canCycleProcessingOutputs());
        this.cycleOutputBtn.setVisibility(bl && this.encodingMenu.canCycleProcessingOutputs());
        this.cycleInputBtn.setVisibility(bl && this.encodingMenu.canCycleProcessingInputs());
        for (ModifyIconButton modifyIconButton : this.modifyButtons) {
            modifyIconButton.setVisibility(bl);
        }
        this.clearFilterBtn.setVisibility(bl);
        this.parent.setSlotsHidden(SlotSemantics.PROCESSING_OUTPUTS, !bl);
        this.parent.setSlotsHidden(SlotSemantics.PROCESSING_INPUTS, !bl);
        this.parent.setSlotsHidden(GTOSlotSemantics.BATCH_FILTER, !bl);
    }

    @Override
    public ItemStack getTabIconItem() {
        return GTOMachines.THREAD_HATCH[8].asStack();
    }

    @Override
    public Component getTabTooltip() {
        return Component.m_237115_(BATCH_ENCODING_TAB_TOOLTIP);
    }
}

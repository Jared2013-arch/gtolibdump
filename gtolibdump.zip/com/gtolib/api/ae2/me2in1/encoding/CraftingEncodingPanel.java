package com.gtolib.api.ae2.me2in1.encoding;

import appeng.client.Point;
import appeng.client.gui.Icon;
import appeng.client.gui.style.Blitter;
import appeng.client.gui.widgets.ToggleButton;
import appeng.core.localization.ButtonToolTips;
import appeng.core.localization.GuiText;
import appeng.menu.SlotSemantics;
import appeng.menu.slot.FakeSlot;
import com.gtolib.api.ae2.me2in1.Me2in1Screen;
import com.gtolib.api.ae2.me2in1.UtilsMiscs;
import com.gtolib.api.ae2.me2in1.encoding.EncodingModePanel;
import it.unimi.dsi.fastutil.ints.IntIterator;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class CraftingEncodingPanel
extends EncodingModePanel {
    private static final Blitter BG = Blitter.texture("guis/ex_encoding_modes.png").src(0, 0, 126, 68);
    private final ToggleButton substitutionsBtn = this.createSubstitutionButton();
    private final ToggleButton fluidSubstitutionsBtn;
    private static final int BG_X_OFFSET = 0;
    private static final int BG_Y_OFFSET = 0;
    private static final int CRAFTING_INPUT_SLOT_X_OFFSET = 9;
    private static final int CRAFTING_INPUT_SLOT_Y_OFFSET = 8;
    private static final int CRAFTING_RESULT_SLOT_X_OFFSET = 101;
    private static final int CRAFTING_RESULT_SLOT_Y_OFFSET = 26;
    private static final int CLR_BTN_X_OFFSET = 76;
    private static final int SUB_BTN_X_OFFSET = 86;
    private static final int F_SUB_BTN_X_OFFSET = 96;
    private static final int BTN_Y_OFFSET = 6;

    public CraftingEncodingPanel(Me2in1Screen<?> me2in1Screen) {
        super(me2in1Screen);
        me2in1Screen.getSubWidgets().put("crafting_substitutions_btn", (AbstractWidget)((Object)this.substitutionsBtn));
        this.fluidSubstitutionsBtn = this.createCraftingFluidSubstitutionButton();
        me2in1Screen.getSubWidgets().put("crafting_fluid_substitutions_btn", (AbstractWidget)((Object)this.fluidSubstitutionsBtn));
    }

    @Override
    public ItemStack getTabIconItem() {
        return Items.f_41960_.m_7968_();
    }

    @Override
    public Component getTabTooltip() {
        return GuiText.CraftingPattern.text();
    }

    private ToggleButton createCraftingFluidSubstitutionButton() {
        ToggleButton toggleButton = new ToggleButton(Icon.FLUID_SUBSTITUTION_ENABLED, Icon.FLUID_SUBSTITUTION_DISABLED, this.encodingMenu::setSubstituteFluids);
        toggleButton.setHalfSize(true);
        toggleButton.setTooltipOn(List.of((Object)ButtonToolTips.FluidSubstitutions.text(), (Object)ButtonToolTips.FluidSubstitutionsDescEnabled.text()));
        toggleButton.setTooltipOff(List.of((Object)ButtonToolTips.FluidSubstitutions.text(), (Object)ButtonToolTips.FluidSubstitutionsDescDisabled.text()));
        return toggleButton;
    }

    @Override
    public void drawBackgroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
        super.drawBackgroundLayer(guiGraphics, rect2i, point);
        BG.dest(this.x + rect2i.m_110085_() + 0, this.y + rect2i.m_110086_() + 0).blit(guiGraphics);
        int n = rect2i.m_110085_() + point.getX();
        int n2 = rect2i.m_110086_() + point.getY();
        if (this.encodingMenu.isSubstituteFluids() && this.fluidSubstitutionsBtn.m_5953_(n, n2)) {
            IntIterator intIterator = this.encodingMenu.slotsSupportingFluidSubstitution().iterator();
            while (intIterator.hasNext()) {
                Integer n3 = (Integer)intIterator.next();
                this.drawSlotGreenBG(rect2i, guiGraphics, this.encodingMenu.getCraftingGridSlots()[n3]);
            }
        }
    }

    private void drawSlotGreenBG(Rect2i rect2i, GuiGraphics guiGraphics, Slot slot) {
        int n = rect2i.m_110085_() + slot.f_40220_;
        int n2 = rect2i.m_110086_() + slot.f_40221_;
        guiGraphics.m_280509_(n, n2, n + 16, n2 + 16, 0x7F00FF00);
    }

    @Override
    public void updateBeforeRender() {
        this.getScreen().setSlotsHidden(SlotSemantics.CRAFTING_GRID, !this.isVisible());
        this.getScreen().setSlotsHidden(SlotSemantics.CRAFTING_RESULT, !this.isVisible());
        if (!this.isVisible()) {
            return;
        }
        this.clearBtn.m_264152_(this.getGuiLeft() + this.x + 76, this.y + 6 + this.getGuiTop());
        this.substitutionsBtn.setState(this.encodingMenu.isSubstitute());
        this.substitutionsBtn.m_264152_(this.getGuiLeft() + this.x + 86, this.y + 6 + this.getGuiTop());
        this.fluidSubstitutionsBtn.setState(this.encodingMenu.isSubstituteFluids());
        this.fluidSubstitutionsBtn.m_264152_(this.getGuiLeft() + this.x + 96, this.y + 6 + this.getGuiTop());
        for (int i = 0; i < this.encodingMenu.getCraftingGridSlots().length; ++i) {
            FakeSlot fakeSlot = this.encodingMenu.getCraftingGridSlots()[i];
            if (fakeSlot == null) continue;
            UtilsMiscs.setSlotPos(fakeSlot, i % 3 * 18 + this.x + 9, i / 3 * 18 + this.y + 8);
        }
        Slot slot = this.encodingMenu.getCraftingResultSlot();
        if (slot != null) {
            UtilsMiscs.setSlotPos(slot, this.x + 101, this.y + 26);
        }
    }

    @Override
    public void setVisible(boolean bl) {
        super.setVisible(bl);
        this.substitutionsBtn.setVisibility(bl);
        this.fluidSubstitutionsBtn.setVisibility(bl);
        this.parent.setSlotsHidden(SlotSemantics.CRAFTING_GRID, !bl);
        this.parent.setSlotsHidden(SlotSemantics.CRAFTING_RESULT, !bl);
    }
}

package com.gtolib.api.ae2.me2in1.encoding;

import appeng.client.Point;
import appeng.client.gui.Tooltip;
import appeng.client.gui.style.Blitter;
import appeng.client.gui.widgets.Scrollbar;
import appeng.core.localization.GuiText;
import appeng.menu.SlotSemantics;
import appeng.menu.slot.FakeSlot;
import com.gtolib.api.ae2.me2in1.Me2in1Screen;
import com.gtolib.api.ae2.me2in1.UtilsMiscs;
import com.gtolib.api.ae2.me2in1.encoding.EncodingModePanel;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.StonecutterRecipe;
import org.jetbrains.annotations.Nullable;

public final class StonecuttingEncodingPanel
extends EncodingModePanel {
    private static final Blitter BG = Blitter.texture("guis/ex_encoding_modes.png").src(0, 141, 126, 68);
    private static final Blitter BG_SLOT = BG.copy().src(126, 141, 16, 18);
    private static final Blitter BG_SLOT_SELECTED = BG.copy().src(126, 159, 16, 18);
    private static final Blitter BG_SLOT_HOVER = BG.copy().src(126, 177, 16, 18);
    private static final int COLS = 4;
    private static final int ROWS = 3;
    private final Scrollbar scrollbar = new Scrollbar(Scrollbar.SMALL);
    private static final int BG_X_OFFSET = 0;
    private static final int BG_Y_OFFSET = 0;
    private static final int SCROLLBAR_X = 110;
    private static final int SCROLLBAR_Y = 8;
    private static final int CLR_BTN_X_OFFSET = 31;
    private static final int CLR_BTN_Y_OFFSET = 24;
    private static final int STONECUTTER_SLOT_X = 12;
    private static final int STONECUTTER_SLOT_Y = 25;
    private static final int STONECUTTER_OUT_SLOT_X = 44;
    private static final int STONECUTTER_OUT_SLOT_Y = 8;

    public StonecuttingEncodingPanel(Me2in1Screen<?> me2in1Screen) {
        super(me2in1Screen);
        this.scrollbar.setRange(0, 0, 4);
        this.scrollbar.setCaptureMouseWheel(false);
    }

    @Override
    public void updateBeforeRender() {
        this.getScreen().setSlotsHidden(SlotSemantics.STONECUTTING_INPUT, !this.isVisible());
        if (!this.isVisible()) {
            return;
        }
        this.clearBtn.m_264152_(31 + this.x + this.getGuiLeft(), this.y + this.getGuiTop() + 24);
        int n = (this.encodingMenu.getStonecuttingRecipes().size() + 4 - 1) / 4;
        this.scrollbar.setRange(0, n - 3, 3);
        this.scrollbar.setPosition(new Point(this.x + 110, this.y + 8));
        this.scrollbar.setSize(18, 52);
        FakeSlot fakeSlot = this.encodingMenu.getStonecuttingInputSlot();
        UtilsMiscs.setSlotPos(fakeSlot, this.x + 12, this.y + 25);
    }

    @Override
    public void drawBackgroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
        super.drawBackgroundLayer(guiGraphics, rect2i, point);
        BG.dest(this.x + rect2i.m_110085_() + 0, this.y + rect2i.m_110086_() + 0).blit(guiGraphics);
        this.scrollbar.drawBackgroundLayer(guiGraphics, rect2i, point);
        this.drawRecipes(guiGraphics, rect2i, point);
    }

    @Override
    public void drawForegroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
        super.drawForegroundLayer(guiGraphics, rect2i, point);
        this.scrollbar.drawForegroundLayer(guiGraphics, rect2i, point);
    }

    private RegistryAccess getRegistryAccess() {
        return Objects.requireNonNull(Minecraft.m_91087_().f_91073_).m_9598_();
    }

    private void drawRecipes(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
        List<StonecutterRecipe> list = this.encodingMenu.getStonecuttingRecipes();
        int n = this.scrollbar.getCurrentScroll() * 4;
        int n2 = n + 12;
        ResourceLocation resourceLocation = this.encodingMenu.getStonecuttingRecipeId();
        for (int i = n; i < n2 && i < list.size(); ++i) {
            Rect2i rect2i2 = this.getRecipeBounds(i - n);
            StonecutterRecipe stonecutterRecipe = list.get(i);
            boolean bl = resourceLocation != null && resourceLocation.equals(stonecutterRecipe.m_6423_());
            Blitter blitter = BG_SLOT;
            if (bl) {
                blitter = BG_SLOT_SELECTED;
            } else if (point.isIn(rect2i2)) {
                blitter = BG_SLOT_HOVER;
            }
            int n3 = rect2i.m_110085_() + rect2i2.m_110085_();
            int n4 = rect2i.m_110086_() + rect2i2.m_110086_();
            blitter.dest(n3, n4 - 1).blit(guiGraphics);
            ItemStack itemStack = stonecutterRecipe.m_8043_(this.getRegistryAccess());
            guiGraphics.m_280480_(itemStack, n3, n4);
            guiGraphics.m_280370_(Minecraft.m_91087_().f_91062_, itemStack, n3, n4);
        }
    }

    @Override
    public boolean onMouseDown(Point point, int n) {
        StonecutterRecipe stonecutterRecipe = this.getRecipeAt(point);
        if (stonecutterRecipe != null) {
            this.encodingMenu.setStonecuttingRecipeId(stonecutterRecipe.m_6423_());
            Minecraft.m_91087_().m_91106_().m_120367_(SimpleSoundInstance.m_119752_(SoundEvents.f_12495_, 1.0f));
            return true;
        }
        return false;
    }

    @Override
    @Nullable
    public Tooltip getTooltip(int n, int n2) {
        StonecutterRecipe stonecutterRecipe = this.getRecipeAt(new Point(n, n2));
        if (stonecutterRecipe != null) {
            List<Component> list = this.parent.m_280553_(stonecutterRecipe.m_8043_(this.getRegistryAccess()));
            return new Tooltip(list);
        }
        return null;
    }

    @Nullable
    private StonecutterRecipe getRecipeAt(Point point) {
        List<StonecutterRecipe> list = this.encodingMenu.getStonecuttingRecipes();
        if (!list.isEmpty()) {
            int n = this.scrollbar.getCurrentScroll() * 4;
            int n2 = n + 12;
            for (int i = n; i < n2 && i < list.size(); ++i) {
                Rect2i rect2i = this.getRecipeBounds(i - n);
                if (!point.isIn(rect2i)) continue;
                return list.get(i);
            }
        }
        return null;
    }

    private Rect2i getRecipeBounds(int n) {
        int n2 = n % 4;
        int n3 = n / 4;
        int n4 = this.x + 44 + n2 * BG_SLOT.getSrcWidth();
        int n5 = this.y + 8 + n3 * BG_SLOT.getSrcHeight();
        return new Rect2i(n4, n5, BG_SLOT.getSrcWidth(), BG_SLOT.getSrcHeight());
    }

    @Override
    public boolean onMouseWheel(Point point, double d) {
        return this.scrollbar.onMouseWheel(point, d);
    }

    @Override
    public ItemStack getTabIconItem() {
        return new ItemStack(Items.f_42776_);
    }

    @Override
    public Component getTabTooltip() {
        return GuiText.StonecuttingPattern.text();
    }

    @Override
    public void setVisible(boolean bl) {
        super.setVisible(bl);
        this.scrollbar.setVisible(bl);
        this.parent.setSlotsHidden(SlotSemantics.STONECUTTING_INPUT, !bl);
    }
}

package com.gtolib.api.ae2.me2in1.encoding;

import appeng.api.config.ActionItems;
import appeng.client.Point;
import appeng.client.gui.style.Blitter;
import appeng.client.gui.widgets.ActionButton;
import appeng.client.gui.widgets.Scrollbar;
import appeng.core.localization.GuiText;
import appeng.menu.SlotSemantics;
import appeng.menu.slot.FakeSlot;
import com.gtolib.api.ae2.ModifyIcon;
import com.gtolib.api.ae2.ModifyIconButton;
import com.gtolib.api.ae2.me2in1.Me2in1Screen;
import com.gtolib.api.ae2.me2in1.UtilsMiscs;
import com.gtolib.api.ae2.me2in1.encoding.EncodingModePanel;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class ProcessingEncodingPanel
extends EncodingModePanel {
    private static final Blitter BG = Blitter.texture("guis/ex_encoding_modes.png").src(0, 70, 126, 68);
    protected final ActionButton cycleOutputBtn;
    protected final Scrollbar scrollbar;
    protected final ActionButton cycleInputBtn;
    protected final ModifyIconButton[] modifyButtons = new ModifyIconButton[6];
    protected final ModifyIconButton clearSecOutput;
    private static final int BG_X_OFFSET = 0;
    private static final int BG_Y_OFFSET = 0;
    private static final int CLR_BTN_X_OFFSET = 71;
    private static final int CLR_BTN_Y_OFFSET = 6;
    private static final int cycleI_X_OFFSET = 71;
    private static final int cycleI_Y_OFFSET = 17;
    private static final int cycleO_X_OFFSET = 119;
    private static final int cycleO_Y_OFFSET = 6;
    private static final int clearSecOutput_X_OFFSET = 119;
    private static final int clearSecOutput_Y_OFFSET = 17;
    private static final int SCROLLBAR_X = 8;
    private static final int SCROLLBAR_Y = 8;
    private static final int PROC_INPUT_X_OFFSET = 17;
    private static final int PROC_INPUT_Y_OFFSET = 8;
    private static final int PROC_OUTPUT_X_OFFSET = 101;
    private static final int PROC_OUTPUT_Y_OFFSET = 8;
    private static final int MUL_BTN_X_OFFSET = 91;
    private static final int DIV_BTN_X_OFFSET = 28;
    private static final int MUL_BTN_Y_OFFSET = 33;

    public ProcessingEncodingPanel(Me2in1Screen<?> me2in1Screen) {
        super(me2in1Screen);
        int[] nArray = new int[]{2, -2, 3, -3, 5, -5};
        for (int i = 0; i < this.modifyButtons.length; ++i) {
            int n = nArray[i];
            this.modifyButtons[i] = this.getMultiplyButton(n);
            me2in1Screen.getSubWidgets().put("modifyButton" + n + this.getClass().getSimpleName(), (AbstractWidget)((Object)this.modifyButtons[i]));
        }
        this.clearSecOutput = new ModifyIconButton(button -> this.menu.gtolib$clearSecOutput(), ModifyIcon.TOOLBAR_BUTTON_BACKGROUND, Component.m_237115_("gtocore.pattern.clearSecOutput"), Component.m_237115_("gtocore.pattern.tooltip.clearSecOutput"));
        me2in1Screen.getSubWidgets().put("clearSecOutput" + this.getClass().getSimpleName(), (AbstractWidget)((Object)this.clearSecOutput));
        this.cycleOutputBtn = new ActionButton(ActionItems.CYCLE_PROCESSING_OUTPUT, actionItems -> this.encodingMenu.cycleProcessingOutput());
        this.cycleOutputBtn.setHalfSize(true);
        me2in1Screen.getSubWidgets().put("cycleOutputBtn" + this.getClass().getSimpleName(), (AbstractWidget)((Object)this.cycleOutputBtn));
        this.cycleInputBtn = new ActionButton(ActionItems.CYCLE_PROCESSING_OUTPUT, actionItems -> this.encodingMenu.cycleProcessingInput());
        this.cycleInputBtn.setHalfSize(true);
        me2in1Screen.getSubWidgets().put("cycleInputBtn" + this.getClass().getSimpleName(), (AbstractWidget)((Object)this.cycleInputBtn));
        this.scrollbar = new Scrollbar(Scrollbar.SMALL);
        this.scrollbar.setRange(0, this.encodingMenu.getProcessingInputSlots().length / 3 - 3, 3);
        this.scrollbar.setCaptureMouseWheel(false);
    }

    @Override
    public void updateBeforeRender() {
        int n;
        int n2;
        this.clearBtn.m_264152_(this.getGuiLeft() + this.x + 71, this.y + 6 + this.getGuiTop());
        AtomicInteger atomicInteger = new AtomicInteger(0);
        for (ModifyIconButton modifyIconButton : this.modifyButtons) {
            modifyIconButton.m_264152_(this.x + this.getGuiLeft() + 91 + (atomicInteger.get() % 2 == 0 ? 0 : 28), this.y + this.getGuiTop() + 33 + atomicInteger.getAndIncrement() / 2 * 11);
        }
        this.clearSecOutput.m_264152_(this.getGuiLeft() + this.x + 119, this.y + 17 + this.getGuiTop());
        this.cycleOutputBtn.m_264152_(this.getGuiLeft() + this.x + 119, this.y + 6 + this.getGuiTop());
        this.cycleInputBtn.m_264152_(this.getGuiLeft() + this.x + 71, this.y + 17 + this.getGuiTop());
        this.scrollbar.setPosition(new Point(this.x + 8, this.y + 8));
        this.scrollbar.setSize(18, 52);
        for (n2 = 0; n2 < this.encodingMenu.getProcessingInputSlots().length; ++n2) {
            FakeSlot fakeSlot = this.encodingMenu.getProcessingInputSlots()[n2];
            n = n2 / 3 - this.scrollbar.getCurrentScroll();
            fakeSlot.setActive(n >= 0 && n < 3);
            UtilsMiscs.setSlotPos(fakeSlot, this.x + n2 % 3 * 18 + 17, -this.scrollbar.getCurrentScroll() * 18 + n2 / 3 * 18 + this.y + 8);
        }
        for (n2 = 0; n2 < this.encodingMenu.getProcessingOutputSlots().length; ++n2) {
            FakeSlot fakeSlot = this.encodingMenu.getProcessingOutputSlots()[n2];
            n = n2 - this.scrollbar.getCurrentScroll();
            fakeSlot.setActive(n >= 0 && n < 3);
            UtilsMiscs.setSlotPos(fakeSlot, this.x + 101, -this.scrollbar.getCurrentScroll() * 18 + n2 * 18 + this.y + 8);
        }
    }

    @Override
    public void drawBackgroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
        super.drawBackgroundLayer(guiGraphics, rect2i, point);
        BG.dest(this.x + rect2i.m_110085_() + 0, this.y + rect2i.m_110086_() + 0).blit(guiGraphics);
        this.scrollbar.drawBackgroundLayer(guiGraphics, rect2i, point);
    }

    @Override
    public void drawForegroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
        super.drawForegroundLayer(guiGraphics, rect2i, point);
        this.scrollbar.drawForegroundLayer(guiGraphics, rect2i, point);
    }

    @Override
    public boolean onMouseWheel(Point point, double d2) {
        return this.scrollbar.onMouseWheel(point, d2);
    }

    @Override
    public ItemStack getTabIconItem() {
        return Items.f_41962_.m_7968_();
    }

    @Override
    public Component getTabTooltip() {
        return GuiText.ProcessingPattern.text();
    }

    @Override
    public void setVisible(boolean bl) {
        super.setVisible(bl);
        this.scrollbar.setVisible(bl);
        this.cycleOutputBtn.setVisibility(bl && this.encodingMenu.canCycleProcessingOutputs());
        this.cycleInputBtn.setVisibility(bl && this.encodingMenu.canCycleProcessingInputs());
        for (ModifyIconButton modifyIconButton : this.modifyButtons) {
            modifyIconButton.setVisibility(bl);
        }
        this.clearSecOutput.setVisibility(bl && this.encodingMenu.canCycleProcessingOutputs());
        this.parent.setSlotsHidden(SlotSemantics.PROCESSING_INPUTS, !bl);
        this.parent.setSlotsHidden(SlotSemantics.PROCESSING_OUTPUTS, !bl);
    }

    private ModifyIconButton getMultiplyButton(int n) {
        String string = n < 0 ? "divide" : "multiply";
        int n2 = Math.abs(n);
        return new ModifyIconButton(button -> this.menu.gtolib$modifyPatter(n), ModifyIcon.getBy(n), Component.m_237110_("gtocore.pattern." + string, new Object[]{n2}), Component.m_237110_("gtocore.pattern.tooltip." + string, new Object[]{n2}));
    }
}

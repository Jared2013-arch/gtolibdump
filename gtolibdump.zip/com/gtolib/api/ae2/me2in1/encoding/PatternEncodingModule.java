package com.gtolib.api.ae2.me2in1.encoding;

import appeng.api.behaviors.ContainerItemStrategies;
import appeng.api.behaviors.EmptyingAction;
import appeng.api.stacks.GenericStack;
import appeng.client.Point;
import appeng.client.gui.AEBaseScreen;
import appeng.client.gui.Tooltip;
import appeng.client.gui.WidgetContainer;
import appeng.core.AEConfig;
import appeng.core.localization.ButtonToolTips;
import appeng.core.localization.Tooltips;
import com.gtolib.ae2.me2in1.b;
import com.gtolib.ae2.me2in1.panel.a;
import com.gtolib.ae2.me2in1.panel.c;
import com.gtolib.api.ae2.gui.hooks.IStylelessCompositeWidget;
import com.gtolib.api.ae2.me2in1.Me2in1Menu;
import com.gtolib.api.ae2.me2in1.Me2in1Screen;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;
import vazkii.botania.mixin.client.AbstractContainerScreenAccessor;

public class PatternEncodingModule
implements IStylelessCompositeWidget {
    private final Me2in1Screen<?> screen;
    private final a bufferPanel;
    private final c modePanel;

    public PatternEncodingModule(Me2in1Screen<?> me2in1Screen) {
        this.screen = me2in1Screen;
        this.modePanel = new c(me2in1Screen);
        this.bufferPanel = new a(me2in1Screen);
    }

    private b getEncodingMenu() {
        return ((Me2in1Menu)this.screen.m_6262_()).getEncoding();
    }

    @Override
    public void initialize(String string, WidgetContainer widgetContainer) {
        widgetContainer.add(string + "_encodePanel", this.modePanel);
        widgetContainer.add(string + "_bufferPanel", this.bufferPanel);
    }

    @Override
    public AEBaseScreen<?> getScreen() {
        return this.screen;
    }

    @Override
    public void setPosition(Point point) {
    }

    public void setSize(int n, int n2) {
    }

    @Override
    public Rect2i getBounds() {
        return new Rect2i(0, 0, 126, 68);
    }

    @Override
    @Nullable
    public Tooltip getTooltip(int n, int n2) {
        Slot slot = ((AbstractContainerScreenAccessor)((Object)this.screen)).getHoveredSlot();
        if (((Me2in1Menu)this.screen.m_6262_()).m_142621_().m_41619_() && this.getEncodingMenu().canModifyAmountForSlot(slot)) {
            ObjectArrayList objectArrayList = new ObjectArrayList(this.screen.m_280553_(slot.m_7993_()));
            GenericStack genericStack = GenericStack.fromItemStack(slot.m_7993_());
            if (genericStack != null) {
                objectArrayList.add(Tooltips.getAmountTooltip(ButtonToolTips.Amount, genericStack));
            }
            objectArrayList.add(Tooltips.getSetAmountTooltip());
            return new Tooltip(objectArrayList);
        }
        return null;
    }

    @Nullable
    public EmptyingAction getEmptyingAction(Slot slot, ItemStack itemStack) {
        if (this.getEncodingMenu().isProcessingPatternSlot(slot)) {
            return ContainerItemStrategies.getEmptyingAction(itemStack);
        }
        return null;
    }

    public List<Component> getTooltipFromContainerItem(ItemStack itemStack) {
        ObjectArrayList objectArrayList = new ObjectArrayList();
        Slot slot = ((AbstractContainerScreenAccessor)((Object)this.screen)).getHoveredSlot();
        if (slot != null && this.screen.shouldShowCraftableIndicatorForSlot(slot)) {
            objectArrayList = new ObjectArrayList(objectArrayList);
            objectArrayList.add(ButtonToolTips.Craftable.text().m_130940_(ChatFormatting.DARK_GRAY));
        }
        return objectArrayList;
    }

    public void onClose() {
        if (AEConfig.instance().isClearGridOnClose()) {
            this.getEncodingMenu().clear();
            this.getEncodingMenu().clearFilter();
        }
    }

    public void receiveS2CPanelUpdate() {
        ((Me2in1Menu)this.screen.m_6262_()).receiveS2CPanelUpdate(this.bufferPanel);
        ((Me2in1Menu)this.screen.m_6262_()).receiveS2CPanelUpdate(this.modePanel);
    }

    public void resetPanelPosition() {
        this.bufferPanel.i();
        this.modePanel.i();
    }
}

package com.gtolib.api.ae2.me2in1.encoding;

public enum ExtendedEncodingMode {
    CRAFTING(true),
    PROCESSING(false),
    SMITHING_TABLE(true),
    STONECUTTING(true),
    BATCH(false);

    public final boolean certernRecipe;

    private ExtendedEncodingMode(boolean bl) {
        this.certernRecipe = bl;
    }
}

package com.gtolib.api.ae2.me2in1.encoding;

import appeng.api.config.ActionItems;
import appeng.client.Point;
import appeng.client.gui.AEBaseScreen;
import appeng.client.gui.Icon;
import appeng.client.gui.WidgetContainer;
import appeng.client.gui.style.Blitter;
import appeng.client.gui.widgets.ActionButton;
import appeng.client.gui.widgets.ToggleButton;
import appeng.core.localization.ButtonToolTips;
import com.gtolib.ae2.me2in1.b;
import com.gtolib.api.ae2.gui.hooks.IStylelessCompositeWidget;
import com.gtolib.api.ae2.me2in1.Me2in1Menu;
import com.gtolib.api.ae2.me2in1.Me2in1Screen;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

public abstract class EncodingModePanel
implements IStylelessCompositeWidget {
    private static final Blitter FRAME = Blitter.texture("guis/encoding_module.png").src(0, 0, 140, 86);
    protected final ActionButton clearBtn;
    protected final b encodingMenu;
    protected final Me2in1Menu menu;
    protected final Me2in1Screen<?> parent;
    protected boolean visible = false;
    protected int x;
    protected int y;
    private static final int BG_X_OFFSET = -9;
    private static final int BG_Y_OFFSET = -12;

    public EncodingModePanel(Me2in1Screen<?> me2in1Screen) {
        this.parent = me2in1Screen;
        this.menu = (Me2in1Menu)me2in1Screen.m_6262_();
        this.encodingMenu = this.menu.getEncoding();
        this.clearBtn = new ActionButton(ActionItems.CLOSE, actionItems -> this.encodingMenu.clear());
        this.clearBtn.setHalfSize(true);
        me2in1Screen.getSubWidgets().put("clearBtn" + this.getClass().getSimpleName(), (AbstractWidget)((Object)this.clearBtn));
    }

    public abstract ItemStack getTabIconItem();

    public abstract Component getTabTooltip();

    @Override
    public void setPosition(Point point) {
        this.x = point.getX();
        this.y = point.getY();
    }

    @Override
    public void drawBackgroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
        FRAME.dest(this.x + rect2i.m_110085_() + -9, this.y + rect2i.m_110086_() + -12).blit(guiGraphics);
    }

    public void setSize(int n, int n2) {
    }

    @Override
    public Rect2i getBounds() {
        return new Rect2i(this.x, this.y, 126, 68);
    }

    public void setVisible(boolean bl) {
        this.visible = bl;
        this.clearBtn.setVisibility(bl);
    }

    public boolean isVisible() {
        return this.visible;
    }

    @Override
    public void initialize(String string, WidgetContainer widgetContainer) {
    }

    @Override
    public AEBaseScreen<?> getScreen() {
        return this.parent;
    }

    protected ToggleButton createSubstitutionButton() {
        ToggleButton toggleButton = new ToggleButton(Icon.SUBSTITUTION_ENABLED, Icon.SUBSTITUTION_DISABLED, this.encodingMenu::setSubstitute);
        toggleButton.setHalfSize(true);
        toggleButton.setTooltipOn(List.of((Object)ButtonToolTips.SubstitutionsOn.text(), (Object)ButtonToolTips.SubstitutionsDescEnabled.text()));
        toggleButton.setTooltipOff(List.of((Object)ButtonToolTips.SubstitutionsOff.text(), (Object)ButtonToolTips.SubstitutionsDescDisabled.text()));
        return toggleButton;
    }
}

package com.gtolib.api.ae2.me2in1;

import java.util.Map;
import net.minecraft.client.gui.components.AbstractWidget;

public interface Me2in1Screen$INeedsInit {
    public void onInitPre(Map<String, AbstractWidget> var1);

    public void onInitPost();

    public boolean isVisible();
}

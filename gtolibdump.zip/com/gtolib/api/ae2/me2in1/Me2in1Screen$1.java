package com.gtolib.api.ae2.me2in1;

import appeng.client.gui.Icon;
import appeng.client.gui.widgets.IconButton;
import java.util.List;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

class Me2in1Screen$1
extends IconButton {
    Me2in1Screen$1(Button.OnPress onPress) {
        super(onPress);
    }

    protected Icon getIcon() {
        return Icon.SCHEDULING_DEFAULT;
    }

    public List<Component> getTooltipMessage() {
        return List.of((Object)Component.m_237115_("gtocore.ae.appeng.me2in1.reset_panel_position"), (Object)Component.m_237115_("gtocore.ae.appeng.me2in1.reset_panel_position.1"));
    }
}

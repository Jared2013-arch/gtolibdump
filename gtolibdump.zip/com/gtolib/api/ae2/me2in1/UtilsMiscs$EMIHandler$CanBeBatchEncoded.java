package com.gtolib.api.ae2.me2in1;

import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import appeng.integration.modules.jeirei.TransferHelper;
import appeng.menu.AEBaseMenu;
import com.gregtechceu.gtceu.common.data.GTMaterials;
import com.gtolib.utils.AEChemicalHelper;
import com.hepdd.ae2emicraftingforge.client.helper.mapper.EmiStackHelper;
import com.hepdd.ae2emicraftingforge.client.helper.rendering.Rendering;
import com.hepdd.ae2emicraftingforge.client.helper.rendering.Result;
import com.mojang.blaze3d.vertex.PoseStack;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.handler.EmiCraftContext;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.Bounds;
import dev.emi.emi.api.widget.SlotWidget;
import dev.emi.emi.api.widget.Widget;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import java.util.Set;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

class UtilsMiscs$EMIHandler$CanBeBatchEncoded
extends Result {
    private final Set<AEKey> craftableKeys;

    public UtilsMiscs$EMIHandler$CanBeBatchEncoded(Set<AEKey> set) {
        this.craftableKeys = set;
    }

    public boolean canCraft() {
        return true;
    }

    public List<Component> getTooltip(EmiRecipe emiRecipe, EmiCraftContext<?> emiCraftContext) {
        boolean bl;
        boolean bl2 = emiRecipe.getInputs().stream().anyMatch(emiIngredient -> UtilsMiscs$EMIHandler$CanBeBatchEncoded.isCraftable(this.craftableKeys, emiIngredient));
        List list = bl2 ? TransferHelper.createEncodingTooltip((boolean)true) : new ObjectArrayList();
        boolean bl3 = emiRecipe.getInputs().stream().anyMatch(emiIngredient -> emiIngredient.getEmiStacks().stream().anyMatch(UtilsMiscs$EMIHandler$CanBeBatchEncoded::hasGTMaterial));
        boolean bl4 = bl = !emiRecipe.getCatalysts().isEmpty();
        if (bl) {
            list.add(Component.m_237115_("gtocore.ae.appeng.me2in1.emi.catalyst").m_130940_(ChatFormatting.AQUA));
            list.add(Component.m_237115_("gtocore.ae.appeng.me2in1.emi.catalyst.fill").m_130940_(ChatFormatting.GREEN));
            list.add(Component.m_237115_("gtocore.ae.appeng.me2in1.emi.catalyst.virtual").m_130940_(ChatFormatting.DARK_GREEN));
        }
        if (bl3) {
            list.add(Component.m_237115_("gtocore.ae.appeng.me2in1.emi.gt_batch_encode").m_130940_(ChatFormatting.YELLOW));
            list.add(Component.m_237115_("gtocore.ae.appeng.me2in1.emi.gt_batch_encode.1").m_130940_(ChatFormatting.GRAY));
        }
        return list.isEmpty() ? null : list;
    }

    public void render(EmiRecipe emiRecipe, EmiCraftContext<? extends AEBaseMenu> emiCraftContext, List<Widget> list, GuiGraphics guiGraphics) {
        for (Widget widget : list) {
            SlotWidget slotWidget;
            if (widget instanceof SlotWidget && Rendering.isInputSlot((SlotWidget)(slotWidget = (SlotWidget)widget)) && UtilsMiscs$EMIHandler$CanBeBatchEncoded.isCraftable(this.craftableKeys, slotWidget.getStack())) {
                UtilsMiscs$EMIHandler$CanBeBatchEncoded.renderSlotOverlay(guiGraphics, slotWidget, 0x400000FF);
            }
            if (!(widget instanceof SlotWidget) || !(slotWidget = (SlotWidget)widget).getStack().getEmiStacks().stream().anyMatch(UtilsMiscs$EMIHandler$CanBeBatchEncoded::hasGTMaterial)) continue;
            UtilsMiscs$EMIHandler$CanBeBatchEncoded.renderSlotOverlay(guiGraphics, slotWidget, 0x66FFFF00);
        }
    }

    private static boolean isCraftable(Set<AEKey> set, EmiIngredient emiIngredient) {
        return emiIngredient.getEmiStacks().stream().anyMatch(emiStack -> {
            GenericStack genericStack = EmiStackHelper.toGenericStack(emiStack);
            return genericStack != null && set.contains(genericStack.what());
        });
    }

    private static void renderSlotOverlay(GuiGraphics guiGraphics, SlotWidget slotWidget, int n) {
        PoseStack poseStack = guiGraphics.m_280168_();
        poseStack.m_85836_();
        poseStack.m_252880_(0.0f, 0.0f, 400.0f);
        Bounds bounds = Rendering.getInnerBounds((SlotWidget)slotWidget);
        guiGraphics.m_280509_(bounds.x(), bounds.y(), bounds.right(), bounds.bottom(), n);
        poseStack.m_85849_();
    }

    private static boolean hasGTMaterial(EmiStack emiStack) {
        return EmiStackHelper.toGenericStack(emiStack) != null && AEChemicalHelper.getMaterial(EmiStackHelper.toGenericStack(emiStack).what()) != GTMaterials.NULL;
    }
}

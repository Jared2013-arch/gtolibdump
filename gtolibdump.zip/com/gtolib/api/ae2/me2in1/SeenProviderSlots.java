package com.gtolib.api.ae2.me2in1;

import appeng.client.gui.me.patternaccess.PatternSlot;
import appeng.menu.guisync.PacketWritable;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import net.minecraft.network.FriendlyByteBuf;

public class SeenProviderSlots
implements PacketWritable {
    private List<Integer> machineSlotIndex;
    private List<Long> machineSlotServerId;

    public SeenProviderSlots() {
        this.machineSlotIndex = new ObjectArrayList();
        this.machineSlotServerId = new ObjectArrayList();
    }

    public SeenProviderSlots(FriendlyByteBuf friendlyByteBuf) {
        int n = friendlyByteBuf.readInt();
        this.machineSlotIndex = new ObjectArrayList(n);
        this.machineSlotServerId = new ObjectArrayList(n);
        for (int i = 0; i < n; ++i) {
            this.machineSlotIndex.add(friendlyByteBuf.readInt());
            this.machineSlotServerId.add(friendlyByteBuf.readLong());
        }
    }

    public List<Integer> getMachineSlotIndex() {
        return this.machineSlotIndex;
    }

    public void setMachineSlotIndex(List<Integer> list) {
        this.machineSlotIndex = list;
    }

    public List<Long> getMachineSlotServerId() {
        return this.machineSlotServerId;
    }

    public void setMachineSlotServerId(List<Long> list) {
        this.machineSlotServerId = list;
    }

    public void add(PatternSlot patternSlot) {
        this.machineSlotIndex.add(patternSlot.getSlotIndex());
        this.machineSlotServerId.add(patternSlot.getMachineInv().getServerId());
    }

    public void combine(SeenProviderSlots seenProviderSlots) {
        this.machineSlotIndex.addAll(seenProviderSlots.getMachineSlotIndex());
        this.machineSlotServerId.addAll(seenProviderSlots.getMachineSlotServerId());
    }

    public void writeToPacket(FriendlyByteBuf friendlyByteBuf) {
        int n = this.machineSlotIndex.size();
        friendlyByteBuf.writeInt(n);
        for (int i = 0; i < n; ++i) {
            friendlyByteBuf.writeInt(this.machineSlotIndex.get(i));
            friendlyByteBuf.writeLong(this.machineSlotServerId.get(i));
        }
    }
}

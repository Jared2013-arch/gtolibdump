package com.gtolib.api.ae2.me2in1;

import com.gtolib.api.ae2.me2in1.encoding.ExtendedEncodingMode;

class ExtendedEncodingMenu$1 {
    static final int[] $SwitchMap$com$gtolib$api$ae2$me2in1$encoding$ExtendedEncodingMode;

    static {
        $SwitchMap$com$gtolib$api$ae2$me2in1$encoding$ExtendedEncodingMode = new int[ExtendedEncodingMode.values().length];
        try {
            ExtendedEncodingMenu$1.$SwitchMap$com$gtolib$api$ae2$me2in1$encoding$ExtendedEncodingMode[ExtendedEncodingMode.CRAFTING.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ExtendedEncodingMenu$1.$SwitchMap$com$gtolib$api$ae2$me2in1$encoding$ExtendedEncodingMode[ExtendedEncodingMode.PROCESSING.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ExtendedEncodingMenu$1.$SwitchMap$com$gtolib$api$ae2$me2in1$encoding$ExtendedEncodingMode[ExtendedEncodingMode.SMITHING_TABLE.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ExtendedEncodingMenu$1.$SwitchMap$com$gtolib$api$ae2$me2in1$encoding$ExtendedEncodingMode[ExtendedEncodingMode.STONECUTTING.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ExtendedEncodingMenu$1.$SwitchMap$com$gtolib$api$ae2$me2in1$encoding$ExtendedEncodingMode[ExtendedEncodingMode.BATCH.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

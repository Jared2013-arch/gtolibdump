package com.gtolib.api.ae2;

public enum BlockingType {
    NONE,
    ALL,
    CONTAIN,
    NON_CONTAIN,
    PARALLEL;

}

package com.gtolib.api.ae2;

import appeng.api.stacks.AEKeyType;
import com.gtolib.api.ae2.AEKeyTypeMap;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.jetbrains.annotations.NotNull;

class AEKeyTypeMap$EntrySet
implements Set<Map.Entry<AEKeyType, T>> {
    private AEKeyTypeMap$EntrySet() {
    }

    @Override
    public int size() {
        boolean bl;
        boolean bl2 = AEKeyTypeMap.this.item != null;
        boolean bl3 = bl = AEKeyTypeMap.this.fluid != null;
        return bl2 && bl ? 2 : (bl2 || bl ? 1 : 0);
    }

    @Override
    public boolean isEmpty() {
        return AEKeyTypeMap.this.item == null && AEKeyTypeMap.this.fluid == null;
    }

    @Override
    public boolean contains(Object object) {
        throw new UnsupportedOperationException();
    }

    @Override
    @NotNull
    public Iterator<Map.Entry<AEKeyType, T>> iterator() {
        boolean bl;
        boolean bl2 = AEKeyTypeMap.this.item != null;
        boolean bl3 = bl = AEKeyTypeMap.this.fluid != null;
        if (!bl2 && !bl) {
            return Collections.emptyIterator();
        }
        if (AEKeyTypeMap.this.entryIterator == null) {
            AEKeyTypeMap.this.entryIterator = new AEKeyTypeMap.EntryIterator(AEKeyTypeMap.this);
        }
        AEKeyTypeMap.this.entryIterator.hasNext = true;
        AEKeyTypeMap.this.entryIterator.complete = bl2 && bl;
        return AEKeyTypeMap.this.entryIterator;
    }

    @Override
    @NotNull
    public @NotNull Object @NotNull [] toArray() {
        throw new UnsupportedOperationException();
    }

    @Override
    @NotNull
    public <O> @NotNull O @NotNull [] toArray(@NotNull @NotNull O @NotNull [] OArray) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean add(Map.Entry<AEKeyType, T> entry) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean remove(Object object) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean containsAll(@NotNull Collection<?> collection) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean addAll(@NotNull Collection<? extends Map.Entry<AEKeyType, T>> collection) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean retainAll(@NotNull Collection<?> collection) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean removeAll(@NotNull Collection<?> collection) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void clear() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean equals(Object object) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int hashCode() {
        throw new UnsupportedOperationException();
    }
}

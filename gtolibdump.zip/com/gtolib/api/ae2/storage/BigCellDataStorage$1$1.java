// ERROR: Unable to apply inner class name fixup
package com.gtolib.api.ae2.storage;

import appeng.api.stacks.AEKey;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import java.math.BigInteger;

class BigCellDataStorage.1
extends O2OOpenCacheHashMap<AEKey, BigInteger> {
    BigCellDataStorage.1() {
    }

    public BigInteger put(AEKey aEKey, BigInteger bigInteger) {
        return BigInteger.ZERO;
    }

    @Override
    public BigInteger get(Object object) {
        return BigInteger.ZERO;
    }
}

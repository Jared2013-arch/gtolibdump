package com.gtolib.api.ae2.storage;

import appeng.api.stacks.AEKey;
import appeng.api.stacks.KeyCounter;
import com.gregtechceu.gtceu.utils.collection.O2LOpenCacheHashMap;
import com.gtolib.b.a;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import it.unimi.dsi.fastutil.objects.Object2LongOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import org.jetbrains.annotations.NotNull;

public class CellDataStorage {
    static final ListTag EMPTY_LISTTAG = new ListTag();
    public static final CellDataStorage EMPTY = new CellDataStorage(){
        private static final Object2LongOpenHashMap<AEKey> EMPTY_MAP = new O2LOpenCacheHashMap<AEKey>(){

            public long put(AEKey aEKey, long l) {
                return 0L;
            }

            @Override
            public long getLong(Object object) {
                return 0L;
            }

            public boolean remove(Object object, long l) {
                return false;
            }
        };

        @Override
        public ListTag getKeys() {
            return EMPTY_LISTTAG;
        }

        @Override
        public long[] getAmounts() {
            return new long[0];
        }

        @Override
        public double getBytes() {
            return 0.0;
        }

        @Override
        public boolean isPersisted() {
            return true;
        }

        @Override
        public Object2LongOpenHashMap<AEKey> getStoredMap() {
            return EMPTY_MAP;
        }
    };
    private ListTag keys;
    private long[] amounts;
    private double bytes;
    private boolean isPersisted;
    private Object2LongOpenHashMap<AEKey> storedMap;
    private KeyCounter keyCounter;

    public static void setDirty() {
        a.a.m_77760_(true);
    }

    public static void remove(@NotNull UUID uUID) {
        a.a.a(uUID);
    }

    public static CellDataStorage get(@NotNull UUID uUID) {
        return a.a.c(uUID);
    }

    public CellDataStorage() {
        this(EMPTY_LISTTAG, new long[0]);
    }

    private CellDataStorage(ListTag listTag, long[] lArray) {
        this.keys = listTag;
        this.amounts = lArray;
    }

    public CompoundTag toNbt() {
        if (this == EMPTY) {
            return null;
        }
        if (!this.isPersisted && this.storedMap != null) {
            double d = 0.0;
            LongArrayList longArrayList = new LongArrayList(this.storedMap.size());
            ListTag listTag = new ListTag();
            ObjectIterator objectIterator = this.storedMap.object2LongEntrySet().fastIterator();
            while (objectIterator.hasNext()) {
                Object2LongMap.Entry entry = (Object2LongMap.Entry)objectIterator.next();
                long l = entry.getLongValue();
                if (l <= 0L) continue;
                AEKey aEKey = (AEKey)entry.getKey();
                d += (double)l / (double)aEKey.getType().getAmountPerByte();
                listTag.add(aEKey.toTagGeneric());
                longArrayList.add(l);
            }
            this.setPersisted(true);
            this.setAmounts(longArrayList.toArray(new long[0]));
            this.setKeys(listTag);
            this.setBytes(d);
        }
        if (this.amounts.length == 0 || this.keys.isEmpty()) {
            return null;
        }
        CompoundTag compoundTag = new CompoundTag();
        compoundTag.m_128365_("k", this.keys);
        compoundTag.m_128388_("a", this.amounts);
        return compoundTag;
    }

    public static CellDataStorage fromNbt(CompoundTag compoundTag) {
        ListTag listTag = compoundTag.m_128437_("k", 10);
        long[] lArray = compoundTag.m_128467_("a");
        return new CellDataStorage(listTag, lArray);
    }

    public void setKeys(ListTag listTag) {
        this.keys = listTag;
    }

    public void setAmounts(long[] lArray) {
        this.amounts = lArray;
    }

    public void setBytes(double d) {
        this.bytes = d;
    }

    public void setPersisted(boolean bl) {
        this.isPersisted = bl;
    }

    public void setStoredMap(Object2LongOpenHashMap<AEKey> object2LongOpenHashMap) {
        this.storedMap = object2LongOpenHashMap;
    }

    public void setKeyCounter(KeyCounter keyCounter) {
        this.keyCounter = keyCounter;
    }

    public ListTag getKeys() {
        return this.keys;
    }

    public long[] getAmounts() {
        return this.amounts;
    }

    public double getBytes() {
        return this.bytes;
    }

    public boolean isPersisted() {
        return this.isPersisted;
    }

    public Object2LongOpenHashMap<AEKey> getStoredMap() {
        return this.storedMap;
    }

    public KeyCounter getKeyCounter() {
        return this.keyCounter;
    }
}

package com.gtolib.api.ae2.storage;

import appeng.api.stacks.AEKey;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtolib.api.ae2.storage.BigCellDataStorage;
import com.gtolib.api.ae2.storage.CellDataStorage;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.math.BigInteger;
import net.minecraft.nbt.ListTag;

class BigCellDataStorage$1
extends BigCellDataStorage {
    private static final Object2ObjectOpenHashMap<AEKey, BigInteger> EMPTY_MAP = new O2OOpenCacheHashMap<AEKey, BigInteger>(){

        public BigInteger put(AEKey aEKey, BigInteger bigInteger) {
            return BigInteger.ZERO;
        }

        @Override
        public BigInteger get(Object object) {
            return BigInteger.ZERO;
        }
    };

    BigCellDataStorage$1() {
    }

    @Override
    public ListTag getKeys() {
        return CellDataStorage.EMPTY_LISTTAG;
    }

    @Override
    public ListTag getAmounts() {
        return CellDataStorage.EMPTY_LISTTAG;
    }

    @Override
    public double getBytes() {
        return 0.0;
    }

    @Override
    public boolean isPersisted() {
        return true;
    }

    @Override
    public Object2ObjectOpenHashMap<AEKey, BigInteger> getStoredMap() {
        return EMPTY_MAP;
    }
}

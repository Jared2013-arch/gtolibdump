// ERROR: Unable to apply inner class name fixup
package com.gtolib.api.ae2.storage;

import appeng.api.stacks.AEKey;
import com.gregtechceu.gtceu.utils.collection.O2LOpenCacheHashMap;

class CellDataStorage.1
extends O2LOpenCacheHashMap<AEKey> {
    CellDataStorage.1() {
    }

    public long put(AEKey aEKey, long l) {
        return 0L;
    }

    @Override
    public long getLong(Object object) {
        return 0L;
    }

    public boolean remove(Object object, long l) {
        return false;
    }
}

package com.gtolib.api.ae2.storage;

import appeng.api.stacks.AEKey;
import appeng.api.stacks.KeyCounter;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtolib.api.ae2.storage.CellDataStorage;
import com.gtolib.b.a;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.math.BigInteger;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import org.jetbrains.annotations.NotNull;

public class BigCellDataStorage {
    public static final BigCellDataStorage EMPTY = new BigCellDataStorage(){
        private static final Object2ObjectOpenHashMap<AEKey, BigInteger> EMPTY_MAP = new O2OOpenCacheHashMap<AEKey, BigInteger>(){

            public BigInteger put(AEKey aEKey, BigInteger bigInteger) {
                return BigInteger.ZERO;
            }

            @Override
            public BigInteger get(Object object) {
                return BigInteger.ZERO;
            }
        };

        @Override
        public ListTag getKeys() {
            return CellDataStorage.EMPTY_LISTTAG;
        }

        @Override
        public ListTag getAmounts() {
            return CellDataStorage.EMPTY_LISTTAG;
        }

        @Override
        public double getBytes() {
            return 0.0;
        }

        @Override
        public boolean isPersisted() {
            return true;
        }

        @Override
        public Object2ObjectOpenHashMap<AEKey, BigInteger> getStoredMap() {
            return EMPTY_MAP;
        }
    };
    private ListTag keys;
    private ListTag amounts;
    private double bytes;
    private boolean isPersisted;
    private Object2ObjectOpenHashMap<AEKey, BigInteger> storedMap;
    private KeyCounter keyCounter;

    public static void remove(@NotNull UUID uUID) {
        a.a.b(uUID);
    }

    public static BigCellDataStorage get(@NotNull UUID uUID) {
        return a.a.d(uUID);
    }

    public BigCellDataStorage() {
        this(CellDataStorage.EMPTY_LISTTAG, CellDataStorage.EMPTY_LISTTAG);
    }

    private BigCellDataStorage(ListTag listTag, ListTag listTag2) {
        this.keys = listTag;
        this.amounts = listTag2;
    }

    public CompoundTag toNbt() {
        if (this == EMPTY) {
            return null;
        }
        if (!this.isPersisted && this.storedMap != null) {
            double d = 0.0;
            ListTag listTag = new ListTag();
            ListTag listTag2 = new ListTag();
            ObjectIterator objectIterator = this.storedMap.object2ObjectEntrySet().fastIterator();
            while (objectIterator.hasNext()) {
                Object2ObjectMap.Entry entry = (Object2ObjectMap.Entry)objectIterator.next();
                BigInteger bigInteger = (BigInteger)entry.getValue();
                if (bigInteger.signum() <= 0) continue;
                AEKey aEKey = (AEKey)entry.getKey();
                d += bigInteger.doubleValue() / (double)aEKey.getType().getAmountPerByte();
                listTag2.add(aEKey.toTagGeneric());
                listTag.add(StringTag.m_129297_(bigInteger.toString()));
            }
            this.setPersisted(true);
            this.setAmounts(listTag);
            this.setKeys(listTag2);
            this.setBytes(d);
        }
        if (this.amounts.isEmpty() || this.keys.isEmpty()) {
            return null;
        }
        CompoundTag compoundTag = new CompoundTag();
        compoundTag.m_128365_("k", this.keys);
        compoundTag.m_128365_("a", this.amounts);
        return compoundTag;
    }

    public static BigCellDataStorage fromNbt(CompoundTag compoundTag) {
        ListTag listTag = compoundTag.m_128437_("k", 10);
        ListTag listTag2 = compoundTag.m_128437_("a", 8);
        return new BigCellDataStorage(listTag, listTag2);
    }

    public void setKeys(ListTag listTag) {
        this.keys = listTag;
    }

    public void setAmounts(ListTag listTag) {
        this.amounts = listTag;
    }

    public void setBytes(double d) {
        this.bytes = d;
    }

    public void setPersisted(boolean bl) {
        this.isPersisted = bl;
    }

    public void setStoredMap(Object2ObjectOpenHashMap<AEKey, BigInteger> object2ObjectOpenHashMap) {
        this.storedMap = object2ObjectOpenHashMap;
    }

    public void setKeyCounter(KeyCounter keyCounter) {
        this.keyCounter = keyCounter;
    }

    public ListTag getKeys() {
        return this.keys;
    }

    public ListTag getAmounts() {
        return this.amounts;
    }

    public double getBytes() {
        return this.bytes;
    }

    public boolean isPersisted() {
        return this.isPersisted;
    }

    public Object2ObjectOpenHashMap<AEKey, BigInteger> getStoredMap() {
        return this.storedMap;
    }

    public KeyCounter getKeyCounter() {
        return this.keyCounter;
    }
}

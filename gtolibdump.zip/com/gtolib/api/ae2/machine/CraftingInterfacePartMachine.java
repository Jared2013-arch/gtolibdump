package com.gtolib.api.ae2.machine;

import appeng.api.networking.GridHelper;
import appeng.api.networking.IManagedGridNode;
import appeng.api.networking.events.GridCraftingCpuChange;
import appeng.api.networking.security.IActionHost;
import appeng.me.cluster.implementations.CraftingCPUCluster;
import appeng.me.helpers.MachineSource;
import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.machine.ConditionalSubscriptionHandler;
import com.gregtechceu.gtceu.api.machine.feature.IMachineLife;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiController;
import com.gregtechceu.gtceu.api.machine.multiblock.part.MultiblockPartMachine;
import com.gregtechceu.gtceu.integration.ae2.machine.feature.IGridConnectedMachine;
import com.gregtechceu.gtceu.integration.ae2.machine.trait.GridNodeHolder;
import com.gtolib.api.ae2.crafting.ICraftingCPUCluster;
import com.gtolib.api.ae2.machine.MECPUMachine;
import com.lowdragmc.lowdraglib.syncdata.annotation.Persisted;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedFieldHolder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Objects;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.NotNull;

public class CraftingInterfacePartMachine
extends MultiblockPartMachine
implements IActionHost,
IMachineLife,
IGridConnectedMachine {
    private static final ManagedFieldHolder MANAGED_FIELD_HOLDER = new ManagedFieldHolder(CraftingInterfacePartMachine.class, MultiblockPartMachine.MANAGED_FIELD_HOLDER);
    @Persisted
    private final GridNodeHolder nodeHolder;
    @Persisted
    public long storage;
    @Persisted
    public int thread;
    @Persisted
    public int accelerator;
    private boolean isOnline;
    private CompoundTag tag;
    private final MachineSource source;
    private final ObjectArrayList<CraftingCPUCluster> clusters = new ObjectArrayList();
    private final List<CraftingCPUCluster> list = new ObjectArrayList();
    private final ConditionalSubscriptionHandler tickSubs;

    public CraftingInterfacePartMachine(MetaMachineBlockEntity metaMachineBlockEntity) {
        super(metaMachineBlockEntity);
        this.nodeHolder = new GridNodeHolder(this);
        this.source = new MachineSource(this);
        this.tickSubs = new ConditionalSubscriptionHandler(this, this::tickUpdate, () -> true);
    }

    @Override
    public void saveCustomPersistedData(@NotNull CompoundTag compoundTag, boolean bl) {
        super.saveCustomPersistedData(compoundTag, bl);
        ListTag listTag = new ListTag();
        for (CraftingCPUCluster craftingCPUCluster : this.clusters) {
            CompoundTag compoundTag2 = new CompoundTag();
            craftingCPUCluster.writeToNBT(compoundTag2);
            listTag.add(compoundTag2);
        }
        compoundTag.m_128365_("clusters", listTag);
    }

    @Override
    public void loadCustomPersistedData(@NotNull CompoundTag compoundTag) {
        super.loadCustomPersistedData(compoundTag);
        this.tag = compoundTag;
    }

    @Override
    public void onLoad() {
        super.onLoad();
        if (this.getLevel() instanceof ServerLevel) {
            if (this.tag != null) {
                ListTag listTag = this.tag.m_128437_("clusters", 10);
                this.setThread(Math.max(this.thread, listTag.size()));
                for (int i = 0; i < listTag.size(); ++i) {
                    CompoundTag compoundTag = listTag.m_128728_(i);
                    CraftingCPUCluster craftingCPUCluster = (CraftingCPUCluster)this.clusters.get(i);
                    craftingCPUCluster.readFromNBT(compoundTag);
                }
                this.tag = null;
            } else {
                this.setThread(this.thread);
            }
            this.tickSubs.initialize(this.getLevel());
            GridHelper.onFirstTick(this.holder, metaMachineBlockEntity -> this.updateList());
        }
    }

    @Override
    public void onUnload() {
        super.onUnload();
        this.tickSubs.unsubscribe();
    }

    public void onMachineRemoved() {
        if (this.getLevel() instanceof ServerLevel) {
            for (CraftingCPUCluster craftingCPUCluster : this.clusters) {
                ICraftingCPUCluster.of(craftingCPUCluster).setDestroyed(true);
            }
            this.clusters.clear();
            this.updateList();
        }
    }

    private void tickUpdate() {
        block4: {
            if (this.getOffsetTimer() % 10L != 0L) break block4;
            this.updateList();
            if (this.list.size() > 1) {
                for (IMultiController iMultiController : this.getControllers()) {
                    if (!(iMultiController instanceof MECPUMachine)) continue;
                    MECPUMachine mECPUMachine = (MECPUMachine)iMultiController;
                    mECPUMachine.activated = true;
                    mECPUMachine.requestSync();
                }
            } else {
                for (IMultiController iMultiController : this.getControllers()) {
                    if (!(iMultiController instanceof MECPUMachine)) continue;
                    MECPUMachine mECPUMachine = (MECPUMachine)iMultiController;
                    mECPUMachine.activated = false;
                    mECPUMachine.requestSync();
                }
            }
        }
    }

    private void updateList() {
        Object object;
        int n = 0;
        if (this.list.isEmpty()) {
            if (this.clusters.isEmpty()) {
                return;
            }
        } else {
            ListIterator<CraftingCPUCluster> listIterator = this.list.listIterator();
            while (listIterator.hasNext()) {
                object = listIterator.next();
                if (((CraftingCPUCluster)object).isDestroyed()) {
                    listIterator.remove();
                    continue;
                }
                if (((CraftingCPUCluster)object).isBusy()) continue;
                ++n;
            }
        }
        if (n != 1) {
            this.list.clear();
            boolean bl = true;
            for (CraftingCPUCluster craftingCPUCluster : this.clusters) {
                if (craftingCPUCluster.isBusy()) {
                    this.list.add(craftingCPUCluster);
                    continue;
                }
                if (!bl) continue;
                bl = false;
                this.list.add(craftingCPUCluster);
            }
            object = this.nodeHolder.getMainNode().getGrid();
            if (object != null) {
                object.postEvent(new GridCraftingCpuChange(this.nodeHolder.getMainNode().getNode()));
            }
        }
    }

    public void setStorage(long l) {
        this.storage = l;
        for (CraftingCPUCluster craftingCPUCluster : this.clusters) {
            ICraftingCPUCluster.of(craftingCPUCluster).setStorage(l);
        }
    }

    public void setAccelerator(int n) {
        this.accelerator = n;
        for (CraftingCPUCluster craftingCPUCluster : this.clusters) {
            ICraftingCPUCluster.of(craftingCPUCluster).setAccelerator(n);
        }
    }

    public void setThread(int n) {
        this.thread = n;
        int n2 = this.clusters.size();
        if (n2 == n) {
            return;
        }
        if ((n2 = Math.max(n2, n)) == 0) {
            return;
        }
        this.clusters.size(n2);
        for (int i = 0; i < n2; ++i) {
            CraftingCPUCluster craftingCPUCluster = (CraftingCPUCluster)this.clusters.get(i);
            if (craftingCPUCluster == null) {
                craftingCPUCluster = ICraftingCPUCluster.create(this, this.source, Component.m_237113_("CPU").m_130946_("-" + i), this.storage, this.accelerator);
                this.clusters.set(i, (Object)craftingCPUCluster);
                continue;
            }
            if (i < n) continue;
            ICraftingCPUCluster.of(craftingCPUCluster).setDestroyed(true);
            this.clusters.set(i, null);
        }
        this.clusters.removeIf(Objects::isNull);
    }

    public List<CraftingCPUCluster> getClusters() {
        return this.list;
    }

    @NotNull
    public ManagedFieldHolder getFieldHolder() {
        return MANAGED_FIELD_HOLDER;
    }

    public boolean shouldOpenUI(Player player, InteractionHand interactionHand, BlockHitResult blockHitResult) {
        return false;
    }

    public IManagedGridNode getMainNode() {
        return this.nodeHolder.getMainNode();
    }

    public boolean isOnline() {
        return this.isOnline;
    }

    public void setOnline(boolean bl) {
        this.isOnline = bl;
    }
}

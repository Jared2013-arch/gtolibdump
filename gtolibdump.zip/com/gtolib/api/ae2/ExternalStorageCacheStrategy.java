package com.gtolib.api.ae2;

import appbot.ae2.ManaExternalStorageStrategy;
import appbot.ae2.ManaKeyType;
import appeng.api.behaviors.ExternalStorageStrategy;
import appeng.api.stacks.AEKeyType;
import appeng.api.storage.MEStorage;
import appeng.me.storage.ExternalStorageFacade;
import appeng.parts.automation.HandlerStrategy;
import com.gtolib.api.ae2.AEKeyTypeMap;
import com.gtolib.utils.BlockCapabilityCache;
import gripe._90.arseng.me.key.SourceKeyType;
import gripe._90.arseng.me.strategy.SourceExternalStorageStrategy;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

public class ExternalStorageCacheStrategy<C, S>
implements ExternalStorageStrategy {
    private final BlockCapabilityCache<C> apiCache;
    private final BlockPos pos;
    private final Direction side;
    private final Direction oppositeSide;
    private final HandlerStrategy<C, S> conversion;

    private ExternalStorageCacheStrategy(Capability<C> capability, HandlerStrategy<C, S> handlerStrategy, BlockEntity blockEntity, BlockPos blockPos, Direction direction, Direction direction2) {
        this.apiCache = BlockCapabilityCache.create(capability, blockEntity);
        this.side = direction;
        this.pos = blockPos;
        this.oppositeSide = direction2;
        this.conversion = handlerStrategy;
    }

    public MEStorage createWrapper(boolean bl, Runnable runnable) {
        C c = this.apiCache.find(this.pos, this.side, this.oppositeSide);
        if (c == null) {
            return null;
        }
        ExternalStorageFacade externalStorageFacade = this.conversion.getFacade(c);
        externalStorageFacade.setChangeListener(runnable);
        externalStorageFacade.setExtractableOnly(bl);
        return externalStorageFacade;
    }

    public static Map<AEKeyType, ExternalStorageStrategy> createExternalStorageStrategies(BlockEntity blockEntity, BlockPos blockPos, Direction direction, Direction direction2) {
        return new AEKeyTypeMap<ExternalStorageStrategy>(new ExternalStorageCacheStrategy(ForgeCapabilities.ITEM_HANDLER, HandlerStrategy.ITEMS, blockEntity, blockPos, direction, direction2), new ExternalStorageCacheStrategy(ForgeCapabilities.FLUID_HANDLER, HandlerStrategy.FLUIDS, blockEntity, blockPos, direction, direction2));
    }

    public static Map<AEKeyType, ExternalStorageStrategy> createWithManaExternalStorageStrategies(BlockEntity blockEntity, BlockPos blockPos, Direction direction, Direction direction2) {
        return Map.of((Object)AEKeyTypeMap.ITEM_TYPE, new ExternalStorageCacheStrategy(ForgeCapabilities.ITEM_HANDLER, HandlerStrategy.ITEMS, blockEntity, blockPos, direction, direction2), (Object)AEKeyTypeMap.FLUID_TYPE, new ExternalStorageCacheStrategy(ForgeCapabilities.FLUID_HANDLER, HandlerStrategy.FLUIDS, blockEntity, blockPos, direction, direction2), (Object)ManaKeyType.TYPE, (Object)new ManaExternalStorageStrategy((ServerLevel)blockEntity.m_58904_(), blockPos, direction2), (Object)SourceKeyType.TYPE, (Object)new SourceExternalStorageStrategy((ServerLevel)blockEntity.m_58904_(), blockPos, direction2));
    }
}

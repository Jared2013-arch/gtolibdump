package com.gtolib.api.ae2;

import com.gtolib.api.ae2.BlockingType;

class PatternProviderTargetCache$1 {
    static final int[] $SwitchMap$com$gtolib$api$ae2$BlockingType;

    static {
        $SwitchMap$com$gtolib$api$ae2$BlockingType = new int[BlockingType.values().length];
        try {
            PatternProviderTargetCache$1.$SwitchMap$com$gtolib$api$ae2$BlockingType[BlockingType.ALL.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            PatternProviderTargetCache$1.$SwitchMap$com$gtolib$api$ae2$BlockingType[BlockingType.NON_CONTAIN.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            PatternProviderTargetCache$1.$SwitchMap$com$gtolib$api$ae2$BlockingType[BlockingType.PARALLEL.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            PatternProviderTargetCache$1.$SwitchMap$com$gtolib$api$ae2$BlockingType[BlockingType.CONTAIN.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            PatternProviderTargetCache$1.$SwitchMap$com$gtolib$api$ae2$BlockingType[BlockingType.NONE.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

package com.gtolib.api.ae2;

import appeng.api.stacks.AEKeyType;
import java.util.Map;

class AEKeyTypeMap$FluidEntry
implements Map.Entry<AEKeyType, T> {
    private AEKeyTypeMap$FluidEntry() {
    }

    @Override
    public AEKeyType getKey() {
        return FLUID_TYPE;
    }

    @Override
    public T getValue() {
        return AEKeyTypeMap.this.fluid;
    }

    @Override
    public T setValue(T t) {
        Object t2 = AEKeyTypeMap.this.fluid;
        AEKeyTypeMap.this.fluid = t;
        return t2;
    }
}

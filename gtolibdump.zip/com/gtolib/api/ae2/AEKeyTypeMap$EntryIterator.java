package com.gtolib.api.ae2;

import appeng.api.stacks.AEKeyType;
import com.gtolib.api.ae2.AEKeyTypeMap;
import java.util.Iterator;
import java.util.Map;

class AEKeyTypeMap$EntryIterator
implements Iterator<Map.Entry<AEKeyType, T>> {
    private boolean hasNext;
    private boolean complete;

    private AEKeyTypeMap$EntryIterator() {
    }

    @Override
    public boolean hasNext() {
        return this.hasNext;
    }

    @Override
    public Map.Entry<AEKeyType, T> next() {
        if (this.complete) {
            this.complete = false;
            if (AEKeyTypeMap.this.itemEntry == null) {
                AEKeyTypeMap.this.itemEntry = new AEKeyTypeMap.ItemEntry(AEKeyTypeMap.this);
            }
            return AEKeyTypeMap.this.itemEntry;
        }
        this.hasNext = false;
        if (AEKeyTypeMap.this.fluid != null) {
            if (AEKeyTypeMap.this.fluidEntry == null) {
                AEKeyTypeMap.this.fluidEntry = new AEKeyTypeMap.FluidEntry(AEKeyTypeMap.this);
            }
            return AEKeyTypeMap.this.fluidEntry;
        }
        if (AEKeyTypeMap.this.itemEntry == null) {
            AEKeyTypeMap.this.itemEntry = new AEKeyTypeMap.ItemEntry(AEKeyTypeMap.this);
        }
        return AEKeyTypeMap.this.itemEntry;
    }
}

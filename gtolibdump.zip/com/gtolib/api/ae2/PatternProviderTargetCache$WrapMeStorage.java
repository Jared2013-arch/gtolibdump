package com.gtolib.api.ae2;

import appeng.api.config.Actionable;
import appeng.api.crafting.IPatternDetails;
import appeng.api.networking.security.IActionSource;
import appeng.api.stacks.AEKey;
import appeng.api.stacks.KeyCounter;
import appeng.api.storage.MEStorage;
import appeng.helpers.patternprovider.PatternProviderTarget;
import com.gtolib.api.ae2.IPatternProviderLogic;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import java.util.Iterator;
import java.util.Set;
import org.jetbrains.annotations.Nullable;

public record PatternProviderTargetCache$WrapMeStorage(MEStorage storage, IActionSource src, IPatternProviderLogic logic, long pos, int dir) implements PatternProviderTarget
{
    public long insert(AEKey aEKey, long l, Actionable actionable) {
        return this.storage.insert(aEKey, l, actionable, this.src);
    }

    public boolean containsPatternInput(Set<AEKey> set) {
        switch (this.logic.gtolib$getBlocking()) {
            case ALL: {
                return this.isNonEmpty(null);
            }
            case NON_CONTAIN: {
                IPatternDetails iPatternDetails = this.logic.gtolib$getCachePattern(this.pos, this.dir);
                if (iPatternDetails == null) {
                    return false;
                }
                IPatternDetails iPatternDetails2 = this.logic.gtolib$getCurrentPattern();
                return iPatternDetails2 != null && !iPatternDetails2.equals(iPatternDetails) && this.isNonEmpty(set);
            }
            case PARALLEL: 
            case CONTAIN: {
                return this.isNonEmpty(set);
            }
            case NONE: {
                return false;
            }
        }
        return false;
    }

    private boolean isNonEmpty(@Nullable Set<AEKey> set) {
        KeyCounter keyCounter = this.storage.getAvailableStacks();
        keyCounter.removeZeros();
        if (keyCounter.isEmpty()) {
            return false;
        }
        if (set == null) {
            return true;
        }
        Iterator iterator = keyCounter.iterator();
        while (iterator.hasNext()) {
            Object2LongMap.Entry entry = (Object2LongMap.Entry)iterator.next();
            if (!set.contains(((AEKey)entry.getKey()).dropSecondary())) continue;
            return true;
        }
        return false;
    }
}

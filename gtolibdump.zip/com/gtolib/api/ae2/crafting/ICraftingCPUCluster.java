package com.gtolib.api.ae2.crafting;

import appeng.me.cluster.implementations.CraftingCPUCluster;
import appeng.me.helpers.MachineSource;
import appeng.util.ConfigManager;
import com.gtolib.api.ae2.machine.CraftingInterfacePartMachine;
import net.minecraft.network.chat.Component;

public interface ICraftingCPUCluster {
    public ConfigManager getConfigManager();

    public void setName(Component var1);

    public void setDestroyed(boolean var1);

    public void setStorage(long var1);

    public void setMachineSrc(MachineSource var1);

    public void setAccelerator(int var1);

    public void setMachine(CraftingInterfacePartMachine var1);

    public static ICraftingCPUCluster of(CraftingCPUCluster craftingCPUCluster) {
        return (ICraftingCPUCluster)((Object)craftingCPUCluster);
    }

    public static CraftingCPUCluster create(CraftingInterfacePartMachine craftingInterfacePartMachine, MachineSource machineSource, Component component, long l, int n) {
        CraftingCPUCluster craftingCPUCluster = new CraftingCPUCluster(craftingInterfacePartMachine.getPos(), craftingInterfacePartMachine.getPos());
        ICraftingCPUCluster iCraftingCPUCluster = ICraftingCPUCluster.of(craftingCPUCluster);
        iCraftingCPUCluster.setMachine(craftingInterfacePartMachine);
        iCraftingCPUCluster.setMachineSrc(machineSource);
        iCraftingCPUCluster.setName(component);
        iCraftingCPUCluster.setStorage(l);
        iCraftingCPUCluster.setAccelerator(n);
        return craftingCPUCluster;
    }
}

package com.gtolib.api.ae2.crafting;

import appeng.api.networking.IGrid;
import appeng.api.networking.crafting.CalculationStrategy;
import appeng.api.networking.crafting.ICraftingPlan;
import appeng.api.networking.crafting.ICraftingSimulationRequester;
import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import com.gtolib.ae2.a.b.a;
import com.gtolib.ae2.a.b.c;
import com.gtolib.ae2.a.b.c.b;
import com.gtolib.ae2.a.b.c.d;
import com.gtolib.ae2.a.b.c.e;
import com.gtolib.ae2.a.b.c.f;
import com.gtolib.ae2.a.b.c.g;
import com.gtolib.ae2.a.b.c.h;

public final class OptimizedCalculation {
    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static ICraftingPlan execute(IGrid iGrid, ICraftingSimulationRequester iCraftingSimulationRequester, AEKey aEKey, long l, CalculationStrategy calculationStrategy) {
        Object object = com.gtolib.e.a.a;
        synchronized (object) {
            com.gtolib.ae2.a.b.a.a.a a2 = new com.gtolib.ae2.a.b.a.a.a();
            a2.b(new h()).a(new d()).a(new f()).a(new b()).a(new com.gtolib.ae2.a.b.c.c()).b(new com.gtolib.ae2.a.b.c.a()).b(new e()).b(new g());
            return a2.a((a)a.a((ICraftingSimulationRequester)iCraftingSimulationRequester, (CalculationStrategy)calculationStrategy, (IGrid)iGrid, (GenericStack)new GenericStack((AEKey)aEKey, (long)l), (c)new c(null), (boolean)false)).r;
        }
    }
}

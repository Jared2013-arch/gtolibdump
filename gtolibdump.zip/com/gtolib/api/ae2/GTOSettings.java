package com.gtolib.api.ae2;

import appeng.api.config.Setting;
import appeng.api.config.Settings;
import com.gtolib.api.ae2.BlockingType;
import com.gtolib.api.ae2.ShiftTransferTo;
import com.gtolib.api.ae2.ShowMolecularAssembler;

public final class GTOSettings {
    public static Setting<BlockingType> BLOCKING_TYPE;
    public static Setting<ShowMolecularAssembler> TERMINAL_SHOW_MOLECULAR_ASSEMBLERS;
    public static Setting<ShiftTransferTo> ME2IN1_SHIFT_TRANSFER_TO;

    static {
        Settings.ACCESS.getName();
    }
}

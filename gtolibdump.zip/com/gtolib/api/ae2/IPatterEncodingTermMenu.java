package com.gtolib.api.ae2;

public interface IPatterEncodingTermMenu {
    default public void gtolib$modifyPatter(Integer n) {
    }

    default public void gtolib$clearSecOutput() {
    }

    default public void gtolib$addRecipe(String string) {
    }
}

package com.gtolib.api.ae2;

import com.gtolib.api.ae2.ShowMolecularAssembler;

public interface IPatternAccessTermMenu {
    public ShowMolecularAssembler gtolib$getShownMolecularAssemblers();
}

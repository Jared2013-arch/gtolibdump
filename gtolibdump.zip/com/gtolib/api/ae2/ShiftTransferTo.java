package com.gtolib.api.ae2;

public enum ShiftTransferTo {
    INVENTORY_OR_BUFFER,
    CURRENTLY_VISIBLE_ACCESSOR;

}

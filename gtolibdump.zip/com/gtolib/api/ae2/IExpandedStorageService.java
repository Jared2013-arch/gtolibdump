package com.gtolib.api.ae2;

import appeng.api.networking.storage.IStorageService;
import appeng.api.stacks.KeyCounter;
import com.gtocore.api.ae2.stacks.FuzzyKeyCounter;

public interface IExpandedStorageService {
    public FuzzyKeyCounter getFuzzyKeyCounter();

    public KeyCounter getLazyKeyCounter();

    public Object gtolib$getLock();

    public static IExpandedStorageService of(IStorageService iStorageService) {
        return (IExpandedStorageService)((Object)iStorageService);
    }
}

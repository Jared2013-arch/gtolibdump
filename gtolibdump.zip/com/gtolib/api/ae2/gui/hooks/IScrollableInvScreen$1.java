package com.gtolib.api.ae2.gui.hooks;

import appeng.client.gui.widgets.Scrollbar;

class IScrollableInvScreen$1
extends Scrollbar {
    IScrollableInvScreen$1(Scrollbar.Style style) {
        super(style);
    }

    @Override
    public boolean isVisible() {
        return IScrollableInvScreen.this.gto$ae$isVisible();
    }
}

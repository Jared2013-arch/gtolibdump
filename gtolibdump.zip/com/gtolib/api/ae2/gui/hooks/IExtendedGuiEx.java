package com.gtolib.api.ae2.gui.hooks;

import appeng.client.gui.widgets.AETextField;

public interface IExtendedGuiEx {
    public AETextField gtolib$getSearchOutField();
}

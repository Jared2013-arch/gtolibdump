package com.gtolib.api.ae2.gui.hooks;

import appeng.client.gui.Icon;

public interface IconSlot {
    public Icon getIcon();

    public void setIcon(Icon var1);

    default public float getOpacityOfIcon() {
        return 1.0f;
    }
}

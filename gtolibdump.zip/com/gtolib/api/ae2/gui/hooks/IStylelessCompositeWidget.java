package com.gtolib.api.ae2.gui.hooks;

import appeng.client.gui.AEBaseScreen;
import appeng.client.gui.ICompositeWidget;
import appeng.client.gui.WidgetContainer;
import net.minecraft.client.renderer.Rect2i;

public interface IStylelessCompositeWidget
extends ICompositeWidget {
    default public void adjustPosition(Rect2i rect2i) {
    }

    public void initialize(String var1, WidgetContainer var2);

    public AEBaseScreen<?> getScreen();

    default public int getGuiTop() {
        return this.getScreen().getGuiTop();
    }

    default public int getGuiLeft() {
        return this.getScreen().getGuiLeft();
    }
}

package com.gtolib.api.ae2.gui.hooks;

import net.minecraft.world.item.ItemStack;

public interface IDraggableSlot {
    public boolean isDraggable();

    public void setDraggable(boolean var1);

    public void onXEIDragged(ItemStack var1);
}

package com.gtolib.api.ae2.gui.hooks;

import appeng.api.config.Setting;
import appeng.client.gui.Icon;
import appeng.client.gui.widgets.SettingToggleButton;
import java.lang.reflect.Constructor;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;

public class SettingToggleButtonReflect {
    static Constructor<?> ctorButtonAppearance;
    static Constructor<?> ctorEnumPair;

    public static Object newButtonAppearance(Icon icon, Item item, List<Component> list) {
        try {
            return ctorButtonAppearance.newInstance(icon, item, list);
        }
        catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    public static <T extends Enum<T>> Object newEnumPair(Setting<T> setting, Enum<T> enum_) {
        try {
            return ctorEnumPair.newInstance(setting, enum_);
        }
        catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    static {
        Class<SettingToggleButton> clazz = SettingToggleButton.class;
        try {
            for (Class<?> clazz2 : clazz.getDeclaredClasses()) {
                if (clazz2.getSimpleName().equals("ButtonAppearance")) {
                    ctorButtonAppearance = clazz2.getDeclaredConstructor(Icon.class, Item.class, List.class);
                    ctorButtonAppearance.setAccessible(true);
                }
                if (!clazz2.getSimpleName().equals("EnumPair")) continue;
                ctorEnumPair = clazz2.getDeclaredConstructor(Setting.class, Enum.class);
                ctorEnumPair.setAccessible(true);
            }
        }
        catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }
}

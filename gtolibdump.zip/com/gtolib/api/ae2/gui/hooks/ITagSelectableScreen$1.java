package com.gtolib.api.ae2.gui.hooks;

import appeng.client.Point;
import appeng.client.gui.Tooltip;
import com.glodblock.github.extendedae.client.gui.widget.MultilineTextFieldWidget;
import com.gtolib.api.ae2.gui.widgets.AEListBox;
import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.network.chat.Component;

class ITagSelectableScreen$1
implements AEListBox.ListItem {
    boolean visible = true;
    Point position = new Point(0, 0);
    final Font val$font;
    final Component val$tagName;
    final MultilineTextFieldWidget val$fieldsInput;
    final String val$tag;

    ITagSelectableScreen$1() {
        this.val$font = font;
        this.val$tagName = component;
        this.val$fieldsInput = multilineTextFieldWidget;
        this.val$tag = string;
    }

    @Override
    public void setVisible(boolean bl) {
        this.visible = bl;
    }

    @Override
    public void setPosition(Point point) {
        this.position = point;
    }

    @Override
    public Rect2i getBounds() {
        int n = this.position.getX();
        int n2 = this.position.getY();
        int n3 = this.val$font.m_92852_(this.val$tagName);
        Objects.requireNonNull(this.val$font);
        return new Rect2i(n, n2, n3, 9);
    }

    @Override
    public void drawForegroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
        if (this.visible) {
            guiGraphics.m_280430_(this.val$font, this.val$tagName, rect2i.m_110085_(), rect2i.m_110086_(), 0xFFFFFF);
        }
    }

    @Override
    public boolean onMouseUp(Point point, int n) {
        if (!this.visible || !this.getBounds().m_110087_(point.getX(), point.getY())) {
            return false;
        }
        switch (n) {
            case 0: {
                this.val$fieldsInput.setValue(this.val$tag);
                break;
            }
            case 1: {
                Minecraft.m_91087_().f_91068_.m_90911_(this.val$tag);
                break;
            }
            default: {
                return false;
            }
        }
        return true;
    }

    @Override
    public Tooltip getTooltip(int n, int n2) {
        return new Tooltip(new Component[]{Component.m_237115_("gtocore.part.extendae.tag_filter.tooltip")});
    }
}

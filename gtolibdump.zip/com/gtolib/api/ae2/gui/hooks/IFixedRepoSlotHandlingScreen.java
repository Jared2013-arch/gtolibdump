package com.gtolib.api.ae2.gui.hooks;

import appeng.api.behaviors.ContainerItemStrategies;
import appeng.api.behaviors.EmptyingAction;
import appeng.api.client.AEKeyRendering;
import appeng.api.stacks.AmountFormat;
import appeng.client.gui.AEBaseScreen;
import appeng.client.gui.me.common.Repo;
import appeng.client.gui.me.common.StackSizeRenderer;
import appeng.core.AEConfig;
import appeng.core.localization.ButtonToolTips;
import appeng.core.localization.GuiText;
import appeng.core.localization.Tooltips;
import appeng.core.sync.network.NetworkHandler;
import appeng.core.sync.packets.MEInteractionPacket;
import appeng.helpers.InventoryAction;
import appeng.menu.me.common.GridInventoryEntry;
import appeng.menu.me.common.MEStorageMenu;
import com.gtolib.GTOCore;
import com.gtolib.api.ae2.gui.FixedRepoSlot;
import com.gtolib.api.ae2.gui.hooks.IRepoSlot;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Unique;

@OnlyIn(value=Dist.CLIENT)
public interface IFixedRepoSlotHandlingScreen {
    public static final Font gtolib$font = Minecraft.m_91087_().f_91062_;

    @Unique
    public Repo gtolib$getRepo();

    public MEStorageMenu gtolib$getMenu();

    public void gtolib$handleGridInventoryEntryMouseClick(@Nullable GridInventoryEntry var1, int var2, ClickType var3);

    public static boolean gtolib$renderSlot(IFixedRepoSlotHandlingScreen iFixedRepoSlotHandlingScreen, GuiGraphics guiGraphics, Slot slot) {
        if (slot instanceof IRepoSlot) {
            IRepoSlot iRepoSlot = (IRepoSlot)((Object)slot);
            if (!iFixedRepoSlotHandlingScreen.gtolib$getRepo().hasPower()) {
                guiGraphics.m_280509_(slot.f_40220_, slot.f_40221_, 16 + slot.f_40220_, 16 + slot.f_40221_, 0x66111111);
            } else {
                GridInventoryEntry gridInventoryEntry = iRepoSlot.getEntry();
                if (gridInventoryEntry != null) {
                    try {
                        AEKeyRendering.drawInGui(Minecraft.m_91087_(), guiGraphics, slot.f_40220_, slot.f_40221_, gridInventoryEntry.getWhat());
                    }
                    catch (Exception exception) {
                        GTOCore.LOGGER.warn("[AppEng] AE prevented crash while drawing slot: {}", (Object)String.valueOf(exception));
                    }
                    long l = gridInventoryEntry.getStoredAmount();
                    boolean bl = gridInventoryEntry.isCraftable();
                    boolean bl2 = AEConfig.instance().isUseLargeFonts();
                    if (bl && (iFixedRepoSlotHandlingScreen.gtolib$isViewOnlyCraftable() || l <= 0L)) {
                        String string = bl2 ? GuiText.LargeFontCraft.getLocal() : GuiText.SmallFontCraft.getLocal();
                        StackSizeRenderer.renderSizeLabel(guiGraphics, gtolib$font, slot.f_40220_, slot.f_40221_, string);
                    } else {
                        AmountFormat amountFormat = bl2 ? AmountFormat.SLOT_LARGE_FONT : AmountFormat.SLOT;
                        String string = gridInventoryEntry.getWhat().formatAmount(l, amountFormat);
                        StackSizeRenderer.renderSizeLabel(guiGraphics, gtolib$font, slot.f_40220_, slot.f_40221_, string, bl2);
                        if (bl) {
                            StackSizeRenderer.renderSizeLabel(guiGraphics, gtolib$font, slot.f_40220_ - 11, slot.f_40221_ - 11, "+", false);
                        }
                    }
                }
            }
            return true;
        }
        return false;
    }

    public boolean gtolib$isViewOnlyCraftable();

    public static boolean gtolib$renderTooltip(IFixedRepoSlotHandlingScreen iFixedRepoSlotHandlingScreen, GuiGraphics guiGraphics, int n, int n2) {
        Object object = iFixedRepoSlotHandlingScreen.gtolib$hoveredSlot();
        if (object instanceof IRepoSlot) {
            Object object2;
            IRepoSlot iRepoSlot = (IRepoSlot)object;
            ItemStack itemStack = iFixedRepoSlotHandlingScreen.gtolib$getMenu().m_142621_();
            if (iRepoSlot.getStoredAmount() == 0L && iRepoSlot instanceof FixedRepoSlot && !((FixedRepoSlot)(object2 = (FixedRepoSlot)iRepoSlot)).getEmptyTooltipMessage().isEmpty()) {
                object = ((FixedRepoSlot)object2).getEmptyTooltipMessage();
            } else if (itemStack.m_41619_()) {
                object = List.of();
            } else {
                EmptyingAction emptyingAction = ContainerItemStrategies.getEmptyingAction(itemStack);
                List<Component> list = object = emptyingAction != null && iFixedRepoSlotHandlingScreen.gtolib$getMenu().isKeyVisible(emptyingAction.what()) ? Tooltips.getEmptyingTooltip(ButtonToolTips.StoreAction, itemStack, emptyingAction) : List.of();
            }
            if (!object.isEmpty()) {
                ((AEBaseScreen)((Object)iFixedRepoSlotHandlingScreen)).drawTooltip(guiGraphics, n, n2, (List)object);
                return true;
            }
            if (itemStack.m_41619_() && (object2 = iRepoSlot.getEntry()) != null) {
                iFixedRepoSlotHandlingScreen.gtolib$renderGridInventoryEntryTooltip(guiGraphics, (GridInventoryEntry)object2, n, n2);
                return true;
            }
        }
        return false;
    }

    public static boolean gtolib$mouseScrolled(IFixedRepoSlotHandlingScreen iFixedRepoSlotHandlingScreen, double d, double d2, double d3, double d4) {
        Object object;
        if (d4 != 0.0 && Screen.m_96638_() && (object = ((AEBaseScreen)((Object)iFixedRepoSlotHandlingScreen)).m_97744_(d, d2)) instanceof FixedRepoSlot) {
            FixedRepoSlot fixedRepoSlot = (FixedRepoSlot)object;
            long l = (object = fixedRepoSlot.getEntry()) != null ? ((GridInventoryEntry)object).getSerial() : -1L;
            InventoryAction inventoryAction = d4 > 0.0 ? InventoryAction.ROLL_DOWN : InventoryAction.ROLL_UP;
            int n = (int)Math.abs(d4);
            for (int i = 0; i < n; ++i) {
                MEInteractionPacket mEInteractionPacket = new MEInteractionPacket(iFixedRepoSlotHandlingScreen.gtolib$getMenu().f_38840_, l, inventoryAction);
                NetworkHandler.instance().sendToServer(mEInteractionPacket);
            }
            return true;
        }
        return false;
    }

    public void gtolib$renderGridInventoryEntryTooltip(GuiGraphics var1, GridInventoryEntry var2, int var3, int var4);

    public Slot gtolib$hoveredSlot();
}

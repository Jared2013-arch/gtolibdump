package com.gtolib.api.ae2.gui.hooks;

import appeng.client.Point;
import appeng.client.gui.AEBaseScreen;
import appeng.client.gui.ICompositeWidget;
import appeng.client.gui.style.Blitter;
import appeng.client.gui.widgets.Scrollbar;
import appeng.menu.AEBaseMenu;
import appeng.menu.SlotSemantic;
import appeng.menu.slot.AppEngSlot;
import com.gtocore.mixin.ae2.screen.AEBaseScreenAccessor;
import com.gtolib.api.ae2.gui.BlitterGroup;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.Rect2i;
import org.jetbrains.annotations.NotNull;

public interface IScrollableInvScreen<MENU extends AEBaseMenu, SCREEN extends AEBaseScreen<MENU>> {
    public static final BlitterGroup gto$ae$SCROLLBAR_BG = BlitterGroup.createFromSplittingBlitter(Blitter.texture("guis/pattern_provider_scrollbar.png").src(0, 0, 21, 103), 17, 18);
    public static final int SLOT_HEIGHT = 18;
    public static final int SLOT_NUMBER_PER_ROW = 9;
    public static final int BG_WIDTH = 21;

    @NotNull
    public MENU gto$ae$getMenu();

    public SCREEN gto$ae$getSelf();

    public boolean gto$ae$shouldAddScrollBar();

    public void gto$ae$setScrollBar(Scrollbar var1);

    public Scrollbar gto$ae$getScrollBar();

    public List<AppEngSlot> gto$ae$getScrollerSlots();

    public SlotSemantic gto$ae$getScrollableSlotSemantic();

    public int gto$ae$getEffectiveRowCount();

    public int gto$ae$getBGHeight();

    public String gto$ae$getStylesheetName();

    default public boolean gto$ae$isVisible() {
        return true;
    }

    default public void gto$ae$initScrollBar() {
        if (this.gto$ae$shouldAddScrollBar()) {
            Scrollbar scrollbar = new Scrollbar(Scrollbar.DEFAULT){

                @Override
                public boolean isVisible() {
                    return IScrollableInvScreen.this.gto$ae$isVisible();
                }
            }.setHeight(18 * this.gto$ae$getEffectiveRowCount());
            scrollbar.setRange(0, (int)Math.ceil((float)(((AEBaseMenu)this.gto$ae$getMenu()).getSlots(this.gto$ae$getScrollableSlotSemantic()).size() - this.gto$ae$getEffectiveRowCount() * 9) / 9.0f), 1);
            ((AEBaseScreenAccessor)((Object)this)).gtolib$getWidgets().add(this.gto$ae$getStylesheetName() + "Scrollbar", scrollbar);
            this.gto$ae$setScrollBar(scrollbar);
            ((AEBaseScreenAccessor)((Object)this)).gtolib$getWidgets().add(this.gto$ae$getStylesheetName() + "ScrollbarBackground", new ICompositeWidget(){
                private int x = 0;
                private int y = 0;

                @Override
                public void setPosition(Point point) {
                    this.x = point.getX();
                    this.y = point.getY();
                }

                public void setSize(int n, int n2) {
                }

                @Override
                public Rect2i getBounds() {
                    return new Rect2i(this.x, this.y, 21, IScrollableInvScreen.this.gto$ae$getBGHeight());
                }

                @Override
                public void drawBackgroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
                    ICompositeWidget.super.drawBackgroundLayer(guiGraphics, rect2i, point);
                    gto$ae$SCROLLBAR_BG.copy().dest(this.x + ((AEBaseScreen)IScrollableInvScreen.this.gto$ae$getSelf()).getGuiLeft(), this.y + ((AEBaseScreen)IScrollableInvScreen.this.gto$ae$getSelf()).getGuiTop()).vBlitFixedHeight(guiGraphics, IScrollableInvScreen.this.gto$ae$getBGHeight());
                }

                public boolean isVisible() {
                    return IScrollableInvScreen.this.gto$ae$isVisible();
                }
            });
        }
    }

    default public void gto$ae$repositionSlots() {
        if (this.gto$ae$getScrollBar() != null && this.gto$ae$isVisible()) {
            ((AEBaseScreen)this.gto$ae$getSelf()).repositionSlots(this.gto$ae$getScrollableSlotSemantic());
            for (int i = 0; i < this.gto$ae$getScrollerSlots().size(); ++i) {
                AppEngSlot appEngSlot = this.gto$ae$getScrollerSlots().get(i);
                int n = i / 9 - this.gto$ae$getScrollBar().getCurrentScroll();
                appEngSlot.setActive(n >= 0 && n < this.gto$ae$getEffectiveRowCount());
                appEngSlot.f_40221_ -= this.gto$ae$getScrollBar().getCurrentScroll() * 18;
            }
        }
    }
}

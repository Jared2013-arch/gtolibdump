package com.gtolib.api.ae2.gui.hooks;

public interface IGuiDataSyncPacketExt {
    public boolean gtolib$isInnerMenuPacket();

    public void gtolib$setInnerMenuPacket(boolean var1);
}

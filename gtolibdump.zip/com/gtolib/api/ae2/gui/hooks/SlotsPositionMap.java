package com.gtolib.api.ae2.gui.hooks;

import appeng.client.gui.layout.SlotGridLayout;
import appeng.client.gui.style.SlotPosition;
import java.util.HashMap;
import java.util.Map;

public class SlotsPositionMap
extends HashMap<String, SlotPosition> {
    public SlotsPositionMap(Map<String, SlotPosition> map) {
        this.putAll(map);
    }

    @Override
    public SlotPosition get(Object object) {
        return this.computeIfAbsent((String)object, string -> {
            SlotPosition slotPosition = new SlotPosition();
            slotPosition.setGrid(SlotGridLayout.BREAK_AFTER_9COLS);
            return slotPosition;
        });
    }
}

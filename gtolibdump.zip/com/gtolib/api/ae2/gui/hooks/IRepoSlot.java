package com.gtolib.api.ae2.gui.hooks;

import appeng.menu.me.common.GridInventoryEntry;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;

public interface IRepoSlot {
    public GridInventoryEntry getEntry();

    public long getStoredAmount();

    public boolean isCraftable();

    @NotNull
    public ItemStack m_7993_();

    public boolean m_6657_();
}

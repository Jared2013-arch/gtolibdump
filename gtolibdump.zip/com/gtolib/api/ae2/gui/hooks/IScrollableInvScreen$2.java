package com.gtolib.api.ae2.gui.hooks;

import appeng.client.Point;
import appeng.client.gui.AEBaseScreen;
import appeng.client.gui.ICompositeWidget;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.Rect2i;

class IScrollableInvScreen$2
implements ICompositeWidget {
    private int x = 0;
    private int y = 0;

    IScrollableInvScreen$2() {
    }

    @Override
    public void setPosition(Point point) {
        this.x = point.getX();
        this.y = point.getY();
    }

    public void setSize(int n, int n2) {
    }

    @Override
    public Rect2i getBounds() {
        return new Rect2i(this.x, this.y, 21, IScrollableInvScreen.this.gto$ae$getBGHeight());
    }

    @Override
    public void drawBackgroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
        ICompositeWidget.super.drawBackgroundLayer(guiGraphics, rect2i, point);
        gto$ae$SCROLLBAR_BG.copy().dest(this.x + ((AEBaseScreen)IScrollableInvScreen.this.gto$ae$getSelf()).getGuiLeft(), this.y + ((AEBaseScreen)IScrollableInvScreen.this.gto$ae$getSelf()).getGuiTop()).vBlitFixedHeight(guiGraphics, IScrollableInvScreen.this.gto$ae$getBGHeight());
    }

    public boolean isVisible() {
        return IScrollableInvScreen.this.gto$ae$isVisible();
    }
}

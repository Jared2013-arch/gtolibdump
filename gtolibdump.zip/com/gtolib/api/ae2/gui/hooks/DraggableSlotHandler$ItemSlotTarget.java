package com.gtolib.api.ae2.gui.hooks;

import appeng.client.gui.AEBaseScreen;
import appeng.menu.AEBaseMenu;
import com.gtolib.api.ae2.gui.hooks.DraggableSlotHandler;
import mezz.jei.api.gui.handlers.IGhostIngredientHandler;
import mezz.jei.api.ingredients.IIngredientType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

class DraggableSlotHandler$ItemSlotTarget<I>
implements IGhostIngredientHandler.Target<I> {
    private final IIngredientType<I> type;
    private final Slot slot;
    private final Rect2i area;

    public DraggableSlotHandler$ItemSlotTarget(IIngredientType<I> iIngredientType, AEBaseScreen<?> aEBaseScreen, Slot slot) {
        this.type = iIngredientType;
        this.slot = slot;
        this.area = new Rect2i(aEBaseScreen.getGuiLeft() + slot.f_40220_, aEBaseScreen.getGuiTop() + slot.f_40221_, 16, 16);
    }

    public Rect2i getArea() {
        return this.area;
    }

    public void accept(I i) {
        AbstractContainerMenu abstractContainerMenu;
        LocalPlayer localPlayer;
        ItemStack itemStack = DraggableSlotHandler.wrapDraggedItem(this.type, i);
        if (itemStack != null && (localPlayer = Minecraft.m_91087_().f_91074_) != null && (abstractContainerMenu = ((Player)localPlayer).f_36096_) instanceof AEBaseMenu) {
            AEBaseMenu aEBaseMenu = (AEBaseMenu)abstractContainerMenu;
            this.slot.m_5852_(itemStack);
        }
    }
}

package com.gtolib.api.ae2.gui;

import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import appeng.client.gui.Icon;
import appeng.client.gui.me.common.ClientReadOnlySlot;
import appeng.client.gui.me.common.Repo;
import appeng.menu.me.common.GridInventoryEntry;
import com.gtolib.api.ae2.gui.hooks.IDraggableSlot;
import com.gtolib.api.ae2.gui.hooks.IRepoSlot;
import com.gtolib.api.ae2.gui.hooks.IconSlot;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class FixedRepoSlot
extends ClientReadOnlySlot
implements IDraggableSlot,
IRepoSlot,
IconSlot {
    private final Repo repo;
    @Nullable
    private AEKey what;
    private final List<Component> emptyTooltips = new ObjectArrayList();
    private Icon icon;
    private boolean draggable = false;

    public FixedRepoSlot(Repo repo, @Nullable AEKey aEKey, int n, int n2) {
        super(n, n2);
        this.repo = repo;
        this.what = aEKey;
    }

    @Override
    public GridInventoryEntry getEntry() {
        if (this.what == null || this.repo == null) {
            return null;
        }
        if (this.repo.hasPower()) {
            return this.repo.getAllEntries().stream().filter(gridInventoryEntry -> gridInventoryEntry.getWhat() != null).filter(gridInventoryEntry -> gridInventoryEntry.getWhat().equals(this.what)).findFirst().orElse(null);
        }
        return null;
    }

    @Override
    public Icon getIcon() {
        return this.icon;
    }

    @Override
    public void setIcon(Icon icon) {
        this.icon = icon;
    }

    @Override
    public long getStoredAmount() {
        GridInventoryEntry gridInventoryEntry = this.getEntry();
        return gridInventoryEntry != null ? gridInventoryEntry.getStoredAmount() : 0L;
    }

    public long getRequestableAmount() {
        GridInventoryEntry gridInventoryEntry = this.getEntry();
        return gridInventoryEntry != null ? gridInventoryEntry.getRequestableAmount() : 0L;
    }

    @Override
    public boolean isCraftable() {
        GridInventoryEntry gridInventoryEntry = this.getEntry();
        return gridInventoryEntry != null && gridInventoryEntry.isCraftable();
    }

    @Override
    @NotNull
    public ItemStack m_7993_() {
        GridInventoryEntry gridInventoryEntry = this.getEntry();
        if (gridInventoryEntry != null && gridInventoryEntry.getWhat() != null) {
            return gridInventoryEntry.getWhat().wrapForDisplayOrFilter();
        }
        return ItemStack.f_41583_;
    }

    @Override
    public boolean m_6657_() {
        return this.getEntry() != null;
    }

    @NotNull
    public List<Component> getEmptyTooltipMessage() {
        return this.emptyTooltips;
    }

    public void setEmptyTooltipMessage(@NotNull List<Component> list) {
        this.emptyTooltips.clear();
        this.emptyTooltips.addAll(list);
    }

    @Override
    public boolean isDraggable() {
        return this.draggable;
    }

    @Override
    public void setDraggable(boolean bl) {
        this.draggable = bl;
    }

    @Override
    public void onXEIDragged(ItemStack itemStack) {
        this.what = GenericStack.unwrapItemStack(itemStack).what();
    }
}

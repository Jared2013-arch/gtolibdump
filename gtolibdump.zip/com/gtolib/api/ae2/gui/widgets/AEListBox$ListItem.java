package com.gtolib.api.ae2.gui.widgets;

import appeng.client.gui.ICompositeWidget;

public interface AEListBox$ListItem
extends ICompositeWidget {
    default public int getWidth() {
        return this.getBounds().m_110090_();
    }

    default public int getHeight() {
        return this.getBounds().m_110091_();
    }

    default public void setSize(int n, int n2) {
    }

    public void setVisible(boolean var1);
}

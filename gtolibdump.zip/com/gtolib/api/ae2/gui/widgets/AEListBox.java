package com.gtolib.api.ae2.gui.widgets;

import appeng.client.Point;
import appeng.client.gui.AEBaseScreen;
import appeng.client.gui.ICompositeWidget;
import appeng.client.gui.Tooltip;
import appeng.client.gui.WidgetContainer;
import appeng.client.gui.widgets.Scrollbar;
import com.gtolib.api.ae2.gui.hooks.IStylelessCompositeWidget;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.Rect2i;
import org.jetbrains.annotations.Nullable;

public class AEListBox
implements IStylelessCompositeWidget {
    private int x = 0;
    private int y = 0;
    private int showNum = 3;
    private boolean isVisible = true;
    private boolean catchScrollbar = true;
    private final Scrollbar scrollbar;
    private final List<ListItem> items = new ObjectArrayList();
    private final AEBaseScreen<?> screen;

    public AEListBox(AEBaseScreen<?> aEBaseScreen) {
        this.screen = aEBaseScreen;
        this.scrollbar = new Scrollbar(Scrollbar.SMALL);
        this.scrollbar.setCaptureMouseWheel(false);
        this.scrollbar.setVisible(false);
    }

    @Override
    public AEBaseScreen<?> getScreen() {
        return this.screen;
    }

    public boolean wantsAllMouseWheelEvents() {
        return this.catchScrollbar;
    }

    public void setCatchScrollbar(boolean bl) {
        this.catchScrollbar = bl;
        this.scrollbar.setCaptureMouseWheel(bl);
    }

    public void addItem(ListItem listItem) {
        this.items.add(listItem);
        listItem.setPosition(new Point(this.x, this.y + this.items.size() * listItem.getHeight()));
    }

    public void clearItems() {
        this.items.clear();
    }

    @Override
    public void setPosition(Point point) {
        this.x = point.getX();
        this.y = point.getY();
    }

    public void setSize(int n, int n2) {
    }

    public void setShowNum(int n) {
        this.showNum = n;
    }

    public int width() {
        return this.getVisibleItems().stream().mapToInt(ListItem::getWidth).max().orElse(0) + this.scrollbar.getBounds().m_110090_();
    }

    public int height() {
        return this.getVisibleItems().stream().mapToInt(ListItem::getHeight).sum();
    }

    private List<ListItem> getVisibleItems() {
        this.scrollbar.setRange(0, Math.max(0, this.items.size() - this.showNum), 1);
        int n = this.scrollbar.getCurrentScroll();
        int n2 = Math.min(n + this.showNum, this.items.size());
        return this.items.subList(n, n2);
    }

    @Override
    public Rect2i getBounds() {
        return new Rect2i(this.x, this.y, this.width(), this.height());
    }

    @Override
    public boolean onMouseWheel(Point point, double d) {
        this.scrollbar.onMouseWheel(point, d);
        return IStylelessCompositeWidget.super.onMouseWheel(point, d);
    }

    @Override
    @Nullable
    public Tooltip getTooltip(int n, int n2) {
        if (!this.isVisible) {
            return null;
        }
        for (ListItem listItem : this.getVisibleItems()) {
            Tooltip tooltip = listItem.getTooltip(n, n2);
            if (tooltip == null) continue;
            return tooltip;
        }
        return null;
    }

    @Override
    public void initialize(String string, WidgetContainer widgetContainer) {
    }

    @Override
    public void updateBeforeRender() {
        List<ListItem> list = this.getVisibleItems();
        int n = 0;
        for (ListItem listItem : this.items) {
            if (list.contains(listItem)) {
                listItem.setVisible(true);
                listItem.setPosition(new Point(this.x, this.y + n));
                listItem.updateBeforeRender();
                n += listItem.getHeight();
                continue;
            }
            listItem.setVisible(false);
        }
        if (this.items.size() > this.showNum) {
            this.scrollbar.setVisible(true);
            this.scrollbar.setPosition(new Point(this.x + this.width() - this.scrollbar.getBounds().m_110090_(), this.y));
            this.scrollbar.setSize(this.scrollbar.getBounds().m_110090_(), this.height());
            this.scrollbar.updateBeforeRender();
        } else {
            this.scrollbar.setVisible(false);
        }
        IStylelessCompositeWidget.super.updateBeforeRender();
    }

    @Override
    public boolean onMouseDown(Point point, int n) {
        for (ListItem listItem : this.getVisibleItems()) {
            if (!listItem.getBounds().m_110087_(point.getX(), point.getY())) continue;
            listItem.onMouseDown(point, n);
            return true;
        }
        return IStylelessCompositeWidget.super.onMouseDown(point, n);
    }

    @Override
    public boolean onMouseUp(Point point, int n) {
        for (ListItem listItem : this.getVisibleItems()) {
            if (!listItem.getBounds().m_110087_(point.getX(), point.getY())) continue;
            listItem.onMouseUp(point, n);
            return true;
        }
        return IStylelessCompositeWidget.super.onMouseUp(point, n);
    }

    @Override
    public void drawBackgroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
        for (ListItem listItem : this.getVisibleItems()) {
            listItem.drawBackgroundLayer(guiGraphics, listItem.getBounds(), point);
        }
        if (this.scrollbar.isVisible()) {
            this.scrollbar.drawBackgroundLayer(guiGraphics, this.scrollbar.getBounds(), point);
        }
    }

    @Override
    public void drawForegroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
        guiGraphics.m_280509_(this.x, this.y, this.x + this.width(), this.y + this.height(), -864585814);
        for (ListItem listItem : this.getVisibleItems()) {
            listItem.drawForegroundLayer(guiGraphics, listItem.getBounds(), point);
        }
        if (this.scrollbar.isVisible()) {
            this.scrollbar.drawForegroundLayer(guiGraphics, this.scrollbar.getBounds(), point);
        }
    }

    public void addExclusionZones(List<Rect2i> list, Rect2i rect2i) {
        list.add(new Rect2i(this.x + this.getGuiLeft(), this.y + this.getGuiTop(), this.width(), this.height()));
    }

    public void setVisible(boolean bl) {
        this.isVisible = bl;
    }

    public boolean isVisible() {
        return this.isVisible;
    }

    public static interface ListItem
    extends ICompositeWidget {
        default public int getWidth() {
            return this.getBounds().m_110090_();
        }

        default public int getHeight() {
            return this.getBounds().m_110091_();
        }

        default public void setSize(int n, int n2) {
        }

        public void setVisible(boolean var1);
    }
}

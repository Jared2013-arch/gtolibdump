package com.gtolib.api.ae2.gui.widgets;

import appeng.client.Point;
import appeng.client.gui.AEBaseScreen;
import appeng.client.gui.Icon;
import appeng.client.gui.Tooltip;
import appeng.client.gui.WidgetContainer;
import appeng.client.gui.style.Blitter;
import com.gtolib.api.ae2.gui.hooks.IStylelessCompositeWidget;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.Slot;
import org.jetbrains.annotations.Nullable;

public class AESlotWidget
implements IStylelessCompositeWidget {
    private static final Blitter SLOT = Icon.SLOT_BACKGROUND.getBlitter();
    private final Slot slot;
    private final AEBaseScreen<?> screen;
    private final List<Component> tooltips = new ObjectArrayList();

    public AESlotWidget(Slot slot, AEBaseScreen<?> aEBaseScreen) {
        this.slot = slot;
        this.screen = aEBaseScreen;
    }

    @Override
    public void setPosition(Point point) {
    }

    @Override
    public AEBaseScreen<?> getScreen() {
        return this.screen;
    }

    @Override
    public void drawBackgroundLayer(GuiGraphics guiGraphics, Rect2i rect2i, Point point) {
        SLOT.dest(this.slot.f_40220_ + this.getGuiLeft() - 1, this.slot.f_40221_ + this.getGuiTop() - 1).blit(guiGraphics);
    }

    public void setSize(int n, int n2) {
    }

    @Override
    @Nullable
    public Tooltip getTooltip(int n, int n2) {
        return new Tooltip(this.tooltips);
    }

    public void setTooltip(List<Component> list) {
        this.tooltips.clear();
        this.tooltips.addAll(list);
    }

    public void setTooltip(Component ... componentArray) {
        this.tooltips.clear();
        this.tooltips.addAll(List.of((Object[])componentArray));
    }

    @Override
    public Rect2i getBounds() {
        return new Rect2i(this.slot.f_40220_, this.slot.f_40221_, 18, 18);
    }

    @Override
    public void initialize(String string, WidgetContainer widgetContainer) {
    }
}

package com.gtolib.api.ae2.gui;

import appeng.client.gui.style.Blitter;
import appeng.client.gui.style.TextureTransform;
import com.gtolib.GTOCore;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.Rect2i;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public final class BlitterGroup {
    private final Blitter head;
    private final Blitter tail;
    private final Blitter middleSegment;
    private int r = 255;
    private int g = 255;
    private int b = 255;
    private int a = 255;
    private Rect2i destRect = new Rect2i(0, 0, 0, 0);
    private boolean blending = true;
    private TextureTransform transform = TextureTransform.NONE;
    private int zOffset;

    BlitterGroup(Blitter blitter, Blitter blitter2, Blitter blitter3) {
        this.head = blitter;
        this.tail = blitter2;
        this.middleSegment = blitter3;
    }

    public static BlitterGroup createFromSplittingBlitter(Blitter blitter, int n, int n2) {
        int n3 = blitter.getSrcX();
        int n4 = blitter.getSrcY();
        int n5 = blitter.getSrcWidth();
        int n6 = blitter.getSrcHeight();
        return new BlitterGroup(blitter.copy().src(n3, n4, n5, n), blitter.copy().src(n3, n4 + n6 - n2, n5, n2), blitter.copy().src(n3, n4 + n, n5, 1));
    }

    public BlitterGroup dest(int n, int n2) {
        this.destRect = new Rect2i(n, n2, 0, 0);
        return this;
    }

    public void vBlit(GuiGraphics guiGraphics, int n) {
        if (n <= 0) {
            return;
        }
        this.vBlit(guiGraphics, this.head);
        if (n > 1) {
            for (int i = 0; i < n - 2; ++i) {
                this.vBlit(guiGraphics, this.middleSegment);
            }
        }
        this.vBlit(guiGraphics, this.tail);
    }

    public void vBlitFixedHeight(GuiGraphics guiGraphics, int n) {
        if (n <= this.head.getSrcHeight() + this.tail.getSrcHeight()) {
            GTOCore.LOGGER.warn("Fixed height {} is too small for the blitter group with head height {} and tail height {}", n, this.head.getSrcHeight(), this.tail.getSrcHeight());
            return;
        }
        int n2 = n - this.head.getSrcHeight() - this.tail.getSrcHeight();
        this.vBlit(guiGraphics, n2);
    }

    private void vBlit(GuiGraphics guiGraphics, Blitter blitter) {
        guiGraphics.m_280168_().m_85836_();
        guiGraphics.m_280168_().m_252880_(0.0f, 0.0f, this.zOffset);
        blitter.dest(this.destRect).color(this.r, this.g, this.b, this.a).blending(this.blending).transform(this.transform).blit(guiGraphics);
        guiGraphics.m_280168_().m_85849_();
        this.destRect = new Rect2i(this.destRect.m_110085_(), this.destRect.m_110086_() + blitter.getSrcHeight(), this.destRect.m_110090_(), 0);
    }

    public BlitterGroup copy() {
        BlitterGroup blitterGroup = new BlitterGroup(this.head.copy(), this.tail.copy(), this.middleSegment.copy());
        blitterGroup.r = this.r;
        blitterGroup.g = this.g;
        blitterGroup.b = this.b;
        blitterGroup.a = this.a;
        blitterGroup.destRect = this.destRect;
        blitterGroup.blending = this.blending;
        blitterGroup.transform = this.transform;
        blitterGroup.zOffset = this.zOffset;
        return blitterGroup;
    }
}

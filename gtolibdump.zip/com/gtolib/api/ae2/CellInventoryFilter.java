package com.gtolib.api.ae2;

import appeng.api.inventories.InternalInventory;
import appeng.api.storage.StorageCells;
import appeng.util.inv.filter.IAEItemFilter;
import net.minecraft.world.item.ItemStack;

public class CellInventoryFilter
implements IAEItemFilter {
    private final Runnable runnable;

    public CellInventoryFilter(Runnable runnable) {
        this.runnable = runnable;
    }

    public boolean allowExtract(InternalInventory internalInventory, int n, int n2) {
        this.runnable.run();
        return true;
    }

    public boolean allowInsert(InternalInventory internalInventory, int n, ItemStack itemStack) {
        return StorageCells.getHandler(itemStack) != null;
    }
}

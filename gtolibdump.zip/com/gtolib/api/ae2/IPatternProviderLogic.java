package com.gtolib.api.ae2;

import appeng.api.crafting.IPatternDetails;
import appeng.api.stacks.KeyCounter;
import com.gtolib.api.ae2.BlockingType;
import com.gtolib.utils.holder.ObjectHolder;
import java.util.function.IntSupplier;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.world.level.Level;

public interface IPatternProviderLogic {
    public BlockingType gtolib$getBlocking();

    public IPatternDetails gtolib$getCurrentPattern();

    public IPatternDetails gtolib$getCachePattern(long var1, int var3);

    public int gtolib$pushPattern(IPatternDetails var1, ObjectHolder<KeyCounter[]> var2, IntSupplier var3);

    default public GlobalPos gto$getPos() {
        return GlobalPos.m_122643_(Level.f_46428_, BlockPos.f_121853_);
    }
}

package com.gtolib.api.ae2.pattern;

import appeng.api.crafting.IPatternDetails;
import appeng.api.crafting.PatternDetailsHelper;
import appeng.api.networking.IGrid;
import appeng.api.stacks.AEKey;
import appeng.core.definitions.AEItems;
import appeng.helpers.patternprovider.PatternContainer;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.HashMultiset;
import com.google.common.collect.Multiset;
import com.google.common.collect.SetMultimap;
import com.gregtechceu.gtceu.utils.collection.OpenCacheHashSet;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class GridPatternsRemover {
    private final SetMultimap<AEKey, PatternLocator> whereIsThePatterns = HashMultimap.create();
    private final SetMultimap<AEKey, AEKey> whatDoesThisProductConsistOf = HashMultimap.create();
    private final Multiset<AEKey> howManyUsagesDoesThisIngredientHave = HashMultiset.create();

    public GridPatternsRemover(IGrid iGrid, Level level) {
        for (Class clazz : iGrid.getMachineClasses()) {
            Class<? extends PatternContainer> clazz2 = GridPatternsRemover.tryCastMachineToContainer(clazz);
            if (clazz2 == null) continue;
            OpenCacheHashSet openCacheHashSet = new OpenCacheHashSet();
            for (PatternContainer patternContainer : iGrid.getActiveMachines(clazz2)) {
                for (int i = 0; i < patternContainer.getTerminalPatternInventory().size(); ++i) {
                    IPatternDetails iPatternDetails;
                    ItemStack itemStack = patternContainer.getTerminalPatternInventory().getStackInSlot(i);
                    if (!itemStack.m_150930_(AEItems.PROCESSING_PATTERN.m_5456_()) || (iPatternDetails = PatternDetailsHelper.decodePattern(itemStack, level)) == null) continue;
                    AEKey aEKey = iPatternDetails.getPrimaryOutput().what();
                    List list = Stream.of(iPatternDetails.getInputs()).map(IPatternDetails.IInput::getPossibleInputs).map(genericStackArray -> genericStackArray[0].what()).toList();
                    this.whereIsThePatterns.put(aEKey, new PatternLocator(patternContainer, i));
                    if (!openCacheHashSet.add(new PatternDetailsNoAmount(aEKey, list))) continue;
                    this.whatDoesThisProductConsistOf.putAll(aEKey, list);
                    this.howManyUsagesDoesThisIngredientHave.addAll(list);
                }
            }
        }
    }

    public static List<PatternLocator> collectPatternToRemove(IGrid iGrid, Level level, AEKey aEKey, boolean bl) {
        if (bl) {
            return new GridPatternsRemover(iGrid, level).collectPatternToRemove(aEKey, new OpenCacheHashSet());
        }
        return new GridPatternsRemover((IGrid)iGrid, (Level)level).whereIsThePatterns.get((Object)aEKey).stream().toList();
    }

    List<PatternLocator> collectPatternToRemove(AEKey aEKey, Set<AEKey> set) {
        ObjectArrayList objectArrayList = new ObjectArrayList(this.whereIsThePatterns.get((Object)aEKey));
        if (!set.add(aEKey)) {
            return objectArrayList;
        }
        for (AEKey aEKey2 : this.whatDoesThisProductConsistOf.get((Object)aEKey)) {
            if (this.howManyUsagesDoesThisIngredientHave.count(aEKey2) > 1) continue;
            objectArrayList.addAll(this.collectPatternToRemove(aEKey2, set));
        }
        return objectArrayList;
    }

    private static Class<? extends PatternContainer> tryCastMachineToContainer(Class<?> clazz) {
        if (PatternContainer.class.isAssignableFrom(clazz)) {
            return clazz.asSubclass(PatternContainer.class);
        }
        return null;
    }

    public record PatternLocator(PatternContainer container, int slot) {
    }

    private record PatternDetailsNoAmount(AEKey key, List<AEKey> inputs) {
    }
}

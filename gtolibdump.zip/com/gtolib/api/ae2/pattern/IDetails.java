package com.gtolib.api.ae2.pattern;

import appeng.api.crafting.IPatternDetails;
import appeng.api.stacks.KeyCounter;

public interface IDetails
extends IPatternDetails {
    default public KeyCounter[] gtolib$getInputHolder() {
        throw new UnsupportedOperationException();
    }
}

package com.gtolib.api.ae2.pattern;

import appeng.api.stacks.AEKey;
import java.util.List;

record GridPatternsRemover$PatternDetailsNoAmount(AEKey key, List<AEKey> inputs) {
}

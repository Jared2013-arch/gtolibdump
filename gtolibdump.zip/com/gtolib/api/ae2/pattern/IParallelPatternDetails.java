package com.gtolib.api.ae2.pattern;

import appeng.api.crafting.IPatternDetails;
import appeng.crafting.pattern.AECraftingPattern;
import appeng.crafting.pattern.AEProcessingPattern;
import appeng.crafting.pattern.AESmithingTablePattern;
import appeng.crafting.pattern.AEStonecuttingPattern;
import com.gtolib.ae2.b.a;
import com.gtolib.ae2.b.b;
import com.gtolib.ae2.b.c;
import com.gtolib.ae2.b.d;
import com.gtolib.api.ae2.pattern.IDetails;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public interface IParallelPatternDetails
extends IDetails {
    public IParallelPatternDetails copy(long var1, Level var3);

    public IParallelPatternDetails getCopy();

    public void parallel(long var1);

    public long getParallel();

    @Nullable
    public static IParallelPatternDetails of(@Nullable IPatternDetails iPatternDetails, @Nullable Level level, long l) {
        if (iPatternDetails instanceof AEProcessingPattern) {
            AEProcessingPattern aEProcessingPattern = (AEProcessingPattern)iPatternDetails;
            return new b(aEProcessingPattern.getDefinition(), l);
        }
        if (iPatternDetails instanceof AECraftingPattern) {
            AECraftingPattern aECraftingPattern = (AECraftingPattern)((Object)iPatternDetails);
            return new a(aECraftingPattern.getDefinition(), level, l);
        }
        if (iPatternDetails instanceof AEStonecuttingPattern) {
            AEStonecuttingPattern aEStonecuttingPattern = (AEStonecuttingPattern)((Object)iPatternDetails);
            return new d(aEStonecuttingPattern.getDefinition(), level, l);
        }
        if (iPatternDetails instanceof AESmithingTablePattern) {
            AESmithingTablePattern aESmithingTablePattern = (AESmithingTablePattern)((Object)iPatternDetails);
            return new c(aESmithingTablePattern.getDefinition(), level, l);
        }
        return null;
    }
}

package com.gtolib.api.ae2.stacks;

import appeng.api.stacks.AEKey;
import appeng.api.stacks.KeyCounter;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import it.unimi.dsi.fastutil.objects.Object2LongOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.math.BigInteger;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface IKeyCounter {
    @Nullable
    public Object2LongOpenHashMap<AEKey> gtolib$getMap();

    public boolean gtolib$contains(AEKey var1);

    public void gtolib$ensureCapacity(int var1);

    public void gtolib$addAll(Object2LongOpenHashMap<AEKey> var1);

    public void gtolib$addAll(Object2ObjectOpenHashMap<AEKey, BigInteger> var1);

    public static void addAll(KeyCounter keyCounter, Object2LongOpenHashMap<AEKey> object2LongOpenHashMap) {
        ((IKeyCounter)((Object)keyCounter)).gtolib$addAll(object2LongOpenHashMap);
    }

    public static void addAll(KeyCounter keyCounter, Object2ObjectOpenHashMap<AEKey, BigInteger> object2ObjectOpenHashMap) {
        ((IKeyCounter)((Object)keyCounter)).gtolib$addAll(object2ObjectOpenHashMap);
    }

    @NotNull
    public static IKeyCounter of(KeyCounter keyCounter) {
        return (IKeyCounter)((Object)keyCounter);
    }

    public static class Entry
    implements Object2LongMap.Entry<AEKey> {
        private final long value;
        private final AEKey key;

        public Entry(long l, AEKey aEKey) {
            this.value = l;
            this.key = aEKey;
        }

        @Override
        public long getLongValue() {
            return this.value;
        }

        @Override
        public long setValue(long l) {
            return 0L;
        }

        @Override
        public AEKey getKey() {
            return this.key;
        }
    }
}

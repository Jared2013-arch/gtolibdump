package com.gtolib.api.ae2.stacks;

import net.minecraft.world.item.ItemStack;

public interface IAEItemKey {
    public void gtolib$setMaxStackSize(int var1);

    public void gtolib$setReadOnlyStack(ItemStack var1);
}

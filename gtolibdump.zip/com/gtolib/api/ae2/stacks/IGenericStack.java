package com.gtolib.api.ae2.stacks;

import appeng.api.stacks.GenericStack;
import org.jetbrains.annotations.NotNull;

public interface IGenericStack {
    public void setAmount(long var1);

    public static IGenericStack of(@NotNull GenericStack genericStack) {
        return (IGenericStack)((Object)genericStack);
    }
}

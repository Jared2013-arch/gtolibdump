package com.gtolib.api.ae2.stacks;

import appeng.api.stacks.AEKey;
import it.unimi.dsi.fastutil.objects.Object2LongMap;

public class IKeyCounter$Entry
implements Object2LongMap.Entry<AEKey> {
    private final long value;
    private final AEKey key;

    public IKeyCounter$Entry(long l, AEKey aEKey) {
        this.value = l;
        this.key = aEKey;
    }

    @Override
    public long getLongValue() {
        return this.value;
    }

    @Override
    public long setValue(long l) {
        return 0L;
    }

    @Override
    public AEKey getKey() {
        return this.key;
    }
}

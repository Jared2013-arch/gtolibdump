package com.gtolib.api.ae2;

public enum ShowMolecularAssembler {
    ONLY_MOLECULAR_ASSEMBLER,
    EXPECT_MOLECULAR_ASSEMBLER,
    ALL;

}

package com.gtolib.api.capability;

import com.gtolib.api.wireless.WirelessComputationContainer;
import com.hepdd.gtmthings.api.capability.IBindable;
import javax.annotation.Nullable;

public interface IWirelessComputationContainerHolder
extends IBindable {
    public void setWirelessComputationContainerCache(WirelessComputationContainer var1);

    public WirelessComputationContainer getWirelessComputationContainerCache();

    @Nullable
    default public WirelessComputationContainer getWirelessComputationContainer() {
        if (this.getUUID() != null && this.getWirelessComputationContainerCache() == null) {
            WirelessComputationContainer wirelessComputationContainer = WirelessComputationContainer.getOrCreateContainer(this.getUUID());
            this.setWirelessComputationContainerCache(wirelessComputationContainer);
        }
        return this.getWirelessComputationContainerCache();
    }
}

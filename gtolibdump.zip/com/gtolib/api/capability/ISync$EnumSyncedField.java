package com.gtolib.api.capability;

import com.gtolib.api.capability.ISync;
import java.lang.invoke.LambdaMetafactory;
import java.util.function.BiConsumer;
import net.minecraft.network.FriendlyByteBuf;

public class ISync$EnumSyncedField<T extends Enum<T>>
extends ISync.ObjectSyncedField<T> {
    private ISync$EnumSyncedField(ISync iSync) {
        super(iSync, null, (BiConsumer<FriendlyByteBuf, Enum>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;Ljava/lang/Object;)V, m_130068_(java.lang.Enum ), (Lnet/minecraft/network/FriendlyByteBuf;Ljava/lang/Enum;)V)());
    }

    @Override
    protected T readBuffer(FriendlyByteBuf friendlyByteBuf) {
        return (T)friendlyByteBuf.m_130066_(((Enum)this.value).getClass());
    }
}

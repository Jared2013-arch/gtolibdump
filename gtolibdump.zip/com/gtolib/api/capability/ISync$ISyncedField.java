package com.gtolib.api.capability;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.fml.LogicalSide;

public interface ISync$ISyncedField {
    public void writeBuffer(FriendlyByteBuf var1);

    public void readBuffer(FriendlyByteBuf var1, LogicalSide var2);
}

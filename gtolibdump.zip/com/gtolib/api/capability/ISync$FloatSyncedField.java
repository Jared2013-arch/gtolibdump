package com.gtolib.api.capability;

import com.gtolib.api.capability.ISync;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.fml.LogicalSide;
import org.jetbrains.annotations.NotNull;

public class ISync$FloatSyncedField
extends ISync.AbstractSyncedField {
    private float value;
    private ISync.FloatListener receiverListener = ISync.FloatListener.EMPTY;
    private ISync.FloatListener senderListener = ISync.FloatListener.EMPTY;

    private ISync$FloatSyncedField(ISync iSync) {
        super(iSync);
    }

    @Override
    public void readBuffer(FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide) {
        float f = this.value;
        this.value = friendlyByteBuf.readFloat();
        this.receiverListener.onSync(logicalSide, f, this.value);
    }

    @Override
    public void writeBuffer(FriendlyByteBuf friendlyByteBuf) {
        friendlyByteBuf.writeFloat(this.value);
    }

    public ISync$FloatSyncedField setReceiverListener(@NotNull ISync.FloatListener floatListener) {
        this.receiverListener = floatListener;
        return this;
    }

    public ISync$FloatSyncedField setSenderListener(@NotNull ISync.FloatListener floatListener) {
        this.senderListener = floatListener;
        return this;
    }

    public ISync$FloatSyncedField set(float f) {
        this.value = f;
        return this;
    }

    public float get() {
        return this.value;
    }

    public void setAndAutoSync(float f) {
        if (this.sync.getLevel().f_46443_) {
            this.setAndSyncToServer(f);
        } else {
            this.setAndSyncToClient(f);
        }
    }

    public void setAndSyncToServer(float f) {
        float f2 = this.value;
        this.value = f;
        this.senderListener.onSync(LogicalSide.CLIENT, f2, f);
        this.sync.syncToServer(this.getName());
    }

    public void setAndSyncToClient(float f) {
        float f2 = this.value;
        this.value = f;
        this.senderListener.onSync(LogicalSide.SERVER, f2, f);
        this.sync.syncToClient(this.getName());
    }
}

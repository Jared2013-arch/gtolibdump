package com.gtolib.api.capability;

import com.gtolib.api.capability.ISync;
import java.util.function.BiConsumer;
import java.util.function.Function;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.fml.LogicalSide;
import org.jetbrains.annotations.NotNull;

public class ISync$ObjectSyncedField<T>
extends ISync.AbstractSyncedField {
    protected T value;
    protected final Function<FriendlyByteBuf, T> readBuffer;
    protected final BiConsumer<FriendlyByteBuf, T> writeBuffer;
    protected ISync.Listener<T> receiverListener = ISync.Listener.EMPTY;
    protected ISync.Listener<T> senderListener = ISync.Listener.EMPTY;

    protected ISync$ObjectSyncedField(ISync iSync, Function<FriendlyByteBuf, T> function, BiConsumer<FriendlyByteBuf, T> biConsumer) {
        super(iSync);
        this.readBuffer = function;
        this.writeBuffer = biConsumer;
    }

    @Override
    public void readBuffer(FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide) {
        T t = this.value;
        this.value = this.readBuffer(friendlyByteBuf);
        this.receiverListener.onSync(logicalSide, t, this.value);
    }

    @Override
    public void writeBuffer(FriendlyByteBuf friendlyByteBuf) {
        this.writeBuffer.accept(friendlyByteBuf, (FriendlyByteBuf)this.value);
    }

    public ISync$ObjectSyncedField<T> setReceiverListener(@NotNull ISync.Listener<T> listener) {
        this.receiverListener = listener;
        return this;
    }

    public ISync$ObjectSyncedField<T> setSenderListener(@NotNull ISync.Listener<T> listener) {
        this.senderListener = listener;
        return this;
    }

    protected T readBuffer(FriendlyByteBuf friendlyByteBuf) {
        return this.readBuffer.apply(friendlyByteBuf);
    }

    public ISync$ObjectSyncedField<T> set(T t) {
        this.value = t;
        return this;
    }

    public T get() {
        return this.value;
    }

    public void setAndAutoSync(T t) {
        if (this.sync.getLevel().f_46443_) {
            this.setAndSyncToServer(t);
        } else {
            this.setAndSyncToClient(t);
        }
    }

    public void setAndSyncToServer(T t) {
        T t2 = this.value;
        this.value = t;
        this.senderListener.onSync(LogicalSide.CLIENT, t2, t);
        this.sync.syncToServer(this.getName());
    }

    public void setAndSyncToClient(T t) {
        T t2 = this.value;
        this.value = t;
        this.senderListener.onSync(LogicalSide.SERVER, t2, t);
        this.sync.syncToClient(this.getName());
    }
}

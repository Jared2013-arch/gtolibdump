package com.gtolib.api.capability;

import com.gtolib.api.capability.ISync;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.fml.LogicalSide;
import org.jetbrains.annotations.NotNull;

public class ISync$IntSyncedField
extends ISync.AbstractSyncedField {
    private int value;
    private ISync.IntListener receiverListener = ISync.IntListener.EMPTY;
    private ISync.IntListener senderListener = ISync.IntListener.EMPTY;

    private ISync$IntSyncedField(ISync iSync) {
        super(iSync);
    }

    @Override
    public void readBuffer(FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide) {
        int n = this.value;
        this.value = friendlyByteBuf.readInt();
        this.receiverListener.onSync(logicalSide, n, this.value);
    }

    @Override
    public void writeBuffer(FriendlyByteBuf friendlyByteBuf) {
        friendlyByteBuf.writeInt(this.value);
    }

    public ISync$IntSyncedField setReceiverListener(@NotNull ISync.IntListener intListener) {
        this.receiverListener = intListener;
        return this;
    }

    public ISync$IntSyncedField setSenderListener(@NotNull ISync.IntListener intListener) {
        this.senderListener = intListener;
        return this;
    }

    public ISync$IntSyncedField set(int n) {
        this.value = n;
        return this;
    }

    public int get() {
        return this.value;
    }

    public void setAndAutoSync(int n) {
        if (this.sync.getLevel().f_46443_) {
            this.setAndSyncToServer(n);
        } else {
            this.setAndSyncToClient(n);
        }
    }

    public void setAndSyncToServer(int n) {
        int n2 = this.value;
        this.value = n;
        this.senderListener.onSync(LogicalSide.CLIENT, n2, n);
        this.sync.syncToServer(this.getName());
    }

    public void setAndSyncToClient(int n) {
        int n2 = this.value;
        this.value = n;
        this.senderListener.onSync(LogicalSide.SERVER, n2, n);
        this.sync.syncToClient(this.getName());
    }
}

package com.gtolib.api.capability.recipe;

import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.recipe.content.Content;
import com.gregtechceu.gtceu.api.recipe.content.ContentModifier;
import com.gregtechceu.gtceu.api.recipe.content.SerializerLong;
import com.lowdragmc.lowdraglib.gui.widget.LabelWidget;
import com.lowdragmc.lowdraglib.gui.widget.WidgetGroup;
import com.lowdragmc.lowdraglib.utils.LocalizationUtils;
import java.util.List;
import org.apache.commons.lang3.mutable.MutableInt;

public final class ManaRecipeCapability
extends RecipeCapability<Long> {
    public static final ManaRecipeCapability CAP = new ManaRecipeCapability();

    private ManaRecipeCapability() {
        super("mana", -16731649, false, 3, SerializerLong.INSTANCE);
    }

    public Long copyInner(Long l) {
        return l;
    }

    public Long copyWithModifier(Long l, ContentModifier contentModifier) {
        return contentModifier.apply(l);
    }

    public void addXEIInfo(WidgetGroup widgetGroup, int n, GTRecipe gTRecipe, List<Content> list, boolean bl, boolean bl2, MutableInt mutableInt) {
        long l = list.stream().map(Content::getContent).mapToLong(CAP::of).sum();
        widgetGroup.addWidget(new LabelWidget(3 - n, mutableInt.addAndGet(10), LocalizationUtils.format(bl2 ? "gtocore.machine.mana_input" : "gtocore.machine.mana_output", new Object[]{l}) + (bl ? " /t" : "")));
        if (bl) {
            widgetGroup.addWidget(new LabelWidget(3 - n, mutableInt.addAndGet(10), LocalizationUtils.format("gtocore.machine.mana_stored", new Object[]{l * (long)gTRecipe.duration})));
        }
    }
}

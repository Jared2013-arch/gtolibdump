package com.gtolib.api.capability.recipe;

import com.gregtechceu.gtceu.api.registry.GTRegistries;
import com.gtolib.api.capability.recipe.ManaRecipeCapability;

public final class GTORecipeCapabilities {
    public static void init() {
        GTRegistries.RECIPE_CAPABILITIES.register(ManaRecipeCapability.CAP.name, ManaRecipeCapability.CAP);
    }
}

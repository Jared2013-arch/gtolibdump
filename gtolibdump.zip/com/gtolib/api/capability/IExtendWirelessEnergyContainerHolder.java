package com.gtolib.api.capability;

import com.gtolib.api.wireless.ExtendWirelessEnergyContainer;
import com.hepdd.gtmthings.api.machine.IWirelessEnergyContainerHolder;
import com.hepdd.gtmthings.api.misc.WirelessEnergyContainer;
import javax.annotation.Nullable;

public interface IExtendWirelessEnergyContainerHolder
extends IWirelessEnergyContainerHolder {
    @Nullable
    default public ExtendWirelessEnergyContainer getWirelessEnergyContainer() {
        if (this.getUUID() != null && this.getWirelessEnergyContainerCache() == null) {
            WirelessEnergyContainer wirelessEnergyContainer = WirelessEnergyContainer.getOrCreateContainer(this.getUUID());
            this.setWirelessEnergyContainerCache(wirelessEnergyContainer);
        }
        return (ExtendWirelessEnergyContainer)this.getWirelessEnergyContainerCache();
    }
}

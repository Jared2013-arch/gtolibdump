package com.gtolib.api.capability;

import net.minecraftforge.fml.LogicalSide;

@FunctionalInterface
public interface ISync$Listener<T> {
    public static final ISync$Listener EMPTY = (logicalSide, object, object2) -> {};

    public void onSync(LogicalSide var1, T var2, T var3);
}

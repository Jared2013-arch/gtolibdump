package com.gtolib.api.capability;

import net.minecraftforge.fml.LogicalSide;

@FunctionalInterface
public interface ISync$IntListener {
    public static final ISync$IntListener EMPTY = (logicalSide, n, n2) -> {};

    public void onSync(LogicalSide var1, int var2, int var3);
}

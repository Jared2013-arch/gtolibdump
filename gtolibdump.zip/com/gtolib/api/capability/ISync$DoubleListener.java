package com.gtolib.api.capability;

import net.minecraftforge.fml.LogicalSide;

@FunctionalInterface
public interface ISync$DoubleListener {
    public static final ISync$DoubleListener EMPTY = (logicalSide, d, d2) -> {};

    public void onSync(LogicalSide var1, double var2, double var4);
}

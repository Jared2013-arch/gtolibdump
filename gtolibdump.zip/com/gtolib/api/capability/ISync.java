package com.gtolib.api.capability;

import com.gtolib.d;
import com.gtolib.syncdata.SyncManagedFieldHolder;
import java.lang.invoke.LambdaMetafactory;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.Function;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.level.Level;
import net.minecraftforge.fml.LogicalSide;
import org.jetbrains.annotations.NotNull;

public interface ISync {
    public Level getLevel();

    public BlockPos getPos();

    public SyncManagedFieldHolder getSyncHolder();

    default public void syncToServer(String string) {
        ((d)((Object)this.getLevel())).gtolib$getSyncFieldManager().a(this, string);
    }

    default public void syncToClient(String string) {
        ((d)((Object)this.getLevel())).gtolib$getSyncFieldManager().b(this, string);
    }

    default public void syncToServer() {
        ((d)((Object)this.getLevel())).gtolib$getSyncFieldManager().a(this);
    }

    default public void syncToClient() {
        ((d)((Object)this.getLevel())).gtolib$getSyncFieldManager().b(this);
    }

    default public void registerSync() {
        ((d)((Object)this.getLevel())).gtolib$getSyncFieldManager().a.put(this.getPos().m_121878_(), (Object)this);
    }

    default public void unregisterSync() {
        ((d)((Object)this.getLevel())).gtolib$getSyncFieldManager().a.remove(this.getPos().m_121878_());
    }

    public static BooleanSyncedField createBooleanField(ISync iSync) {
        return new BooleanSyncedField(iSync);
    }

    public static IntSyncedField createIntField(ISync iSync) {
        return new IntSyncedField(iSync);
    }

    public static LongSyncedField createLongField(ISync iSync) {
        return new LongSyncedField(iSync);
    }

    public static FloatSyncedField createFloatField(ISync iSync) {
        return new FloatSyncedField(iSync);
    }

    public static DoubleSyncedField createDoubleField(ISync iSync) {
        return new DoubleSyncedField(iSync);
    }

    public static <T extends Enum<T>> EnumSyncedField<T> createEnumField(ISync iSync) {
        return new EnumSyncedField(iSync);
    }

    public static ObjectSyncedField<String> createStringField(ISync iSync) {
        return new ObjectSyncedField<String>(iSync, FriendlyByteBuf::m_130277_, FriendlyByteBuf::m_130070_);
    }

    public static ObjectSyncedField<UUID> createUUIDField(ISync iSync) {
        return new ObjectSyncedField<UUID>(iSync, (Function<FriendlyByteBuf, UUID>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, m_130259_(), (Lnet/minecraft/network/FriendlyByteBuf;)Ljava/util/UUID;)(), (BiConsumer<FriendlyByteBuf, UUID>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;Ljava/lang/Object;)V, m_130077_(java.util.UUID ), (Lnet/minecraft/network/FriendlyByteBuf;Ljava/util/UUID;)V)());
    }

    public static <T> ObjectSyncedField<T> createObjectField(ISync iSync, Function<FriendlyByteBuf, T> function, BiConsumer<FriendlyByteBuf, T> biConsumer) {
        return new ObjectSyncedField<T>(iSync, function, biConsumer);
    }

    public static class BooleanSyncedField
    extends AbstractSyncedField {
        private boolean value;
        private BooleanListener receiverListener = BooleanListener.EMPTY;
        private BooleanListener senderListener = BooleanListener.EMPTY;

        private BooleanSyncedField(ISync iSync) {
            super(iSync);
        }

        @Override
        public void readBuffer(FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide) {
            boolean bl = this.value;
            this.value = friendlyByteBuf.readBoolean();
            this.receiverListener.onSync(logicalSide, bl, this.value);
        }

        @Override
        public void writeBuffer(FriendlyByteBuf friendlyByteBuf) {
            friendlyByteBuf.writeBoolean(this.value);
        }

        public BooleanSyncedField setReceiverListener(@NotNull BooleanListener booleanListener) {
            this.receiverListener = booleanListener;
            return this;
        }

        public BooleanSyncedField setSenderListener(@NotNull BooleanListener booleanListener) {
            this.senderListener = booleanListener;
            return this;
        }

        public BooleanSyncedField set(boolean bl) {
            this.value = bl;
            return this;
        }

        public boolean get() {
            return this.value;
        }

        public void setAndAutoSync(boolean bl) {
            if (this.sync.getLevel().f_46443_) {
                this.setAndSyncToServer(bl);
            } else {
                this.setAndSyncToClient(bl);
            }
        }

        public void setAndSyncToServer(boolean bl) {
            boolean bl2 = this.value;
            this.value = bl;
            this.senderListener.onSync(LogicalSide.CLIENT, bl2, bl);
            this.sync.syncToServer(this.getName());
        }

        public void setAndSyncToClient(boolean bl) {
            boolean bl2 = this.value;
            this.value = bl;
            this.senderListener.onSync(LogicalSide.SERVER, bl2, bl);
            this.sync.syncToClient(this.getName());
        }
    }

    public static class IntSyncedField
    extends AbstractSyncedField {
        private int value;
        private IntListener receiverListener = IntListener.EMPTY;
        private IntListener senderListener = IntListener.EMPTY;

        private IntSyncedField(ISync iSync) {
            super(iSync);
        }

        @Override
        public void readBuffer(FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide) {
            int n = this.value;
            this.value = friendlyByteBuf.readInt();
            this.receiverListener.onSync(logicalSide, n, this.value);
        }

        @Override
        public void writeBuffer(FriendlyByteBuf friendlyByteBuf) {
            friendlyByteBuf.writeInt(this.value);
        }

        public IntSyncedField setReceiverListener(@NotNull IntListener intListener) {
            this.receiverListener = intListener;
            return this;
        }

        public IntSyncedField setSenderListener(@NotNull IntListener intListener) {
            this.senderListener = intListener;
            return this;
        }

        public IntSyncedField set(int n) {
            this.value = n;
            return this;
        }

        public int get() {
            return this.value;
        }

        public void setAndAutoSync(int n) {
            if (this.sync.getLevel().f_46443_) {
                this.setAndSyncToServer(n);
            } else {
                this.setAndSyncToClient(n);
            }
        }

        public void setAndSyncToServer(int n) {
            int n2 = this.value;
            this.value = n;
            this.senderListener.onSync(LogicalSide.CLIENT, n2, n);
            this.sync.syncToServer(this.getName());
        }

        public void setAndSyncToClient(int n) {
            int n2 = this.value;
            this.value = n;
            this.senderListener.onSync(LogicalSide.SERVER, n2, n);
            this.sync.syncToClient(this.getName());
        }
    }

    public static class LongSyncedField
    extends AbstractSyncedField {
        private long value;
        private LongListener receiverListener = LongListener.EMPTY;
        private LongListener senderListener = LongListener.EMPTY;

        private LongSyncedField(ISync iSync) {
            super(iSync);
        }

        @Override
        public void readBuffer(FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide) {
            long l = this.value;
            this.value = friendlyByteBuf.readLong();
            this.receiverListener.onSync(logicalSide, l, this.value);
        }

        @Override
        public void writeBuffer(FriendlyByteBuf friendlyByteBuf) {
            friendlyByteBuf.writeLong(this.value);
        }

        public LongSyncedField setReceiverListener(@NotNull LongListener longListener) {
            this.receiverListener = longListener;
            return this;
        }

        public LongSyncedField setSenderListener(@NotNull LongListener longListener) {
            this.senderListener = longListener;
            return this;
        }

        public LongSyncedField set(long l) {
            this.value = l;
            return this;
        }

        public long get() {
            return this.value;
        }

        public void setAndAutoSync(long l) {
            if (this.sync.getLevel().f_46443_) {
                this.setAndSyncToServer(l);
            } else {
                this.setAndSyncToClient(l);
            }
        }

        public void setAndSyncToServer(long l) {
            long l2 = this.value;
            this.value = l;
            this.senderListener.onSync(LogicalSide.CLIENT, l2, l);
            this.sync.syncToServer(this.getName());
        }

        public void setAndSyncToClient(long l) {
            long l2 = this.value;
            this.value = l;
            this.senderListener.onSync(LogicalSide.SERVER, l2, l);
            this.sync.syncToClient(this.getName());
        }
    }

    public static class FloatSyncedField
    extends AbstractSyncedField {
        private float value;
        private FloatListener receiverListener = FloatListener.EMPTY;
        private FloatListener senderListener = FloatListener.EMPTY;

        private FloatSyncedField(ISync iSync) {
            super(iSync);
        }

        @Override
        public void readBuffer(FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide) {
            float f = this.value;
            this.value = friendlyByteBuf.readFloat();
            this.receiverListener.onSync(logicalSide, f, this.value);
        }

        @Override
        public void writeBuffer(FriendlyByteBuf friendlyByteBuf) {
            friendlyByteBuf.writeFloat(this.value);
        }

        public FloatSyncedField setReceiverListener(@NotNull FloatListener floatListener) {
            this.receiverListener = floatListener;
            return this;
        }

        public FloatSyncedField setSenderListener(@NotNull FloatListener floatListener) {
            this.senderListener = floatListener;
            return this;
        }

        public FloatSyncedField set(float f) {
            this.value = f;
            return this;
        }

        public float get() {
            return this.value;
        }

        public void setAndAutoSync(float f) {
            if (this.sync.getLevel().f_46443_) {
                this.setAndSyncToServer(f);
            } else {
                this.setAndSyncToClient(f);
            }
        }

        public void setAndSyncToServer(float f) {
            float f2 = this.value;
            this.value = f;
            this.senderListener.onSync(LogicalSide.CLIENT, f2, f);
            this.sync.syncToServer(this.getName());
        }

        public void setAndSyncToClient(float f) {
            float f2 = this.value;
            this.value = f;
            this.senderListener.onSync(LogicalSide.SERVER, f2, f);
            this.sync.syncToClient(this.getName());
        }
    }

    public static class DoubleSyncedField
    extends AbstractSyncedField {
        private double value;
        private DoubleListener receiverListener = DoubleListener.EMPTY;
        private DoubleListener senderListener = DoubleListener.EMPTY;

        private DoubleSyncedField(ISync iSync) {
            super(iSync);
        }

        @Override
        public void readBuffer(FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide) {
            double d = this.value;
            this.value = friendlyByteBuf.readDouble();
            this.receiverListener.onSync(logicalSide, d, this.value);
        }

        @Override
        public void writeBuffer(FriendlyByteBuf friendlyByteBuf) {
            friendlyByteBuf.writeDouble(this.value);
        }

        public DoubleSyncedField setReceiverListener(@NotNull DoubleListener doubleListener) {
            this.receiverListener = doubleListener;
            return this;
        }

        public DoubleSyncedField setSenderListener(@NotNull DoubleListener doubleListener) {
            this.senderListener = doubleListener;
            return this;
        }

        public DoubleSyncedField set(double d) {
            this.value = d;
            return this;
        }

        public double get() {
            return this.value;
        }

        public void setAndAutoSync(double d) {
            if (this.sync.getLevel().f_46443_) {
                this.setAndSyncToServer(d);
            } else {
                this.setAndSyncToClient(d);
            }
        }

        public void setAndSyncToServer(double d) {
            double d2 = this.value;
            this.value = d;
            this.senderListener.onSync(LogicalSide.CLIENT, d2, d);
            this.sync.syncToServer(this.getName());
        }

        public void setAndSyncToClient(double d) {
            double d2 = this.value;
            this.value = d;
            this.senderListener.onSync(LogicalSide.SERVER, d2, d);
            this.sync.syncToClient(this.getName());
        }
    }

    public static class EnumSyncedField<T extends Enum<T>>
    extends ObjectSyncedField<T> {
        private EnumSyncedField(ISync iSync) {
            super(iSync, null, (BiConsumer<FriendlyByteBuf, Enum>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;Ljava/lang/Object;)V, m_130068_(java.lang.Enum ), (Lnet/minecraft/network/FriendlyByteBuf;Ljava/lang/Enum;)V)());
        }

        @Override
        protected T readBuffer(FriendlyByteBuf friendlyByteBuf) {
            return (T)friendlyByteBuf.m_130066_(((Enum)this.value).getClass());
        }
    }

    public static class ObjectSyncedField<T>
    extends AbstractSyncedField {
        protected T value;
        protected final Function<FriendlyByteBuf, T> readBuffer;
        protected final BiConsumer<FriendlyByteBuf, T> writeBuffer;
        protected Listener<T> receiverListener = Listener.EMPTY;
        protected Listener<T> senderListener = Listener.EMPTY;

        protected ObjectSyncedField(ISync iSync, Function<FriendlyByteBuf, T> function, BiConsumer<FriendlyByteBuf, T> biConsumer) {
            super(iSync);
            this.readBuffer = function;
            this.writeBuffer = biConsumer;
        }

        @Override
        public void readBuffer(FriendlyByteBuf friendlyByteBuf, LogicalSide logicalSide) {
            T t = this.value;
            this.value = this.readBuffer(friendlyByteBuf);
            this.receiverListener.onSync(logicalSide, t, this.value);
        }

        @Override
        public void writeBuffer(FriendlyByteBuf friendlyByteBuf) {
            this.writeBuffer.accept(friendlyByteBuf, (FriendlyByteBuf)this.value);
        }

        public ObjectSyncedField<T> setReceiverListener(@NotNull Listener<T> listener) {
            this.receiverListener = listener;
            return this;
        }

        public ObjectSyncedField<T> setSenderListener(@NotNull Listener<T> listener) {
            this.senderListener = listener;
            return this;
        }

        protected T readBuffer(FriendlyByteBuf friendlyByteBuf) {
            return this.readBuffer.apply(friendlyByteBuf);
        }

        public ObjectSyncedField<T> set(T t) {
            this.value = t;
            return this;
        }

        public T get() {
            return this.value;
        }

        public void setAndAutoSync(T t) {
            if (this.sync.getLevel().f_46443_) {
                this.setAndSyncToServer(t);
            } else {
                this.setAndSyncToClient(t);
            }
        }

        public void setAndSyncToServer(T t) {
            T t2 = this.value;
            this.value = t;
            this.senderListener.onSync(LogicalSide.CLIENT, t2, t);
            this.sync.syncToServer(this.getName());
        }

        public void setAndSyncToClient(T t) {
            T t2 = this.value;
            this.value = t;
            this.senderListener.onSync(LogicalSide.SERVER, t2, t);
            this.sync.syncToClient(this.getName());
        }
    }

    public static abstract class AbstractSyncedField
    implements ISyncedField {
        protected final ISync sync;
        private String name;

        protected AbstractSyncedField(ISync iSync) {
            this.sync = iSync;
        }

        protected String getName() {
            if (this.name == null) {
                this.name = this.sync.getSyncHolder().getSyncFieldName(this.sync, this);
                if (this.name == null) {
                    throw new IllegalStateException("Sync field name is null");
                }
            }
            return this.name;
        }

        public void syncToServer() {
            this.sync.syncToServer(this.getName());
        }

        public void syncToClient() {
            this.sync.syncToClient(this.getName());
        }
    }

    @FunctionalInterface
    public static interface DoubleListener {
        public static final DoubleListener EMPTY = (logicalSide, d, d2) -> {};

        public void onSync(LogicalSide var1, double var2, double var4);
    }

    @FunctionalInterface
    public static interface FloatListener {
        public static final FloatListener EMPTY = (logicalSide, f, f2) -> {};

        public void onSync(LogicalSide var1, float var2, float var3);
    }

    @FunctionalInterface
    public static interface LongListener {
        public static final LongListener EMPTY = (logicalSide, l, l2) -> {};

        public void onSync(LogicalSide var1, long var2, long var4);
    }

    @FunctionalInterface
    public static interface IntListener {
        public static final IntListener EMPTY = (logicalSide, n, n2) -> {};

        public void onSync(LogicalSide var1, int var2, int var3);
    }

    @FunctionalInterface
    public static interface BooleanListener {
        public static final BooleanListener EMPTY = (logicalSide, bl, bl2) -> {};

        public void onSync(LogicalSide var1, boolean var2, boolean var3);
    }

    @FunctionalInterface
    public static interface Listener<T> {
        public static final Listener EMPTY = (logicalSide, object, object2) -> {};

        public void onSync(LogicalSide var1, T var2, T var3);
    }

    public static interface ISyncedField {
        public void writeBuffer(FriendlyByteBuf var1);

        public void readBuffer(FriendlyByteBuf var1, LogicalSide var2);
    }
}

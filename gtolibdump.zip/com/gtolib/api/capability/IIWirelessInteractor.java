package com.gtolib.api.capability;

import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.utils.collection.OpenCacheHashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface IIWirelessInteractor<T extends MetaMachine> {
    @Nullable
    public Level getLevel();

    public T getNetMachineCache();

    public void setNetMachineCache(T var1);

    public Map<ResourceLocation, Set<T>> getMachineNet();

    public boolean testMachine(T var1);

    public boolean firstTestMachine(T var1);

    default public void removeNetMachineCache() {
        this.setNetMachineCache(null);
    }

    @Nullable
    default public T getNetMachine() {
        Level level;
        if (this.getNetMachineCache() == null && (level = this.getLevel()) != null) {
            Set<T> set = this.getMachineNet().get(level.m_46472_().m_135782_());
            if (set == null) {
                return null;
            }
            for (MetaMachine metaMachine : set) {
                if (metaMachine.isInValid() || !this.firstTestMachine(metaMachine)) continue;
                this.setNetMachineCache(metaMachine);
                return (T)metaMachine;
            }
        }
        if ((level = this.getNetMachineCache()) != null) {
            if (!((MetaMachine)((Object)level)).isInValid() && this.testMachine(level)) {
                return (T)level;
            }
            this.removeNetMachineCache();
        }
        return null;
    }

    public static <T extends MetaMachine> void addToNet(@NotNull Map<ResourceLocation, Set<T>> map, @NotNull T t) {
        if (t.isRemote()) {
            return;
        }
        Level level = t.getLevel();
        if (level == null) {
            return;
        }
        map.computeIfAbsent(level.m_46472_().m_135782_(), resourceLocation -> new OpenCacheHashSet()).add(t);
    }

    public static <T extends MetaMachine> void removeFromNet(@NotNull Map<ResourceLocation, Set<T>> map, @NotNull T t) {
        if (t.isRemote()) {
            return;
        }
        Level level = t.getLevel();
        if (level == null) {
            return;
        }
        Set<T> set = map.get(level.m_46472_().m_135782_());
        if (set != null) {
            set.remove(t);
        }
    }
}

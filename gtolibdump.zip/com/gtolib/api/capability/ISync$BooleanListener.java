package com.gtolib.api.capability;

import net.minecraftforge.fml.LogicalSide;

@FunctionalInterface
public interface ISync$BooleanListener {
    public static final ISync$BooleanListener EMPTY = (logicalSide, bl, bl2) -> {};

    public void onSync(LogicalSide var1, boolean var2, boolean var3);
}

package com.gtolib.api.capability;

import com.gregtechceu.gtceu.api.GTValues;
import com.gregtechceu.gtceu.api.capability.GTCapabilityHelper;
import com.gregtechceu.gtceu.api.capability.IElectricItem;
import com.gregtechceu.gtceu.api.capability.IEnergyContainer;
import com.gregtechceu.gtceu.api.machine.multiblock.part.MultiblockPartMachine;
import com.gtolib.api.capability.IIWirelessInteractor;
import com.gtolib.api.machine.feature.IElectricMachine;
import com.gtolib.api.machine.multiblock.WirelessChargerMachine;
import com.gtolib.utils.GTOUtils;
import com.gtolib.utils.MathUtil;
import com.hepdd.gtmthings.api.capability.IBindable;
import com.hepdd.gtmthings.utils.TeamUtil;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.energy.IEnergyStorage;

public interface IWirelessChargerInteraction
extends IIWirelessInteractor<WirelessChargerMachine>,
IBindable {
    public BlockPos getPos();

    @Override
    default public Map<ResourceLocation, Set<WirelessChargerMachine>> getMachineNet() {
        return WirelessChargerMachine.NETWORK;
    }

    @Override
    default public boolean firstTestMachine(WirelessChargerMachine wirelessChargerMachine) {
        Level level = wirelessChargerMachine.getLevel();
        if (level == null) {
            return false;
        }
        UUID uUID = this.getUUID();
        if (uUID == null) {
            return false;
        }
        return this.testMachine(wirelessChargerMachine) && TeamUtil.getTeamUUID(uUID).equals(TeamUtil.getTeamUUID(wirelessChargerMachine.getUUID()));
    }

    @Override
    default public boolean testMachine(WirelessChargerMachine wirelessChargerMachine) {
        return wirelessChargerMachine.isMachine() && wirelessChargerMachine.isFormed() && wirelessChargerMachine.isWorkingEnabled() && wirelessChargerMachine.getRate() > 0 && GTOUtils.calculateDistance(wirelessChargerMachine.getPos(), this.getPos()) < (double)wirelessChargerMachine.getRange();
    }

    default public boolean display() {
        return false;
    }

    default public void charge() {
        IElectricMachine iElectricMachine;
        Object object = this;
        if (object instanceof IElectricMachine && (iElectricMachine = (IElectricMachine)object).self().getOffsetTimer() % 20L == 0L && (object = (WirelessChargerMachine)this.getNetMachine()) != null && !((WirelessChargerMachine)object).isOnlyProvideToPlayer) {
            IEnergyContainer iEnergyContainer;
            if (!((WirelessChargerMachine)object).isProvideToMultiBlockHatch && this instanceof MultiblockPartMachine) {
                return;
            }
            long l = ((WirelessChargerMachine)object).getEnergyStored();
            if (l > 0L && (iEnergyContainer = iElectricMachine.gtolib$getEnergyContainer()).getEnergyStored() < iEnergyContainer.getEnergyCapacity()) {
                ((WirelessChargerMachine)object).removeEnergy(iEnergyContainer.addEnergy(Math.min(GTValues.V[iElectricMachine.getTier()] * 40L, l)));
            }
        }
    }

    public static void charge(WirelessChargerMachine wirelessChargerMachine, ItemStack itemStack) {
        long l;
        if (wirelessChargerMachine != null && (l = wirelessChargerMachine.getEnergyStored()) > 0L) {
            IElectricItem iElectricItem = GTCapabilityHelper.getElectricItem(itemStack);
            if (iElectricItem != null) {
                if (iElectricItem.chargeable() && iElectricItem.getCharge() < iElectricItem.getMaxCharge()) {
                    wirelessChargerMachine.removeEnergy(iElectricItem.charge(Math.min(l, GTValues.V[iElectricItem.getTier()] * (long)wirelessChargerMachine.getRate()), iElectricItem.getTier(), true, false));
                }
            } else {
                IEnergyStorage iEnergyStorage = GTCapabilityHelper.getForgeEnergyItem(itemStack);
                if (iEnergyStorage != null && iEnergyStorage.canReceive() && iEnergyStorage.getEnergyStored() < iEnergyStorage.getMaxEnergyStored()) {
                    wirelessChargerMachine.removeEnergy(iEnergyStorage.receiveEnergy(MathUtil.saturatedCast(l), false));
                }
            }
        }
    }
}

package com.gtolib.api.annotation.language;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import kotlin.annotation.AnnotationTarget;
import kotlin.annotation.Target;

@Target(allowedTargets={AnnotationTarget.FIELD})
@Retention(value=RetentionPolicy.RUNTIME)
public @interface RegisterLanguage {
    public String namePrefix() default "";

    public String valuePrefix() default "";

    public String key() default "";

    public String en();

    public String cn();
}

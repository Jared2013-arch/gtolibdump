package com.gtolib.api.annotation.dynamic;

public record DynamicInitialValueTypes$TypeInfo(String key, String cn, String en) {
}

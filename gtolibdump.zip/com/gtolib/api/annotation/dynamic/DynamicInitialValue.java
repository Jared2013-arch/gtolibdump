package com.gtolib.api.annotation.dynamic;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import kotlin.annotation.AnnotationTarget;
import kotlin.annotation.Target;

@Target(allowedTargets={AnnotationTarget.FIELD})
@Retention(value=RetentionPolicy.RUNTIME)
public @interface DynamicInitialValue {
    public String key();

    public String typeKey() default "default";

    public String en();

    public String cn();

    public String enComment() default "";

    public String cnComment() default "";

    public String simpleValue();

    public String normalValue();

    public String expertValue();
}

package com.gtolib.api.annotation.dynamic;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.registry.registrate.MachineBuilder;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtolib.GTOCore;
import com.gtolib.api.annotation.DataGeneratorScanned;
import com.gtolib.api.annotation.dynamic.DynamicInitialValue;
import com.gtolib.api.annotation.language.RegisterLanguage;
import com.gtolib.api.lang.CNEN;
import com.gtolib.api.registries.ScanningClass;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

@DataGeneratorScanned
public final class DynamicInitialData {
    public static final Map<String, CNEN> LANG = GTCEu.isDataGen() ? new O2OOpenCacheHashMap() : null;
    public static final String PREFIX_DYNAMIC_VALUE = "gtocore.difficulty_config";
    private static final String PREFIX_DYNAMIC_VALUE_WITH_END = "gtocore.difficulty_config.";
    private static final String PREFIX_NAME = "gtocore.difficulty_config.name.";
    private static final String PREFIX_COMMENT = "gtocore.difficulty_config.comment.";
    public static final DynamicInitialData DEFAULT = new DynamicInitialData();
    private final List<Value> list = new ObjectArrayList();
    @RegisterLanguage(en="(Simple) ", cn="(简单) ")
    public static final String IS_SIMPLE = "gtocore.difficulty_config.is_simple";
    @RegisterLanguage(en="(Normal) ", cn="(普通) ")
    public static final String IS_NORMAL = "gtocore.difficulty_config.is_normal";
    @RegisterLanguage(en="(Expert) ", cn="(专家) ")
    public static final String IS_EXPERT = "gtocore.difficulty_config.is_expert";
    @RegisterLanguage(en="(Common) ", cn="(通用) ")
    public static final String COMMON = "gtocore.difficulty_config.common";

    public void update(Object object) {
        for (Value value : this.list) {
            try {
                value.field.set(object, value.value);
            }
            catch (IllegalAccessException illegalAccessException) {
                GTOCore.LOGGER.error("Failed to set difficulty config value for field {}", (Object)value.field.getName(), (Object)illegalAccessException);
            }
        }
    }

    public void add(Object object) {
        this.list.add((Value)object);
    }

    public Object add(Field field) {
        Object object;
        field.setAccessible(true);
        DynamicInitialValue dynamicInitialValue = field.getAnnotation(DynamicInitialValue.class);
        assert (dynamicInitialValue != null);
        if (ScanningClass.LANG != null) {
            ScanningClass.LANG.put(PREFIX_NAME + dynamicInitialValue.key(), new CNEN(dynamicInitialValue.cn(), dynamicInitialValue.en()));
        }
        List list = List.of();
        if (!dynamicInitialValue.enComment().isEmpty() && !dynamicInitialValue.cnComment().isEmpty()) {
            list = new ObjectArrayList();
            String[] stringArray = (String[])dynamicInitialValue.enComment().lines().toArray(String[]::new);
            if (stringArray.length != ((String[])(object = (String[])dynamicInitialValue.cnComment().lines().toArray(String[]::new))).length) {
                throw new IllegalArgumentException("enComment line number is not equal cnComment");
            }
            for (int i = 0; i < stringArray.length; ++i) {
                String string = PREFIX_COMMENT + dynamicInitialValue.key() + "." + i;
                if (ScanningClass.LANG != null) {
                    ScanningClass.LANG.put(string, new CNEN((String)object[i], stringArray[i]));
                }
                list.add(string);
            }
        }
        boolean bl = !dynamicInitialValue.simpleValue().equals(dynamicInitialValue.normalValue()) || !dynamicInitialValue.simpleValue().equals(dynamicInitialValue.expertValue());
        Class<?> clazz = field.getType();
        object = new Value(field, DynamicInitialData.parse(clazz, switch (GTOCore.difficulty) {
            case 1 -> dynamicInitialValue.simpleValue();
            case 3 -> dynamicInitialValue.expertValue();
            default -> dynamicInitialValue.normalValue();
        }), dynamicInitialValue.key(), list, dynamicInitialValue.en().contains("%s"), bl);
        this.list.add((Value)object);
        if (Modifier.isStatic(field.getModifiers())) {
            try {
                field.set(null, ((Value)object).value());
            }
            catch (IllegalAccessException illegalAccessException) {
                throw new RuntimeException(illegalAccessException);
            }
            return null;
        }
        return object;
    }

    public static Component getDifficultyComponent(int n) {
        return switch (n) {
            case 1 -> Component.m_237115_(IS_SIMPLE).m_130940_(ChatFormatting.GREEN);
            case 2 -> Component.m_237115_(IS_NORMAL).m_130940_(ChatFormatting.YELLOW);
            case 3 -> Component.m_237115_(IS_EXPERT).m_130940_(ChatFormatting.LIGHT_PURPLE);
            default -> Component.m_237115_(COMMON);
        };
    }

    public static <T extends MachineBuilder<?>> T addTooltipsText(T t, Class<?> clazz, Predicate<Value> predicate) {
        DynamicInitialData dynamicInitialData = ScanningClass.VALUES.get(clazz);
        if (dynamicInitialData == null) {
            throw new IllegalArgumentException("Class " + clazz.getName() + " is not annotated with @Scanned");
        }
        List list = dynamicInitialData.list;
        list = list.stream().filter(predicate).sorted(Comparator.comparing(value -> !value.isDifficultyConfig())).toList();
        for (Value value2 : list) {
            String[] stringArray = new String[]{value2.value().toString(), value2.value().toString(), value2.value().toString(), value2.value().toString()};
            MutableComponent mutableComponent = Component.m_237119_();
            if (value2.isDifficultyConfig()) {
                MutableComponent mutableComponent2 = switch (GTOCore.difficulty) {
                    case 1 -> Component.m_237115_(IS_SIMPLE).m_130940_(ChatFormatting.DARK_AQUA);
                    case 3 -> Component.m_237115_(IS_EXPERT).m_130940_(ChatFormatting.RED);
                    default -> Component.m_237115_(IS_NORMAL).m_130940_(ChatFormatting.GREEN);
                };
                mutableComponent.m_7220_(mutableComponent2);
            }
            if (value2.hasFormatInName()) {
                mutableComponent.m_7220_(Component.m_237110_(PREFIX_NAME + value2.key(), stringArray).m_130940_(ChatFormatting.AQUA));
            } else {
                mutableComponent.m_7220_(Component.m_237115_(PREFIX_NAME + value2.key()).m_130946_(" : %s".formatted((Object[])stringArray)).m_130940_(ChatFormatting.AQUA));
            }
            t.tooltips(new Component[]{mutableComponent});
            if (value2.commentTranKey().isEmpty()) continue;
            for (String string : value2.commentTranKey()) {
                t.tooltips(new Component[]{Component.m_237113_("  ").m_7220_(Component.m_237110_(string, stringArray)).m_130940_(ChatFormatting.GRAY).m_130940_(ChatFormatting.ITALIC)});
            }
        }
        return t;
    }

    private static Object parse(Class<?> clazz, String string) {
        if (clazz == Integer.TYPE) {
            return Integer.parseInt(string);
        }
        if (clazz == Long.TYPE) {
            return Long.parseLong(string);
        }
        if (clazz == Byte.TYPE) {
            return Byte.parseByte(string);
        }
        if (clazz == Double.TYPE) {
            return Double.parseDouble(string);
        }
        if (clazz == Float.TYPE) {
            return Float.valueOf(Float.parseFloat(string));
        }
        if (clazz == Boolean.TYPE) {
            return Boolean.parseBoolean(string);
        }
        throw new IllegalArgumentException("Unsupported type: " + clazz.getName());
    }

    public record Value(Field field, Object value, String key, List<String> commentTranKey, boolean hasFormatInName, boolean isDifficultyConfig) {
    }
}

package com.gtolib.api.annotation.dynamic;

import java.lang.reflect.Field;
import java.util.List;

public record DynamicInitialData$Value(Field field, Object value, String key, List<String> commentTranKey, boolean hasFormatInName, boolean isDifficultyConfig) {
}

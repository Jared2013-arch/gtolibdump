package com.gtolib.api.annotation;

public @interface Register {
}

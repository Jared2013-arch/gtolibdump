package com.gtolib.api.annotation.component_builder;

import com.gtolib.api.annotation.component_builder.ComponentBuilder;
import com.gtolib.api.annotation.component_builder.ComponentSupplier;
import com.gtolib.api.annotation.component_builder.StyleBuilder;
import com.gtolib.api.lang.CNEN;
import java.util.function.UnaryOperator;
import net.minecraft.network.chat.Component;

public class ComponentTemplate {
    private final String key;
    private final String cnTemplate;
    private final String enTemplate;
    private final UnaryOperator<StyleBuilder> styleOpFromRegister;
    private final Object defaultValue;
    private UnaryOperator<ComponentBuilder> templateCommentOp = UnaryOperator.identity();

    public ComponentTemplate(String string, String string2, String string3, UnaryOperator<StyleBuilder> unaryOperator) {
        this(string, string2, string3, unaryOperator, null);
    }

    public ComponentTemplate(String string, String string2, String string3, UnaryOperator<StyleBuilder> unaryOperator, Object object) {
        this.key = string;
        this.cnTemplate = string2;
        this.enTemplate = string3;
        this.styleOpFromRegister = unaryOperator;
        this.defaultValue = object;
    }

    public ComponentTemplate setComment(UnaryOperator<ComponentBuilder> unaryOperator) {
        this.templateCommentOp = unaryOperator;
        return this;
    }

    private ComponentBuilder createBuilder(ComponentBuilder componentBuilder, ComponentBuilder componentBuilder2, UnaryOperator<StyleBuilder> unaryOperator) {
        ComponentBuilder componentBuilder3 = ComponentBuilder.create();
        this.templateCommentOp.apply(componentBuilder3);
        return ComponentBuilder.create().addElementFromTemplate(this, componentBuilder, unaryOperator).addElementFromNested(componentBuilder3).addElementFromNested(componentBuilder2);
    }

    public ComponentBuilder createBuilder(UnaryOperator<ComponentBuilder> unaryOperator, UnaryOperator<ComponentBuilder> unaryOperator2) {
        return this.createBuilder(ComponentTemplate.applyOperator(unaryOperator), ComponentTemplate.applyOperator(unaryOperator2), null);
    }

    public ComponentBuilder createBuilder(UnaryOperator<ComponentBuilder> unaryOperator, UnaryOperator<ComponentBuilder> unaryOperator2, UnaryOperator<StyleBuilder> unaryOperator3) {
        return this.createBuilder(ComponentTemplate.applyOperator(unaryOperator), ComponentTemplate.applyOperator(unaryOperator2), unaryOperator3);
    }

    private ComponentSupplier create(ComponentBuilder componentBuilder, ComponentBuilder componentBuilder2) {
        return new ComponentSupplier(this.createBuilder(componentBuilder, componentBuilder2, null).build());
    }

    public ComponentSupplier create(UnaryOperator<ComponentBuilder> unaryOperator, UnaryOperator<ComponentBuilder> unaryOperator2) {
        return this.create(ComponentTemplate.applyOperator(unaryOperator), ComponentTemplate.applyOperator(unaryOperator2));
    }

    public ComponentSupplier create(String string, UnaryOperator<ComponentBuilder> unaryOperator) {
        ComponentBuilder componentBuilder = ComponentBuilder.create();
        componentBuilder.addLines(string);
        return this.create(componentBuilder, ComponentTemplate.applyOperator(unaryOperator));
    }

    public ComponentSupplier create(Object object) {
        if (object instanceof Component) {
            Component component = (Component)object;
            return this.create(componentBuilder -> componentBuilder.addLines(new Component[]{component}, styleBuilder -> styleBuilder), componentBuilder -> componentBuilder);
        }
        return this.create(object.toString(), componentBuilder -> componentBuilder);
    }

    public ComponentSupplier create(String string, String string2) {
        return this.create(componentBuilder -> componentBuilder.addLines(string, string2), componentBuilder -> componentBuilder);
    }

    public ComponentSupplier create(CNEN cNEN) {
        return this.create(cNEN.cn(), cNEN.en());
    }

    public ComponentSupplier create(CNEN cNEN, UnaryOperator<ComponentBuilder> unaryOperator) {
        return this.create(componentBuilder -> componentBuilder.addLines(cNEN.cn(), cNEN.en()), unaryOperator);
    }

    public ComponentSupplier create(UnaryOperator<ComponentBuilder> unaryOperator) {
        return this.create(unaryOperator, componentBuilder -> componentBuilder);
    }

    public ComponentSupplier create() {
        return this.create(componentBuilder -> componentBuilder, componentBuilder -> componentBuilder);
    }

    public String getKey() {
        return this.key;
    }

    public String getCnTemplate() {
        return this.cnTemplate;
    }

    public String getEnTemplate() {
        return this.enTemplate;
    }

    public UnaryOperator<StyleBuilder> getStyleOpFromRegister() {
        return this.styleOpFromRegister;
    }

    public Object getDefaultValue() {
        return this.defaultValue;
    }

    private static ComponentBuilder applyOperator(UnaryOperator<ComponentBuilder> unaryOperator) {
        ComponentBuilder componentBuilder = ComponentBuilder.create();
        unaryOperator.apply(componentBuilder);
        return componentBuilder;
    }
}

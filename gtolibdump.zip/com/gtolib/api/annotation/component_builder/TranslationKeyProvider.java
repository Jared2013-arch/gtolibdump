package com.gtolib.api.annotation.component_builder;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtolib.api.lang.CNEN;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;

public final class TranslationKeyProvider {
    public static final Object2ObjectOpenHashMap<String, CNEN> LANG = GTCEu.isDataGen() ? new O2OOpenCacheHashMap() : null;

    public static String getTranslationKey(String string, String string2) {
        return TranslationKeyProvider.getTranslationKey(string, string2, "gtocore.lang");
    }

    public static String getTranslationKey(String string, String string2, String string3) {
        Object object = (string3 != null ? string3 : "") + "." + string2.hashCode();
        object = ((String)object).replace("..", ".");
        if (LANG != null) {
            LANG.put(object, (Object)new CNEN(string, string2));
        }
        return object;
    }
}

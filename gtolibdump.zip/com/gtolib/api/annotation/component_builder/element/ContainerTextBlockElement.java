package com.gtolib.api.annotation.component_builder.element;

import com.gtolib.api.annotation.component_builder.StyleBuilder;
import com.gtolib.api.annotation.component_builder.element.ComponentElement;
import com.gtolib.api.annotation.component_builder.element.LeafTranslatableElement;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import java.util.function.UnaryOperator;
import net.minecraft.network.chat.Component;

public class ContainerTextBlockElement
implements ComponentElement {
    private final String[] cnLines;
    private final String[] enLines;
    private final UnaryOperator<StyleBuilder> styleOp;
    private final Object[] args;

    public ContainerTextBlockElement(String[] stringArray, String[] stringArray2, UnaryOperator<StyleBuilder> unaryOperator, Object ... objectArray) {
        this.cnLines = stringArray;
        this.enLines = stringArray2;
        this.styleOp = unaryOperator;
        this.args = objectArray;
    }

    @Override
    public List<Component> build() {
        ObjectArrayList objectArrayList = new ObjectArrayList();
        for (int i = 0; i < this.cnLines.length; ++i) {
            List<Component> list = new LeafTranslatableElement(this.cnLines[i], this.enLines[i], this.styleOp, this.args).build();
            objectArrayList.addAll(list);
        }
        return objectArrayList;
    }
}

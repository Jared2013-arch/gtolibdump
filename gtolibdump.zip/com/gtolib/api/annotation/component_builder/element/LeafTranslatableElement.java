package com.gtolib.api.annotation.component_builder.element;

import com.gtolib.api.annotation.component_builder.StyleBuilder;
import com.gtolib.api.annotation.component_builder.TranslationKeyProvider;
import com.gtolib.api.annotation.component_builder.element.ComponentElement;
import java.util.Collections;
import java.util.List;
import java.util.function.UnaryOperator;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

public class LeafTranslatableElement
implements ComponentElement {
    private final String cn;
    private final String en;
    private final UnaryOperator<StyleBuilder> styleOp;
    private final Object[] args;

    public LeafTranslatableElement(String string, String string2, UnaryOperator<StyleBuilder> unaryOperator, Object ... objectArray) {
        this.cn = string;
        this.en = string2;
        this.styleOp = unaryOperator;
        this.args = objectArray;
    }

    @Override
    public List<Component> build() {
        String string = TranslationKeyProvider.getTranslationKey(this.cn, this.en);
        MutableComponent mutableComponent = Component.m_237110_(string, this.args);
        if (this.styleOp != null) {
            StyleBuilder styleBuilder = new StyleBuilder();
            this.styleOp.apply(styleBuilder);
            mutableComponent = styleBuilder.apply(mutableComponent);
        }
        return Collections.singletonList(mutableComponent);
    }
}

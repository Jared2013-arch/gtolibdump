package com.gtolib.api.annotation.component_builder.element;

import com.gtolib.api.annotation.component_builder.ComponentBuilder;
import com.gtolib.api.annotation.component_builder.ComponentTemplate;
import com.gtolib.api.annotation.component_builder.StyleBuilder;
import com.gtolib.api.annotation.component_builder.TranslationKeyProvider;
import com.gtolib.api.annotation.component_builder.element.ComponentElement;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import java.util.function.UnaryOperator;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

public class ContainerTemplateElement
implements ComponentElement {
    private final ComponentTemplate template;
    private final Object value;
    private final UnaryOperator<StyleBuilder> styleOpFromCreate;

    public ContainerTemplateElement(ComponentTemplate componentTemplate, Object object, UnaryOperator<StyleBuilder> unaryOperator) {
        ComponentBuilder componentBuilder;
        this.template = componentTemplate;
        this.value = object instanceof ComponentBuilder && (componentBuilder = (ComponentBuilder)object).isEmpty() ? null : object;
        this.styleOpFromCreate = unaryOperator;
    }

    @Override
    public List<Component> build() {
        StyleBuilder styleBuilder;
        Object object;
        ObjectArrayList objectArrayList = new ObjectArrayList();
        Object object2 = this.value;
        if (object2 instanceof ComponentBuilder) {
            object = (ComponentBuilder)object2;
            object2 = ((ComponentBuilder)object).buildSingle();
        } else {
            object2 = this.value != null ? this.value : this.template.getDefaultValue();
        }
        object = TranslationKeyProvider.getTranslationKey(this.template.getCnTemplate(), this.template.getEnTemplate(), "gtocore.lang.template." + this.template.getKey());
        MutableComponent mutableComponent = Component.m_237110_((String)object, new Object[]{object2});
        if (this.template.getStyleOpFromRegister() != null) {
            styleBuilder = new StyleBuilder();
            this.template.getStyleOpFromRegister().apply(styleBuilder);
            mutableComponent = styleBuilder.apply(mutableComponent);
        }
        if (this.styleOpFromCreate != null) {
            styleBuilder = new StyleBuilder();
            this.styleOpFromCreate.apply(styleBuilder);
            mutableComponent = styleBuilder.apply(mutableComponent);
        }
        objectArrayList.add(mutableComponent);
        return objectArrayList;
    }
}

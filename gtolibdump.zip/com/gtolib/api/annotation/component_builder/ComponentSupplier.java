package com.gtolib.api.annotation.component_builder;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.network.chat.Component;

public class ComponentSupplier
implements Supplier<List<Component>> {
    private final Supplier<List<Component>> supplier;

    ComponentSupplier(Supplier<List<Component>> supplier) {
        this.supplier = supplier;
    }

    @Override
    public List<Component> get() {
        return this.supplier.get();
    }

    public Component[] getArray() {
        return this.get().toArray(new Component[0]);
    }
}

package com.gtolib.api.annotation;

import com.gtolib.api.annotation.component_builder.ComponentBuilder;
import com.gtolib.api.annotation.component_builder.ComponentTemplate;
import com.gtolib.api.annotation.component_builder.StyleBuilder;
import net.minecraft.network.chat.Component;

public final class NewDataAttributes {
    public static final String PREFIX = "gtocore.lang";
    public static final String PREFIX_TEMPLATE = "gtocore.lang.template";
    private static final Component PREFIX_BAR = ComponentBuilder.create().addLines("- ", StyleBuilder::setGold).buildSingle();
    private static final Component PREFIX_POINT = ComponentBuilder.create().addLines("৹ ", StyleBuilder::setGold).buildSingle();
    public static final Component PREFIX_STAR = ComponentBuilder.create().addLines("☆", StyleBuilder::setGold).buildSingle();
    public static final Component PREFIX_TAB_POINT = ComponentBuilder.create().addLines("  ৹ ", StyleBuilder::setGold).buildSingle();
    public static final Component PREFIX_TAB_STAR = ComponentBuilder.create().addLines("  ☆", StyleBuilder::setGold).buildSingle();
    public static final Component PREFIX_TAB = ComponentBuilder.create().addLines("  ", StyleBuilder::setGold).buildSingle();
    public static final ComponentTemplate ALLOW_PARALLEL = new ComponentTemplate("allow_parallel", "可并行 : %s", "Parallel : %s", styleBuilder -> styleBuilder.setColor(2003199).setPrefix(PREFIX_BAR), "✔");
    public static final ComponentTemplate EMPTY_WITH_BAR = new ComponentTemplate("empty_with_bar", "%s", "%s", styleBuilder -> styleBuilder.setPrefix(PREFIX_BAR));
    public static final ComponentTemplate EMPTY_WITH_TAB = new ComponentTemplate("empty_with_tab", "%s", "%s", styleBuilder -> styleBuilder.setPrefix(PREFIX_TAB));
    public static final ComponentTemplate TIME_COST_MULTIPLY = new ComponentTemplate("time_cost_multiply", "时间倍率 : %s", "Time Cost Multiply : %s", styleBuilder -> styleBuilder.setPrefix(PREFIX_BAR).setColor(6591981));
    public static final ComponentTemplate ENERGY_COST_MULTIPLY = new ComponentTemplate("energy_cost_multiply", "能量倍率 : %s", "Energy Cost Multiply : %s", styleBuilder -> styleBuilder.setPrefix(PREFIX_BAR).setColor(0x7CCD7C));
    public static final ComponentTemplate EMPTY_WITH_POINT = new ComponentTemplate("empty_with_point", "%s", "%s", styleBuilder -> styleBuilder.setPrefix(PREFIX_POINT));
    public static final ComponentTemplate EMPTY_WITH_NON = new ComponentTemplate("empty_with_non", "%s", "%s", styleBuilder -> styleBuilder);
    public static final ComponentTemplate MULTIPLY = new ComponentTemplate("multiply", "倍率 : %s", "Multiply : %s", styleBuilder -> styleBuilder.setColor(14315734).setPrefix(PREFIX_BAR));
    public static final ComponentTemplate MAIN_FUNCTION = new ComponentTemplate("main_function", "主功能 : %s", "Main Function : %s", styleBuilder -> styleBuilder.setGold().setPrefix(PREFIX_BAR));
    public static final ComponentTemplate CAPACITY = new ComponentTemplate("capacity", "容量 : %s", "Capacity : %s", styleBuilder -> styleBuilder.setLightPurple().setPrefix(PREFIX_BAR));
    public static final ComponentTemplate CURRENT = new ComponentTemplate("current", "电流 : %s A", "Current : %s A", styleBuilder -> styleBuilder.setColor(50637).setPrefix(PREFIX_BAR));
    public static final ComponentTemplate VOLTAGE = new ComponentTemplate("voltage", "电压 : %s", "Voltage : %s", styleBuilder -> styleBuilder.setColor(13789470).setPrefix(PREFIX_BAR));
    public static final ComponentTemplate RUNTIME_REQUIREMENT = new ComponentTemplate("runtime_requirement", "运行要求 : %s", "Runtime Requirement : %s", styleBuilder -> styleBuilder.setYellow().setPrefix(PREFIX_BAR));
    public static final ComponentTemplate MIRACULOUS_TOOLS = new ComponentTemplate("miraculous_tools", "妙妙工具 : %s", "Wonderful Tools : %s", styleBuilder -> styleBuilder.setRainbowSlow().setPrefix(PREFIX_BAR));
    public static final ComponentTemplate NOT_ALLOW_SHARED = new ComponentTemplate("not_allow_shared", "可共享 : %s", "Shared : %s", styleBuilder -> styleBuilder.setColor(16753920).setPrefix(PREFIX_BAR), "✘").setComment(componentBuilder -> componentBuilder.addCommentLines("代表此舱室能否被多台多方块结构共享", "Represents whether this hatch can be shared by multiple multi-block structures"));
    public static final ComponentTemplate ALLOW_PARALLEL_SPECIAL = new ComponentTemplate("allow_parallel_special", "可特殊并行 : %s", "Special Parallel : %s", styleBuilder -> styleBuilder.setColor(2003199).setPrefix(PREFIX_BAR), "✔");
    public static final ComponentTemplate ALLOW_PARALLEL_NUMBER = new ComponentTemplate("allow_parallel_number", "并行数 : %s", "Parallel Number : %s", styleBuilder -> styleBuilder.setColor(0x66FF00).setPrefix(PREFIX_BAR));
    public static final ComponentTemplate ALLOW_MULTI_RECIPE_PARALLEL = new ComponentTemplate("allow_multi_recipe_parallel", "多线程 : %s", "Multi-threading : %s", styleBuilder -> styleBuilder.setBlinkingCyan().setPrefix(PREFIX_BAR), "✔").setComment(componentBuilder -> componentBuilder.addCommentLines("允许安装线程仓实现多线程配方并行处理。\n难以想象的工作效率，尽管去做吧！", "Allows the installation of thread hatches to achieve multi-threaded recipe parallel processing.\nImagine the unimaginable work efficiency, go ahead and do it!"));
    public static final ComponentTemplate PREFECT_OVERCLOCK = new ComponentTemplate("perfect_overclock", "无损超频 : %s", "Perfect Overclock : %s", styleBuilder -> styleBuilder.setBlinkingRed().setPrefix(PREFIX_BAR), "✔");
    public static final ComponentTemplate LASER_ENERGY_HATCH = new ComponentTemplate("laser_energy_hatch", "激光仓 : %s", "Laser Energy Hatch : %s", styleBuilder -> styleBuilder.setBlinkingOrange().setPrefix(PREFIX_BAR), "✔").setComment(componentBuilder -> componentBuilder.addCommentLines("激光仓一般可以提供巨大的能量", "Laser Energy Hatches generally provide massive amounts of energy"));
    public static final ComponentTemplate COMBINED_RECIPE = new ComponentTemplate("combined_recipe", "组合配方类型 : %s", "Combined Recipe Type : %s", styleBuilder -> styleBuilder.setBlue().setPrefix(PREFIX_BAR), "✔").setComment(componentBuilder -> componentBuilder.addCommentLines("允许不同类型的配方同时运行，无需切换模式", "Allows different types of recipes to run simultaneously without switching modes"));
    public static final ComponentTemplate RECIPES_TYPE = new ComponentTemplate("recipes_type", "配方类型 : %s", "Recipes Type : %s", styleBuilder -> styleBuilder.setYellow().setPrefix(PREFIX_BAR));
    public static final ComponentTemplate LEVEL = new ComponentTemplate("level", "等级 : %s", "Level : %s", styleBuilder -> styleBuilder.setGreen().setPrefix(PREFIX_BAR));
    public static final ComponentTemplate RECIPE_LEVEL = new ComponentTemplate("recipe_level", "配方等级 : %s", "Recipe Level : %s", styleBuilder -> styleBuilder.setAqua().setPrefix(PREFIX_BAR));
    public static final ComponentTemplate ALLOW_MODULE = new ComponentTemplate("allow_module", "附属模块 : %s", "Auxiliary Module : %s", styleBuilder -> styleBuilder.setOrange().setPrefix(PREFIX_BAR), "✔").setComment(componentBuilder -> componentBuilder.addCommentLines("允许拓展结构提升机器效率。\n扩展结构可安装额外的仓，带来额外的加成", "Allows the expansion of structures to improve machine efficiency.\nExpansion structures can install additional hatches to bring additional bonuses"));
}

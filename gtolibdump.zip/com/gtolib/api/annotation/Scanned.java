package com.gtolib.api.annotation;

import kotlin.annotation.AnnotationTarget;
import kotlin.annotation.Target;

@Target(allowedTargets={AnnotationTarget.CLASS})
public @interface Scanned {
}

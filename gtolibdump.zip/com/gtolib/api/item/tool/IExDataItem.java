package com.gtolib.api.item.tool;

public interface IExDataItem {
    public boolean requireDataBank();
}

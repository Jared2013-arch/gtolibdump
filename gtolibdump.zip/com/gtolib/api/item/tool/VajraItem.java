package com.gtolib.api.item.tool;

import com.gregtechceu.gtceu.api.data.chemical.material.Material;
import com.gregtechceu.gtceu.api.item.tool.GTToolItem;
import com.gregtechceu.gtceu.api.item.tool.GTToolType;
import com.gregtechceu.gtceu.api.item.tool.IGTToolDefinition;
import com.gregtechceu.gtceu.api.item.tool.MaterialToolTier;
import com.gtocore.client.KeyBind;
import com.mojang.blaze3d.platform.InputConstants;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class VajraItem
extends GTToolItem {
    protected VajraItem(GTToolType gTToolType, MaterialToolTier materialToolTier, Material material, IGTToolDefinition iGTToolDefinition, Item.Properties properties) {
        super(gTToolType, materialToolTier, material, iGTToolDefinition, properties);
    }

    public void m_7373_(ItemStack itemStack, @Nullable Level level, List<Component> list, TooltipFlag tooltipFlag) {
        super.m_7373_(itemStack, level, list, tooltipFlag);
        if (level == null || !level.m_5776_()) {
            return;
        }
        InputConstants.Key key = KeyBind.vajraKey.getKey();
        list.add(Component.m_237110_("item.gtceu.tool.vajra.tooltip", new Object[]{key.m_84875_()}));
        list.add(Component.m_237110_("item.gtceu.tool.vajra.tooltip.shift", new Object[]{key.m_84875_()}));
        float f = this.getMaterialToolSpeed(itemStack);
        float f2 = itemStack.m_41784_().m_128441_("ToolSpeed") ? itemStack.m_41784_().m_128457_("ToolSpeed") : f;
        list.add(Component.m_237110_("item.gtceu.tool.vajra.tooltip.max_speed", new Object[]{Float.valueOf(f2), Float.valueOf(f)}));
    }
}

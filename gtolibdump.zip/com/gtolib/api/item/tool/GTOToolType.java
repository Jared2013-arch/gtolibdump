package com.gtolib.api.item.tool;

import com.gregtechceu.gtceu.api.item.tool.GTToolType;
import com.gregtechceu.gtceu.api.item.tool.behavior.IToolBehavior;
import com.gregtechceu.gtceu.common.item.tool.behavior.DisableShieldBehavior;
import com.gregtechceu.gtceu.common.item.tool.behavior.ToolModeSwitchBehavior;
import com.gregtechceu.gtceu.data.recipe.CustomTags;
import com.gtolib.api.item.tool.VajraItem;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;

public final class GTOToolType {
    public static final GTToolType VAJRA_HV = GTOToolType.vajra(GTToolType.builder("hv_vajra").electric(3));
    public static final GTToolType VAJRA_EV = GTOToolType.vajra(GTToolType.builder("ev_vajra").electric(4));
    public static final GTToolType VAJRA_IV = GTOToolType.vajra(GTToolType.builder("iv_vajra").electric(5));

    private static GTToolType vajra(GTToolType.Builder builder) {
        return builder.idFormat("%s_vajra").toolTag(new TagKey[]{CustomTags.WRENCHES}).toolTag(new TagKey[]{CustomTags.WRENCH}).toolTag(new TagKey[]{CustomTags.WIRE_CUTTERS}).toolTag(new TagKey[]{ItemTags.f_271360_}).toolTag(new TagKey[]{ItemTags.f_271138_}).toolTag(new TagKey[]{ItemTags.f_271207_}).harvestTag(new TagKey[]{BlockTags.f_144282_}).harvestTag(new TagKey[]{BlockTags.f_144283_}).harvestTag(new TagKey[]{BlockTags.f_144280_}).harvestTag(new TagKey[]{CustomTags.MINEABLE_WITH_WRENCH}).toolStats(toolDefinitionBuilder -> toolDefinitionBuilder.crafting().blockBreaking().sneakBypassUse().attacking().attackDamage(10.0f).attackSpeed(2.0f).behaviors(new IToolBehavior[]{DisableShieldBehavior.INSTANCE, ToolModeSwitchBehavior.INSTANCE})).toolClasses(new GTToolType[]{GTToolType.WRENCH, GTToolType.WIRE_CUTTER, GTToolType.PICKAXE, GTToolType.SHEARS, GTToolType.AXE}).constructor(VajraItem::new).build();
    }
}

package com.gtolib.api.item.tool.ae2.patternTool;

import appeng.api.crafting.PatternDetailsHelper;
import appeng.crafting.pattern.AEProcessingPattern;
import com.gregtechceu.gtceu.common.data.GTItems;
import com.gtolib.GTOCore;
import com.gtolib.api.item.tool.ae2.patternTool.Ae2BaseProcessingPatternHelper;
import com.tterrag.registrate.util.entry.ItemEntry;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class Ae2BaseProcessingPattern {
    private ItemStack patternStack;
    private final ServerPlayer serverPlayer;
    private final List<Item> DefaultBlackItem = new ObjectArrayList(List.of((Object)GTItems.PROGRAMMED_CIRCUIT.m_5456_()));

    public void setDefaultFilter() {
        AEProcessingPattern aEProcessingPattern = Ae2BaseProcessingPatternHelper.decodeToAEProcessingPattern(this.patternStack, this.serverPlayer);
        if (aEProcessingPattern == null) {
            return;
        }
        this.patternStack = PatternDetailsHelper.encodeProcessingPattern(Ae2BaseProcessingPatternHelper.GenericStackListBlackFilter(aEProcessingPattern.getSparseInputs(), this.DefaultBlackItem), Ae2BaseProcessingPatternHelper.GenericStackListBlackFilter(aEProcessingPattern.getSparseOutputs(), this.DefaultBlackItem));
    }

    private void useSetScale(int n, boolean bl, long l, long l2) {
        try {
            ItemStack itemStack = this.patternStack;
            ItemStack itemStack2 = Ae2BaseProcessingPatternHelper.multiplyScale(n, bl, Objects.requireNonNull(Ae2BaseProcessingPatternHelper.decodeToAEProcessingPattern(itemStack, this.serverPlayer)), l, l2);
            if (itemStack2 != null && !itemStack2.m_41619_()) {
                this.patternStack = itemStack2;
            }
        }
        catch (Exception exception) {
            GTOCore.LOGGER.error(exception.getMessage());
        }
    }

    public void setScale(int n, boolean bl, long l, long l2) {
        l2 = Math.min(l2, 1000000L);
        l = Math.min(l, 1000000L);
        this.useSetScale(n, bl, l, l2);
    }

    public void setScale(int n, boolean bl) {
        long l = 9999999L;
        long l2 = 9999999L;
        this.useSetScale(n, bl, l, l2);
    }

    public ItemStack getPatternItemStack() {
        return this.patternStack;
    }

    public Ae2BaseProcessingPattern(ItemStack itemStack, ServerPlayer serverPlayer) {
        this.patternStack = itemStack;
        this.serverPlayer = serverPlayer;
        Ae2BaseProcessingPatternHelper.decodeToAEProcessingPattern(itemStack, serverPlayer);
        try {
            for (ItemEntry itemEntry : GTItems.SHAPE_MOLDS) {
                if (itemEntry == null) continue;
                this.DefaultBlackItem.add(itemEntry.m_5456_());
            }
            for (ItemEntry itemEntry : GTItems.SHAPE_EXTRUDERS) {
                if (itemEntry == null) continue;
                this.DefaultBlackItem.add(itemEntry.m_5456_());
            }
        }
        catch (Exception exception) {
            GTOCore.LOGGER.error(exception.getMessage());
        }
    }
}

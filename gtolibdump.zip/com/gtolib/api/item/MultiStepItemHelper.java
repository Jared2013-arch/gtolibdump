package com.gtolib.api.item;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;

public final class MultiStepItemHelper {
    public static ItemStack toMultiStepItem(ItemStack itemStack, int n, int n2) {
        CompoundTag compoundTag = itemStack.m_41784_();
        compoundTag.m_128405_("craft_step", n2);
        compoundTag.m_128405_("current_craft_step", n);
        return itemStack;
    }

    private static ItemStack setStep(ItemStack itemStack, int n, int n2) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag == null || n2 == 0) {
            throw new IllegalArgumentException("ItemStack is not a MultiStepItem");
        }
        compoundTag.m_128405_("current_craft_step", Math.min(n2, n));
        return itemStack;
    }

    public static ItemStack locateStep(ItemStack itemStack, int n) {
        ItemStack itemStack2 = itemStack.m_41777_();
        itemStack2.m_41783_().m_128405_("current_craft_step", n);
        return itemStack2;
    }

    public static ItemStack promoteStep(ItemStack itemStack) {
        int n;
        int n2 = MultiStepItemHelper.getStep(itemStack) + 1;
        if (n2 < (n = MultiStepItemHelper.getMaxStep(itemStack))) {
            return MultiStepItemHelper.setStep(itemStack, n2, n);
        }
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag != null) {
            compoundTag.m_128473_("craft_step");
            compoundTag.m_128473_("current_craft_step");
            if (compoundTag.m_128456_()) {
                itemStack.m_41751_(null);
            }
        }
        return itemStack;
    }

    public static int getStep(ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag == null) {
            return 0;
        }
        return compoundTag.m_128451_("current_craft_step");
    }

    public static int getMaxStep(ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag == null) {
            return 0;
        }
        return compoundTag.m_128451_("craft_step");
    }
}

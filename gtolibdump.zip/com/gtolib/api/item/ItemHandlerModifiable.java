package com.gtolib.api.item;

import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.IItemHandlerModifiable;
import org.jetbrains.annotations.NotNull;

public class ItemHandlerModifiable
implements IItemHandlerModifiable {
    private ItemStack itemStack;

    public ItemHandlerModifiable(ItemStack itemStack) {
        this.itemStack = itemStack;
    }

    public void setStackInSlot(int n, @NotNull ItemStack itemStack) {
        this.itemStack = itemStack;
    }

    public int getSlots() {
        return 1;
    }

    @Override
    @NotNull
    public ItemStack getStackInSlot(int n) {
        return this.itemStack;
    }

    @NotNull
    public ItemStack insertItem(int n, @NotNull ItemStack itemStack, boolean bl) {
        if (this.itemStack.m_150930_(itemStack.m_41720_())) {
            this.itemStack.m_41764_(this.itemStack.m_41613_() + itemStack.m_41613_());
        } else {
            this.itemStack = itemStack;
        }
        return ItemStack.f_41583_;
    }

    @NotNull
    public ItemStack extractItem(int n, int n2, boolean bl) {
        int n3 = this.itemStack.m_41613_() - n2;
        if (n3 < 0) {
            return ItemStack.f_41583_;
        }
        ItemStack itemStack = this.itemStack.m_255036_(n3);
        if (n3 == 0) {
            this.itemStack = ItemStack.f_41583_;
        } else {
            this.itemStack.m_41764_(n3);
        }
        return itemStack;
    }

    public int getSlotLimit(int n) {
        return Integer.MAX_VALUE;
    }

    public boolean isItemValid(int n, @NotNull ItemStack itemStack) {
        return this.itemStack.m_41619_();
    }
}

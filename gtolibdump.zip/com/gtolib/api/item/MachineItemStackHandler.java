package com.gtolib.api.item;

import com.gregtechceu.gtceu.api.transfer.item.CustomItemStackHandler;
import java.util.function.IntSupplier;

public class MachineItemStackHandler
extends CustomItemStackHandler {
    private final IntSupplier supplier;

    public MachineItemStackHandler(IntSupplier intSupplier) {
        super(1);
        this.supplier = intSupplier;
    }

    public int getSlotLimit(int n) {
        return this.supplier.getAsInt();
    }
}

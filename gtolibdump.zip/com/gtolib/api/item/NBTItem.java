package com.gtolib.api.item;

import com.gtolib.utils.ItemUtils;
import com.gtolib.utils.RegistriesUtils;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public record NBTItem(Item item, CompoundTag nbt) {
    public static NBTItem of(ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        boolean bl = compoundTag != null && !compoundTag.m_128456_();
        return new NBTItem(itemStack.m_41720_(), bl ? compoundTag : null);
    }

    public static NBTItem of(CompoundTag compoundTag) {
        return new NBTItem(RegistriesUtils.getItem(compoundTag.m_128461_("id")), compoundTag.m_128469_("tag"));
    }

    public ItemStack toStack() {
        return this.toStack(1);
    }

    public ItemStack toStack(int n) {
        return new ItemStack(this.item, n, this.nbt);
    }

    public CompoundTag serializeNBT() {
        CompoundTag compoundTag = new CompoundTag();
        compoundTag.m_128359_("id", ItemUtils.getId(this.item));
        if (this.nbt != null) {
            compoundTag.m_128365_("tag", this.nbt);
        }
        return compoundTag;
    }

    public boolean equals(Object object) {
        if (object instanceof NBTItem) {
            NBTItem nBTItem = (NBTItem)object;
            if (this.item == nBTItem.item) {
                if (this.nbt == null) {
                    return nBTItem.nbt == null;
                }
                return this.nbt.equals(nBTItem.nbt);
            }
        }
        return false;
    }

    public int hashCode() {
        int n = 17;
        n = 31 * n + (this.item == null ? 0 : this.item.hashCode());
        n = 31 * n + (this.nbt == null ? 0 : this.nbt.hashCode());
        return n;
    }
}

package com.gtolib.api.machine;

import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.gui.widget.PatternPreviewWidget;
import com.gregtechceu.gtceu.api.machine.MachineDefinition;
import com.gregtechceu.gtceu.api.machine.MultiblockMachineDefinition;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiController;
import com.gregtechceu.gtceu.api.pattern.BlockPattern;
import com.gregtechceu.gtceu.api.pattern.MultiblockShapeInfo;
import com.gregtechceu.gtceu.api.pattern.predicates.SimplePredicate;
import com.gregtechceu.gtceu.api.registry.GTRegistries;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtocore.config.GTOConfig;
import com.gtolib.GTOCore;
import com.gtolib.api.annotation.dynamic.DynamicInitialData;
import com.gtolib.api.machine.IDifficultyConfigDefinition;
import com.lowdragmc.lowdraglib.utils.BlockInfo;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.lang.invoke.LambdaMetafactory;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

public final class MultiblockDefinition
extends MultiblockMachineDefinition
implements IDifficultyConfigDefinition {
    private Pattern[] patterns;
    private DynamicInitialData dynamicInitialData;

    private MultiblockDefinition(ResourceLocation resourceLocation) {
        super(resourceLocation);
    }

    public static MultiblockDefinition createDefinition(ResourceLocation resourceLocation) {
        return new MultiblockDefinition(resourceLocation);
    }

    public static MultiblockDefinition of(MultiblockMachineDefinition multiblockMachineDefinition) {
        return (MultiblockDefinition)multiblockMachineDefinition;
    }

    public static List<MultiblockShapeInfo> getMatchingShapes(boolean bl, BlockPattern blockPattern) {
        List<Supplier<BlockInfo[][][]>> list = MultiblockDefinition.repetitionDFS(blockPattern, new ObjectArrayList(), blockPattern.aisleRepetitions, new IntArrayList());
        if (bl) {
            ObjectArrayList objectArrayList = new ObjectArrayList();
            objectArrayList.add(new MultiblockShapeInfo(list.get(0).get()));
            if (list.size() > 1) {
                objectArrayList.add(new MultiblockShapeInfo(list.get(list.size() - 1).get()));
            }
            return objectArrayList;
        }
        return list.stream().map(Supplier::get).map(MultiblockShapeInfo::new).toList();
    }

    private static List<Supplier<BlockInfo[][][]>> repetitionDFS(BlockPattern blockPattern, List<Supplier<BlockInfo[][][]>> list, int[][] nArray, IntArrayList intArrayList) {
        if (intArrayList.size() == nArray.length) {
            int[] nArray2 = new int[intArrayList.size()];
            for (int i = 0; i < intArrayList.size(); ++i) {
                nArray2[i] = intArrayList.getInt(i);
            }
            list.add(() -> blockPattern.getPreview(nArray2));
        } else {
            for (int i = nArray[intArrayList.size()][0]; i <= nArray[intArrayList.size()][1]; ++i) {
                intArrayList.push(i);
                MultiblockDefinition.repetitionDFS(blockPattern, list, nArray, intArrayList);
                intArrayList.popInt();
            }
        }
        return list;
    }

    private static BlockInfo[][][] getBlockInfos(BlockPattern blockPattern) {
        return MultiblockDefinition.repetitionDFS(blockPattern, new ObjectArrayList(), blockPattern.aisleRepetitions, new IntArrayList()).get(0).get();
    }

    public List<MultiblockShapeInfo> getMatchingShapes() {
        List list;
        Supplier supplier = this.getShapes();
        if (supplier != null && !(list = (List)supplier.get()).isEmpty()) {
            return list;
        }
        return MultiblockDefinition.getMatchingShapes(true, (BlockPattern)this.getPatternFactory().get());
    }

    public void clear() {
        this.recoveryItems = null;
        this.patterns = null;
        this.setShapes(null);
    }

    public static void init() {
        long l = System.currentTimeMillis();
        for (MachineDefinition machineDefinition : GTRegistries.MACHINES.values()) {
            int n;
            Object[] objectArray;
            MultiblockDefinition multiblockDefinition;
            if (!(machineDefinition instanceof MultiblockDefinition) || !(multiblockDefinition = (MultiblockDefinition)machineDefinition).isRenderXEIPreview()) continue;
            List<Object> list = (List<MultiblockShapeInfo>)multiblockDefinition.getShapes().get();
            if (list.isEmpty()) {
                if (multiblockDefinition.subPatternFactory != null) {
                    objectArray = new MultiblockShapeInfo[multiblockDefinition.subPatternFactory.length + 1];
                    objectArray[0] = new MultiblockShapeInfo(MultiblockDefinition.getBlockInfos((BlockPattern)multiblockDefinition.getPatternFactory().get()));
                    for (n = 0; n < multiblockDefinition.subPatternFactory.length; ++n) {
                        objectArray[n + 1] = new MultiblockShapeInfo(MultiblockDefinition.getBlockInfos((BlockPattern)multiblockDefinition.subPatternFactory[n].get()));
                    }
                    list = Arrays.asList(objectArray);
                } else {
                    list = MultiblockDefinition.getMatchingShapes(GTOConfig.INSTANCE.fastMultiBlockPage, (BlockPattern)multiblockDefinition.getPatternFactory().get());
                }
            }
            objectArray = new Pattern[list.size()];
            for (n = 0; n < list.size(); ++n) {
                objectArray[n] = MultiblockDefinition.initializePattern(list.get(n));
            }
            multiblockDefinition.patterns = objectArray;
        }
        GTOCore.LOGGER.info("Pre initialization of multiBlock took {}ms", (Object)(System.currentTimeMillis() - l));
    }

    private static Pattern initializePattern(MultiblockShapeInfo multiblockShapeInfo) {
        Long2ObjectOpenHashMap long2ObjectOpenHashMap = new Long2ObjectOpenHashMap(multiblockShapeInfo.amount);
        O2OOpenCacheHashMap o2OOpenCacheHashMap = new O2OOpenCacheHashMap();
        IMultiController iMultiController = null;
        BlockPos blockPos = PatternPreviewWidget.locateNextRegion(500);
        BlockInfo[][][] blockInfoArray = multiblockShapeInfo.getBlocks();
        int n = blockInfoArray.length;
        for (int i = 0; i < n; ++i) {
            BlockInfo[][] blockInfoArray2 = blockInfoArray[i];
            int n2 = blockInfoArray2.length;
            for (int j = 0; j < n2; ++j) {
                BlockInfo[] blockInfoArray3 = blockInfoArray2[j];
                int n3 = blockInfoArray3.length;
                for (int k = 0; k < n3; ++k) {
                    boolean bl;
                    Object object;
                    Object object2;
                    Block block;
                    BlockInfo blockInfo = blockInfoArray3[k];
                    if (blockInfo == null || (block = blockInfo.getBlockState().m_60734_()) == Blocks.f_50016_) continue;
                    BlockPos blockPos2 = blockPos.m_7918_(i, j, k);
                    if (iMultiController == null && (object2 = blockInfo.getBlockEntity(blockPos2)) instanceof MetaMachineBlockEntity && (object2 = ((MetaMachineBlockEntity)(object = (MetaMachineBlockEntity)object2)).getMetaMachine()) instanceof IMultiController) {
                        IMultiController iMultiController2;
                        iMultiController = iMultiController2 = (IMultiController)object2;
                        bl = true;
                    } else {
                        bl = false;
                    }
                    long2ObjectOpenHashMap.put(blockPos2.m_121878_(), blockInfo);
                    object = SimplePredicate.toItem(block);
                    if (object == Items.f_41852_) continue;
                    ++o2OOpenCacheHashMap.computeIfAbsent(object, (Function<Item, PartInfo>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, lambda$initializePattern$1(com.lowdragmc.lowdraglib.utils.BlockInfo boolean net.minecraft.world.item.Item ), (Lnet/minecraft/world/item/Item;)Lcom/gtolib/api/machine/MultiblockDefinition$PartInfo;)((BlockInfo)blockInfo, (boolean)bl)).amount;
                }
            }
        }
        return new Pattern(iMultiController, long2ObjectOpenHashMap, o2OOpenCacheHashMap.values().stream().sorted((partInfo, partInfo2) -> {
            if (partInfo.isController) {
                return -1;
            }
            if (partInfo2.isController) {
                return 1;
            }
            if (partInfo.isTile && !partInfo2.isTile) {
                return -1;
            }
            if (partInfo2.isTile && !partInfo.isTile) {
                return 1;
            }
            if (partInfo.blockId != partInfo2.blockId) {
                return partInfo2.blockId - partInfo.blockId;
            }
            return partInfo2.amount - partInfo.amount;
        }).map(PartInfo::getItemStack).filter(itemStack -> !itemStack.m_41619_()).collect(Collectors.toList()));
    }

    public Pattern[] getPatterns() {
        return this.patterns;
    }

    @Override
    public DynamicInitialData getDynamicInitialData() {
        return this.dynamicInitialData;
    }

    @Override
    public void setDynamicInitialData(DynamicInitialData dynamicInitialData) {
        this.dynamicInitialData = dynamicInitialData;
    }

    private static PartInfo lambda$initializePattern$1(BlockInfo blockInfo, boolean bl, Item item) {
        return new PartInfo(item, blockInfo, bl);
    }

    public record Pattern(@Nullable IMultiController multiController, Long2ObjectOpenHashMap<BlockInfo> blockMap, List<ItemStack> parts) {
    }

    private static final class PartInfo {
        private final Item item;
        private final boolean isController;
        private final boolean isTile;
        private final int blockId;
        private int amount;

        private PartInfo(Item item, BlockInfo blockInfo, boolean bl) {
            this.item = item;
            this.isController = bl;
            this.blockId = Block.m_49956_((BlockState)blockInfo.getBlockState());
            this.isTile = blockInfo.hasBlockEntity();
        }

        private ItemStack getItemStack() {
            return this.item.m_7968_().m_255036_(this.amount);
        }
    }
}

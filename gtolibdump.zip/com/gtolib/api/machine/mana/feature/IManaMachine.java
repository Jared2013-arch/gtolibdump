package com.gtolib.api.machine.mana.feature;

import com.google.common.base.Predicates;
import com.gregtechceu.gtceu.api.machine.feature.IMachineFeature;
import com.gtolib.api.machine.mana.feature.IManaContainerMachine;
import com.gtolib.utils.MathUtil;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import vazkii.botania.api.internal.ManaBurst;
import vazkii.botania.api.mana.ManaCollector;
import vazkii.botania.api.mana.spark.ManaSpark;
import vazkii.botania.api.mana.spark.SparkAttachable;
import vazkii.botania.common.block.BotaniaBlocks;

public interface IManaMachine
extends IMachineFeature,
IManaContainerMachine,
ManaCollector,
SparkAttachable {
    default public Level getManaReceiverLevel() {
        return this.self().getLevel();
    }

    default public BlockPos getManaReceiverPos() {
        return this.self().getPos();
    }

    default public void onClientDisplayTick() {
    }

    default public float getManaYieldMultiplier(ManaBurst manaBurst) {
        return 1.0f;
    }

    default public int getMaxMana() {
        return MathUtil.saturatedCast(this.getManaContainer().getMaxMana());
    }

    default public int getCurrentMana() {
        return MathUtil.saturatedCast(this.getManaContainer().getCurrentMana());
    }

    default public boolean isFull() {
        return this.getManaContainer().getMaxMana() <= this.getManaContainer().getCurrentMana();
    }

    default public void receiveMana(int n) {
        if (n > 0) {
            this.getManaContainer().addMana(n, 1, false);
        } else if (n < 0) {
            this.getManaContainer().removeMana(-n, 1, false);
        }
    }

    default public boolean canAttachSpark(ItemStack itemStack) {
        return true;
    }

    default public int getAvailableSpaceForMana() {
        Level level = this.self().getLevel();
        if (level == null) {
            return 0;
        }
        int n = Math.max(0, MathUtil.saturatedCast(this.getManaContainer().getMaxMana() - this.getManaContainer().getCurrentMana()));
        if (n > 0) {
            return n;
        }
        if (level.m_8055_(this.self().getPos().m_7495_()).m_60713_(BotaniaBlocks.manaVoid)) {
            return this.getMaxMana();
        }
        return 0;
    }

    default public ManaSpark getAttachedSpark() {
        Level level = this.self().getLevel();
        if (level == null) {
            return null;
        }
        List list = level.m_6443_(Entity.class, new AABB(this.self().getPos().m_7494_(), this.self().getPos().m_7494_().m_7918_(1, 1, 1)), Predicates.instanceOf(ManaSpark.class));
        if (list.size() == 1) {
            Entity entity = (Entity)list.get(0);
            return (ManaSpark)((Object)entity);
        }
        return null;
    }

    default public boolean areIncomingTranfersDone() {
        return false;
    }
}

package com.gtolib.api.machine.mana.feature;

import com.gtolib.api.capability.IManaContainer;
import org.jetbrains.annotations.NotNull;

public interface IManaContainerMachine {
    @NotNull
    public IManaContainer getManaContainer();

    default public boolean useMana(long l, boolean bl) {
        if (l < 0L) {
            if (!bl) {
                this.getManaContainer().addMana(-l, 1, false);
            }
            return true;
        }
        return this.getManaContainer().removeMana(l, 1, bl) == l;
    }
}

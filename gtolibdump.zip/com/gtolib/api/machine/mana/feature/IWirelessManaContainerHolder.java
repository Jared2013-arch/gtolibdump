package com.gtolib.api.machine.mana.feature;

import com.gtolib.api.wireless.WirelessManaContainer;
import com.hepdd.gtmthings.api.capability.IBindable;
import javax.annotation.Nullable;

public interface IWirelessManaContainerHolder
extends IBindable {
    public void setWirelessManaContainerCache(WirelessManaContainer var1);

    public WirelessManaContainer getWirelessManaContainerCache();

    @Nullable
    default public WirelessManaContainer getWirelessManaContainer() {
        if (this.getUUID() != null && this.getWirelessManaContainerCache() == null) {
            WirelessManaContainer wirelessManaContainer = WirelessManaContainer.getOrCreateContainer(this.getUUID());
            this.setWirelessManaContainerCache(wirelessManaContainer);
        }
        return this.getWirelessManaContainerCache();
    }
}

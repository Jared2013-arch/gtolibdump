package com.gtolib.api.machine.mana.feature;

import com.gtolib.api.machine.mana.feature.IManaContainerMachine;
import com.gtolib.api.misc.ManaContainerList;
import org.jetbrains.annotations.NotNull;

public interface IManaMultiblock
extends IManaContainerMachine {
    @Override
    @NotNull
    public ManaContainerList getManaContainer();

    public boolean isGeneratorMana();

    default public long removeMana(long l, int n, boolean bl) {
        return this.getManaContainer().removeMana(l, n, bl);
    }
}

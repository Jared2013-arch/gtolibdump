package com.gtolib.api.machine.mana.trait;

import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gtolib.api.machine.mana.feature.IWirelessManaContainerHolder;
import com.gtolib.api.machine.mana.trait.NotifiableManaContainer;
import com.gtolib.api.wireless.WirelessManaContainer;
import java.math.BigInteger;
import java.util.UUID;
import javax.annotation.Nullable;

public final class NotifiableWirelessManaContainer
extends NotifiableManaContainer
implements IWirelessManaContainerHolder {
    private WirelessManaContainer WirelessManaContainerCache;

    public NotifiableWirelessManaContainer(MetaMachine metaMachine, IO iO, long l, long l2) {
        super(metaMachine, iO, l, l2);
    }

    @Override
    protected void updateTick() {
        WirelessManaContainer wirelessManaContainer;
        if (!this.getMachine().isRemote() && this.getMachine().getOffsetTimer() % 10L == 0L && (wirelessManaContainer = this.getWirelessManaContainer()) != null) {
            long l = this.getCurrentMana();
            if (this.getHandlerIO() == IO.IN) {
                long l2 = Math.min(this.getMaxMana() - l, wirelessManaContainer.getStorage().longValue());
                if (l2 > 0L) {
                    wirelessManaContainer.setStorage(wirelessManaContainer.getStorage().subtract(BigInteger.valueOf(l2)));
                    this.setCurrentMana(l + l2);
                    this.notifyListeners();
                }
            } else if (l > 0L) {
                wirelessManaContainer.setStorage(wirelessManaContainer.getStorage().add(BigInteger.valueOf(l)));
                this.setCurrentMana(0L);
                this.notifyListeners();
            }
        }
    }

    @Override
    @Nullable
    public UUID getUUID() {
        return this.getMachine().getOwnerUUID();
    }

    @Override
    public boolean acceptDistributor() {
        return false;
    }

    @Override
    public void setWirelessManaContainerCache(WirelessManaContainer wirelessManaContainer) {
        this.WirelessManaContainerCache = wirelessManaContainer;
    }

    @Override
    public WirelessManaContainer getWirelessManaContainerCache() {
        return this.WirelessManaContainerCache;
    }
}

package com.gtolib.api.machine;

import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiController;
import com.lowdragmc.lowdraglib.utils.BlockInfo;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.util.List;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

public record MultiblockDefinition$Pattern(@Nullable IMultiController multiController, Long2ObjectOpenHashMap<BlockInfo> blockMap, List<ItemStack> parts) {
}

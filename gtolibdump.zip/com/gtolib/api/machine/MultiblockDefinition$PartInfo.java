package com.gtolib.api.machine;

import com.lowdragmc.lowdraglib.utils.BlockInfo;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

final class MultiblockDefinition$PartInfo {
    private final Item item;
    private final boolean isController;
    private final boolean isTile;
    private final int blockId;
    private int amount;

    private MultiblockDefinition$PartInfo(Item item, BlockInfo blockInfo, boolean bl) {
        this.item = item;
        this.isController = bl;
        this.blockId = Block.m_49956_((BlockState)blockInfo.getBlockState());
        this.isTile = blockInfo.hasBlockEntity();
    }

    private ItemStack getItemStack() {
        return this.item.m_7968_().m_255036_(this.amount);
    }
}

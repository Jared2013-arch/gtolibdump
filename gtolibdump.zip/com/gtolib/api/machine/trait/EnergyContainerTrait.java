package com.gtolib.api.machine.trait;

import com.gregtechceu.gtceu.api.capability.IEnergyContainer;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.trait.MachineTrait;
import com.lowdragmc.lowdraglib.syncdata.annotation.Persisted;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedFieldHolder;
import net.minecraft.core.Direction;

public class EnergyContainerTrait
extends MachineTrait
implements IEnergyContainer {
    private static final ManagedFieldHolder MANAGED_FIELD_HOLDER = new ManagedFieldHolder(EnergyContainerTrait.class);
    @Persisted
    protected long energyStored;
    private long energyCapacity;

    public EnergyContainerTrait(MetaMachine metaMachine, long l) {
        super(metaMachine);
        this.energyCapacity = l;
    }

    public void resetBasicInfo(long l) {
        this.energyCapacity = l;
    }

    public long acceptEnergyFromNetwork(Object object, Direction direction, long l, long l2) {
        return 0L;
    }

    public boolean inputsEnergy(Direction direction) {
        return false;
    }

    @Override
    public long changeEnergy(long l) {
        long l2;
        long l3 = this.energyStored;
        long l4 = l2 = this.energyCapacity - l3 < l ? this.energyCapacity : l3 + l;
        if (l2 < 0L) {
            l2 = 0L;
        }
        this.energyStored = l2;
        return l2 - l3;
    }

    public long getInputAmperage() {
        return 0L;
    }

    public long getInputVoltage() {
        return 0L;
    }

    public ManagedFieldHolder getFieldHolder() {
        return MANAGED_FIELD_HOLDER;
    }

    @Override
    public long getEnergyStored() {
        return this.energyStored;
    }

    @Override
    public long getEnergyCapacity() {
        return this.energyCapacity;
    }

    public void setEnergyStored(long l) {
        this.energyStored = l;
    }
}

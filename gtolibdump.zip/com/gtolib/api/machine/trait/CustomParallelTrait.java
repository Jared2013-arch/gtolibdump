package com.gtolib.api.machine.trait;

import com.gtolib.api.machine.feature.multiblock.IMultiblockTraitHolder;
import com.gtolib.api.machine.feature.multiblock.IParallelMachine;
import com.gtolib.api.machine.trait.MultiblockTrait;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.modifier.ParallelLogic;
import com.lowdragmc.lowdraglib.syncdata.annotation.Persisted;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedFieldHolder;
import java.util.function.ToLongFunction;
import org.jetbrains.annotations.NotNull;

public class CustomParallelTrait
extends MultiblockTrait {
    private static final ManagedFieldHolder MANAGED_FIELD_HOLDER = new ManagedFieldHolder(CustomParallelTrait.class, MultiblockTrait.MANAGED_FIELD_HOLDER);
    @Persisted
    private long parallelNumber;
    private boolean defaultMax = true;
    private final boolean defaultParallel;
    private final ToLongFunction<IParallelMachine> parallel;

    public CustomParallelTrait(IParallelMachine iParallelMachine, boolean bl, @NotNull ToLongFunction<IParallelMachine> toLongFunction) {
        super((IMultiblockTraitHolder)((Object)iParallelMachine));
        this.defaultParallel = bl;
        this.parallel = toLongFunction;
    }

    @Override
    public ManagedFieldHolder getFieldHolder() {
        return MANAGED_FIELD_HOLDER;
    }

    @Override
    public Recipe modifyRecipe(@NotNull Recipe recipe) {
        if (this.defaultParallel && (recipe = ParallelLogic.accurateParallel(this.getMachine(), recipe, this.getParallel())) == null) {
            return null;
        }
        return super.modifyRecipe(recipe);
    }

    @Override
    public void onStructureInvalid() {
        this.parallelNumber = 0L;
    }

    public long getMaxParallel() {
        if (this.getMachine().isFormed()) {
            return Math.min(IParallelMachine.MAX_PARALLEL, this.parallel.applyAsLong((IParallelMachine)((Object)this.getMachine())));
        }
        return 0L;
    }

    public long getParallel() {
        if (this.defaultMax && this.parallelNumber == 0L) {
            this.parallelNumber = this.getMaxParallel();
        }
        return Math.max(1L, this.parallelNumber);
    }

    public void setParallel(long l) {
        this.parallelNumber = l < 1L ? 1L : Math.min(l, this.getMaxParallel());
    }

    public void setDefaultMax(boolean bl) {
        this.defaultMax = bl;
    }
}

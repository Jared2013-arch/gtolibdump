package com.gtolib.api.machine.trait;

import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.trait.NotifiableFluidTank;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.recipe.ingredient.FluidIngredient;
import com.gtolib.api.recipe.ingredient.FastFluidIngredient;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Collection;
import java.util.List;
import java.util.ListIterator;
import net.minecraftforge.fluids.FluidStack;

public final class NotifiableNotConsumableFluidHandler
extends NotifiableFluidTank {
    public NotifiableNotConsumableFluidHandler(MetaMachine metaMachine, int n, int n2) {
        super(metaMachine, n, n2, IO.IN, IO.NONE);
    }

    public boolean skipParallelComputing() {
        return true;
    }

    @Override
    public boolean isEmpty() {
        return this.getFluidMap() == null;
    }

    public boolean shouldSearchContent() {
        return false;
    }

    public boolean isNotConsumable() {
        return true;
    }

    public boolean isRecipeOnly() {
        return true;
    }

    public List<FluidIngredient> handleRecipe(IO iO, GTRecipe gTRecipe, List<?> list, boolean bl) {
        return this.handleRecipeInner(iO, gTRecipe, list, bl);
    }

    public List<FluidIngredient> handleRecipeInner(IO iO, GTRecipe gTRecipe, List<FluidIngredient> objectArrayList, boolean bl) {
        if (bl && iO == IO.IN && !this.isEmpty()) {
            objectArrayList = new ObjectArrayList((Collection)objectArrayList);
            ListIterator listIterator = objectArrayList.listIterator(0);
            block0: while (listIterator.hasNext()) {
                FluidIngredient fluidIngredient = (FluidIngredient)listIterator.next();
                if (fluidIngredient.isEmpty()) {
                    listIterator.remove();
                    continue;
                }
                long l = FastFluidIngredient.getAmount(fluidIngredient);
                for (int i = 0; i < this.storages.length; ++i) {
                    FluidStack fluidStack = this.getFluidInTank(i);
                    int n = fluidStack.getAmount();
                    if (n == 0) continue;
                    if (fluidIngredient.test(fluidStack)) {
                        l -= (long)n;
                    }
                    if (l > 0L) continue;
                    listIterator.remove();
                    continue block0;
                }
            }
        }
        return objectArrayList.isEmpty() ? null : objectArrayList;
    }
}

package com.gtolib.api.machine.trait;

import com.gregtechceu.gtceu.api.GTValues;
import com.gregtechceu.gtceu.api.capability.IEnergyContainer;
import com.gregtechceu.gtceu.api.capability.recipe.EURecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.capability.recipe.IRecipeCapabilityHolder;
import com.gregtechceu.gtceu.api.capability.recipe.IRecipeHandler;
import com.gregtechceu.gtceu.api.misc.EnergyContainerList;
import com.gregtechceu.gtceu.utils.FormattingUtil;
import com.gregtechceu.gtceu.utils.GTUtil;
import com.gtolib.api.machine.feature.IElectricMachine;
import com.gtolib.api.machine.feature.multiblock.IMultiblockTraitHolder;
import com.gtolib.api.machine.trait.MultiblockTrait;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import org.jetbrains.annotations.NotNull;

public class ElectricTrait
extends MultiblockTrait {
    @NotNull
    private EnergyContainerList energyContainer = EnergyContainerList.EMPTY;

    public ElectricTrait(IElectricMachine iElectricMachine) {
        super((IMultiblockTraitHolder)((Object)iElectricMachine));
    }

    @Override
    public void onStructureInvalid() {
        this.energyContainer = EnergyContainerList.EMPTY;
    }

    @Override
    public void onStructureFormed() {
        ObjectArrayList objectArrayList = new ObjectArrayList();
        List list = ((IRecipeCapabilityHolder)((Object)this.machine)).getCapabilitiesFlat(IO.IN, EURecipeCapability.CAP);
        if (list.isEmpty()) {
            list = ((IRecipeCapabilityHolder)((Object)this.machine)).getCapabilitiesFlat(IO.OUT, EURecipeCapability.CAP);
        }
        for (IRecipeHandler iRecipeHandler : list) {
            if (!(iRecipeHandler instanceof IEnergyContainer)) continue;
            IEnergyContainer iEnergyContainer = (IEnergyContainer)((Object)iRecipeHandler);
            objectArrayList.add(iEnergyContainer);
        }
        this.energyContainer = new EnergyContainerList(objectArrayList);
    }

    @Override
    public void customText(@NotNull List<Component> list) {
        super.customText(list);
        if (this.energyContainer.getEnergyCapacity() > 0L) {
            long l = Math.max(this.energyContainer.getInputVoltage(), this.energyContainer.getOutputVoltage());
            String string = FormattingUtil.formatNumbers(l);
            byte by = GTUtil.getFloorTierByVoltage(l);
            MutableComponent mutableComponent = Component.m_237113_(GTValues.VNF[by]);
            MutableComponent mutableComponent2 = Component.m_237110_("gtceu.multiblock.max_energy_per_tick", new Object[]{string, mutableComponent}).m_130940_(ChatFormatting.GRAY);
            MutableComponent mutableComponent3 = Component.m_237115_("gtceu.multiblock.max_energy_per_tick_hover").m_130940_(ChatFormatting.GRAY);
            list.add(mutableComponent2.m_130938_(style -> style.m_131144_(new HoverEvent(HoverEvent.Action.f_130831_, mutableComponent3))));
        }
    }

    @NotNull
    public EnergyContainerList getEnergyContainer() {
        return this.energyContainer;
    }
}

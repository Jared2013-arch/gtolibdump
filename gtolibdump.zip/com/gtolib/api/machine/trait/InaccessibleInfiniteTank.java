package com.gtolib.api.machine.trait;

import appeng.api.networking.IGrid;
import appeng.api.stacks.AEFluidKey;
import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.TickableSubscription;
import com.gregtechceu.gtceu.api.machine.trait.NotifiableFluidTank;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.recipe.ingredient.FluidIngredient;
import com.gregtechceu.gtceu.api.transfer.fluid.CustomFluidTank;
import com.gregtechceu.gtceu.integration.ae2.utils.KeyStorage;
import com.gtocore.common.machine.multiblock.part.ae.MEPartMachine;
import com.gtolib.api.recipe.ingredient.FastFluidIngredient;
import com.lowdragmc.lowdraglib.syncdata.ISubscription;
import java.util.List;
import net.minecraft.server.TickTask;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.capability.IFluidHandler;
import org.jetbrains.annotations.NotNull;

public final class InaccessibleInfiniteTank
extends NotifiableFluidTank {
    private final FluidStorageDelegate delegate;
    private TickableSubscription updateSubs;
    private final MEPartMachine machine;

    public InaccessibleInfiniteTank(MetaMachine metaMachine, KeyStorage keyStorage) {
        super(metaMachine, List.of((Object)new FluidStorageDelegate(keyStorage)), IO.OUT, IO.NONE);
        this.machine = (MEPartMachine)((Object)metaMachine);
        this.delegate = (FluidStorageDelegate)this.getStorages()[0];
        this.delegate.setOnContentsChangedAndfreeze(this::updateAutoOutputSubscription);
    }

    public void updateAutoOutputSubscription() {
        if (!this.delegate.internalBuffer.storage.isEmpty() && this.machine.isWorkingEnabled() && this.machine.isOnline()) {
            this.updateSubs = this.getMachine().subscribeServerTick(this.updateSubs, this::updateTick);
        } else if (this.updateSubs != null) {
            this.updateSubs.unsubscribe();
            this.updateSubs = null;
        }
    }

    @Override
    public ISubscription addChangedListener(Runnable runnable) {
        return () -> {};
    }

    @Override
    public void onMachineLoad() {
        super.onMachineLoad();
        Level level = this.machine.getLevel();
        if (level instanceof ServerLevel) {
            ServerLevel serverLevel = (ServerLevel)level;
            serverLevel.m_7654_().m_6937_(new TickTask(0, this::updateAutoOutputSubscription));
        }
    }

    @Override
    public void onMachineUnLoad() {
        super.onMachineUnLoad();
        if (this.updateSubs != null) {
            this.updateSubs.unsubscribe();
            this.updateSubs = null;
        }
    }

    private void updateTick() {
        IGrid iGrid;
        if (this.machine.getOffsetTimer() % 40L != 0L) {
            return;
        }
        if (this.machine.isWorkingEnabled() && !this.delegate.internalBuffer.isEmpty() && this.machine.updateMEStatus() && (iGrid = this.machine.getMainNode().getGrid()) != null && this.delegate.internalBuffer.lock.tryLock()) {
            try {
                this.delegate.internalBuffer.insertInventory(iGrid.getStorageService().getInventory(), this.machine.getActionSource());
            }
            finally {
                this.delegate.internalBuffer.lock.unlock();
            }
        }
        this.updateAutoOutputSubscription();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void fillInternal(FluidStack fluidStack, long l) {
        if (l < 1L || fluidStack.isEmpty()) {
            return;
        }
        this.delegate.internalBuffer.lock.lock();
        try {
            this.delegate.internalBuffer.storage.addTo(AEFluidKey.of(fluidStack), l);
        }
        finally {
            this.delegate.internalBuffer.lock.unlock();
            this.updateAutoOutputSubscription();
        }
    }

    public int fillInternal(FluidStack fluidStack, IFluidHandler.FluidAction fluidAction) {
        return this.delegate.fill(fluidStack, fluidAction);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public List<FluidIngredient> handleRecipeInner(IO iO, GTRecipe gTRecipe, List<FluidIngredient> list, boolean bl) {
        if (iO == IO.OUT) {
            if (bl) {
                return null;
            }
            this.delegate.internalBuffer.lock.lock();
            try {
                for (FluidIngredient fluidIngredient : list) {
                    long l;
                    Fluid fluid = FastFluidIngredient.getFluid(fluidIngredient);
                    if (fluid == null || (l = FastFluidIngredient.getAmount(fluidIngredient)) <= 0L) continue;
                    this.delegate.internalBuffer.storage.addTo(AEFluidKey.of(fluid, fluidIngredient.getNbt()), l);
                }
            }
            finally {
                this.delegate.internalBuffer.lock.unlock();
                this.updateAutoOutputSubscription();
            }
            return null;
        }
        return list;
    }

    public List<FluidIngredient> handleRecipe(IO iO, GTRecipe gTRecipe, List<?> list, boolean bl) {
        return this.handleRecipeInner(iO, gTRecipe, list, bl);
    }

    @Override
    public int getTanks() {
        return 1;
    }

    public double getTotalContentAmount() {
        return 0.0;
    }

    @Override
    public boolean isEmpty() {
        return true;
    }

    @Override
    @NotNull
    public FluidStack getFluidInTank(int n) {
        return FluidStack.EMPTY;
    }

    public void setFluidInTank(int n, @NotNull FluidStack fluidStack) {
    }

    public int getTankCapacity(int n) {
        return Integer.MAX_VALUE;
    }

    public boolean isFluidValid(int n, @NotNull FluidStack fluidStack) {
        return true;
    }

    private static final class FluidStorageDelegate
    extends CustomFluidTank {
        private final KeyStorage internalBuffer;

        private FluidStorageDelegate(KeyStorage keyStorage) {
            super(0);
            this.internalBuffer = keyStorage;
        }

        public int getCapacity() {
            return Integer.MAX_VALUE;
        }

        public void setFluid(FluidStack fluidStack) {
        }

        /*
         * WARNING - Removed try catching itself - possible behaviour change.
         */
        public int fill(FluidStack fluidStack, IFluidHandler.FluidAction fluidAction) {
            int n = fluidStack.getAmount();
            if (n > 0 && fluidAction.execute()) {
                this.internalBuffer.lock.lock();
                try {
                    this.internalBuffer.storage.addTo(AEFluidKey.of(fluidStack.getFluid(), fluidStack.getTag()), n);
                }
                finally {
                    this.internalBuffer.lock.unlock();
                    this.onContentsChanged.run();
                }
            }
            return n;
        }

        public boolean supportsFill(int n) {
            return false;
        }

        public boolean supportsDrain(int n) {
            return false;
        }
    }
}

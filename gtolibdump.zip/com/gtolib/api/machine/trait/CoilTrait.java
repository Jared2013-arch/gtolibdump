package com.gtolib.api.machine.trait;

import com.gregtechceu.gtceu.api.block.ICoilType;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.ICoilMachine;
import com.gregtechceu.gtceu.api.machine.trait.RecipeLogic;
import com.gregtechceu.gtceu.common.block.CoilBlock;
import com.gregtechceu.gtceu.utils.FormattingUtil;
import com.gtolib.api.machine.feature.multiblock.IMultiblockTraitHolder;
import com.gtolib.api.machine.multiblock.ElectricMultiblockMachine;
import com.gtolib.api.machine.trait.IEnhancedRecipeLogic;
import com.gtolib.api.machine.trait.MultiblockTrait;
import com.gtolib.api.recipe.IdleReason;
import com.gtolib.api.recipe.Recipe;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import org.jetbrains.annotations.NotNull;

public class CoilTrait
extends MultiblockTrait {
    private ICoilType coilType = CoilBlock.CoilType.CUPRONICKEL;
    private int temperature;
    private final boolean ebf;
    private final boolean check;

    public CoilTrait(ICoilMachine iCoilMachine, boolean bl, boolean bl2) {
        super((IMultiblockTraitHolder)((Object)iCoilMachine));
        this.ebf = bl;
        this.check = bl2;
    }

    @Override
    public boolean beforeWorking(@NotNull Recipe recipe) {
        if (this.check && this.temperature < recipe.data.m_128451_("ebf_temp")) {
            RecipeLogic recipeLogic = this.getMachine().getRecipeLogic();
            if (recipeLogic instanceof IEnhancedRecipeLogic) {
                IEnhancedRecipeLogic iEnhancedRecipeLogic = (IEnhancedRecipeLogic)((Object)recipeLogic);
                iEnhancedRecipeLogic.gtolib$setIdleReason(IdleReason.INSUFFICIENT_TEMPERATURE.reason());
            }
            return true;
        }
        return false;
    }

    @Override
    public Recipe modifyRecipe(@NotNull Recipe recipe) {
        if (this.check && this.temperature < recipe.data.m_128451_("ebf_temp")) {
            RecipeLogic recipeLogic = this.getMachine().getRecipeLogic();
            if (recipeLogic instanceof IEnhancedRecipeLogic) {
                IEnhancedRecipeLogic iEnhancedRecipeLogic = (IEnhancedRecipeLogic)((Object)recipeLogic);
                iEnhancedRecipeLogic.gtolib$setIdleReason(IdleReason.INSUFFICIENT_TEMPERATURE.reason());
            }
            return null;
        }
        return super.modifyRecipe(recipe);
    }

    @Override
    public void customText(@NotNull List<Component> list) {
        list.add(Component.m_237110_("gtceu.multiblock.blast_furnace.max_temperature", new Object[]{Component.m_237115_(FormattingUtil.formatNumbers(this.temperature) + "K").m_6270_(Style.f_131099_.m_131140_(ChatFormatting.RED))}));
    }

    @Override
    public void onStructureFormed() {
        Object object = this.getMachine().getMultiblockState().getMatchContext().get("CoilType");
        if (object instanceof ICoilType) {
            ICoilType iCoilType;
            this.coilType = iCoilType = (ICoilType)object;
        }
        this.temperature = this.coilType.getCoilTemperature() + (this.ebf ? 100 * Math.max(0, this.getMachine().getTier() - 2) : 0);
    }

    @Override
    public ElectricMultiblockMachine getMachine() {
        return (ElectricMultiblockMachine)this.machine;
    }

    @Override
    public void onStructureInvalid() {
        this.coilType = CoilBlock.CoilType.CUPRONICKEL;
    }

    public ICoilType getCoilType() {
        return this.coilType;
    }

    public int getTemperature() {
        return this.temperature;
    }
}

package com.gtolib.api.machine.trait;

import appeng.api.stacks.AEFluidKey;
import com.gregtechceu.gtceu.api.transfer.fluid.CustomFluidTank;
import com.gregtechceu.gtceu.integration.ae2.utils.KeyStorage;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.capability.IFluidHandler;

final class InaccessibleInfiniteTank$FluidStorageDelegate
extends CustomFluidTank {
    private final KeyStorage internalBuffer;

    private InaccessibleInfiniteTank$FluidStorageDelegate(KeyStorage keyStorage) {
        super(0);
        this.internalBuffer = keyStorage;
    }

    public int getCapacity() {
        return Integer.MAX_VALUE;
    }

    public void setFluid(FluidStack fluidStack) {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public int fill(FluidStack fluidStack, IFluidHandler.FluidAction fluidAction) {
        int n = fluidStack.getAmount();
        if (n > 0 && fluidAction.execute()) {
            this.internalBuffer.lock.lock();
            try {
                this.internalBuffer.storage.addTo(AEFluidKey.of(fluidStack.getFluid(), fluidStack.getTag()), n);
            }
            finally {
                this.internalBuffer.lock.unlock();
                this.onContentsChanged.run();
            }
        }
        return n;
    }

    public boolean supportsFill(int n) {
        return false;
    }

    public boolean supportsDrain(int n) {
        return false;
    }
}

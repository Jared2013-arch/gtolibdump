package com.gtolib.api.machine.trait;

import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gtolib.api.capability.IIWirelessInteractor;
import com.gtolib.api.machine.multiblock.DrillingControlCenterMachine;
import com.gtolib.utils.GTOUtils;
import java.util.Map;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

public interface IFluidDrillLogic
extends IIWirelessInteractor<DrillingControlCenterMachine> {
    public MetaMachine getMachine();

    @Override
    default public Level getLevel() {
        return this.getMachine().getLevel();
    }

    @Override
    default public Map<ResourceLocation, Set<DrillingControlCenterMachine>> getMachineNet() {
        return DrillingControlCenterMachine.NETWORK;
    }

    @Override
    default public boolean firstTestMachine(DrillingControlCenterMachine drillingControlCenterMachine) {
        Level level = drillingControlCenterMachine.getLevel();
        if (level == null) {
            return false;
        }
        return drillingControlCenterMachine.isFormed() && drillingControlCenterMachine.getRecipeLogic().isWorking() && GTOUtils.calculateDistance(drillingControlCenterMachine.getPos(), this.getMachine().getPos()) < 16.0;
    }

    @Override
    default public boolean testMachine(DrillingControlCenterMachine drillingControlCenterMachine) {
        return drillingControlCenterMachine.isFormed() && drillingControlCenterMachine.getRecipeLogic().isWorking();
    }
}

package com.gtolib.api.machine.trait;

import com.gregtechceu.gtceu.api.capability.IEnergyContainer;
import com.gregtechceu.gtceu.api.capability.recipe.EURecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.TickableSubscription;
import com.gregtechceu.gtceu.api.machine.feature.ITieredMachine;
import com.gregtechceu.gtceu.api.machine.trait.NotifiableRecipeHandlerTrait;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gtolib.api.capability.IExtendWirelessEnergyContainerHolder;
import com.gtolib.api.wireless.ExtendTransferData;
import com.gtolib.api.wireless.ExtendWirelessEnergyContainer;
import com.hepdd.gtmthings.api.misc.BasicTransferData;
import com.hepdd.gtmthings.api.misc.WirelessEnergyContainer;
import com.lowdragmc.lowdraglib.syncdata.annotation.Persisted;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedFieldHolder;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public final class WirelessEnergyContainerTrait
extends NotifiableRecipeHandlerTrait<Long>
implements IEnergyContainer,
IExtendWirelessEnergyContainerHolder {
    private static final ManagedFieldHolder MANAGED_FIELD_HOLDER = new ManagedFieldHolder(WirelessEnergyContainerTrait.class, NotifiableRecipeHandlerTrait.MANAGED_FIELD_HOLDER);
    private ExtendWirelessEnergyContainer WirelessEnergyContainerCache;
    private int tier;
    @Persisted
    private long energyStored;
    private final long energyCapacity;
    private final long inputVoltage;
    private final long inputAmperage;
    private final long outputVoltage;
    private final long outputAmperage;
    private final IO handlerIO;
    @Nullable
    private TickableSubscription updateSubs;

    private WirelessEnergyContainerTrait(MetaMachine metaMachine, long l, long l2, long l3, long l4, long l5) {
        super(metaMachine);
        this.energyCapacity = l;
        this.inputVoltage = l2;
        this.inputAmperage = l3;
        this.outputVoltage = l4;
        this.outputAmperage = l5;
        this.handlerIO = l2 > 0L ? IO.IN : IO.OUT;
    }

    public static WirelessEnergyContainerTrait emitterContainer(MetaMachine metaMachine, long l, long l2, long l3) {
        return new WirelessEnergyContainerTrait(metaMachine, l, 0L, 0L, l2, l3);
    }

    public static WirelessEnergyContainerTrait receiverContainer(MetaMachine metaMachine, long l, long l2, long l3) {
        return new WirelessEnergyContainerTrait(metaMachine, l, l2, l3, 0L, 0L);
    }

    public ManagedFieldHolder getFieldHolder() {
        return MANAGED_FIELD_HOLDER;
    }

    @Override
    public void onMachineLoad() {
        super.onMachineLoad();
        if (!this.machine.isRemote()) {
            this.updateSubs = this.getMachine().subscribeServerTick(this.updateSubs, this::updateTick);
        }
    }

    @Override
    public void onMachineUnLoad() {
        super.onMachineUnLoad();
        if (this.updateSubs != null) {
            this.updateSubs.unsubscribe();
            this.updateSubs = null;
        }
    }

    public List<Long> handleRecipeInner(IO iO, GTRecipe gTRecipe, List<Long> list, boolean bl) {
        throw new UnsupportedOperationException("Not supported yet");
    }

    @Override
    public long changeEnergy(long l) {
        long l2;
        if (l == 0L) {
            return 0L;
        }
        if (this.WirelessEnergyContainerCache == null && this.getWirelessEnergyContainer() == null) {
            return 0L;
        }
        if (l > 0L) {
            l2 = Math.min(l, Math.min(this.energyCapacity - this.energyStored, this.WirelessEnergyContainerCache.getRate()));
            if (l2 > 0L && WirelessEnergyContainer.observed && this.getMachine() != null) {
                long l3 = l2 / 1000L * (long)this.WirelessEnergyContainerCache.getLoss();
                WirelessEnergyContainer.TRANSFER_DATA.put(this.getMachine(), new ExtendTransferData(this.WirelessEnergyContainerCache.getUuid(), l2 - l3, l3, this.getMachine()));
            }
        } else {
            l2 = Math.min(-l, Math.min(this.energyStored, this.WirelessEnergyContainerCache.getRate()));
            if ((l2 = -l2) < 0L && WirelessEnergyContainer.observed && this.getMachine() != null) {
                WirelessEnergyContainer.TRANSFER_DATA.put(this.getMachine(), new BasicTransferData(this.WirelessEnergyContainerCache.getUuid(), l2, this.getMachine()));
            }
        }
        this.energyStored += l2;
        return l2;
    }

    private void updateTick() {
        if (this.getMachine().getOffsetTimer() % 20L == 0L) {
            Level level = this.machine.getLevel();
            ExtendWirelessEnergyContainer extendWirelessEnergyContainer = this.getWirelessEnergyContainer();
            if (extendWirelessEnergyContainer != null && level != null) {
                long l;
                if (this.tier < ((ITieredMachine)((Object)this.machine)).getTier()) {
                    this.tier = extendWirelessEnergyContainer.getDimension().getInt((Object)level.m_46472_().m_135782_());
                    return;
                }
                if (this.handlerIO == IO.IN) {
                    long l2;
                    long l3 = this.energyCapacity - this.energyStored;
                    if (l3 > 0L && (l2 = extendWirelessEnergyContainer.unrestrictedRemoveEnergy(l3)) > 0L) {
                        this.energyStored += l2;
                        this.notifyListeners();
                    }
                } else if (this.energyStored > 0L && (l = extendWirelessEnergyContainer.unrestrictedAddEnergy(this.energyStored)) > 0L) {
                    this.energyStored -= l;
                    this.notifyListeners();
                }
            }
        }
    }

    public long acceptEnergyFromNetwork(Object object, Direction direction, long l, long l2) {
        return 0L;
    }

    public boolean inputsEnergy(Direction direction) {
        return false;
    }

    @Override
    @Nullable
    public UUID getUUID() {
        return this.getMachine().getOwnerUUID();
    }

    public double getTotalContentAmount() {
        return this.energyStored;
    }

    public RecipeCapability<Long> getCapability() {
        return EURecipeCapability.CAP;
    }

    @Override
    public void setWirelessEnergyContainerCache(WirelessEnergyContainer wirelessEnergyContainer) {
        this.WirelessEnergyContainerCache = (ExtendWirelessEnergyContainer)wirelessEnergyContainer;
    }

    @Override
    public WirelessEnergyContainer getWirelessEnergyContainerCache() {
        return this.WirelessEnergyContainerCache;
    }

    @Override
    public long getEnergyStored() {
        return this.energyStored;
    }

    @Override
    public long getEnergyCapacity() {
        return this.energyCapacity;
    }

    public long getInputVoltage() {
        return this.inputVoltage;
    }

    public long getInputAmperage() {
        return this.inputAmperage;
    }

    public long getOutputVoltage() {
        return this.outputVoltage;
    }

    public long getOutputAmperage() {
        return this.outputAmperage;
    }

    public IO getHandlerIO() {
        return this.handlerIO;
    }
}

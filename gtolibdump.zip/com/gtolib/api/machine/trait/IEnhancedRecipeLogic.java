package com.gtolib.api.machine.trait;

import com.gregtechceu.gtceu.api.machine.trait.RecipeHandlerList;
import com.gregtechceu.gtceu.api.machine.trait.RecipeLogic;
import com.gtolib.api.recipe.AsyncRecipeOutputTask;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.RecipeBuilder;
import com.gtolib.api.recipe.modifier.ParallelCache;
import java.util.Map;
import net.minecraft.network.chat.Component;

public interface IEnhancedRecipeLogic {
    public static IEnhancedRecipeLogic of(RecipeLogic recipeLogic) {
        return (IEnhancedRecipeLogic)((Object)recipeLogic);
    }

    default public RecipeLogic getLogic() {
        return (RecipeLogic)((Object)this);
    }

    default public RecipeBuilder gtolib$getRecipeBuilder() {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public Map<Recipe, RecipeHandlerList> gtolib$getRecipeCache() {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public ParallelCache gtolib$getParallelCache() {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public AsyncRecipeOutputTask gtolib$getAsyncRecipeOutputTask() {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public void gtolib$setAsyncRecipeOutputTask(AsyncRecipeOutputTask asyncRecipeOutputTask) {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public void gtolib$setIdleReason(Component component) {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public Component gtolib$getIdleReason() {
        throw new UnsupportedOperationException("Not implemented");
    }
}

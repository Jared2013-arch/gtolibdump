package com.gtolib.api.machine.trait;

import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.trait.NotifiableEnergyContainer;
import net.minecraft.core.Direction;

public class NotifiableSafeEnergyContainer
extends NotifiableEnergyContainer {
    public NotifiableSafeEnergyContainer(MetaMachine metaMachine, long l, long l2, long l3) {
        super(metaMachine, l, l2, l3, 0L, 0L);
    }

    public long acceptEnergyFromNetwork(Object object, Direction direction, long l, long l2) {
        if (direction == null || this.inputsEnergy(direction)) {
            long l3 = this.getInputVoltage();
            long l4 = this.getEnergyStored();
            l2 = Math.min(this.getEnergyCapacity() - l4, Math.min(l2, l3 * this.getInputAmperage()));
            if (l2 > 0L) {
                this.setEnergyStored(l4 + l2);
                return l2;
            }
        }
        return 0L;
    }
}

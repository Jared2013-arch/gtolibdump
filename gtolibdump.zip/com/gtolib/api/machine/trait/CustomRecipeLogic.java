package com.gtolib.api.machine.trait;

import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.machine.feature.IRecipeLogicMachine;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiPart;
import com.gregtechceu.gtceu.api.machine.multiblock.MultiblockControllerMachine;
import com.gregtechceu.gtceu.api.machine.trait.RecipeLogic;
import com.gtolib.api.machine.trait.IEnhancedRecipeLogic;
import com.gtolib.api.recipe.IdleReason;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.RecipeRunner;
import java.util.function.Supplier;

public class CustomRecipeLogic
extends RecipeLogic
implements IEnhancedRecipeLogic {
    private final Supplier<Recipe> recipeSupplier;
    private final boolean tryLast;

    public CustomRecipeLogic(IRecipeLogicMachine iRecipeLogicMachine, Supplier<Recipe> supplier) {
        this(iRecipeLogicMachine, supplier, false);
    }

    public CustomRecipeLogic(IRecipeLogicMachine iRecipeLogicMachine, Supplier<Recipe> supplier, boolean bl) {
        super(iRecipeLogicMachine);
        this.recipeSupplier = supplier;
        this.tryLast = bl;
    }

    public void findAndHandleRecipe() {
        Recipe recipe;
        this.gtolib$setIdleReason(IdleReason.NO_MATCH.reason());
        this.lastRecipe = null;
        if (this.machine.hasCapabilityProxies() && this.checkMaintain() && (recipe = this.recipeSupplier.get()) != null) {
            this.setupRecipe(recipe);
        }
    }

    public void onRecipeFinish() {
        this.machine.afterWorking();
        if (this.lastRecipe != null) {
            this.handleRecipeIO(this.lastRecipe, IO.OUT);
        }
        if (this.suspendAfterFinish) {
            this.setStatus(RecipeLogic.Status.SUSPEND);
            this.suspendAfterFinish = false;
        } else {
            Recipe recipe;
            if (!this.recipeDirty && this.tryLast && this.checkMaintain() && RecipeRunner.check(this.machine, (Recipe)this.lastRecipe)) {
                this.setupRecipe(this.lastRecipe);
                return;
            }
            this.recipeDirty = false;
            if (this.checkMaintain() && (recipe = this.recipeSupplier.get()) != null) {
                this.setupRecipe(recipe);
                return;
            }
            this.setStatus(RecipeLogic.Status.IDLE);
        }
        this.progress = 0;
        this.duration = 0;
        this.isActive = false;
        if (!this.machine.keepSubscribing()) {
            this.unsubscribe();
        }
    }

    private boolean checkMaintain() {
        IRecipeLogicMachine iRecipeLogicMachine = this.machine;
        if (iRecipeLogicMachine instanceof MultiblockControllerMachine) {
            MultiblockControllerMachine multiblockControllerMachine = (MultiblockControllerMachine)((Object)iRecipeLogicMachine);
            for (IMultiPart iMultiPart : multiblockControllerMachine.getParts()) {
                if (iMultiPart.modifyRecipe(Recipe.EMPTY) != null) continue;
                return false;
            }
        }
        return true;
    }
}

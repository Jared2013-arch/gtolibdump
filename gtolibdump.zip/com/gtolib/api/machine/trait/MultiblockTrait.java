package com.gtolib.api.machine.trait;

import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiPart;
import com.gregtechceu.gtceu.api.machine.multiblock.MultiblockControllerMachine;
import com.gregtechceu.gtceu.api.machine.trait.MachineTrait;
import com.gtolib.api.machine.feature.multiblock.IMultiblockTraitHolder;
import com.gtolib.api.recipe.Recipe;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedFieldHolder;
import java.util.List;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.NotNull;

public abstract class MultiblockTrait
extends MachineTrait {
    protected static final ManagedFieldHolder MANAGED_FIELD_HOLDER = new ManagedFieldHolder(MultiblockTrait.class);

    protected MultiblockTrait(IMultiblockTraitHolder iMultiblockTraitHolder) {
        super(iMultiblockTraitHolder.self());
        iMultiblockTraitHolder.getMultiblockTraits().add(this);
    }

    public Recipe modifyRecipe(@NotNull Recipe recipe) {
        return recipe;
    }

    public boolean beforeWorking(@NotNull Recipe recipe) {
        return false;
    }

    public void afterWorking() {
    }

    public void customText(@NotNull List<Component> list) {
    }

    public void onPartScan(IMultiPart iMultiPart) {
    }

    public void onStructureFormed() {
    }

    public void onStructureInvalid() {
    }

    public MultiblockControllerMachine getMachine() {
        return (MultiblockControllerMachine)this.machine;
    }

    public ManagedFieldHolder getFieldHolder() {
        return MANAGED_FIELD_HOLDER;
    }
}

package com.gtolib.api.machine.trait;

import com.gregtechceu.gtceu.api.capability.recipe.FluidRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.trait.IRecipeHandlerTrait;
import com.gregtechceu.gtceu.api.machine.trait.NotifiableRecipeHandlerTrait;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.recipe.ingredient.FluidIngredient;
import com.lowdragmc.lowdraglib.syncdata.ISubscription;
import it.unimi.dsi.fastutil.objects.Object2LongOpenHashMap;
import java.util.List;
import net.minecraftforge.fluids.FluidStack;
import org.jetbrains.annotations.NotNull;

public class ProxyFluidRecipeHandler
extends NotifiableRecipeHandlerTrait<FluidIngredient> {
    protected IRecipeHandlerTrait<FluidIngredient> proxy = null;
    private ISubscription proxySub = null;

    public ProxyFluidRecipeHandler(MetaMachine metaMachine) {
        super(metaMachine);
    }

    public void setProxy(IRecipeHandlerTrait<FluidIngredient> iRecipeHandlerTrait) {
        this.proxy = iRecipeHandlerTrait;
        if (this.proxySub != null) {
            this.proxySub.unsubscribe();
            this.proxySub = null;
        }
        if (iRecipeHandlerTrait != null) {
            this.proxySub = iRecipeHandlerTrait.addChangedListener(this::notifyListeners);
        }
    }

    public List<FluidIngredient> handleRecipeInner(IO iO, GTRecipe gTRecipe, List<FluidIngredient> list, boolean bl) {
        if (this.proxy == null) {
            return list;
        }
        return this.proxy.handleRecipeInner(iO, gTRecipe, list, bl);
    }

    public int getSize() {
        if (this.proxy == null) {
            return 0;
        }
        return this.proxy.getSize();
    }

    @Override
    @NotNull
    public Object[] getContents() {
        if (this.proxy == null) {
            return super.getContents();
        }
        return this.proxy.getContents();
    }

    public double getTotalContentAmount() {
        if (this.proxy == null) {
            return 0.0;
        }
        return this.proxy.getTotalContentAmount();
    }

    public boolean shouldSearchContent() {
        if (this.proxy == null) {
            return false;
        }
        return this.proxy.shouldSearchContent();
    }

    public boolean skipParallelComputing() {
        if (this.proxy == null) {
            return true;
        }
        return this.proxy.skipParallelComputing();
    }

    public boolean isNotConsumable() {
        if (this.proxy == null) {
            return true;
        }
        return this.proxy.isNotConsumable();
    }

    public boolean isRecipeOnly() {
        if (this.proxy == null) {
            return true;
        }
        return this.proxy.isRecipeOnly();
    }

    public Object2LongOpenHashMap<FluidStack> getFluidMap() {
        if (this.proxy == null) {
            return null;
        }
        return this.proxy.getFluidMap();
    }

    public int getPriority() {
        if (this.proxy == null) {
            return -1073741824;
        }
        return this.proxy.getPriority();
    }

    public boolean isDistinct() {
        return true;
    }

    public RecipeCapability<FluidIngredient> getCapability() {
        return FluidRecipeCapability.CAP;
    }

    public IO getHandlerIO() {
        return IO.IN;
    }
}

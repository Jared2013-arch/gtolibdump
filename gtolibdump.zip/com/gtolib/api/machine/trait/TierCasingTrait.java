package com.gtolib.api.machine.trait;

import com.gregtechceu.gtceu.api.machine.feature.IRecipeLogicMachine;
import com.gregtechceu.gtceu.utils.collection.O2IOpenCacheHashMap;
import com.gtolib.api.machine.feature.multiblock.IMultiblockTraitHolder;
import com.gtolib.api.machine.feature.multiblock.ITierCasingMachine;
import com.gtolib.api.machine.trait.IEnhancedRecipeLogic;
import com.gtolib.api.machine.trait.MultiblockTrait;
import com.gtolib.api.recipe.IdleReason;
import com.gtolib.api.recipe.Recipe;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.List;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.NotNull;

public class TierCasingTrait
extends MultiblockTrait {
    private final Object2IntOpenHashMap<String> casingTiers = new O2IOpenCacheHashMap(2);

    public TierCasingTrait(ITierCasingMachine iTierCasingMachine, String ... stringArray) {
        super((IMultiblockTraitHolder)((Object)iTierCasingMachine));
        for (String string : stringArray) {
            this.casingTiers.put((Object)string, 0);
        }
    }

    @Override
    public void onStructureFormed() {
        this.casingTiers.replaceAll((string, n) -> (Integer)this.getMachine().getMultiblockState().getMatchContext().getOrDefault(string, 0));
    }

    @Override
    public void onStructureInvalid() {
        this.casingTiers.replaceAll((string, n) -> 0);
    }

    @Override
    public boolean beforeWorking(@NotNull Recipe recipe) {
        ObjectIterator objectIterator = this.casingTiers.object2IntEntrySet().fastIterator();
        while (objectIterator.hasNext()) {
            IRecipeLogicMachine iRecipeLogicMachine;
            Object2IntMap.Entry entry = (Object2IntMap.Entry)objectIterator.next();
            String string = (String)entry.getKey();
            if (recipe.data.m_128451_(string) <= entry.getIntValue()) continue;
            Object object = this.getMachine();
            if (object instanceof IRecipeLogicMachine && (object = (iRecipeLogicMachine = (IRecipeLogicMachine)object).getRecipeLogic()) instanceof IEnhancedRecipeLogic) {
                IEnhancedRecipeLogic iEnhancedRecipeLogic = (IEnhancedRecipeLogic)object;
                iEnhancedRecipeLogic.gtolib$setIdleReason(IdleReason.BLOCK_TIER_NOT_SATISFIES.reason());
            }
            return true;
        }
        return false;
    }

    @Override
    public void customText(@NotNull List<Component> list) {
        this.casingTiers.object2IntEntrySet().fastForEach(entry -> list.add(Component.m_237110_(TierCasingTrait.getTierTranslationKey((String)entry.getKey()), new Object[]{entry.getIntValue()})));
    }

    public static String getTierTranslationKey(String string) {
        return "gtocore.tier." + string;
    }

    public Object2IntOpenHashMap<String> getCasingTiers() {
        return this.casingTiers;
    }
}

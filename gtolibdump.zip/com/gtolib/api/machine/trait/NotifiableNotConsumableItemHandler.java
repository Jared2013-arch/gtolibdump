package com.gtolib.api.machine.trait;

import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.trait.NotifiableItemStackHandler;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.transfer.item.CustomItemStackHandler;
import com.gtolib.api.recipe.ingredient.FastSizedIngredient;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Collection;
import java.util.List;
import java.util.ListIterator;
import java.util.function.IntFunction;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import org.jetbrains.annotations.NotNull;

public class NotifiableNotConsumableItemHandler
extends NotifiableItemStackHandler {
    NotifiableNotConsumableItemHandler(MetaMachine metaMachine, int n, @NotNull IO iO, IntFunction<CustomItemStackHandler> intFunction) {
        super(metaMachine, n, IO.IN, iO, intFunction);
    }

    public NotifiableNotConsumableItemHandler(MetaMachine metaMachine, int n, @NotNull IO iO) {
        this(metaMachine, n, iO, CustomItemStackHandler::new);
    }

    public boolean skipParallelComputing() {
        return true;
    }

    @Override
    public boolean isEmpty() {
        return this.getItemMap() == null;
    }

    public boolean isNotConsumable() {
        return true;
    }

    public boolean isRecipeOnly() {
        return true;
    }

    @Override
    public void exportToNearby(Direction ... directionArray) {
    }

    public void importFromNearby(Direction ... directionArray) {
    }

    public List<Ingredient> handleRecipe(IO iO, GTRecipe gTRecipe, List<?> list, boolean bl) {
        return this.handleRecipeInner(iO, gTRecipe, list, bl);
    }

    public List<Ingredient> handleRecipeInner(IO iO, GTRecipe gTRecipe, List<Ingredient> objectArrayList, boolean bl) {
        if (bl && iO == IO.IN && !this.isEmpty()) {
            objectArrayList = new ObjectArrayList((Collection)objectArrayList);
            ListIterator listIterator = objectArrayList.listIterator(0);
            block0: while (listIterator.hasNext()) {
                long l;
                Ingredient ingredient = (Ingredient)listIterator.next();
                if (ingredient.m_43947_()) {
                    listIterator.remove();
                    continue;
                }
                if (ingredient instanceof FastSizedIngredient) {
                    FastSizedIngredient fastSizedIngredient = (FastSizedIngredient)ingredient;
                    l = fastSizedIngredient.getAmount();
                } else {
                    l = 1L;
                }
                int n = this.storage.getSlots();
                for (int i = 0; i < n; ++i) {
                    ItemStack itemStack = this.storage.getStackInSlot(i);
                    int n2 = itemStack.m_41613_();
                    if (n2 == 0) continue;
                    if (ingredient.test(itemStack)) {
                        l -= (long)n2;
                    }
                    if (l >= 1L) continue;
                    listIterator.remove();
                    continue block0;
                }
            }
        }
        return objectArrayList.isEmpty() ? null : objectArrayList;
    }
}

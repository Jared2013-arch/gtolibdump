package com.gtolib.api.machine.trait;

import appeng.api.stacks.AEItemKey;
import com.gregtechceu.gtceu.api.transfer.item.CustomItemStackHandler;
import com.gregtechceu.gtceu.integration.ae2.utils.KeyStorage;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;

final class InaccessibleInfiniteHandler$ItemStackHandlerDelegate
extends CustomItemStackHandler {
    private final KeyStorage internalBuffer;

    private InaccessibleInfiniteHandler$ItemStackHandlerDelegate(KeyStorage keyStorage) {
        this.internalBuffer = keyStorage;
    }

    @Override
    public int getSlots() {
        return Short.MAX_VALUE;
    }

    public int getSlotLimit(int n) {
        return Integer.MAX_VALUE;
    }

    @Override
    @NotNull
    public ItemStack getStackInSlot(int n) {
        return ItemStack.f_41583_;
    }

    @Override
    public void setStackInSlot(int n, @NotNull ItemStack itemStack) {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @NotNull
    public ItemStack insertItem(int n, @NotNull ItemStack itemStack, boolean bl) {
        int n2 = itemStack.m_41613_();
        if (n2 > 0 && !bl) {
            this.internalBuffer.lock.lock();
            try {
                this.internalBuffer.storage.addTo(AEItemKey.of(itemStack), n2);
            }
            finally {
                this.internalBuffer.lock.unlock();
                this.onContentsChanged.run();
            }
        }
        return ItemStack.f_41583_;
    }
}

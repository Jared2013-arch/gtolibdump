package com.gtolib.api.machine.trait;

import appeng.api.networking.IGrid;
import appeng.api.stacks.AEItemKey;
import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.TickableSubscription;
import com.gregtechceu.gtceu.api.machine.trait.NotifiableItemStackHandler;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.transfer.item.CustomItemStackHandler;
import com.gregtechceu.gtceu.integration.ae2.utils.KeyStorage;
import com.gtocore.common.machine.multiblock.part.ae.MEPartMachine;
import com.gtolib.utils.ItemUtils;
import com.lowdragmc.lowdraglib.syncdata.ISubscription;
import java.util.List;
import net.minecraft.server.TickTask;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;

public final class InaccessibleInfiniteHandler
extends NotifiableItemStackHandler {
    private final ItemStackHandlerDelegate delegate;
    private TickableSubscription updateSubs;
    private final MEPartMachine machine;

    public InaccessibleInfiniteHandler(MetaMachine metaMachine, KeyStorage keyStorage) {
        super(metaMachine, 1, IO.OUT, IO.NONE, n -> new ItemStackHandlerDelegate(keyStorage));
        this.machine = (MEPartMachine)((Object)metaMachine);
        this.delegate = (ItemStackHandlerDelegate)this.storage;
        this.delegate.setOnContentsChangedAndfreeze(this::updateAutoOutputSubscription);
    }

    public void updateAutoOutputSubscription() {
        if (!this.delegate.internalBuffer.storage.isEmpty() && this.machine.isWorkingEnabled() && this.machine.isOnline()) {
            this.updateSubs = this.getMachine().subscribeServerTick(this.updateSubs, this::updateTick);
        } else if (this.updateSubs != null) {
            this.updateSubs.unsubscribe();
            this.updateSubs = null;
        }
    }

    @Override
    public ISubscription addChangedListener(Runnable runnable) {
        return () -> {};
    }

    @Override
    public void onMachineLoad() {
        super.onMachineLoad();
        Level level = this.machine.getLevel();
        if (level instanceof ServerLevel) {
            ServerLevel serverLevel = (ServerLevel)level;
            serverLevel.m_7654_().m_6937_(new TickTask(0, this::updateAutoOutputSubscription));
        }
    }

    @Override
    public void onMachineUnLoad() {
        super.onMachineUnLoad();
        if (this.updateSubs != null) {
            this.updateSubs.unsubscribe();
            this.updateSubs = null;
        }
    }

    private void updateTick() {
        IGrid iGrid;
        if (this.machine.getOffsetTimer() % 40L != 0L) {
            return;
        }
        if (this.machine.isWorkingEnabled() && !this.delegate.internalBuffer.isEmpty() && this.machine.updateMEStatus() && (iGrid = this.machine.getMainNode().getGrid()) != null && this.delegate.internalBuffer.lock.tryLock()) {
            try {
                this.delegate.internalBuffer.insertInventory(iGrid.getStorageService().getInventory(), this.machine.getActionSource());
            }
            finally {
                this.delegate.internalBuffer.lock.unlock();
            }
        }
        this.updateAutoOutputSubscription();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void insertInternal(ItemStack itemStack, long l) {
        if (l < 1L || itemStack.m_41619_()) {
            return;
        }
        this.delegate.internalBuffer.lock.lock();
        try {
            this.delegate.internalBuffer.storage.addTo(AEItemKey.of(itemStack), l);
        }
        finally {
            this.delegate.internalBuffer.lock.unlock();
            this.updateAutoOutputSubscription();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public List<Ingredient> handleRecipeInner(IO iO, GTRecipe gTRecipe, List<Ingredient> list, boolean bl) {
        if (iO == IO.OUT) {
            if (bl) {
                return null;
            }
            this.delegate.internalBuffer.lock.lock();
            try {
                for (Ingredient ingredient : list) {
                    long l;
                    if (ingredient.m_43947_() || (l = ItemUtils.getSizedAmount(ingredient)) <= 0L) continue;
                    this.delegate.internalBuffer.storage.addTo(AEItemKey.of(ItemUtils.getFirstSized(ingredient)), l);
                }
            }
            finally {
                this.delegate.internalBuffer.lock.unlock();
                this.updateAutoOutputSubscription();
            }
            return null;
        }
        return list;
    }

    public List<Ingredient> handleRecipe(IO iO, GTRecipe gTRecipe, List<?> list, boolean bl) {
        return this.handleRecipeInner(iO, gTRecipe, list, bl);
    }

    public double getTotalContentAmount() {
        return 0.0;
    }

    @Override
    public boolean isEmpty() {
        return true;
    }

    @NotNull
    public ItemStack extractItem(int n, int n2, boolean bl) {
        return ItemStack.f_41583_;
    }

    private static final class ItemStackHandlerDelegate
    extends CustomItemStackHandler {
        private final KeyStorage internalBuffer;

        private ItemStackHandlerDelegate(KeyStorage keyStorage) {
            this.internalBuffer = keyStorage;
        }

        @Override
        public int getSlots() {
            return Short.MAX_VALUE;
        }

        public int getSlotLimit(int n) {
            return Integer.MAX_VALUE;
        }

        @Override
        @NotNull
        public ItemStack getStackInSlot(int n) {
            return ItemStack.f_41583_;
        }

        @Override
        public void setStackInSlot(int n, @NotNull ItemStack itemStack) {
        }

        /*
         * WARNING - Removed try catching itself - possible behaviour change.
         */
        @NotNull
        public ItemStack insertItem(int n, @NotNull ItemStack itemStack, boolean bl) {
            int n2 = itemStack.m_41613_();
            if (n2 > 0 && !bl) {
                this.internalBuffer.lock.lock();
                try {
                    this.internalBuffer.storage.addTo(AEItemKey.of(itemStack), n2);
                }
                finally {
                    this.internalBuffer.lock.unlock();
                    this.onContentsChanged.run();
                }
            }
            return ItemStack.f_41583_;
        }
    }
}

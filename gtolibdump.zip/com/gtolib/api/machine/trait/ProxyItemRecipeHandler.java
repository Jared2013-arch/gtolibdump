package com.gtolib.api.machine.trait;

import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.capability.recipe.ItemRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.trait.IRecipeHandlerTrait;
import com.gregtechceu.gtceu.api.machine.trait.NotifiableRecipeHandlerTrait;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.lowdragmc.lowdraglib.syncdata.ISubscription;
import it.unimi.dsi.fastutil.objects.Object2LongOpenCustomHashMap;
import java.util.List;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import org.jetbrains.annotations.NotNull;

public class ProxyItemRecipeHandler
extends NotifiableRecipeHandlerTrait<Ingredient> {
    protected IRecipeHandlerTrait<Ingredient> proxy = null;
    private ISubscription proxySub = null;

    public ProxyItemRecipeHandler(MetaMachine metaMachine) {
        super(metaMachine);
    }

    public void setProxy(IRecipeHandlerTrait<Ingredient> iRecipeHandlerTrait) {
        this.proxy = iRecipeHandlerTrait;
        if (this.proxySub != null) {
            this.proxySub.unsubscribe();
            this.proxySub = null;
        }
        if (iRecipeHandlerTrait != null) {
            this.proxySub = iRecipeHandlerTrait.addChangedListener(this::notifyListeners);
        }
    }

    public List<Ingredient> handleRecipeInner(IO iO, GTRecipe gTRecipe, List<Ingredient> list, boolean bl) {
        if (this.proxy == null) {
            return list;
        }
        return this.proxy.handleRecipeInner(iO, gTRecipe, list, bl);
    }

    public int getSize() {
        if (this.proxy == null) {
            return 0;
        }
        return this.proxy.getSize();
    }

    @Override
    @NotNull
    public Object[] getContents() {
        if (this.proxy == null) {
            return super.getContents();
        }
        return this.proxy.getContents();
    }

    public double getTotalContentAmount() {
        if (this.proxy == null) {
            return 0.0;
        }
        return this.proxy.getTotalContentAmount();
    }

    public boolean shouldSearchContent() {
        if (this.proxy == null) {
            return false;
        }
        return this.proxy.shouldSearchContent();
    }

    public boolean skipParallelComputing() {
        if (this.proxy == null) {
            return true;
        }
        return this.proxy.skipParallelComputing();
    }

    public boolean isNotConsumable() {
        if (this.proxy == null) {
            return true;
        }
        return this.proxy.isNotConsumable();
    }

    public boolean isRecipeOnly() {
        if (this.proxy == null) {
            return true;
        }
        return this.proxy.isRecipeOnly();
    }

    public Object2LongOpenCustomHashMap<ItemStack> getItemMap() {
        if (this.proxy == null) {
            return null;
        }
        return this.proxy.getItemMap();
    }

    public int getPriority() {
        if (this.proxy == null) {
            return -1073741824;
        }
        return this.proxy.getPriority();
    }

    public boolean isDistinct() {
        return true;
    }

    public RecipeCapability<Ingredient> getCapability() {
        return ItemRecipeCapability.CAP;
    }

    public IO getHandlerIO() {
        return IO.IN;
    }
}

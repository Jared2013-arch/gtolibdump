package com.gtolib.api.machine.multiblock;

import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.gui.fancy.ConfiguratorPanel;
import com.gregtechceu.gtceu.api.gui.fancy.IFancyConfigurator;
import com.gtolib.api.gui.ParallelConfigurator;
import com.gtolib.api.machine.feature.multiblock.IParallelMachine;
import com.gtolib.api.machine.multiblock.NoEnergyMultiblockMachine;
import com.gtolib.api.machine.trait.CustomParallelTrait;
import com.lowdragmc.lowdraglib.syncdata.annotation.Persisted;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedFieldHolder;
import java.util.function.Function;
import java.util.function.ToLongFunction;
import org.jetbrains.annotations.NotNull;

public class NoEnergyCustomParallelMultiblockMachine
extends NoEnergyMultiblockMachine
implements IParallelMachine {
    protected static final ManagedFieldHolder MANAGED_FIELD_HOLDER = new ManagedFieldHolder(NoEnergyCustomParallelMultiblockMachine.class, NoEnergyMultiblockMachine.MANAGED_FIELD_HOLDER);
    @Persisted
    private final CustomParallelTrait customParallelTrait;

    public static Function<MetaMachineBlockEntity, NoEnergyCustomParallelMultiblockMachine> createParallel(ToLongFunction<NoEnergyCustomParallelMultiblockMachine> toLongFunction, boolean bl) {
        return metaMachineBlockEntity -> new NoEnergyCustomParallelMultiblockMachine((MetaMachineBlockEntity)metaMachineBlockEntity, bl, toLongFunction);
    }

    @Override
    @NotNull
    public ManagedFieldHolder getFieldHolder() {
        return MANAGED_FIELD_HOLDER;
    }

    protected NoEnergyCustomParallelMultiblockMachine(MetaMachineBlockEntity metaMachineBlockEntity, boolean bl, @NotNull ToLongFunction<NoEnergyCustomParallelMultiblockMachine> toLongFunction) {
        super(metaMachineBlockEntity);
        this.customParallelTrait = new CustomParallelTrait(this, bl, iParallelMachine -> toLongFunction.applyAsLong((NoEnergyCustomParallelMultiblockMachine)iParallelMachine));
    }

    @Override
    public void attachConfigurators(@NotNull ConfiguratorPanel configuratorPanel) {
        super.attachConfigurators(configuratorPanel);
        configuratorPanel.attachConfigurators(new IFancyConfigurator[]{new ParallelConfigurator(this)});
    }

    @Override
    public long getMaxParallel() {
        return this.customParallelTrait.getMaxParallel();
    }

    @Override
    public long getParallelLong() {
        return this.customParallelTrait.getParallel();
    }

    @Override
    public void setParallel(long l) {
        this.customParallelTrait.setParallel(l);
    }
}

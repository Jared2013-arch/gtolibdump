package com.gtolib.api.machine.multiblock;

import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.capability.IControllable;
import com.gregtechceu.gtceu.api.gui.GuiTextures;
import com.gregtechceu.gtceu.api.gui.fancy.ConfiguratorPanel;
import com.gregtechceu.gtceu.api.gui.fancy.FancyMachineUIWidget;
import com.gregtechceu.gtceu.api.gui.fancy.IFancyConfigurator;
import com.gregtechceu.gtceu.api.gui.fancy.IFancyConfiguratorButton;
import com.gregtechceu.gtceu.api.gui.fancy.IFancyUIProvider;
import com.gregtechceu.gtceu.api.gui.fancy.TooltipsPanel;
import com.gregtechceu.gtceu.api.machine.feature.IFancyUIMachine;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IDisplayUIMachine;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiPart;
import com.gregtechceu.gtceu.api.machine.multiblock.MultiblockControllerMachine;
import com.gtolib.api.machine.feature.multiblock.ICheckPatternMachine;
import com.gtolib.api.machine.feature.multiblock.IMultiblockTraitHolder;
import com.gtolib.api.machine.trait.MultiblockTrait;
import com.lowdragmc.lowdraglib.gui.modular.ModularUI;
import com.lowdragmc.lowdraglib.gui.texture.IGuiTexture;
import com.lowdragmc.lowdraglib.gui.util.ClickData;
import com.lowdragmc.lowdraglib.gui.widget.ComponentPanelWidget;
import com.lowdragmc.lowdraglib.gui.widget.DraggableScrollableWidgetGroup;
import com.lowdragmc.lowdraglib.gui.widget.LabelWidget;
import com.lowdragmc.lowdraglib.gui.widget.Widget;
import com.lowdragmc.lowdraglib.gui.widget.WidgetGroup;
import com.lowdragmc.lowdraglib.syncdata.annotation.Persisted;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedFieldHolder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.lang.invoke.LambdaMetafactory;
import java.util.List;
import java.util.Objects;
import java.util.function.BiConsumer;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.NotNull;

public class NoRecipeLogicMultiblockMachine
extends MultiblockControllerMachine
implements IControllable,
IFancyUIMachine,
IDisplayUIMachine,
IMultiblockTraitHolder {
    protected static final ManagedFieldHolder MANAGED_FIELD_HOLDER = new ManagedFieldHolder(NoRecipeLogicMultiblockMachine.class, MultiblockControllerMachine.MANAGED_FIELD_HOLDER);
    private final List<MultiblockTrait> multiblockTraits = new ObjectArrayList();
    @Persisted
    private boolean enabled = true;

    public NoRecipeLogicMultiblockMachine(MetaMachineBlockEntity metaMachineBlockEntity) {
        super(metaMachineBlockEntity);
    }

    @NotNull
    public ManagedFieldHolder getFieldHolder() {
        return MANAGED_FIELD_HOLDER;
    }

    public boolean hasCheckButton() {
        return true;
    }

    @Override
    public void onStructureFormed() {
        super.onStructureFormed();
        this.getParts().forEach(iMultiPart -> this.multiblockTraits.forEach(multiblockTrait -> multiblockTrait.onPartScan((IMultiPart)iMultiPart)));
        this.multiblockTraits.forEach(MultiblockTrait::onStructureFormed);
    }

    @Override
    public void onStructureInvalid() {
        super.onStructureInvalid();
        this.multiblockTraits.forEach(MultiblockTrait::onStructureInvalid);
    }

    public void addDisplayText(List<Component> list) {
        if (this.isRemote()) {
            return;
        }
        if (this.isFormed()) {
            this.customText((List)list);
        } else {
            MutableComponent mutableComponent = Component.m_237115_("gtceu.multiblock.invalid_structure").m_130940_(ChatFormatting.RED);
            MutableComponent mutableComponent2 = Component.m_237115_("gtceu.multiblock.invalid_structure.tooltip").m_130940_(ChatFormatting.GRAY);
            list.add(mutableComponent.m_130938_(style -> style.m_131144_(new HoverEvent(HoverEvent.Action.f_130831_, mutableComponent2))));
        }
        IDisplayUIMachine.super.addDisplayText(list);
    }

    public void attachConfigurators(ConfiguratorPanel configuratorPanel) {
        configuratorPanel.attachConfigurators(new IFancyConfigurator[]{new IFancyConfiguratorButton.Toggle(GuiTextures.BUTTON_POWER.getSubTexture(0.0, 0.0, 1.0, 0.5), GuiTextures.BUTTON_POWER.getSubTexture(0.0, 0.5, 1.0, 0.5), this::isWorkingEnabled, (clickData, bl) -> this.setWorkingEnabled((boolean)bl)).setTooltipsSupplier(bl -> List.of((Object)Component.m_237115_(bl != false ? "behaviour.soft_hammer.enabled" : "behaviour.soft_hammer.disabled")))});
        ICheckPatternMachine.attachConfigurators(configuratorPanel, this);
    }

    public Widget createUIWidget() {
        WidgetGroup widgetGroup = new WidgetGroup(0, 0, 190, 125);
        widgetGroup.addWidget(new DraggableScrollableWidgetGroup(4, 4, 182, 117).setBackground(this.getScreenTexture()).addWidget(new LabelWidget(4, 5, this.self().getBlockState().m_60734_().m_7705_())).addWidget(new ComponentPanelWidget(4, 17, this::addDisplayText).textSupplier(Objects.requireNonNull(this.getLevel()).f_46443_ ? null : this::addDisplayText).setMaxWidthLimit(200).clickHandler((BiConsumer<String, ClickData>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;Ljava/lang/Object;)V, handleDisplayClick(java.lang.String com.lowdragmc.lowdraglib.gui.util.ClickData ), (Ljava/lang/String;Lcom/lowdragmc/lowdraglib/gui/util/ClickData;)V)((NoRecipeLogicMultiblockMachine)this))));
        widgetGroup.setBackground(new IGuiTexture[]{GuiTextures.BACKGROUND_INVERSE});
        return widgetGroup;
    }

    public ModularUI createUI(Player player) {
        return new ModularUI(198, 208, this, player).widget(new FancyMachineUIWidget(this, 198, 208));
    }

    public List<IFancyUIProvider> getSubTabs() {
        return this.getParts().stream().filter(Objects::nonNull).map(IFancyUIProvider.class::cast).toList();
    }

    public void attachTooltips(TooltipsPanel tooltipsPanel) {
        for (IMultiPart iMultiPart : this.getParts()) {
            iMultiPart.attachFancyTooltipsToController(this, tooltipsPanel);
        }
    }

    public boolean isWorkingEnabled() {
        return this.enabled;
    }

    public void setWorkingEnabled(boolean bl) {
        this.enabled = bl;
    }

    @Override
    public List<MultiblockTrait> getMultiblockTraits() {
        return this.multiblockTraits;
    }

    public boolean isEnabled() {
        return this.enabled;
    }
}

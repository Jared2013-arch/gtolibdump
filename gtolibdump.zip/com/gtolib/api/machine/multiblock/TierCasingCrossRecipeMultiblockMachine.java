package com.gtolib.api.machine.multiblock;

import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gtolib.api.machine.feature.multiblock.ITierCasingMachine;
import com.gtolib.api.machine.multiblock.CrossRecipeMultiblockMachine;
import com.gtolib.api.machine.trait.TierCasingTrait;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import java.util.function.Function;
import java.util.function.ToLongFunction;
import org.jetbrains.annotations.NotNull;

public final class TierCasingCrossRecipeMultiblockMachine
extends CrossRecipeMultiblockMachine
implements ITierCasingMachine {
    private final TierCasingTrait tierCasingTrait;

    public static Function<MetaMachineBlockEntity, TierCasingCrossRecipeMultiblockMachine> createParallel(ToLongFunction<TierCasingCrossRecipeMultiblockMachine> toLongFunction, String ... stringArray) {
        return metaMachineBlockEntity -> new TierCasingCrossRecipeMultiblockMachine((MetaMachineBlockEntity)metaMachineBlockEntity, toLongFunction, stringArray);
    }

    private TierCasingCrossRecipeMultiblockMachine(MetaMachineBlockEntity metaMachineBlockEntity, @NotNull ToLongFunction<TierCasingCrossRecipeMultiblockMachine> toLongFunction, String ... stringArray) {
        super(metaMachineBlockEntity, false, false, (CrossRecipeMultiblockMachine crossRecipeMultiblockMachine) -> toLongFunction.applyAsLong((TierCasingCrossRecipeMultiblockMachine)crossRecipeMultiblockMachine));
        this.tierCasingTrait = new TierCasingTrait(this, stringArray);
    }

    @Override
    public Object2IntMap<String> getCasingTiers() {
        return this.tierCasingTrait.getCasingTiers();
    }
}

package com.gtolib.api.machine.multiblock;

import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.gui.GuiTextures;
import com.gregtechceu.gtceu.api.gui.fancy.ConfiguratorPanel;
import com.gregtechceu.gtceu.api.gui.fancy.FancyMachineUIWidget;
import com.gregtechceu.gtceu.api.gui.fancy.IFancyConfigurator;
import com.gregtechceu.gtceu.api.gui.fancy.IFancyConfiguratorButton;
import com.gregtechceu.gtceu.api.gui.fancy.IFancyUIProvider;
import com.gregtechceu.gtceu.api.gui.fancy.TooltipsPanel;
import com.gregtechceu.gtceu.api.machine.feature.IFancyUIMachine;
import com.gregtechceu.gtceu.api.machine.feature.IVoidable;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IDisplayUIMachine;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiPart;
import com.gregtechceu.gtceu.api.machine.multiblock.WorkableMultiblockMachine;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gtolib.api.machine.feature.multiblock.ICheckPatternMachine;
import com.gtolib.api.machine.feature.multiblock.IEnhancedMultiblockMachine;
import com.gtolib.api.machine.trait.MultiblockTrait;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.RecipeType;
import com.gtolib.utils.MachineUtils;
import com.lowdragmc.lowdraglib.gui.modular.ModularUI;
import com.lowdragmc.lowdraglib.gui.texture.IGuiTexture;
import com.lowdragmc.lowdraglib.gui.util.ClickData;
import com.lowdragmc.lowdraglib.gui.widget.ComponentPanelWidget;
import com.lowdragmc.lowdraglib.gui.widget.DraggableScrollableWidgetGroup;
import com.lowdragmc.lowdraglib.gui.widget.LabelWidget;
import com.lowdragmc.lowdraglib.gui.widget.Widget;
import com.lowdragmc.lowdraglib.gui.widget.WidgetGroup;
import com.lowdragmc.lowdraglib.syncdata.annotation.Persisted;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedFieldHolder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.lang.invoke.LambdaMetafactory;
import java.util.List;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.MustBeInvokedByOverriders;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
public class NoEnergyMultiblockMachine
extends WorkableMultiblockMachine
implements IFancyUIMachine,
IDisplayUIMachine,
IEnhancedMultiblockMachine {
    protected static final ManagedFieldHolder MANAGED_FIELD_HOLDER = new ManagedFieldHolder(NoEnergyMultiblockMachine.class, WorkableMultiblockMachine.MANAGED_FIELD_HOLDER);
    private final List<MultiblockTrait> multiblockTraits = new ObjectArrayList();
    @Persisted
    protected IVoidable.VoidingMode voidingMode = IVoidable.VoidingMode.VOID_NONE;

    public NoEnergyMultiblockMachine(MetaMachineBlockEntity metaMachineBlockEntity) {
        super(metaMachineBlockEntity, new Object[0]);
    }

    @NotNull
    public ManagedFieldHolder getFieldHolder() {
        return MANAGED_FIELD_HOLDER;
    }

    @Override
    @NotNull
    public RecipeType getRecipeType() {
        return (RecipeType)super.getRecipeType();
    }

    public boolean hasCheckButton() {
        return true;
    }

    @Nullable
    protected Recipe getRealRecipe(Recipe recipe) {
        return (Recipe)this.getDefinition().getRecipeModifier().applyModifier(this.self(), recipe);
    }

    @Nullable
    protected final GTRecipe getRealRecipe(@NotNull GTRecipe gTRecipe) {
        return this.getRealRecipe((Recipe)gTRecipe);
    }

    @Nullable
    private Recipe fullModifyRecipe(@NotNull Recipe recipe) {
        for (MultiblockTrait multiblockTrait : this.multiblockTraits) {
            recipe = multiblockTrait.modifyRecipe(recipe);
            if (recipe != null) continue;
            return null;
        }
        return (Recipe)this.doModifyRecipe(recipe);
    }

    @Nullable
    public final GTRecipe fullModifyRecipe(@NotNull GTRecipe gTRecipe) {
        return this.fullModifyRecipe((Recipe)gTRecipe);
    }

    protected boolean beforeWorking(@Nullable Recipe recipe) {
        if (recipe == null) {
            return true;
        }
        for (MultiblockTrait multiblockTrait : this.multiblockTraits) {
            if (!multiblockTrait.beforeWorking(recipe)) continue;
            return false;
        }
        return super.beforeWorking(recipe);
    }

    @Override
    public final boolean beforeWorking(@Nullable GTRecipe gTRecipe) {
        return this.beforeWorking((Recipe)gTRecipe);
    }

    @Override
    public void afterWorking() {
        this.multiblockTraits.forEach(MultiblockTrait::afterWorking);
        super.afterWorking();
    }

    @Override
    @MustBeInvokedByOverriders
    public void onPartScan(@NotNull IMultiPart iMultiPart) {
        this.multiblockTraits.forEach(multiblockTrait -> multiblockTrait.onPartScan(iMultiPart));
    }

    @Override
    @MustBeInvokedByOverriders
    public void onStructureFormed() {
        super.onStructureFormed();
        this.multiblockTraits.forEach(MultiblockTrait::onStructureFormed);
    }

    @Override
    @MustBeInvokedByOverriders
    public void onStructureInvalid() {
        super.onStructureInvalid();
        this.multiblockTraits.forEach(MultiblockTrait::onStructureInvalid);
    }

    public void addDisplayText(List<Component> list) {
        MachineUtils.addMachineText(list, this, this::customText);
        IDisplayUIMachine.super.addDisplayText(list);
    }

    @Override
    public void customText(@NotNull List<Component> list) {
        list.add(Component.m_237115_("gtceu.gui.multiblock_no_voiding.0").m_130946_(": ").m_7220_(ComponentPanelWidget.withButton(Component.m_237115_(this.voidingMode.ordinal() == 0 ? "gtceu.gui.multiblock_no_voiding.1" : this.voidingMode.m_7912_()), "voidingMode")));
        IEnhancedMultiblockMachine.super.customText(list);
    }

    public void handleDisplayClick(String string, ClickData clickData) {
        if (!clickData.isRemote && string.equals("voidingMode")) {
            this.voidingMode = this.voidingMode.ordinal() + 1 < IVoidable.VoidingMode.VALUES.length ? IVoidable.VoidingMode.VALUES[this.voidingMode.ordinal() + 1] : IVoidable.VoidingMode.VALUES[0];
        }
    }

    public void attachConfigurators(ConfiguratorPanel configuratorPanel) {
        configuratorPanel.attachConfigurators(new IFancyConfigurator[]{new IFancyConfiguratorButton.Toggle(GuiTextures.BUTTON_POWER.getSubTexture(0.0, 0.0, 1.0, 0.5), GuiTextures.BUTTON_POWER.getSubTexture(0.0, 0.5, 1.0, 0.5), (BooleanSupplier)LambdaMetafactory.metafactory(null, null, null, ()Z, isWorkingEnabled(), ()Z)((NoEnergyMultiblockMachine)this), (clickData, bl) -> this.setWorkingEnabled((boolean)bl)).setTooltipsSupplier(bl -> List.of((Object)Component.m_237115_(bl != false ? "behaviour.soft_hammer.enabled" : "behaviour.soft_hammer.disabled")))});
        ICheckPatternMachine.attachConfigurators(configuratorPanel, this);
        for (Direction direction : Direction.values()) {
            IFancyConfigurator iFancyConfigurator;
            if (!this.getCoverContainer().hasCover(direction) || (iFancyConfigurator = this.getCoverContainer().getCoverAtSide(direction).getConfigurator()) == null) continue;
            configuratorPanel.attachConfigurators(new IFancyConfigurator[]{iFancyConfigurator});
        }
    }

    public Widget createUIWidget() {
        WidgetGroup widgetGroup = new WidgetGroup(0, 0, 190, 125);
        widgetGroup.addWidget(new DraggableScrollableWidgetGroup(4, 4, 182, 117).setBackground(this.getScreenTexture()).addWidget(new LabelWidget(4, 5, this.self().getBlockState().m_60734_().m_7705_())).addWidget(new ComponentPanelWidget(4, 17, this::addDisplayText).textSupplier(Objects.requireNonNull(this.getLevel()).f_46443_ ? null : this::addDisplayText).setMaxWidthLimit(200).clickHandler(this::handleDisplayClick)));
        widgetGroup.setBackground(new IGuiTexture[]{GuiTextures.BACKGROUND_INVERSE});
        return widgetGroup;
    }

    public ModularUI createUI(Player player) {
        return new ModularUI(198, 208, this, player).widget(new FancyMachineUIWidget(this, 198, 208));
    }

    public List<IFancyUIProvider> getSubTabs() {
        return this.getParts().stream().filter(Objects::nonNull).map(IFancyUIProvider.class::cast).toList();
    }

    public void attachTooltips(TooltipsPanel tooltipsPanel) {
        for (IMultiPart iMultiPart : this.getParts()) {
            iMultiPart.attachFancyTooltipsToController(this, tooltipsPanel);
        }
    }

    @Override
    public List<MultiblockTrait> getMultiblockTraits() {
        return this.multiblockTraits;
    }

    public void setVoidingMode(IVoidable.VoidingMode voidingMode) {
        this.voidingMode = voidingMode;
    }

    public IVoidable.VoidingMode getVoidingMode() {
        return this.voidingMode;
    }
}

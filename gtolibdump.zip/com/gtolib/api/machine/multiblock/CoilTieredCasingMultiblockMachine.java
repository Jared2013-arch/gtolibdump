package com.gtolib.api.machine.multiblock;

import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gtolib.api.machine.feature.multiblock.ITierCasingMachine;
import com.gtolib.api.machine.multiblock.CoilCrossRecipeMultiblockMachine;
import com.gtolib.api.machine.trait.TierCasingTrait;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import java.util.function.Function;
import java.util.function.ToLongFunction;

public class CoilTieredCasingMultiblockMachine
extends CoilCrossRecipeMultiblockMachine
implements ITierCasingMachine {
    private final TierCasingTrait tierCasingTrait;

    public static Function<MetaMachineBlockEntity, CoilTieredCasingMultiblockMachine> createEBFParallel(ToLongFunction<CoilTieredCasingMultiblockMachine> toLongFunction, boolean bl, String ... stringArray) {
        return metaMachineBlockEntity -> new CoilTieredCasingMultiblockMachine((MetaMachineBlockEntity)metaMachineBlockEntity, false, false, true, bl, toLongFunction, stringArray);
    }

    protected CoilTieredCasingMultiblockMachine(MetaMachineBlockEntity metaMachineBlockEntity, boolean bl, boolean bl2, boolean bl3, boolean bl4, ToLongFunction<CoilTieredCasingMultiblockMachine> toLongFunction, String ... stringArray) {
        super(metaMachineBlockEntity, bl, bl2, bl3, bl4, coilCrossRecipeMultiblockMachine -> toLongFunction.applyAsLong((CoilTieredCasingMultiblockMachine)coilCrossRecipeMultiblockMachine));
        this.tierCasingTrait = new TierCasingTrait(this, stringArray);
    }

    @Override
    public Object2IntMap<String> getCasingTiers() {
        return this.tierCasingTrait.getCasingTiers();
    }
}

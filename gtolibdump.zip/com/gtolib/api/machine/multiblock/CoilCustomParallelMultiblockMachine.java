package com.gtolib.api.machine.multiblock;

import com.gregtechceu.gtceu.api.block.ICoilType;
import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.ICoilMachine;
import com.gtolib.api.machine.multiblock.CustomParallelMultiblockMachine;
import com.gtolib.api.machine.trait.CoilTrait;
import java.util.function.Function;
import java.util.function.ToLongFunction;

public class CoilCustomParallelMultiblockMachine
extends CustomParallelMultiblockMachine
implements ICoilMachine {
    private final CoilTrait coilTrait;

    public static Function<MetaMachineBlockEntity, CoilCustomParallelMultiblockMachine> createParallelCoil(ToLongFunction<CoilCustomParallelMultiblockMachine> toLongFunction, boolean bl, boolean bl2, boolean bl3) {
        return metaMachineBlockEntity -> new CoilCustomParallelMultiblockMachine((MetaMachineBlockEntity)metaMachineBlockEntity, bl, bl2, bl3, toLongFunction);
    }

    protected CoilCustomParallelMultiblockMachine(MetaMachineBlockEntity metaMachineBlockEntity, boolean bl, boolean bl2, boolean bl3, ToLongFunction<CoilCustomParallelMultiblockMachine> toLongFunction) {
        super(metaMachineBlockEntity, bl, customParallelMultiblockMachine -> toLongFunction.applyAsLong((CoilCustomParallelMultiblockMachine)customParallelMultiblockMachine));
        this.coilTrait = new CoilTrait(this, bl2, bl3);
    }

    public int getTemperature() {
        return this.coilTrait.getTemperature();
    }

    @Override
    public ICoilType getCoilType() {
        return this.coilTrait.getCoilType();
    }
}

package com.gtolib.api.machine.multiblock;

import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.machine.trait.RecipeLogic;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtolib.api.capability.IIWirelessInteractor;
import com.gtolib.api.machine.multiblock.ElectricMultiblockMachine;
import com.gtolib.api.machine.trait.CustomRecipeLogic;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.RecipeRunner;
import com.gtolib.utils.ClientUtil;
import com.lowdragmc.lowdraglib.gui.util.ClickData;
import com.lowdragmc.lowdraglib.gui.widget.ComponentPanelWidget;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class DrillingControlCenterMachine
extends ElectricMultiblockMachine {
    public static final Map<ResourceLocation, Set<DrillingControlCenterMachine>> NETWORK = new O2OOpenCacheHashMap();

    public DrillingControlCenterMachine(MetaMachineBlockEntity metaMachineBlockEntity) {
        super(metaMachineBlockEntity);
    }

    public double getMultiplier() {
        return Math.pow(1.5, this.getTier() - 5);
    }

    @Override
    public void onStructureFormed() {
        super.onStructureFormed();
        IIWirelessInteractor.addToNet(NETWORK, this);
    }

    @Override
    public void onStructureInvalid() {
        super.onStructureInvalid();
        IIWirelessInteractor.removeFromNet(NETWORK, this);
    }

    @Override
    public void onUnload() {
        super.onUnload();
        IIWirelessInteractor.removeFromNet(NETWORK, this);
    }

    @Override
    public void customText(@NotNull List<Component> list) {
        super.customText(list);
        list.add(ComponentPanelWidget.withButton(Component.m_237115_("gui.enderio.range.show"), "show"));
    }

    @Override
    public void handleDisplayClick(String string, ClickData clickData) {
        if (clickData.isRemote && "show".equals(string)) {
            ClientUtil.highlighting(this.getPos(), 16);
        }
    }

    @Nullable
    private Recipe getRecipe() {
        if (this.getTier() < 5) {
            return null;
        }
        Recipe recipe = this.getRecipeBuilder().duration(20).EUt(this.getOverclockVoltage()).buildRawRecipe();
        if (RecipeRunner.matchTickRecipe(this, recipe)) {
            return recipe;
        }
        return null;
    }

    @NotNull
    public RecipeLogic createRecipeLogic(Object ... objectArray) {
        return new CustomRecipeLogic(this, this::getRecipe, true);
    }
}

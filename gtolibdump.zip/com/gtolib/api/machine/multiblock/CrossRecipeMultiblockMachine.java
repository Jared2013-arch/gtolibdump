package com.gtolib.api.machine.multiblock;

import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.capability.recipe.FluidRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.ItemRecipeCapability;
import com.gregtechceu.gtceu.api.gui.fancy.ConfiguratorPanel;
import com.gregtechceu.gtceu.api.gui.fancy.IFancyConfigurator;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiPart;
import com.gregtechceu.gtceu.api.machine.trait.RecipeLogic;
import com.gregtechceu.gtceu.api.recipe.content.Content;
import com.gregtechceu.gtceu.api.recipe.content.ContentModifier;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCustomCacheHashMap;
import com.gtocore.common.machine.multiblock.part.OverclockHatchPartMachine;
import com.gtocore.common.machine.multiblock.part.ThreadHatchPartMachine;
import com.gtocore.common.machine.multiblock.part.WirelessEnergyInterfacePartMachine;
import com.gtocore.config.GTOConfig;
import com.gtolib.api.gui.ParallelConfigurator;
import com.gtolib.api.machine.feature.multiblock.IParallelMachine;
import com.gtolib.api.machine.multiblock.ElectricMultiblockMachine;
import com.gtolib.api.machine.trait.CustomParallelTrait;
import com.gtolib.api.machine.trait.CustomRecipeLogic;
import com.gtolib.api.recipe.ContentBuilder;
import com.gtolib.api.recipe.ContentList;
import com.gtolib.api.recipe.IdleReason;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.RecipeBuilder;
import com.gtolib.api.recipe.RecipeRunner;
import com.gtolib.api.recipe.RecipeType;
import com.gtolib.api.recipe.SeparateContent;
import com.gtolib.api.recipe.modifier.ParallelLogic;
import com.gtolib.api.wireless.ExtendWirelessEnergyContainer;
import com.gtolib.utils.MachineUtils;
import com.gtolib.utils.MathUtil;
import com.lowdragmc.lowdraglib.syncdata.annotation.Persisted;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedFieldHolder;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenCustomHashMap;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.function.ToLongFunction;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.MustBeInvokedByOverriders;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class CrossRecipeMultiblockMachine
extends ElectricMultiblockMachine
implements IParallelMachine {
    protected static final ManagedFieldHolder MANAGED_FIELD_HOLDER = new ManagedFieldHolder(CrossRecipeMultiblockMachine.class, ElectricMultiblockMachine.MANAGED_FIELD_HOLDER);
    private final Set<Recipe> lastRecipes = new ReferenceOpenHashSet();
    private int lastItems = 16;
    private int lastFluids = 16;
    private final Object2ObjectOpenCustomHashMap<Content, Content> itemMap = new O2OOpenCustomCacheHashMap(ContentBuilder.HASH_STRATEGY);
    private final Object2ObjectOpenCustomHashMap<Content, Content> fluidMap = new O2OOpenCustomCacheHashMap(ContentBuilder.HASH_STRATEGY);
    private long availableParallel;
    private long maxParallel;
    private long lastParallel;
    private ThreadHatchPartMachine threadHatchPartMachine;
    private OverclockHatchPartMachine overclockHatchPartMachine;
    private WirelessEnergyInterfacePartMachine energyInterfacePartMachine;
    @Persisted
    private double totalEu;
    @Persisted
    private final CustomParallelTrait customParallelTrait;
    private final boolean infinite;
    private final boolean isHatchParallel;

    public static CrossRecipeMultiblockMachine createHatchParallel(MetaMachineBlockEntity metaMachineBlockEntity) {
        return new CrossRecipeMultiblockMachine(metaMachineBlockEntity, false, true, MachineUtils::getHatchParallelLong);
    }

    public static Function<MetaMachineBlockEntity, CrossRecipeMultiblockMachine> createParallel(boolean bl, boolean bl2, ToLongFunction<CrossRecipeMultiblockMachine> toLongFunction) {
        return metaMachineBlockEntity -> new CrossRecipeMultiblockMachine((MetaMachineBlockEntity)metaMachineBlockEntity, bl, bl2, toLongFunction);
    }

    @NotNull
    public ManagedFieldHolder getFieldHolder() {
        return MANAGED_FIELD_HOLDER;
    }

    public Set<Recipe> getLastRecipes() {
        return this.lastRecipes;
    }

    protected CrossRecipeMultiblockMachine(MetaMachineBlockEntity metaMachineBlockEntity, boolean bl, boolean bl2, @NotNull ToLongFunction<CrossRecipeMultiblockMachine> toLongFunction) {
        super(metaMachineBlockEntity);
        this.infinite = bl;
        this.isHatchParallel = bl2;
        this.customParallelTrait = new CustomParallelTrait(this, false, iParallelMachine -> toLongFunction.applyAsLong((CrossRecipeMultiblockMachine)iParallelMachine));
    }

    public int getThread() {
        return this.infinite ? 128 : (this.threadHatchPartMachine == null ? 1 : this.threadHatchPartMachine.getCurrentThread());
    }

    private boolean isRepeatedRecipes() {
        if (this.threadHatchPartMachine == null) {
            return true;
        }
        return this.threadHatchPartMachine.isRepeatedRecipes();
    }

    @Override
    public void attachConfigurators(@NotNull ConfiguratorPanel configuratorPanel) {
        super.attachConfigurators(configuratorPanel);
        if (!this.isHatchParallel) {
            configuratorPanel.attachConfigurators(new IFancyConfigurator[]{new ParallelConfigurator(this)});
        }
    }

    private Recipe getRecipe() {
        Object object;
        Recipe recipe;
        this.totalEu = 0.0;
        this.lastRecipes.clear();
        if (this.getOverclockVoltage() < 1L) {
            return null;
        }
        boolean bl = this.energyInterfacePartMachine != null;
        ExtendWirelessEnergyContainer extendWirelessEnergyContainer = null;
        BigInteger bigInteger = null;
        double d = 0.0;
        if (bl) {
            extendWirelessEnergyContainer = this.energyInterfacePartMachine.getWirelessEnergyContainer();
            if (extendWirelessEnergyContainer == null) {
                return null;
            }
            bigInteger = extendWirelessEnergyContainer.getStorage();
            if (bigInteger.signum() < 1) {
                return null;
            }
            d = bigInteger.doubleValue();
        }
        double d2 = 0.0;
        int n = this.getThread();
        this.maxParallel = this.getParallelLong();
        this.availableParallel = this.maxParallel * (long)n;
        ContentList contentList = new ContentList(this.lastItems, this.itemMap);
        ContentList contentList2 = new ContentList(this.lastFluids, this.fluidMap);
        while (this.availableParallel > 0L && n > 0 && (recipe = this.LookupRecipe()) != null) {
            object = ContentModifier.multiplier(recipe.parallels);
            for (Map.Entry object2 : recipe.outputs.entrySet()) {
                int n2;
                if (object2.getKey() == ItemRecipeCapability.CAP) {
                    for (Content d4 : (List)object2.getValue()) {
                        if (d4.chance == ContentBuilder.maxChance) {
                            contentList.add(ItemRecipeCapability.CAP, d4, recipe.parallels < 2L);
                            continue;
                        }
                        n2 = Mth.m_14045_(d4.chance + recipe.ocLevel * d4.tierChanceBoost, 0, ContentBuilder.maxChance);
                        if (n2 == ContentBuilder.maxChance) {
                            contentList.add(new Content(ItemRecipeCapability.CAP.copyContent(d4.content, (ContentModifier)object), n2, n2, 0));
                            continue;
                        }
                        contentList.add(ItemRecipeCapability.CAP, new SeparateContent(d4.content, n2, 0, ContentBuilder.maxChance, recipe.parallels), recipe.parallels < 2L);
                    }
                    continue;
                }
                for (Content d4 : (List)object2.getValue()) {
                    if (d4.chance == ContentBuilder.maxChance) {
                        contentList2.add(FluidRecipeCapability.CAP, d4, recipe.parallels < 2L);
                        continue;
                    }
                    n2 = Mth.m_14045_(d4.chance + recipe.ocLevel * d4.tierChanceBoost, 0, ContentBuilder.maxChance);
                    if (n2 == ContentBuilder.maxChance) {
                        contentList2.add(new Content(FluidRecipeCapability.CAP.copyContent(d4.content, (ContentModifier)object), n2, n2, 0));
                        continue;
                    }
                    contentList2.add(FluidRecipeCapability.CAP, new SeparateContent(d4.content, n2, 0, ContentBuilder.maxChance, recipe.parallels), recipe.parallels < 2L);
                }
            }
            --n;
            this.availableParallel -= this.lastParallel;
            d2 += (double)recipe.parallels;
            double d3 = (double)recipe.duration * (double)recipe.getInputEUt();
            if (bl) {
                d3 *= (double)this.lastParallel;
            }
            this.totalEu += d3;
            if (!bl || !(this.totalEu > d)) continue;
            break;
        }
        recipe = null;
        if (!this.lastRecipes.isEmpty()) {
            object = this.getRecipeBuilder();
            int n3 = this.gtolib$getOCLimit();
            if (bl) {
                BigInteger l = BigDecimal.valueOf(this.totalEu).toBigInteger();
                if (bigInteger.compareTo(l) < 0) {
                    this.setIdleReason(IdleReason.NO_EU);
                    return null;
                }
                extendWirelessEnergyContainer.setStorage(bigInteger.subtract(l));
                ((RecipeBuilder)object).duration(n3);
            } else {
                long l = this.getOverclockVoltage();
                double d3 = this.totalEu / (double)l;
                ((RecipeBuilder)object).EUt(d3 >= (double)n3 ? l : (long)((double)l * d3 / (double)n3 + 0.5)).duration((int)Math.max(d3 + 0.5, (double)n3));
            }
            recipe = ((RecipeBuilder)object).buildRawRecipe();
            recipe.setParallels(MathUtil.saturatedCast(d2));
            recipe.outputs.put(ItemRecipeCapability.CAP, contentList);
            recipe.outputs.put(FluidRecipeCapability.CAP, contentList2);
            this.lastItems = Math.max(this.lastItems, contentList.size());
            this.lastFluids = Math.max(this.lastFluids, contentList2.size());
        }
        return recipe;
    }

    private Recipe LookupRecipe() {
        Iterator<Recipe> iterator = RecipeType.searchIterator(this.getRecipeType(), this, this::canHandle);
        while (iterator.hasNext()) {
            Recipe recipe = iterator.next();
            if (recipe == null) continue;
            this.lastParallel = 0L;
            Recipe recipe2 = this.fullModifyRecipe(recipe.copy());
            if (recipe2 == null || !RecipeRunner.handleRecipeInput(this, recipe2)) continue;
            this.lastRecipes.add(recipe);
            return recipe2;
        }
        return null;
    }

    private boolean canHandle(Recipe recipe) {
        return !this.lastRecipes.contains(recipe) && recipe.tier <= this.getOverclockTier() && RecipeRunner.fastMatchRecipe(this, recipe) && RecipeRunner.checkConditions(this, recipe);
    }

    @NotNull
    public RecipeLogic createRecipeLogic(Object ... objectArray) {
        return new CustomRecipeLogic(this, this::getRecipe);
    }

    @Override
    @MustBeInvokedByOverriders
    public Recipe getRealRecipe(@NotNull Recipe recipe) {
        long l = ParallelLogic.getMaxContentParallel(this, recipe);
        if (l == 0L) {
            return null;
        }
        recipe.contentParallel = l;
        double d = this.overclockHatchPartMachine == null ? 0.55 : this.overclockHatchPartMachine.getCurrentMultiplier();
        long l2 = this.getOverclockVoltage();
        if (d < 0.25) {
            CrossRecipeMultiblockMachine.overclocking(recipe, l2, (long)((double)recipe.eut * this.gtolib$getPowerAmplifier()), (double)recipe.duration / this.gtolib$getPowerAmplifier(), d, this.gtolib$getOCLimit());
            this.parallel(recipe, l2);
        } else {
            this.parallel(recipe, l2);
            CrossRecipeMultiblockMachine.overclocking(recipe, l2, (long)((double)recipe.eut * this.gtolib$getPowerAmplifier()), (double)recipe.duration / this.gtolib$getPowerAmplifier(), d, this.gtolib$getOCLimit());
        }
        long l3 = l / this.lastParallel;
        if (l3 > 1L) {
            long l4;
            long l5;
            long l6 = 1L;
            long l7 = recipe.eut;
            int n = 0;
            while ((l5 = l7 << 2) <= l2 && l5 >= 0L && (l4 = l6 << 1) <= l3) {
                l6 = l4;
                l7 = l5;
                ++n;
            }
            recipe.setEut(l7);
            recipe.ocLevel += n;
            boolean bl = this.isBatchEnabled();
            if (bl || l6 > 1L) {
                if (bl) {
                    if (l6 < l3) {
                        int n2 = Math.min(MathUtil.saturatedCast(l3 / l6), GTOConfig.INSTANCE.batchProcessingMaxDuration / recipe.duration);
                        recipe.duration *= n2;
                        l6 *= (long)n2;
                    }
                    recipe.batchParallels = MathUtil.saturatedCast(l6);
                }
                recipe.modifier(ContentModifier.multiplier(l6), false);
            }
        }
        return recipe;
    }

    private static void overclocking(Recipe recipe, long l, long l2, double d, double d2, int n) {
        double d3;
        long l3;
        int n2 = 0;
        while ((l3 = l2 << 2) <= l && l3 >= 0L && !((d3 = d * d2) < (double)n)) {
            d = d3;
            l2 = l3;
            ++n2;
        }
        recipe.setEut(l2);
        recipe.duration = (int)Math.ceil(d);
        recipe.ocLevel = n2;
    }

    private void parallel(Recipe recipe, long l) {
        long l2 = Math.min(recipe.contentParallel, this.isRepeatedRecipes() ? this.availableParallel : Math.min(this.availableParallel, this.maxParallel));
        if (l2 > 1L) {
            if (this.energyInterfacePartMachine == null && recipe.eut > 0L) {
                if ((l2 = Math.min(l2, l / recipe.eut)) > 1L) {
                    recipe.modifier(ContentModifier.multiplier(l2), true);
                }
            } else {
                recipe.modifier(ContentModifier.multiplier(l2), false);
            }
        }
        this.lastParallel = recipe.parallels;
    }

    @Override
    public final boolean beforeWorking(@Nullable Recipe recipe) {
        return true;
    }

    @Override
    public void onPartScan(@NotNull IMultiPart iMultiPart) {
        super.onPartScan(iMultiPart);
        if (this.threadHatchPartMachine == null && iMultiPart instanceof ThreadHatchPartMachine) {
            ThreadHatchPartMachine threadHatchPartMachine;
            this.threadHatchPartMachine = threadHatchPartMachine = (ThreadHatchPartMachine)((Object)iMultiPart);
        } else if (this.overclockHatchPartMachine == null && iMultiPart instanceof OverclockHatchPartMachine) {
            OverclockHatchPartMachine overclockHatchPartMachine;
            this.overclockHatchPartMachine = overclockHatchPartMachine = (OverclockHatchPartMachine)((Object)iMultiPart);
        } else if (this.energyInterfacePartMachine == null && iMultiPart instanceof WirelessEnergyInterfacePartMachine) {
            WirelessEnergyInterfacePartMachine wirelessEnergyInterfacePartMachine;
            this.energyInterfacePartMachine = wirelessEnergyInterfacePartMachine = (WirelessEnergyInterfacePartMachine)((Object)iMultiPart);
        }
    }

    @Override
    public void onStructureInvalid() {
        super.onStructureInvalid();
        this.threadHatchPartMachine = null;
        this.overclockHatchPartMachine = null;
    }

    @Override
    public long getMaxParallel() {
        return this.customParallelTrait.getMaxParallel();
    }

    @Override
    public long getParallelLong() {
        if (this.isHatchParallel) {
            return this.getMaxParallel();
        }
        return this.customParallelTrait.getParallel();
    }

    @Override
    public void setParallel(long l) {
        this.customParallelTrait.setParallel(l);
    }

    public WirelessEnergyInterfacePartMachine getEnergyInterfacePartMachine() {
        return this.energyInterfacePartMachine;
    }

    public double getTotalEu() {
        return this.totalEu;
    }
}

package com.gtolib.api.machine.multiblock;

import com.gregtechceu.gtceu.api.block.ICoilType;
import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.ICoilMachine;
import com.gtolib.api.machine.multiblock.ElectricMultiblockMachine;
import com.gtolib.api.machine.trait.CoilTrait;
import java.util.function.Function;

public class CoilMultiblockMachine
extends ElectricMultiblockMachine
implements ICoilMachine {
    private final CoilTrait coilTrait;

    public static Function<MetaMachineBlockEntity, CoilMultiblockMachine> createCoilMachine(boolean bl, boolean bl2) {
        return metaMachineBlockEntity -> new CoilMultiblockMachine((MetaMachineBlockEntity)metaMachineBlockEntity, bl, bl2);
    }

    protected CoilMultiblockMachine(MetaMachineBlockEntity metaMachineBlockEntity, boolean bl, boolean bl2) {
        super(metaMachineBlockEntity);
        this.coilTrait = new CoilTrait(this, bl, bl2);
    }

    public int getTemperature() {
        return this.coilTrait.getTemperature();
    }

    @Override
    public ICoilType getCoilType() {
        return this.coilTrait.getCoilType();
    }
}

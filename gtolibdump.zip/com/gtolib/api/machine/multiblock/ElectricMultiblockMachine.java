package com.gtolib.api.machine.multiblock;

import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiPart;
import com.gregtechceu.gtceu.api.machine.multiblock.WorkableElectricMultiblockMachine;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gtolib.api.machine.feature.IElectricMachine;
import com.gtolib.api.machine.feature.IOverclockConfigMachine;
import com.gtolib.api.machine.feature.IPowerAmplifierMachine;
import com.gtolib.api.machine.feature.IUpgradeMachine;
import com.gtolib.api.machine.feature.multiblock.IEnhancedMultiblockMachine;
import com.gtolib.api.machine.trait.MultiblockTrait;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.RecipeType;
import com.gtolib.utils.MachineUtils;
import com.lowdragmc.lowdraglib.gui.widget.ComponentPanelWidget;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.MustBeInvokedByOverriders;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ElectricMultiblockMachine
extends WorkableElectricMultiblockMachine
implements IElectricMachine,
IOverclockConfigMachine,
IPowerAmplifierMachine,
IUpgradeMachine,
IEnhancedMultiblockMachine {
    private final List<MultiblockTrait> multiblockTraits = new ObjectArrayList();

    public ElectricMultiblockMachine(MetaMachineBlockEntity metaMachineBlockEntity) {
        super(metaMachineBlockEntity, new Object[0]);
    }

    @Override
    @NotNull
    public RecipeType getRecipeType() {
        return (RecipeType)super.getRecipeType();
    }

    @Nullable
    protected Recipe getRealRecipe(Recipe recipe) {
        return (Recipe)this.getDefinition().getRecipeModifier().applyModifier(this.self(), recipe);
    }

    @Nullable
    protected final GTRecipe getRealRecipe(@NotNull GTRecipe gTRecipe) {
        return this.getRealRecipe((Recipe)gTRecipe);
    }

    @Nullable
    protected Recipe fullModifyRecipe(@NotNull Recipe recipe) {
        for (MultiblockTrait multiblockTrait : this.multiblockTraits) {
            recipe = multiblockTrait.modifyRecipe(recipe);
            if (recipe != null) continue;
            return null;
        }
        return (Recipe)this.doModifyRecipe(recipe);
    }

    @Nullable
    public final GTRecipe fullModifyRecipe(@NotNull GTRecipe gTRecipe) {
        return this.fullModifyRecipe((Recipe)gTRecipe);
    }

    protected boolean beforeWorking(@Nullable Recipe recipe) {
        if (recipe == null) {
            return true;
        }
        for (MultiblockTrait multiblockTrait : this.multiblockTraits) {
            if (!multiblockTrait.beforeWorking(recipe)) continue;
            return false;
        }
        return super.beforeWorking(recipe);
    }

    @Override
    public final boolean beforeWorking(@Nullable GTRecipe gTRecipe) {
        return this.beforeWorking((Recipe)gTRecipe);
    }

    @Override
    public void afterWorking() {
        this.multiblockTraits.forEach(MultiblockTrait::afterWorking);
        super.afterWorking();
    }

    @Override
    @MustBeInvokedByOverriders
    public void onPartScan(@NotNull IMultiPart iMultiPart) {
        this.multiblockTraits.forEach(multiblockTrait -> multiblockTrait.onPartScan(iMultiPart));
    }

    @Override
    @MustBeInvokedByOverriders
    public void onStructureFormed() {
        super.onStructureFormed();
        this.multiblockTraits.forEach(MultiblockTrait::onStructureFormed);
    }

    @Override
    @MustBeInvokedByOverriders
    public void onStructureInvalid() {
        super.onStructureInvalid();
        this.multiblockTraits.forEach(MultiblockTrait::onStructureInvalid);
    }

    public void addDisplayText(@NotNull List<Component> list) {
        MachineUtils.addMachineText(list, this, this::customText);
        for (IMultiPart iMultiPart : this.getParts()) {
            iMultiPart.addMultiText(list);
        }
    }

    @Override
    public void customText(@NotNull List<Component> list) {
        list.add(Component.m_237115_("gtceu.gui.multiblock_no_voiding.0").m_130946_(": ").m_7220_(ComponentPanelWidget.withButton(Component.m_237115_(this.getVoidingMode().ordinal() == 0 ? "gtceu.gui.multiblock_no_voiding.1" : this.getVoidingMode().m_7912_()), "voidingMode")));
        IEnhancedMultiblockMachine.super.customText(list);
    }

    @Override
    public boolean gtolib$canUpgraded() {
        return false;
    }

    @Override
    public List<MultiblockTrait> getMultiblockTraits() {
        return this.multiblockTraits;
    }
}

package com.gtolib.api.machine.multiblock;

import com.gregtechceu.gtceu.common.data.GTItems;
import java.util.Map;
import net.minecraft.world.item.Item;

class WirelessChargerMachine$Wrapper {
    private static final Map<Item, Integer> GENERATOR = Map.of((Object)((Item)GTItems.FIELD_GENERATOR_LV.get()), (Object)1, (Object)((Item)GTItems.FIELD_GENERATOR_MV.get()), (Object)2, (Object)((Item)GTItems.FIELD_GENERATOR_HV.get()), (Object)3, (Object)((Item)GTItems.FIELD_GENERATOR_EV.get()), (Object)4, (Object)((Item)GTItems.FIELD_GENERATOR_IV.get()), (Object)5, (Object)((Item)GTItems.FIELD_GENERATOR_LuV.get()), (Object)6, (Object)((Item)GTItems.FIELD_GENERATOR_ZPM.get()), (Object)7, (Object)((Item)GTItems.FIELD_GENERATOR_UV.get()), (Object)8);

    private WirelessChargerMachine$Wrapper() {
    }
}

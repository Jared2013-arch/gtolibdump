package com.gtolib.api.machine.multiblock;

import com.gregtechceu.gtceu.api.block.ICoilType;
import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.ICoilMachine;
import com.gtolib.api.machine.multiblock.CrossRecipeMultiblockMachine;
import com.gtolib.api.machine.trait.CoilTrait;
import com.gtolib.utils.MachineUtils;
import java.util.function.Function;
import java.util.function.ToLongFunction;
import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.MethodsReturnNonnullByDefault;

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
public class CoilCrossRecipeMultiblockMachine
extends CrossRecipeMultiblockMachine
implements ICoilMachine {
    private final CoilTrait coilTrait;

    public static CrossRecipeMultiblockMachine createCoilParallel(MetaMachineBlockEntity metaMachineBlockEntity) {
        return CoilCrossRecipeMultiblockMachine.createCoilParallel(metaMachineBlockEntity, false);
    }

    public static CrossRecipeMultiblockMachine createInfiniteCoilParallel(MetaMachineBlockEntity metaMachineBlockEntity) {
        return CoilCrossRecipeMultiblockMachine.createCoilParallel(metaMachineBlockEntity, true);
    }

    private static CrossRecipeMultiblockMachine createCoilParallel(MetaMachineBlockEntity metaMachineBlockEntity, boolean bl) {
        return new CoilCrossRecipeMultiblockMachine(metaMachineBlockEntity, bl, false, false, false, CoilCrossRecipeMultiblockMachine::temperatureParallel);
    }

    public static Function<MetaMachineBlockEntity, CrossRecipeMultiblockMachine> createHatchParallel(boolean bl) {
        return metaMachineBlockEntity -> new CoilCrossRecipeMultiblockMachine((MetaMachineBlockEntity)metaMachineBlockEntity, false, true, bl, true, MachineUtils::getHatchParallelLong);
    }

    public static Function<MetaMachineBlockEntity, CrossRecipeMultiblockMachine> createCoilParallelEBF() {
        return metaMachineBlockEntity -> new CoilCrossRecipeMultiblockMachine((MetaMachineBlockEntity)metaMachineBlockEntity, false, false, true, false, CoilCrossRecipeMultiblockMachine::temperatureParallel);
    }

    protected CoilCrossRecipeMultiblockMachine(MetaMachineBlockEntity metaMachineBlockEntity, boolean bl, boolean bl2, boolean bl3, boolean bl4, ToLongFunction<CoilCrossRecipeMultiblockMachine> toLongFunction) {
        super(metaMachineBlockEntity, bl, bl2, crossRecipeMultiblockMachine -> toLongFunction.applyAsLong((CoilCrossRecipeMultiblockMachine)crossRecipeMultiblockMachine));
        this.coilTrait = new CoilTrait(this, bl3, bl4);
    }

    public int getTemperature() {
        return this.coilTrait.getTemperature();
    }

    @Override
    public ICoilType getCoilType() {
        return this.coilTrait.getCoilType();
    }

    private long temperatureParallel() {
        return this.isFormed() ? 1L << Math.min(60, (int)((double)this.getTemperature() / 900.0)) : 0L;
    }
}

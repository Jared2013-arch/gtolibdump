package com.gtolib.api.machine;

import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.capability.recipe.FluidRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.capability.recipe.ItemRecipeCapability;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.feature.IRecipeLogicMachine;
import com.gregtechceu.gtceu.api.machine.trait.NotifiableFluidTank;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gregtechceu.gtceu.api.transfer.item.CustomItemStackHandler;
import com.gtocore.common.data.GTORecipeTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

public final class DummyMachine
extends MetaMachine {
    public String id = "";
    public int temp;
    public int manat;
    public long eut;
    public int duration;
    public int circuit;
    public final GTRecipeType recipeType;
    public final CustomItemStackHandler importItems;
    public final CustomItemStackHandler exportItems;
    public final NotifiableFluidTank importFluids;
    public final NotifiableFluidTank exportFluids;

    private DummyMachine(MetaMachineBlockEntity metaMachineBlockEntity, GTRecipeType gTRecipeType) {
        super(metaMachineBlockEntity);
        this.recipeType = gTRecipeType == GTORecipeTypes.CHEMICAL ? GTORecipeTypes.LARGE_CHEMICAL_RECIPES : gTRecipeType;
        this.importItems = this.createImportItemHandler();
        this.exportItems = this.createExportItemHandler();
        this.importFluids = this.createImportFluidHandler();
        this.exportFluids = this.createExportFluidHandler();
    }

    public void sett(String string) {
        this.temp = Integer.parseInt(string);
    }

    public void setMANAt(String string) {
        this.manat = Integer.parseInt(string);
    }

    public void setEUt(String string) {
        this.eut = Long.parseLong(string);
    }

    public void setDuration(String string) {
        this.duration = Integer.parseInt(string);
    }

    public void setCircuit(String string) {
        this.circuit = Integer.parseInt(string);
    }

    private CustomItemStackHandler createImportItemHandler() {
        return new CustomItemStackHandler(this.recipeType.getMaxInputs(ItemRecipeCapability.CAP));
    }

    private CustomItemStackHandler createExportItemHandler() {
        return new CustomItemStackHandler(this.recipeType.getMaxOutputs(ItemRecipeCapability.CAP));
    }

    private NotifiableFluidTank createImportFluidHandler() {
        return new NotifiableFluidTank((MetaMachine)this, this.recipeType.getMaxInputs(FluidRecipeCapability.CAP), Integer.MAX_VALUE, IO.BOTH);
    }

    private NotifiableFluidTank createExportFluidHandler() {
        return new NotifiableFluidTank((MetaMachine)this, this.recipeType.getMaxOutputs(FluidRecipeCapability.CAP), Integer.MAX_VALUE, IO.BOTH);
    }

    public static DummyMachine createDummyMachine(MetaMachine metaMachine) {
        return DummyMachine.createDummyMachine(metaMachine.holder.getBlockEntityType(), metaMachine.getPos(), metaMachine.getBlockState(), ((IRecipeLogicMachine)((Object)metaMachine)).getRecipeType());
    }

    public static DummyMachine createDummyMachine(BlockEntityType<?> blockEntityType, BlockPos blockPos, BlockState blockState, GTRecipeType gTRecipeType) {
        return new DummyMachine(MetaMachineBlockEntity.createBlockEntity(blockEntityType, blockPos, blockState), gTRecipeType);
    }

    public void setId(String string) {
        this.id = string;
    }
}

package com.gtolib.api.machine.part;

import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.gui.GuiTextures;
import com.gregtechceu.gtceu.api.gui.widget.SlotWidget;
import com.gregtechceu.gtceu.api.machine.feature.IMachineLife;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IWorkableMultiController;
import com.gregtechceu.gtceu.api.machine.multiblock.part.TieredIOPartMachine;
import com.gregtechceu.gtceu.api.machine.trait.NotifiableItemStackHandler;
import com.gregtechceu.gtceu.api.transfer.item.CustomItemStackHandler;
import com.gtolib.api.misc.Drone;
import com.gtolib.utils.GTOUtils;
import com.lowdragmc.lowdraglib.gui.texture.IGuiTexture;
import com.lowdragmc.lowdraglib.gui.widget.Widget;
import com.lowdragmc.lowdraglib.gui.widget.WidgetGroup;
import com.lowdragmc.lowdraglib.jei.IngredientIO;
import com.lowdragmc.lowdraglib.syncdata.annotation.Persisted;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedFieldHolder;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class DroneHatchPartMachine
extends TieredIOPartMachine
implements IMachineLife {
    private static final ManagedFieldHolder MANAGED_FIELD_HOLDER = new ManagedFieldHolder(DroneHatchPartMachine.class, TieredIOPartMachine.MANAGED_FIELD_HOLDER);
    @Persisted
    private final DroneItemStackHandler inventory;
    private final int size;

    public DroneHatchPartMachine(MetaMachineBlockEntity metaMachineBlockEntity, int n) {
        super(metaMachineBlockEntity, n, IO.IN);
        int n2 = n - 1;
        this.size = n2 * n2;
        NotifiableItemStackHandler notifiableItemStackHandler = new NotifiableItemStackHandler(this, this.size, IO.NONE, IO.BOTH, DroneItemStackHandler::new);
        this.inventory = (DroneItemStackHandler)notifiableItemStackHandler.storage;
    }

    @NotNull
    public ManagedFieldHolder getFieldHolder() {
        return MANAGED_FIELD_HOLDER;
    }

    public boolean onWorking(IWorkableMultiController iWorkableMultiController) {
        if (this.getOffsetTimer() % 20L == 0L) {
            for (int i = 0; i < this.inventory.getSlots(); ++i) {
                Drone drone = this.getDrone(i);
                if (drone == null) continue;
                drone.work();
            }
        }
        return true;
    }

    public boolean hasDrone(BlockPos blockPos, BlockPos blockPos2) {
        for (int i = 0; i < this.size; ++i) {
            Drone drone = this.getDrone(i);
            if (drone == null || !(GTOUtils.calculateDistance(blockPos, blockPos2) < (double)drone.getRange())) continue;
            return true;
        }
        return false;
    }

    @Nullable
    public Drone getFirstUsableDrone(BlockPos blockPos, BlockPos blockPos2) {
        for (int i = 0; i < this.size; ++i) {
            Drone drone = this.getDrone(i);
            if (drone == null || drone.isWork() || !(GTOUtils.calculateDistance(blockPos, blockPos2) < (double)drone.getRange())) continue;
            return drone;
        }
        return null;
    }

    @Nullable
    public Drone getDrone(int n) {
        return this.inventory.drones[n];
    }

    public void onMachineRemoved() {
        if (this.getLevel() == null) {
            return;
        }
        for (int i = 0; i < this.inventory.getSlots(); ++i) {
            Drone drone = this.getDrone(i);
            if (drone != null && drone.isWork()) {
                return;
            }
            ItemStack itemStack = this.inventory.getStackInSlot(i);
            if (itemStack.m_41619_()) continue;
            this.inventory.setStackInSlot(i, ItemStack.f_41583_);
            Block.m_49840_(this.getLevel(), this.getPos(), itemStack);
        }
        this.inventory.clean();
    }

    @Override
    public void onLoad() {
        super.onLoad();
        if (!this.isRemote()) {
            this.inventory.load();
        }
    }

    @Override
    public void onUnload() {
        super.onUnload();
        this.inventory.clean();
    }

    public Widget createUIWidget() {
        int n = (int)Math.sqrt(this.size);
        WidgetGroup widgetGroup = new WidgetGroup(0, 0, 18 * n + 16, 18 * n + 16);
        WidgetGroup widgetGroup2 = new WidgetGroup(4, 4, 18 * n + 8, 18 * n + 8);
        int n2 = 0;
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                widgetGroup2.addWidget(new SlotWidget(this.inventory, n2++, 4 + j * 18, 4 + i * 18, true, this.io.support(IO.IN)).setBackgroundTexture(GuiTextures.SLOT).setIngredientIO(this.io == IO.IN ? IngredientIO.INPUT : IngredientIO.OUTPUT));
            }
        }
        widgetGroup2.setBackground(new IGuiTexture[]{GuiTextures.BACKGROUND_INVERSE});
        widgetGroup.addWidget(widgetGroup2);
        return widgetGroup;
    }

    public boolean canShared() {
        return false;
    }

    public int getSize() {
        return this.size;
    }

    private static final class DroneItemStackHandler
    extends CustomItemStackHandler {
        private final Drone[] drones = new Drone[this.getSlots()];

        private DroneItemStackHandler(int n) {
            super(n);
        }

        private void load() {
            for (int i = 0; i < this.getSlots(); ++i) {
                Drone drone = Drone.create(this.getStackInSlot(i));
                if (drone == null) continue;
                this.drones[i] = drone;
            }
        }

        private void clean() {
            for (int i = 0; i < this.getSlots(); ++i) {
                this.drones[i] = null;
            }
        }

        @Override
        public void setStackInSlot(int n, @NotNull ItemStack itemStack) {
            Drone drone = this.drones[n];
            if (drone != null && drone.isWork()) {
                return;
            }
            this.drones[n] = null;
            Drone drone2 = Drone.create(itemStack);
            if (drone2 != null) {
                this.drones[n] = drone2;
                super.setStackInSlot(n, itemStack);
            }
        }

        @NotNull
        public ItemStack insertItem(int n, @NotNull ItemStack itemStack, boolean bl) {
            Drone drone = this.drones[n];
            if (drone != null && drone.isWork()) {
                return itemStack;
            }
            this.drones[n] = null;
            Drone drone2 = Drone.create(itemStack);
            if (drone2 != null) {
                if (!bl) {
                    this.drones[n] = drone2;
                    this.stacks[n] = itemStack;
                    this.onContentsChanged(n);
                }
                return ItemStack.f_41583_;
            }
            return itemStack;
        }

        @NotNull
        public ItemStack extractItem(int n, int n2, boolean bl) {
            Drone drone = this.drones[n];
            if (drone != null && drone.isWork()) {
                return ItemStack.f_41583_;
            }
            this.drones[n] = null;
            ItemStack itemStack = this.getStackInSlot(n);
            if (bl) {
                return itemStack.m_41777_();
            }
            this.stacks[n] = ItemStack.f_41583_;
            this.onContentsChanged(n);
            return itemStack;
        }
    }
}

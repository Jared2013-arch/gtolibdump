package com.gtolib.api.machine.part;

import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.gui.GuiTextures;
import com.gregtechceu.gtceu.api.gui.widget.SlotWidget;
import com.gregtechceu.gtceu.api.machine.feature.IMachineLife;
import com.gregtechceu.gtceu.api.machine.multiblock.part.MultiblockPartMachine;
import com.gregtechceu.gtceu.api.machine.trait.NotifiableItemStackHandler;
import com.gtolib.api.item.MachineItemStackHandler;
import com.lowdragmc.lowdraglib.gui.texture.IGuiTexture;
import com.lowdragmc.lowdraglib.gui.widget.Widget;
import com.lowdragmc.lowdraglib.gui.widget.WidgetGroup;
import com.lowdragmc.lowdraglib.syncdata.annotation.DescSynced;
import com.lowdragmc.lowdraglib.syncdata.annotation.Persisted;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedFieldHolder;
import java.util.function.Predicate;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.world.item.ItemStack;

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
public class ItemHatchPartMachine
extends MultiblockPartMachine
implements IMachineLife {
    protected static final ManagedFieldHolder MANAGED_FIELD_HOLDER = new ManagedFieldHolder(ItemHatchPartMachine.class, MultiblockPartMachine.MANAGED_FIELD_HOLDER);
    @DescSynced
    @Persisted
    protected NotifiableItemStackHandler inventory;
    private final int limit;

    public ItemHatchPartMachine(MetaMachineBlockEntity metaMachineBlockEntity, int n, @Nullable Predicate<ItemStack> predicate) {
        super(metaMachineBlockEntity);
        this.limit = n;
        this.inventory = this.createMachineStorage(predicate);
    }

    protected NotifiableItemStackHandler createMachineStorage(@Nullable Predicate<ItemStack> predicate) {
        NotifiableItemStackHandler notifiableItemStackHandler = new NotifiableItemStackHandler(this, 1, IO.NONE, IO.BOTH, n -> new MachineItemStackHandler(this::getSlotLimit));
        notifiableItemStackHandler.setFilter(itemStack -> {
            if (predicate != null && !predicate.test((ItemStack)itemStack)) {
                return false;
            }
            return this.storageFilter((ItemStack)itemStack);
        });
        notifiableItemStackHandler.addChangedListener(this::onMachineChanged);
        return notifiableItemStackHandler;
    }

    protected int getSlotLimit() {
        return this.limit;
    }

    protected boolean storageFilter(ItemStack itemStack) {
        return true;
    }

    protected void onMachineChanged() {
    }

    public ManagedFieldHolder getFieldHolder() {
        return MANAGED_FIELD_HOLDER;
    }

    public static Widget createSLOTWidget(NotifiableItemStackHandler notifiableItemStackHandler) {
        WidgetGroup widgetGroup = new WidgetGroup(0, 0, 34, 34);
        WidgetGroup widgetGroup2 = new WidgetGroup(4, 4, 26, 26);
        widgetGroup2.addWidget(new SlotWidget(notifiableItemStackHandler.storage, 0, 4, 4, true, true).setBackground(new IGuiTexture[]{GuiTextures.SLOT}));
        widgetGroup.addWidget(widgetGroup2);
        return widgetGroup;
    }

    public Widget createUIWidget() {
        return ItemHatchPartMachine.createSLOTWidget(this.getInventory());
    }

    public void onMachineRemoved() {
        this.clearInventory(this.getInventory().storage);
    }

    public boolean canShared() {
        return false;
    }

    public NotifiableItemStackHandler getInventory() {
        return this.inventory;
    }
}

package com.gtolib.api.machine.feature;

import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.feature.IMachineFeature;
import com.gregtechceu.gtceu.api.machine.feature.IRecipeLogicMachine;
import com.gregtechceu.gtceu.utils.GTUtil;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;

public interface IVacuumMachine
extends IMachineFeature {
    public int getVacuumTier();

    default public void update() {
        if (this.getVacuumTier() > 0) {
            Level level = this.self().getLevel();
            if (level == null) {
                return;
            }
            for (Direction direction : GTUtil.DIRECTIONS) {
                MetaMachine metaMachine;
                if (direction.m_122434_() == Direction.Axis.Y || !((metaMachine = this.self().getNeighborMachine(direction)) instanceof IRecipeLogicMachine)) continue;
                IRecipeLogicMachine iRecipeLogicMachine = (IRecipeLogicMachine)((Object)metaMachine);
                iRecipeLogicMachine.getRecipeLogic().updateTickSubscription();
            }
        }
    }
}

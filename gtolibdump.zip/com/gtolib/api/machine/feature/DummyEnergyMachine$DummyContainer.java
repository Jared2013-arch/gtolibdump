package com.gtolib.api.machine.feature;

import com.gregtechceu.gtceu.api.capability.IEnergyContainer;
import net.minecraft.core.Direction;

public class DummyEnergyMachine$DummyContainer
implements IEnergyContainer {
    private final long eut;

    public DummyEnergyMachine$DummyContainer(long l) {
        this.eut = l;
    }

    public long acceptEnergyFromNetwork(Object object, Direction direction, long l, long l2) {
        return 0L;
    }

    public boolean inputsEnergy(Direction direction) {
        return false;
    }

    @Override
    public long changeEnergy(long l) {
        return l;
    }

    @Override
    public long getEnergyStored() {
        return this.eut;
    }

    @Override
    public long getEnergyCapacity() {
        return this.eut;
    }

    public long getInputAmperage() {
        return 0L;
    }

    public long getInputVoltage() {
        return 0L;
    }
}

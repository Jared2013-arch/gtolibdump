package com.gtolib.api.machine.feature;

import com.gregtechceu.gtceu.api.machine.feature.IMachineFeature;
import com.gtolib.api.capability.IIWirelessInteractor;
import com.gtolib.api.machine.multiblock.DroneControlCenterMachine;
import com.gtolib.api.misc.Drone;
import java.util.Map;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public interface IDroneInteractionMachine
extends IMachineFeature,
IIWirelessInteractor<DroneControlCenterMachine> {
    @Override
    default public Map<ResourceLocation, Set<DroneControlCenterMachine>> getMachineNet() {
        return DroneControlCenterMachine.NETWORK;
    }

    @Override
    default public boolean firstTestMachine(DroneControlCenterMachine droneControlCenterMachine) {
        Level level = droneControlCenterMachine.getLevel();
        if (level == null) {
            return false;
        }
        return droneControlCenterMachine.isFormed() && droneControlCenterMachine.getRecipeLogic().isWorking() && droneControlCenterMachine.hasDrone(this.self().getPos());
    }

    @Override
    default public boolean testMachine(DroneControlCenterMachine droneControlCenterMachine) {
        return droneControlCenterMachine.isFormed() && droneControlCenterMachine.getRecipeLogic().isWorking();
    }

    @Nullable
    default public Drone getFirstUsableDrone() {
        DroneControlCenterMachine droneControlCenterMachine = (DroneControlCenterMachine)this.getNetMachine();
        if (droneControlCenterMachine != null) {
            return droneControlCenterMachine.getFirstUsableDrone(this.self().getPos());
        }
        return null;
    }
}

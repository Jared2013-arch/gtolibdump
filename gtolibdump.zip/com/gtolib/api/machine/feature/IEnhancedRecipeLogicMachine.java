package com.gtolib.api.machine.feature;

import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.capability.recipe.IRecipeCapabilityHolder;
import com.gregtechceu.gtceu.api.machine.feature.IRecipeLogicMachine;
import com.gregtechceu.gtceu.api.machine.trait.RecipeLogic;
import com.gtolib.GTOCore;
import com.gtolib.api.machine.trait.IEnhancedRecipeLogic;
import com.gtolib.api.recipe.IdleReason;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.RecipeBuilder;
import com.gtolib.api.recipe.RecipeRunner;
import com.gtolib.utils.MachineUtils;
import java.util.function.Predicate;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.fluids.FluidStack;
import org.jetbrains.annotations.Nullable;

public interface IEnhancedRecipeLogicMachine
extends IRecipeLogicMachine {
    default public IEnhancedRecipeLogic getEnhancedRecipeLogic() {
        return (IEnhancedRecipeLogic)((Object)this.getRecipeLogic());
    }

    default public RecipeBuilder getRecipeBuilder() {
        return ((IEnhancedRecipeLogic)((Object)this.getRecipeLogic())).gtolib$getRecipeBuilder();
    }

    default public boolean matchRecipe(Recipe recipe) {
        return RecipeRunner.matchRecipeInput(this, recipe) && RecipeRunner.matchRecipeOutput(this, recipe);
    }

    default public boolean matchTickRecipe(Recipe recipe) {
        return RecipeRunner.handleTickRecipe(this, recipe, true);
    }

    default public boolean handleRecipeIO(Recipe recipe, IO iO) {
        if (iO == IO.IN) {
            return RecipeRunner.handleRecipeInput(this, recipe, this.getRecipeLogic().getChanceCaches());
        }
        return RecipeRunner.handleRecipeOutput(this, recipe, this.getRecipeLogic().getChanceCaches());
    }

    default public boolean handleTickRecipe(@Nullable Recipe recipe) {
        return RecipeRunner.handleTickRecipe(this, recipe, false);
    }

    default public void regressRecipe(RecipeLogic recipeLogic) {
        if (GTOCore.isExpert()) {
            recipeLogic.interruptRecipe();
        } else if (((IRecipeLogicMachine)((Object)this.self())).regressWhenWaiting() && recipeLogic.getProgress() > 1) {
            recipeLogic.setProgress(1);
        }
    }

    default public void setIdleReason(IdleReason idleReason) {
        ((IEnhancedRecipeLogic)((Object)this.getRecipeLogic())).gtolib$setIdleReason(idleReason.reason());
    }

    default public int checkingCircuit(boolean bl) {
        return MachineUtils.checkingCircuit(this, bl);
    }

    default public long[] getItemAmount(Item ... itemArray) {
        return MachineUtils.getItemAmount(this, itemArray);
    }

    default public long[] getFluidAmount(Fluid ... fluidArray) {
        return MachineUtils.getFluidAmount(this, fluidArray);
    }

    default public void forEachInputItems(Predicate<ItemStack> predicate) {
        MachineUtils.forEachInputItems(this, predicate);
    }

    default public void forEachInputFluids(Predicate<FluidStack> predicate) {
        MachineUtils.forEachInputFluids(this, predicate);
    }

    default public boolean inputItem(ItemStack ... itemStackArray) {
        return MachineUtils.inputItem(this, itemStackArray);
    }

    default public boolean notConsumableItem(ItemStack ... itemStackArray) {
        return MachineUtils.notConsumableItem(this, itemStackArray);
    }

    default public boolean outputItem(ItemStack ... itemStackArray) {
        return MachineUtils.outputItem(this, itemStackArray);
    }

    default public boolean notConsumableCircuit(int n) {
        return MachineUtils.notConsumableCircuit(this, n);
    }

    default public boolean inputFluid(Fluid fluid, long l) {
        return MachineUtils.inputFluid((IRecipeCapabilityHolder)this, fluid, l);
    }

    default public boolean inputFluid(FluidStack ... fluidStackArray) {
        return MachineUtils.inputFluid((IRecipeCapabilityHolder)this, fluidStackArray);
    }

    default public boolean notConsumableFluid(FluidStack ... fluidStackArray) {
        return MachineUtils.notConsumableFluid(this, fluidStackArray);
    }

    default public boolean outputFluid(Fluid fluid, long l) {
        return MachineUtils.outputFluid((IRecipeCapabilityHolder)this, fluid, l);
    }

    default public boolean outputFluid(FluidStack ... fluidStackArray) {
        return MachineUtils.outputFluid((IRecipeCapabilityHolder)this, fluidStackArray);
    }
}

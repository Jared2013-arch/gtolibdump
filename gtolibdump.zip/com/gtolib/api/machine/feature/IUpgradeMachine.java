package com.gtolib.api.machine.feature;

public interface IUpgradeMachine {
    default public void gtolib$setSpeed(double d) {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public void gtolib$setEnergy(double d) {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public double gtolib$getSpeed() {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public double gtolib$getEnergy() {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public boolean gtolib$canUpgraded() {
        throw new UnsupportedOperationException("Not implemented");
    }
}

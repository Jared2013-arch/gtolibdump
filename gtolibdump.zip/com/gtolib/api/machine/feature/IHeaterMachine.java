package com.gtolib.api.machine.feature;

import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.feature.IRecipeLogicMachine;
import com.gregtechceu.gtceu.api.machine.feature.IRedstoneSignalMachine;
import com.gregtechceu.gtceu.utils.GTUtil;
import com.gtolib.api.machine.feature.ITemperatureMachine;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;

public interface IHeaterMachine
extends ITemperatureMachine {
    default public void tickUpdate() {
        Object object;
        IHeaterMachine iHeaterMachine = this;
        if (iHeaterMachine instanceof IRedstoneSignalMachine) {
            object = (IRedstoneSignalMachine)((Object)iHeaterMachine);
            object.updateSignal();
        }
        if ((iHeaterMachine = this) instanceof IRecipeLogicMachine && (object = (IRecipeLogicMachine)((Object)iHeaterMachine)).getRecipeLogic().isWorking()) {
            return;
        }
        this.reduceTemperature(1);
    }

    @Override
    default public int reduceTemperature(int n) {
        int n2 = Math.min(this.getTemperature() - 293, n);
        if (n2 <= 0) {
            this.setTemperature(293);
            return 0;
        }
        this.setTemperature(this.getTemperature() - n2);
        return n2;
    }

    @Override
    default public void raiseTemperature(int n) {
        int n2 = this.getTemperature() + n;
        if (n2 < this.getMaxTemperature()) {
            this.setTemperature(n2);
            Level level = this.self().getLevel();
            if (level == null) {
                return;
            }
            for (Direction direction : GTUtil.DIRECTIONS) {
                MetaMachine metaMachine = this.self().getNeighborMachine(direction);
                if (!(metaMachine instanceof IRecipeLogicMachine)) continue;
                IRecipeLogicMachine iRecipeLogicMachine = (IRecipeLogicMachine)((Object)metaMachine);
                iRecipeLogicMachine.getRecipeLogic().updateTickSubscription();
            }
        } else {
            this.doExplosion(5.0f);
        }
    }
}

package com.gtolib.api.machine.feature;

import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.common.machine.electric.AirScrubberMachine;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtolib.utils.GTOUtils;
import java.util.Map;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;

public interface IAirScrubberInteractor {
    public static final Map<ResourceLocation, Set<AirScrubberMachine>> NETWORK = new O2OOpenCacheHashMap();

    public AirScrubberMachine getAirScrubberMachineCache();

    public void setAirScrubberMachineCache(AirScrubberMachine var1);

    default public AirScrubberMachine getAirScrubberMachine() {
        Object object;
        Set<AirScrubberMachine> set;
        if (this.getAirScrubberMachineCache() == null && (set = this) instanceof MetaMachine && ((MetaMachine)(object = (MetaMachine)((Object)set))).getLevel() != null) {
            set = NETWORK.get(((MetaMachine)object).getLevel().m_46472_().m_135782_());
            if (set == null) {
                return null;
            }
            for (AirScrubberMachine airScrubberMachine : set) {
                if (!airScrubberMachine.getRecipeLogic().isWorking() || airScrubberMachine.getLevel() == null || !(GTOUtils.calculateDistance(airScrubberMachine.getPos(), ((MetaMachine)object).getPos()) < (double)(1 << airScrubberMachine.getTier() << 3))) continue;
                this.setAirScrubberMachineCache(airScrubberMachine);
                return airScrubberMachine;
            }
        }
        if ((object = this.getAirScrubberMachineCache()) != null && ((AirScrubberMachine)object).getRecipeLogic().isWorking()) {
            return object;
        }
        this.setAirScrubberMachineCache(null);
        return null;
    }
}

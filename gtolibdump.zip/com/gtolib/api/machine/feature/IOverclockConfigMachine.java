package com.gtolib.api.machine.feature;

import com.gregtechceu.gtceu.api.machine.feature.IRecipeLogicMachine;

public interface IOverclockConfigMachine
extends IRecipeLogicMachine {
    default public int gtolib$getOCLimit() {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public void gtolib$setOCLimit(int n) {
        throw new UnsupportedOperationException("Not implemented");
    }
}

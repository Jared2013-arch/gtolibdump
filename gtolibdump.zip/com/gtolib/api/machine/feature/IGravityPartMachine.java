package com.gtolib.api.machine.feature;

public interface IGravityPartMachine {
    public int getCurrentGravity();
}

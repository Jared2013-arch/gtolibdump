package com.gtolib.api.machine.feature.multiblock;

import com.glodblock.github.extendedae.client.render.EAEHighlightHandler;
import com.gregtechceu.gtceu.api.gui.GuiTextures;
import com.gregtechceu.gtceu.api.gui.fancy.ConfiguratorPanel;
import com.gregtechceu.gtceu.api.gui.fancy.IFancyConfigurator;
import com.gregtechceu.gtceu.api.gui.fancy.IFancyConfiguratorButton;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiController;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

public interface IHighlightMachine
extends IMultiController {
    public List<BlockPos> getHighlightPos();

    default public void attachHighlightConfigurators(ConfiguratorPanel configuratorPanel) {
        configuratorPanel.attachConfigurators(new IFancyConfigurator[]{new IFancyConfiguratorButton.Toggle(GuiTextures.LIGHT_ON, GuiTextures.LIGHT_ON, () -> false, (clickData, bl) -> {
            if (clickData.isRemote && this.isFormed() && this.self().getLevel() != null) {
                this.getHighlightPos().forEach(blockPos -> EAEHighlightHandler.highlight(blockPos, this.self().getLevel().m_46472_(), System.currentTimeMillis() + (long)this.getHighlightMilliseconds()));
            }
        }).setTooltipsSupplier(bl -> List.of((Object)Component.m_237115_("gtocore.machine.highlight_module")))});
    }

    default public int getHighlightMilliseconds() {
        return 15000;
    }
}

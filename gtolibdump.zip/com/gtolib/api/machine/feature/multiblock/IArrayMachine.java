package com.gtolib.api.machine.feature.multiblock;

import com.gregtechceu.gtceu.api.item.MetaMachineItem;
import com.gregtechceu.gtceu.api.machine.MachineDefinition;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gtocore.common.data.GTORecipeTypes;
import com.gtolib.api.machine.multiblock.ElectricMultiblockMachine;
import net.minecraft.world.item.Item;

public interface IArrayMachine {
    default public ElectricMultiblockMachine multiblockMachine() {
        return (ElectricMultiblockMachine)((Object)this);
    }

    default public MachineDefinition getMachineDefinition() {
        Item item;
        if (this.getMachineDefinitionCache() == null && (item = this.getStorageItem()) instanceof MetaMachineItem) {
            MetaMachineItem metaMachineItem = (MetaMachineItem)((Object)item);
            this.setMachineDefinitionCache(metaMachineItem.getDefinition());
        }
        return this.getMachineDefinitionCache();
    }

    default public GTRecipeType[] recipeTypes() {
        if (this.getRecipeTypeCache() == null) {
            GTRecipeType[] gTRecipeTypeArray;
            MachineDefinition machineDefinition = this.getMachineDefinition();
            if (machineDefinition == null) {
                GTRecipeType[] gTRecipeTypeArray2 = new GTRecipeType[1];
                gTRecipeTypeArray = gTRecipeTypeArray2;
                gTRecipeTypeArray2[0] = GTORecipeTypes.DUMMY_RECIPES;
            } else {
                gTRecipeTypeArray = machineDefinition.getRecipeTypes();
            }
            this.setRecipeTypeCache(gTRecipeTypeArray);
        }
        return this.getRecipeTypeCache();
    }

    default public void onStorageChanged() {
        this.setMachineDefinitionCache(null);
        this.setRecipeTypeCache(null);
        if (this.multiblockMachine().isFormed()) {
            if (this.multiblockMachine().getRecipeLogic().getLastRecipe() != null) {
                this.multiblockMachine().getRecipeLogic().markLastRecipeDirty();
            }
            this.multiblockMachine().getRecipeLogic().updateTickSubscription();
        }
    }

    public Item getStorageItem();

    public void setMachineDefinitionCache(MachineDefinition var1);

    public MachineDefinition getMachineDefinitionCache();

    public void setRecipeTypeCache(GTRecipeType[] var1);

    public GTRecipeType[] getRecipeTypeCache();
}

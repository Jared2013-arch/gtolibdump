package com.gtolib.api.machine.feature.multiblock;

import com.gregtechceu.gtceu.api.machine.multiblock.WorkableMultiblockMachine;
import com.gregtechceu.gtceu.api.pattern.BlockPattern;
import java.lang.invoke.LambdaMetafactory;
import java.util.List;
import net.minecraft.server.TickTask;
import net.minecraft.server.level.ServerLevel;

public interface IMultiStructureMachine {
    default public void updateCheck() {
        WorkableMultiblockMachine workableMultiblockMachine;
        Object object = this;
        if (object instanceof WorkableMultiblockMachine && (workableMultiblockMachine = (WorkableMultiblockMachine)object).isFormed() && (object = workableMultiblockMachine.getLevel()) instanceof ServerLevel) {
            ServerLevel serverLevel = (ServerLevel)object;
            serverLevel.m_7654_().m_6937_(new TickTask(1, (Runnable)LambdaMetafactory.metafactory(null, null, null, ()V, requestCheck(), ()V)((WorkableMultiblockMachine)workableMultiblockMachine)));
        }
    }

    public List<BlockPattern> getMultiPattern();
}

package com.gtolib.api.machine.feature.multiblock;

import com.gregtechceu.gtceu.api.gui.fancy.ConfiguratorPanel;
import com.gregtechceu.gtceu.api.gui.fancy.IFancyConfigurator;
import com.gregtechceu.gtceu.api.gui.fancy.IFancyConfiguratorButton;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiController;
import com.gtolib.api.gui.GTOGuiTextures;
import java.util.List;
import net.minecraft.network.chat.Component;

public interface ICheckPatternMachine {
    public static void attachConfigurators(ConfiguratorPanel configuratorPanel, IMultiController iMultiController) {
        configuratorPanel.attachConfigurators(new IFancyConfigurator[]{new IFancyConfiguratorButton.Toggle(GTOGuiTextures.STRUCTURE_CHECK.getSubTexture(0.0, 0.0, 1.0, 0.5), GTOGuiTextures.STRUCTURE_CHECK.getSubTexture(0.0, 0.5, 1.0, 0.5), () -> iMultiController.getWaitingTime() < 1, (clickData, bl) -> {
            if (clickData.isRemote) {
                return;
            }
            if (iMultiController.getWaitingTime() > 0) {
                iMultiController.setWaitingTime(0);
            } else if (clickData.isShiftClick) {
                iMultiController.requestCheck();
            }
        }).setTooltipsSupplier(bl -> List.of((Object)Component.m_237115_("gtocore.machine.structure_check")))});
    }
}

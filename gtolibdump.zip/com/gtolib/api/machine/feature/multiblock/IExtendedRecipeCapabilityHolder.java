package com.gtolib.api.machine.feature.multiblock;

import com.gregtechceu.gtceu.api.capability.recipe.FluidRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.capability.recipe.IRecipeCapabilityHolder;
import com.gregtechceu.gtceu.api.capability.recipe.IRecipeHandler;
import com.gregtechceu.gtceu.api.capability.recipe.ItemRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.gregtechceu.gtceu.api.machine.feature.IRecipeLogicMachine;
import com.gregtechceu.gtceu.api.machine.trait.RecipeHandlerList;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gtocore.common.machine.trait.InternalSlotRecipeHandler;
import com.gtolib.api.machine.trait.ExtendedRecipeHandlerList;
import com.gtolib.api.recipe.RecipeCapabilityMap;
import com.gtolib.utils.MapUtils;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.ints.Int2ReferenceOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.server.TickTask;
import net.minecraft.server.level.ServerLevel;
import org.jetbrains.annotations.NotNull;

public interface IExtendedRecipeCapabilityHolder
extends IRecipeLogicMachine {
    public static final Comparator<IRecipeHandler<?>> COMPARATOR = Comparator.comparingInt(iRecipeHandler -> iRecipeHandler.isNotConsumable() ? 2 : 0);

    @NotNull
    public static List<RecipeHandlerList> getInputList(@NotNull IRecipeCapabilityHolder iRecipeCapabilityHolder) {
        if (iRecipeCapabilityHolder instanceof IExtendedRecipeCapabilityHolder) {
            IExtendedRecipeCapabilityHolder iExtendedRecipeCapabilityHolder = (IExtendedRecipeCapabilityHolder)iRecipeCapabilityHolder;
            return iExtendedRecipeCapabilityHolder.gtolib$getInput();
        }
        return iRecipeCapabilityHolder.getCapabilitiesForIO(IO.IN);
    }

    @NotNull
    public static List<IRecipeHandler<?>> getInputFlat(@NotNull IRecipeCapabilityHolder iRecipeCapabilityHolder, RecipeCapability<?> recipeCapability) {
        if (iRecipeCapabilityHolder instanceof IExtendedRecipeCapabilityHolder) {
            IExtendedRecipeCapabilityHolder iExtendedRecipeCapabilityHolder = (IExtendedRecipeCapabilityHolder)iRecipeCapabilityHolder;
            return iExtendedRecipeCapabilityHolder.gtolib$getInputFlat().getOrDefault(recipeCapability, Collections.emptyList());
        }
        return iRecipeCapabilityHolder.getCapabilitiesFlat(IO.IN, recipeCapability);
    }

    default public int gtolib$getOutputColor() {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public Int2ReferenceOpenHashMap<RecipeHandlerList> gtolib$getOutputColorMap() {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public boolean isDualMEOutput(@NotNull GTRecipe gTRecipe) {
        throw new UnsupportedOperationException("Not implemented");
    }

    @NotNull
    default public List<RecipeHandlerList> gtolib$getInput() {
        throw new UnsupportedOperationException("Not implemented");
    }

    @NotNull
    default public Map<RecipeCapability<?>, List<IRecipeHandler<?>>> gtolib$getInputFlat() {
        throw new UnsupportedOperationException("Not implemented");
    }

    @NotNull
    default public List<RecipeHandlerList> gtolib$getOutput() {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public void gtolib$setOutputColor(int n) {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public void gtolib$setInput(List<RecipeHandlerList> list) {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public void gtolib$setInputFlat(Map<RecipeCapability<?>, List<IRecipeHandler<?>>> map) {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public void gtolib$setOutput(List<RecipeHandlerList> list) {
        throw new UnsupportedOperationException("Not implemented");
    }

    default public void arrangeAll() {
        this.arrangeDistinct();
        Map map = (Map)this.getCapabilitiesFlat().get(IO.IN);
        if (map != null) {
            RecipeCapabilityMap recipeCapabilityMap = new RecipeCapabilityMap();
            Iterator iterator = MapUtils.fastIterator(map);
            while (iterator.hasNext()) {
                Map.Entry entry = iterator.next();
                RecipeCapability recipeCapability = (RecipeCapability)entry.getKey();
                if (!recipeCapability.isRecipeSearchFilter()) continue;
                ObjectArrayList objectArrayList = new ObjectArrayList(new ReferenceOpenHashSet((Collection)entry.getValue()));
                objectArrayList.sort(COMPARATOR);
                recipeCapabilityMap.put(recipeCapability, objectArrayList);
            }
            this.gtolib$setInputFlat(recipeCapabilityMap);
        } else {
            this.gtolib$setInputFlat(Map.of());
        }
    }

    default public void arrangeDistinct() {
        Object object;
        ObjectArrayList objectArrayList;
        Object object3;
        Object object4;
        Object object5 = this.self().getLevel();
        if (object5 instanceof ServerLevel) {
            object4 = (ServerLevel)object5;
            this.getRecipeLogic().markLastRecipeDirty();
            ((ServerLevel)object4).m_7654_().m_6937_(new TickTask(1, this.getRecipeLogic()::updateTickSubscription));
        }
        this.gtolib$getOutputColorMap().clear();
        this.setCurrentHandlerList(null, null);
        object4 = (List)this.getCapabilitiesProxy().get(IO.OUT);
        if (object4 == null) {
            this.gtolib$setOutput(Collections.emptyList());
        } else {
            object5 = new Int2ObjectOpenHashMap();
            object3 = new ObjectArrayList();
            objectArrayList = new ObjectArrayList();
            for (RecipeHandlerList object22 : IExtendedRecipeCapabilityHolder.filterTick((List<RecipeHandlerList>)object4)) {
                int n2;
                if (object22.part != null && (n2 = object22.part.getPaintingColor()) != -1) {
                    ((List)((Int2ObjectOpenHashMap)object5).computeIfAbsent(n2, n -> new ObjectArrayList())).add(object22);
                    continue;
                }
                object3.add(object22);
            }
            object = ((Int2ObjectOpenHashMap)object5).int2ObjectEntrySet().iterator();
            while (object.hasNext()) {
                Int2ObjectMap.Entry entry = (Int2ObjectMap.Entry)object.next();
                ExtendedRecipeHandlerList extendedRecipeHandlerList = new ExtendedRecipeHandlerList(IO.OUT);
                for (RecipeHandlerList recipeHandlerList : (List)entry.getValue()) {
                    extendedRecipeHandlerList.addHandlers(recipeHandlerList.allHandlers);
                }
                int n3 = entry.getIntKey();
                extendedRecipeHandlerList.setColor(n3);
                objectArrayList.add(extendedRecipeHandlerList);
                this.gtolib$getOutputColorMap().put(n3, (Object)extendedRecipeHandlerList);
            }
            object = new ExtendedRecipeHandlerList(IO.OUT);
            Iterator iterator = object3.iterator();
            while (iterator.hasNext()) {
                RecipeHandlerList recipeHandlerList = (RecipeHandlerList)iterator.next();
                ((ExtendedRecipeHandlerList)object).addHandlers(recipeHandlerList.allHandlers);
            }
            if (!((ExtendedRecipeHandlerList)object).handlerMap.isEmpty()) {
                objectArrayList.add(object);
            }
            this.gtolib$setOutput(objectArrayList);
        }
        object5 = (List)this.getCapabilitiesProxy().get(IO.IN);
        if (object5 == null) {
            this.gtolib$setInput(Collections.emptyList());
        } else {
            object3 = new Int2ObjectOpenHashMap();
            objectArrayList = new ObjectArrayList();
            object = new ObjectArrayList();
            for (RecipeHandlerList recipeHandlerList : IExtendedRecipeCapabilityHolder.filterTick((List<RecipeHandlerList>)object5)) {
                int n4;
                if (recipeHandlerList instanceof InternalSlotRecipeHandler.AbstractRHL) {
                    InternalSlotRecipeHandler.AbstractRHL abstractRHL = (InternalSlotRecipeHandler.AbstractRHL)recipeHandlerList;
                    abstractRHL.rhl = abstractRHL;
                }
                if (recipeHandlerList.part != null && (n4 = recipeHandlerList.part.getPaintingColor()) != -1) {
                    ((Map)((Int2ObjectOpenHashMap)object3).computeIfAbsent(n4, n -> new Reference2ObjectOpenHashMap())).computeIfAbsent(recipeHandlerList.part, multiblockPartMachine -> new ObjectArrayList()).add(recipeHandlerList);
                    continue;
                }
                objectArrayList.add(recipeHandlerList);
            }
            ObjectIterator objectIterator = ((Int2ObjectOpenHashMap)object3).int2ObjectEntrySet().iterator();
            while (objectIterator.hasNext()) {
                Int2ObjectMap.Entry entry = (Int2ObjectMap.Entry)objectIterator.next();
                Map map = (Map)entry.getValue();
                int n5 = entry.getIntKey();
                ObjectArrayList objectArrayList2 = new ObjectArrayList(map.values());
                objectArrayList2.sort(Comparator.comparingInt(list -> -list.size()));
                for (RecipeHandlerList recipeHandlerList : (List)objectArrayList2.get(0)) {
                    InternalSlotRecipeHandler.AbstractRHL abstractRHL;
                    RecipeHandlerList recipeHandlerList2;
                    if (recipeHandlerList instanceof InternalSlotRecipeHandler.AbstractRHL) {
                        recipeHandlerList2 = (InternalSlotRecipeHandler.AbstractRHL)recipeHandlerList;
                        abstractRHL = recipeHandlerList2;
                    } else {
                        abstractRHL = null;
                    }
                    InternalSlotRecipeHandler.AbstractRHL abstractRHL2 = abstractRHL;
                    recipeHandlerList2 = abstractRHL2 == null ? new ExtendedRecipeHandlerList(IO.IN) : new InternalSlotRecipeHandler.WrapperRHL(abstractRHL2);
                    ((ExtendedRecipeHandlerList)recipeHandlerList2).addHandlers(recipeHandlerList.allHandlers);
                    int n6 = objectArrayList2.size();
                    for (int i = 1; i < n6; ++i) {
                        for (RecipeHandlerList recipeHandlerList3 : (List)objectArrayList2.get(i)) {
                            ((ExtendedRecipeHandlerList)recipeHandlerList2).addHandlers(recipeHandlerList3.allHandlers);
                        }
                    }
                    recipeHandlerList2.setColor(n5);
                    object.add(recipeHandlerList2);
                }
            }
            ExtendedRecipeHandlerList extendedRecipeHandlerList = new ExtendedRecipeHandlerList(IO.IN);
            for (RecipeHandlerList recipeHandlerList : objectArrayList) {
                if (recipeHandlerList.isDistinct()) {
                    object.add(recipeHandlerList);
                    continue;
                }
                extendedRecipeHandlerList.addHandlers(recipeHandlerList.allHandlers);
            }
            if (!extendedRecipeHandlerList.handlerMap.isEmpty()) {
                object.add(extendedRecipeHandlerList);
            }
            this.gtolib$setInput((List<RecipeHandlerList>)object);
        }
    }

    private static List<RecipeHandlerList> filterTick(List<RecipeHandlerList> list) {
        ObjectArrayList objectArrayList = new ObjectArrayList();
        for (RecipeHandlerList recipeHandlerList : list) {
            if ((recipeHandlerList.allHandlers.isEmpty() || !recipeHandlerList.hasCapability(ItemRecipeCapability.CAP)) && !recipeHandlerList.hasCapability(FluidRecipeCapability.CAP)) continue;
            objectArrayList.add(recipeHandlerList);
        }
        return objectArrayList;
    }
}

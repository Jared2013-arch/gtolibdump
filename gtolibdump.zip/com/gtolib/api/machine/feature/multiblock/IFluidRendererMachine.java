package com.gtolib.api.machine.feature.multiblock;

import com.gregtechceu.gtceu.api.capability.recipe.FluidRecipeCapability;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.recipe.content.Content;
import com.gtolib.api.recipe.ingredient.FastFluidIngredient;
import java.util.List;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.fluids.FluidStack;
import org.jetbrains.annotations.Nullable;

public interface IFluidRendererMachine {
    public Set<BlockPos> getFluidBlockOffsets();

    @Nullable
    public Fluid getCachedFluid();

    @Nullable
    public static Fluid getFluid(GTRecipe gTRecipe) {
        List list;
        if (gTRecipe != null && (list = (List)gTRecipe.inputs.get(FluidRecipeCapability.CAP)) != null) {
            for (Content content : list) {
                FluidStack[] fluidStackArray = FastFluidIngredient.getFluidStack(content.content);
                if (fluidStackArray.length <= 0) continue;
                return fluidStackArray[0].getFluid();
            }
        }
        return null;
    }
}

package com.gtolib.api.machine.feature.multiblock;

import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiController;
import com.gtolib.api.machine.trait.MultiblockTrait;
import java.util.List;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.NotNull;

public interface IMultiblockTraitHolder
extends IMultiController {
    public List<MultiblockTrait> getMultiblockTraits();

    default public void customText(@NotNull List<Component> list) {
        this.getMultiblockTraits().forEach(multiblockTrait -> multiblockTrait.customText(list));
    }
}

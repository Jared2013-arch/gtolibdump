package com.gtolib.api.machine.feature.multiblock;

import it.unimi.dsi.fastutil.objects.Object2IntMap;

public interface ITierCasingMachine {
    public Object2IntMap<String> getCasingTiers();

    default public int getCasingTier(String string) {
        return this.getCasingTiers().getInt((Object)string);
    }
}

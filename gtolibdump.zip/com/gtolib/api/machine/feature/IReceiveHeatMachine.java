package com.gtolib.api.machine.feature;

import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.feature.IRecipeLogicMachine;
import com.gregtechceu.gtceu.api.machine.feature.IRedstoneSignalMachine;
import com.gregtechceu.gtceu.utils.GTUtil;
import com.gtolib.api.machine.feature.IHeaterMachine;
import com.gtolib.api.machine.feature.ITemperatureMachine;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;

public interface IReceiveHeatMachine
extends ITemperatureMachine {
    public BlockPos getPos();

    public Level getLevel();

    default public void tickUpdate() {
        Object object;
        if (this.self().getOffsetTimer() % 20L != 0L) {
            return;
        }
        this.raiseTemperature(this.getHeatCapacity());
        IReceiveHeatMachine iReceiveHeatMachine = this;
        if (iReceiveHeatMachine instanceof IRedstoneSignalMachine) {
            object = (IRedstoneSignalMachine)((Object)iReceiveHeatMachine);
            object.updateSignal();
        }
        if ((iReceiveHeatMachine = this) instanceof IRecipeLogicMachine && (object = (IRecipeLogicMachine)((Object)iReceiveHeatMachine)).getRecipeLogic().isWorking()) {
            return;
        }
        this.reduceTemperature(1);
        if (this.getTemperature() > 293 && (iReceiveHeatMachine = this) instanceof IRecipeLogicMachine) {
            object = (IRecipeLogicMachine)((Object)iReceiveHeatMachine);
            object.getRecipeLogic().updateTickSubscription();
        }
    }

    @Override
    default public int reduceTemperature(int n) {
        int n2 = Math.min(this.getTemperature() - 293, n);
        if (n2 <= 0) {
            this.setTemperature(293);
            return 0;
        }
        this.setTemperature(this.getTemperature() - n2);
        return n2;
    }

    @Override
    default public void raiseTemperature(int n) {
        for (Direction direction : GTUtil.DIRECTIONS) {
            IHeaterMachine iHeaterMachine;
            if (this.getTemperature() >= this.getMaxTemperature()) {
                this.doExplosion(5.0f);
                break;
            }
            MetaMachine metaMachine = this.self().getNeighborMachine(direction);
            if (!(metaMachine instanceof IHeaterMachine) || (iHeaterMachine = (IHeaterMachine)((Object)metaMachine)).getHeatCapacity() == 0 || iHeaterMachine.getTemperature() <= this.getTemperature()) continue;
            int n2 = Math.min(n, Math.min(this.getMaxTemperature() - this.getTemperature(), Math.min(iHeaterMachine.getTemperature() - this.getTemperature(), iHeaterMachine.getHeatCapacity())));
            if (n2 <= 0) break;
            int n3 = iHeaterMachine.reduceTemperature(n2);
            n -= n3;
            this.setTemperature(this.getTemperature() + n3);
        }
    }
}

package com.gtolib.api.machine;

import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.machine.ConditionalSubscriptionHandler;
import com.gregtechceu.gtceu.api.machine.feature.IMachineLife;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtolib.api.capability.IIWirelessInteractor;
import com.gtolib.api.machine.mana.feature.IManaMultiblock;
import com.gtolib.api.machine.mana.feature.IWirelessManaContainerHolder;
import com.gtolib.api.machine.mana.trait.ManaTrait;
import com.gtolib.api.machine.multiblock.NoRecipeLogicMultiblockMachine;
import com.gtolib.api.misc.ManaContainerList;
import com.gtolib.api.wireless.WirelessManaContainer;
import com.gtolib.utils.ClientUtil;
import com.gtolib.utils.GTOUtils;
import com.gtolib.utils.MachineUtils;
import com.lowdragmc.lowdraglib.gui.util.ClickData;
import com.lowdragmc.lowdraglib.gui.widget.ComponentPanelWidget;
import com.lowdragmc.lowdraglib.syncdata.annotation.Persisted;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedFieldHolder;
import java.math.BigInteger;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class ManaDistributorMachine
extends NoRecipeLogicMultiblockMachine
implements IMachineLife,
IManaMultiblock,
IWirelessManaContainerHolder {
    private static final ManagedFieldHolder MANAGED_FIELD_HOLDER = new ManagedFieldHolder(ManaDistributorMachine.class, NoRecipeLogicMultiblockMachine.MANAGED_FIELD_HOLDER);
    public static final Map<ResourceLocation, Set<ManaDistributorMachine>> NETWORK = new O2OOpenCacheHashMap();
    private int amount = 0;
    private BlockPos centrepos;
    private final ManaTrait manaTrait;
    private final int max;
    private final int radius;
    @Persisted
    private boolean wireless;
    private WirelessManaContainer WirelessManaContainerCache;
    private final ConditionalSubscriptionHandler tickSubs;

    public static Function<MetaMachineBlockEntity, ManaDistributorMachine> create(int n, int n2) {
        return metaMachineBlockEntity -> new ManaDistributorMachine((MetaMachineBlockEntity)metaMachineBlockEntity, n, n2);
    }

    @Override
    @NotNull
    public ManagedFieldHolder getFieldHolder() {
        return MANAGED_FIELD_HOLDER;
    }

    private ManaDistributorMachine(MetaMachineBlockEntity metaMachineBlockEntity, int n, int n2) {
        super(metaMachineBlockEntity);
        this.max = n;
        this.radius = n2;
        this.tickSubs = new ConditionalSubscriptionHandler(this, this::tickUpdate, () -> this.isFormed && this.wireless);
        this.manaTrait = new ManaTrait(this);
    }

    private void tickUpdate() {
        if (this.getOffsetTimer() % 20L == 0L) {
            WirelessManaContainer wirelessManaContainer = this.getWirelessManaContainer();
            if (wirelessManaContainer != null) {
                wirelessManaContainer.setStorage(wirelessManaContainer.getStorage().add(BigInteger.valueOf(this.removeMana(this.getManaContainer().getCurrentMana(), 20, false))));
                this.tickSubs.updateSubscription();
            } else {
                this.tickSubs.unsubscribe();
            }
        }
    }

    public boolean add(BlockPos blockPos) {
        if (GTOUtils.calculateDistance(blockPos, this.centrepos) > (double)this.radius) {
            return false;
        }
        if (this.amount >= this.max) {
            return false;
        }
        ++this.amount;
        return true;
    }

    public void remove() {
        if (this.amount > 0) {
            --this.amount;
        }
    }

    @Override
    public void customText(@NotNull List<Component> list) {
        WirelessManaContainer wirelessManaContainer;
        super.customText(list);
        list.add(Component.m_237110_("gtocore.machine.binding_amount", new Object[]{this.amount}));
        list.add(ComponentPanelWidget.withButton(Component.m_237115_("gui.enderio.range.show"), "show"));
        if (this.radius == 128) {
            list.add(ComponentPanelWidget.withButton(Component.m_237115_("gtocore.machine.wireless_mode").m_130946_("[").m_7220_(Component.m_237115_("gtocore.machine." + (this.wireless ? "on" : "off"))).m_130946_("]"), "wireless"));
        }
        if (this.wireless && (wirelessManaContainer = this.getWirelessManaContainer()) != null) {
            list.add(Component.m_237115_("block.gtceu.long_distance_item_pipeline_network_header"));
            list.add(Component.m_237110_("gtocore.machine.mana_stored", new Object[]{wirelessManaContainer.getStorage()}));
        }
    }

    public void handleDisplayClick(String string, ClickData clickData) {
        if (clickData.isRemote) {
            if ("show".equals(string)) {
                ClientUtil.highlighting(MachineUtils.getOffsetPos(2, 2, this.getFrontFacing(), this.getPos()), this.radius);
            }
        } else if ("wireless".equals(string)) {
            boolean bl = this.wireless = !this.wireless;
            if (this.wireless) {
                this.tickSubs.updateSubscription();
            }
        }
    }

    @Override
    public void onStructureFormed() {
        super.onStructureFormed();
        if (this.isRemote()) {
            return;
        }
        this.centrepos = MachineUtils.getOffsetPos(2, 2, this.getFrontFacing(), this.getPos());
        IIWirelessInteractor.addToNet(NETWORK, this);
        if (this.radius == 128) {
            this.tickSubs.initialize(this.getLevel());
        }
    }

    @Override
    public void onStructureInvalid() {
        this.centrepos = null;
        IIWirelessInteractor.removeFromNet(NETWORK, this);
        super.onStructureInvalid();
    }

    @Override
    public void onUnload() {
        super.onUnload();
        this.tickSubs.unsubscribe();
        IIWirelessInteractor.removeFromNet(NETWORK, this);
    }

    @Override
    @NotNull
    public ManaContainerList getManaContainer() {
        return this.manaTrait.getManaContainers();
    }

    @Override
    public boolean isGeneratorMana() {
        return false;
    }

    @Override
    public void setWorkingEnabled(boolean bl) {
        if (bl && this.isFormed()) {
            IIWirelessInteractor.addToNet(NETWORK, this);
        } else {
            IIWirelessInteractor.removeFromNet(NETWORK, this);
        }
        super.setWorkingEnabled(bl);
    }

    public void onMachinePlaced(@Nullable LivingEntity livingEntity, ItemStack itemStack) {
        if (livingEntity != null) {
            this.setOwnerUUID(livingEntity.m_20148_());
        }
    }

    @Override
    @javax.annotation.Nullable
    public UUID getUUID() {
        return this.getOwnerUUID();
    }

    @Override
    public void setWirelessManaContainerCache(WirelessManaContainer wirelessManaContainer) {
        this.WirelessManaContainerCache = wirelessManaContainer;
    }

    @Override
    public WirelessManaContainer getWirelessManaContainerCache() {
        return this.WirelessManaContainerCache;
    }
}

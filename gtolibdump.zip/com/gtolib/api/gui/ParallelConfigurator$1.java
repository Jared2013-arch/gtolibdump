package com.gtolib.api.gui;

import com.gregtechceu.gtceu.api.gui.widget.LongInputWidget;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

class ParallelConfigurator$1
extends LongInputWidget {
    ParallelConfigurator$1(Supplier supplier, Consumer consumer) {
        super(supplier, consumer);
    }

    public void writeInitialData(FriendlyByteBuf friendlyByteBuf) {
        super.writeInitialData(friendlyByteBuf);
        friendlyByteBuf.m_130103_(ParallelConfigurator.this.machine.getMaxParallel());
        this.setMax(ParallelConfigurator.this.machine.getMaxParallel());
    }

    @OnlyIn(value=Dist.CLIENT)
    public void readInitialData(FriendlyByteBuf friendlyByteBuf) {
        super.readInitialData(friendlyByteBuf);
        this.setMax(friendlyByteBuf.m_130258_());
    }

    @Override
    public void detectAndSendChanges() {
        super.detectAndSendChanges();
        long l = ParallelConfigurator.this.machine.getMaxParallel();
        if (l != (Long)this.getMax()) {
            this.setMax(l);
            this.writeUpdateInfo(0, friendlyByteBuf -> friendlyByteBuf.m_130103_(l));
        }
    }

    @Override
    @OnlyIn(value=Dist.CLIENT)
    public void readUpdateInfo(int n, FriendlyByteBuf friendlyByteBuf) {
        super.readUpdateInfo(n, friendlyByteBuf);
        if (n == 0) {
            this.setMax(friendlyByteBuf.m_130258_());
        }
    }
}

package com.gtolib.api.gui;

import com.gtolib.api.gui.PatternSlotWidget;
import dev.emi.emi.api.EmiApi;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.ListEmiIngredient;
import java.util.List;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.IItemHandlerModifiable;

public class SelectedSlotWidget
extends PatternSlotWidget {
    private final List<EmiStack> candidateStacks;

    public SelectedSlotWidget(List<ItemStack> list, IItemHandlerModifiable iItemHandlerModifiable, int n, int n2, int n3) {
        super(iItemHandlerModifiable, n, n2, n3);
        this.candidateStacks = list.stream().map(EmiStack::of).toList();
    }

    public boolean mouseClicked(double d, double d2, int n) {
        if (this.isMouseOverElement(d, d2) && (n == 0 || n == 1)) {
            EmiApi.displayRecipes(new ListEmiIngredient(this.candidateStacks, 1L));
            return true;
        }
        return false;
    }
}

package com.gtolib.api.gui;

import com.gregtechceu.gtceu.api.gui.ISlotWidget;
import com.gregtechceu.gtceu.api.gui.widget.SlotWidget;
import com.lowdragmc.lowdraglib.gui.editor.ColorPattern;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraftforge.items.IItemHandlerModifiable;

public class PatternSlotWidget
extends SlotWidget {
    private final Supplier<EmiIngredient> ingredient;

    public PatternSlotWidget(IItemHandlerModifiable iItemHandlerModifiable, int n, int n2, int n3) {
        super(iItemHandlerModifiable, n, n2, n3, false, false);
        this.setClientSideWidget();
        this.setBackgroundTexture(ColorPattern.T_GRAY.rectTexture());
        this.ingredient = () -> EmiStack.of(iItemHandlerModifiable.getStackInSlot(n));
        this.appendHoverTooltips(new Component[]{Component.m_237110_("gui.tooltips.ae2.Amount", new Object[]{iItemHandlerModifiable.getStackInSlot(0).m_41613_()}).m_130940_(ChatFormatting.GRAY)});
        ((ISlotWidget)((Object)this)).gtm$setAEStylePredicate(itemStack -> true);
    }

    public Object getXEIIngredientOverMouse(double d, double d2) {
        if (this.isMouseOverElement(d, d2)) {
            return this.ingredient.get();
        }
        return null;
    }

    public List<Object> getXEIIngredients() {
        return List.of((Object)this.ingredient.get());
    }

    public Object getXEICurrentIngredient() {
        return this.ingredient.get();
    }
}

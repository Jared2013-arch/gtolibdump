package com.gtolib.api.gui;

import com.gregtechceu.gtceu.api.gui.fancy.IFancyConfigurator;
import com.gregtechceu.gtceu.api.gui.widget.LongInputWidget;
import com.gtolib.api.gui.GTOGuiTextures;
import com.gtolib.api.machine.feature.multiblock.IParallelMachine;
import com.lowdragmc.lowdraglib.gui.texture.IGuiTexture;
import com.lowdragmc.lowdraglib.gui.widget.Widget;
import com.lowdragmc.lowdraglib.gui.widget.WidgetGroup;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public final class ParallelConfigurator
implements IFancyConfigurator {
    private final IParallelMachine machine;

    public ParallelConfigurator(IParallelMachine iParallelMachine) {
        this.machine = iParallelMachine;
    }

    public Component getTitle() {
        return Component.m_237115_("gtceu.machine.parallel_hatch.display");
    }

    public IGuiTexture getIcon() {
        return GTOGuiTextures.PARALLEL_CONFIG;
    }

    public Widget createConfigurator() {
        WidgetGroup widgetGroup = new WidgetGroup(0, 0, 100, 20);
        LongInputWidget longInputWidget = new LongInputWidget(this.machine::getParallelLong, this.machine::setParallel){

            public void writeInitialData(FriendlyByteBuf friendlyByteBuf) {
                super.writeInitialData(friendlyByteBuf);
                friendlyByteBuf.m_130103_(ParallelConfigurator.this.machine.getMaxParallel());
                this.setMax(ParallelConfigurator.this.machine.getMaxParallel());
            }

            @OnlyIn(value=Dist.CLIENT)
            public void readInitialData(FriendlyByteBuf friendlyByteBuf) {
                super.readInitialData(friendlyByteBuf);
                this.setMax(friendlyByteBuf.m_130258_());
            }

            @Override
            public void detectAndSendChanges() {
                super.detectAndSendChanges();
                long l = ParallelConfigurator.this.machine.getMaxParallel();
                if (l != (Long)this.getMax()) {
                    this.setMax(l);
                    this.writeUpdateInfo(0, friendlyByteBuf -> friendlyByteBuf.m_130103_(l));
                }
            }

            @Override
            @OnlyIn(value=Dist.CLIENT)
            public void readUpdateInfo(int n, FriendlyByteBuf friendlyByteBuf) {
                super.readUpdateInfo(n, friendlyByteBuf);
                if (n == 0) {
                    this.setMax(friendlyByteBuf.m_130258_());
                }
            }
        };
        longInputWidget.setMin(1L);
        widgetGroup.addWidget(longInputWidget);
        return widgetGroup;
    }
}

package com.gtolib.api.gui.ktflexible;

import com.gtolib.api.gui.ktflexible.HScrollBox;
import com.gtolib.api.gui.ktflexible.LayoutBuilder;
import com.gtolib.api.gui.ktflexible.Style;
import com.lowdragmc.lowdraglib.gui.widget.Widget;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={2, 1, 0}, k=1, xi=48, d1={"\u00008\n\n\n\u0000\n\b\n\b\n\n\b\n\n\u0000\n\n\u0000\n\n\n\u0000\n\n\b\u00002\b0\u00000B!00\b\b0¢\b\bJ!\r020\u000000¢\bHJ\b0HJ\b0HR0X¢\n\u0000R0X¢\n\u0000R0¢\b\n\u0000\b\t\nR0\fX.¢\n\u0000¨"}, d2={"Lcom/gtolib/api/gui/ktflexible/HScrollBuilder;", "Lcom/gtolib/api/gui/ktflexible/LayoutBuilder;", "width", "", "height", "style", "Lcom/gtolib/api/gui/ktflexible/Style;", "<init>", "(IILcom/gtolib/api/gui/ktflexible/Style;)V", "getStyle", "()Lcom/gtolib/api/gui/ktflexible/Style;", "hscroll", "Lcom/gtolib/api/gui/ktflexible/HScrollBox;", "buildAndInit", "", "init", "Lkotlin/Function1;", "Lkotlin/ExtensionFunctionType;", "getBuiltWidget", "Lcom/lowdragmc/lowdraglib/gui/widget/Widget;", "build", "gtolib"})
@SourceDebugExtension(value={"SMAP\nFlexibleContainerBuilder.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FlexibleContainerBuilder.kt\ncom/gtolib/api/gui/ktflexible/HScrollBuilder\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,225:1\n1869#2,2:226\n1869#2,2:228\n*S KotlinDebug\n*F\n+ 1 FlexibleContainerBuilder.kt\ncom/gtolib/api/gui/ktflexible/HScrollBuilder\n*L\n170#1:226,2\n178#1:228,2\n*E\n"})
public final class HScrollBuilder
extends LayoutBuilder<HScrollBuilder> {
    private final int width;
    private final int height;
    @NotNull
    private final Style style;
    private HScrollBox hscroll;

    public HScrollBuilder(int n, int n2, @NotNull Style style) {
        Intrinsics.checkNotNullParameter(style, "");
        this.width = n;
        this.height = n2;
        this.style = style;
    }

    public HScrollBuilder(int n, int n2, Style style, int n3, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n3 & 4) != 0) {
            style = new Style(HScrollBuilder::_init_$lambda$0);
        }
        this(n, n2, style);
    }

    @NotNull
    public final Style getStyle() {
        return this.style;
    }

    @Override
    public void buildAndInit(@NotNull Function1<? super HScrollBuilder, Unit> function1) {
        Intrinsics.checkNotNullParameter(function1, "");
        this.hscroll = new HScrollBox(this.width, this.height, this.style.getSpacing());
        HScrollBox hScrollBox = this.hscroll;
        if (hScrollBox == null) {
            Intrinsics.throwUninitializedPropertyAccessException("");
            hScrollBox = null;
        }
        this.setContainerInfo$gtolib(hScrollBox);
        function1.invoke((Object)this);
        Iterable iterable = this.getChildren();
        boolean bl = false;
        for (Object t : iterable) {
            Widget widget = (Widget)t;
            boolean bl2 = false;
            HScrollBox hScrollBox2 = this.hscroll;
            if (hScrollBox2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("");
                hScrollBox2 = null;
            }
            Intrinsics.checkNotNull(widget);
            hScrollBox2.addContent(widget);
        }
    }

    @Override
    @NotNull
    public Widget getBuiltWidget() {
        HScrollBox hScrollBox = this.hscroll;
        if (hScrollBox == null) {
            Intrinsics.throwUninitializedPropertyAccessException("");
            hScrollBox = null;
        }
        return hScrollBox;
    }

    @Override
    @NotNull
    public Widget build() {
        HScrollBox hScrollBox;
        if (this.hscroll == null) {
            this.hscroll = new HScrollBox(this.width, this.height, this.style.getSpacing());
            Iterable iterable = this.getChildren();
            boolean bl = false;
            for (Object t : iterable) {
                Widget widget = (Widget)t;
                boolean bl2 = false;
                HScrollBox hScrollBox2 = this.hscroll;
                if (hScrollBox2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("");
                    hScrollBox2 = null;
                }
                Intrinsics.checkNotNull(widget);
                hScrollBox2.addContent(widget);
            }
        }
        if ((hScrollBox = this.hscroll) == null) {
            Intrinsics.throwUninitializedPropertyAccessException("");
            hScrollBox = null;
        }
        return hScrollBox;
    }

    private static final Unit _init_$lambda$0(Style style) {
        Intrinsics.checkNotNullParameter(style, "");
        return Unit.INSTANCE;
    }
}

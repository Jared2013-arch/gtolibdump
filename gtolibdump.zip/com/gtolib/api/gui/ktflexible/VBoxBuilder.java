package com.gtolib.api.gui.ktflexible;

import com.gtolib.api.gui.ktflexible.LayoutBuilder;
import com.gtolib.api.gui.ktflexible.Style;
import com.gtolib.api.gui.ktflexible.VBox;
import com.lowdragmc.lowdraglib.gui.widget.Widget;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectList;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={2, 1, 0}, k=1, xi=48, d1={"\u0000B\n\n\n\u0000\n\b\n\u0000\n\n\u0000\n\n\b\n\n\u0000\n\n\n\u0000\n\n\b\n\n\n\b\u00002\b0\u00000B#0\b\b0\b\b0¢\b\b\tJ020J020HJ!020\u000000¢\bHJ\b0HJ\b0HR0X¢\n\u0000R0¢\b\n\u0000\b\nR0¢\b\n\u0000\b\f\rR0X.¢\n\u0000R\b00X¢\n\u0000¨"}, d2={"Lcom/gtolib/api/gui/ktflexible/VBoxBuilder;", "Lcom/gtolib/api/gui/ktflexible/LayoutBuilder;", "width", "", "style", "Lcom/gtolib/api/gui/ktflexible/Style;", "alwaysHorizonCenter", "", "<init>", "(ILcom/gtolib/api/gui/ktflexible/Style;Z)V", "getStyle", "()Lcom/gtolib/api/gui/ktflexible/Style;", "getAlwaysHorizonCenter", "()Z", "vbox", "Lcom/gtolib/api/gui/ktflexible/VBox;", "tempHorizonCenteredWidget", "Lit/unimi/dsi/fastutil/objects/ObjectArrayList;", "Lcom/lowdragmc/lowdraglib/gui/widget/Widget;", "widgetCenter", "", "widget", "buildAndInit", "init", "Lkotlin/Function1;", "Lkotlin/ExtensionFunctionType;", "getBuiltWidget", "build", "gtolib"})
@SourceDebugExtension(value={"SMAP\nFlexibleContainerBuilder.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FlexibleContainerBuilder.kt\ncom/gtolib/api/gui/ktflexible/VBoxBuilder\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,225:1\n1869#2,2:226\n1869#2,2:228\n*S KotlinDebug\n*F\n+ 1 FlexibleContainerBuilder.kt\ncom/gtolib/api/gui/ktflexible/VBoxBuilder\n*L\n94#1:226,2\n103#1:228,2\n*E\n"})
public final class VBoxBuilder
extends LayoutBuilder<VBoxBuilder> {
    private final int width;
    @NotNull
    private final Style style;
    private final boolean alwaysHorizonCenter;
    private VBox vbox;
    @NotNull
    private final ObjectArrayList<Widget> tempHorizonCenteredWidget;

    public VBoxBuilder(int n, @NotNull Style style, boolean bl) {
        Intrinsics.checkNotNullParameter(style, "");
        this.width = n;
        this.style = style;
        this.alwaysHorizonCenter = bl;
        this.tempHorizonCenteredWidget = new ObjectArrayList();
    }

    public VBoxBuilder(int n, Style style, boolean bl, int n2, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n2 & 2) != 0) {
            style = new Style(VBoxBuilder::_init_$lambda$0);
        }
        if ((n2 & 4) != 0) {
            bl = false;
        }
        this(n, style, bl);
    }

    @NotNull
    public final Style getStyle() {
        return this.style;
    }

    public final boolean getAlwaysHorizonCenter() {
        return this.alwaysHorizonCenter;
    }

    public final void widgetCenter(@NotNull Widget widget) {
        Intrinsics.checkNotNullParameter(widget, "");
        this.widget(widget);
        this.tempHorizonCenteredWidget.add((Object)widget);
    }

    @Override
    public void widget(@NotNull Widget widget) {
        Intrinsics.checkNotNullParameter(widget, "");
        super.widget(widget);
        if (this.alwaysHorizonCenter) {
            this.tempHorizonCenteredWidget.add((Object)widget);
        }
    }

    @Override
    public void buildAndInit(@NotNull Function1<? super VBoxBuilder, Unit> function1) {
        Intrinsics.checkNotNullParameter(function1, "");
        this.vbox = new VBox(this.width, this.style.getSpacing());
        VBox vBox = this.vbox;
        if (vBox == null) {
            Intrinsics.throwUninitializedPropertyAccessException("");
            vBox = null;
        }
        this.setContainerInfo$gtolib(vBox);
        function1.invoke((Object)this);
        VBox vBox2 = this.vbox;
        if (vBox2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("");
            vBox2 = null;
        }
        vBox2.getHorizonCenteredWidget().addAll((ObjectList)this.tempHorizonCenteredWidget);
        Iterable iterable = this.getChildren();
        boolean bl = false;
        for (Object t : iterable) {
            Widget widget = (Widget)t;
            boolean bl2 = false;
            VBox vBox3 = this.vbox;
            if (vBox3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("");
                vBox3 = null;
            }
            vBox3.addWidget(widget);
        }
    }

    @Override
    @NotNull
    public Widget getBuiltWidget() {
        VBox vBox = this.vbox;
        if (vBox == null) {
            Intrinsics.throwUninitializedPropertyAccessException("");
            vBox = null;
        }
        return vBox;
    }

    @Override
    @NotNull
    public Widget build() {
        VBox vBox;
        if (this.vbox == null) {
            this.vbox = new VBox(this.width, this.style.getSpacing());
            Iterable iterable = this.getChildren();
            boolean bl = false;
            for (Object t : iterable) {
                Widget widget = (Widget)t;
                boolean bl2 = false;
                VBox vBox2 = this.vbox;
                if (vBox2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("");
                    vBox2 = null;
                }
                vBox2.addWidget(widget);
            }
        }
        if ((vBox = this.vbox) == null) {
            Intrinsics.throwUninitializedPropertyAccessException("");
            vBox = null;
        }
        return vBox;
    }

    private static final Unit _init_$lambda$0(Style style) {
        Intrinsics.checkNotNullParameter(style, "");
        return Unit.INSTANCE;
    }
}

package com.gtolib.api.gui.ktflexible;

import com.gtolib.api.gui.ktflexible.VBox;
import com.gtolib.api.gui.ktflexible.VScrollBox;
import kotlin.Metadata;

@Metadata(mv={2, 1, 0}, k=1, xi=48, d1={"\u0000\n\u0000\n\n\u0000\n\n\u0000*\u0000\b\n\u000020J\b0H¨"}, d2={"com/gtolib/api/gui/ktflexible/VScrollBox$1", "Lcom/gtolib/api/gui/ktflexible/VBox;", "onSizeUpdate", "", "gtolib"})
public static final class VScrollBox$1
extends VBox {
    final VScrollBox this$0;

    VScrollBox$1(int n, VScrollBox vScrollBox, int n2) {
        this.this$0 = vScrollBox;
        super(n2, n);
    }

    @Override
    protected void onSizeUpdate() {
        if (!this.this$0.isUpdatingContent) {
            this.this$0.updateScrollArea();
        }
    }
}

package com.gtolib.api.gui.ktflexible;

import com.gtolib.api.gui.ktflexible.ContainerSizeProvider;
import com.gtolib.api.gui.ktflexible.CustomBuilder;
import kotlin.Metadata;

@Metadata(mv={2, 1, 0}, k=1, xi=48, d1={"\u0000\n\u0000\n\n\u0000\n\b\n\b*\u0000\b\n\u000020R0X¢\b\n\u0000\bR0X¢\b\n\u0000\b¨\b"}, d2={"com/gtolib/api/gui/ktflexible/CustomBuilder$buildAndInit$1", "Lcom/gtolib/api/gui/ktflexible/ContainerSizeProvider;", "containerWidth", "", "getContainerWidth", "()I", "containerHeight", "getContainerHeight", "gtolib"})
public static final class CustomBuilder$buildAndInit$1
implements ContainerSizeProvider {
    private final int containerWidth;
    private final int containerHeight;

    CustomBuilder$buildAndInit$1(CustomBuilder customBuilder) {
        this.containerWidth = customBuilder.customWidget.getSizeWidth();
        this.containerHeight = customBuilder.customWidget.getSizeHeight();
    }

    @Override
    public int getContainerWidth() {
        return this.containerWidth;
    }

    @Override
    public int getContainerHeight() {
        return this.containerHeight;
    }
}

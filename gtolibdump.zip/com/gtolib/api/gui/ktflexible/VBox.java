package com.gtolib.api.gui.ktflexible;

import com.gtolib.api.gui.ktflexible.Box;
import com.gtolib.api.gui.ktflexible.FlexibleContainerDefenitionKt;
import com.lowdragmc.lowdraglib.gui.widget.Widget;
import com.lowdragmc.lowdraglib.utils.Position;
import com.lowdragmc.lowdraglib.utils.Size;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={2, 1, 0}, k=1, xi=48, d1={"\u0000&\n\n\n\u0000\n\b\n\b\n\n\n\b\n\n\b\b\u000020B0\b\b0¢\bJ\b0HR0¢\b\n\u0000\b\bR \t\b00\nX¢\n\u0000\b\f\r\"\bR08VX¢\b\bR08VX¢\b\b¨"}, d2={"Lcom/gtolib/api/gui/ktflexible/VBox;", "Lcom/gtolib/api/gui/ktflexible/Box;", "width", "", "spacing", "<init>", "(II)V", "getWidth", "()I", "horizonCenteredWidget", "Lit/unimi/dsi/fastutil/objects/ObjectArrayList;", "Lcom/lowdragmc/lowdraglib/gui/widget/Widget;", "getHorizonCenteredWidget", "()Lit/unimi/dsi/fastutil/objects/ObjectArrayList;", "setHorizonCenteredWidget", "(Lit/unimi/dsi/fastutil/objects/ObjectArrayList;)V", "performLayout", "", "containerWidth", "getContainerWidth", "containerHeight", "getContainerHeight", "gtolib"})
@SourceDebugExtension(value={"SMAP\nFlexibleContainerDefenition.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FlexibleContainerDefenition.kt\ncom/gtolib/api/gui/ktflexible/VBox\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,281:1\n1878#2,3:282\n*S KotlinDebug\n*F\n+ 1 FlexibleContainerDefenition.kt\ncom/gtolib/api/gui/ktflexible/VBox\n*L\n95#1:282,3\n*E\n"})
public class VBox
extends Box {
    private final int width;
    @NotNull
    private ObjectArrayList<Widget> horizonCenteredWidget;

    public VBox(int n, int n2) {
        super(n, 0, n2);
        this.width = n;
        this.horizonCenteredWidget = new ObjectArrayList();
    }

    public VBox(int n, int n2, int n3, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n3 & 2) != 0) {
            n2 = 0;
        }
        this(n, n2);
    }

    public final int getWidth() {
        return this.width;
    }

    @NotNull
    public final ObjectArrayList<Widget> getHorizonCenteredWidget() {
        return this.horizonCenteredWidget;
    }

    public final void setHorizonCenteredWidget(@NotNull ObjectArrayList<Widget> objectArrayList) {
        Intrinsics.checkNotNullParameter(objectArrayList, "");
        this.horizonCenteredWidget = objectArrayList;
    }

    @Override
    protected void performLayout() {
        int n = 0;
        List list = this.widgets;
        Intrinsics.checkNotNullExpressionValue(list, "");
        Iterable iterable = list;
        boolean bl = false;
        int n2 = 0;
        for (Object t : iterable) {
            int n3;
            if ((n3 = n2++) < 0) {
                CollectionsKt.throwIndexOverflow();
            }
            Widget widget = (Widget)t;
            int n4 = n3;
            boolean bl2 = false;
            if (n4 > 0) {
                n += this.getSpacing();
            }
            int n5 = this.horizonCenteredWidget.contains((Object)widget) ? this.getContainerWidth() / 2 - widget.getSize().width / 2 : 0;
            widget.setSelfPosition(new Position(n5, n));
            n += widget.getSize().height;
        }
        this.updateSizeIfNeeded(FlexibleContainerDefenitionKt.check(new Size(this.getSize().width, n)));
    }

    @Override
    public int getContainerWidth() {
        return this.width;
    }

    @Override
    public int getContainerHeight() {
        return Integer.MAX_VALUE;
    }
}

package com.gtolib.api.gui.ktflexible;

import com.gtolib.api.gui.ktflexible.HBox;
import com.gtolib.api.gui.ktflexible.LayoutBuilder;
import com.gtolib.api.gui.ktflexible.Style;
import com.lowdragmc.lowdraglib.gui.widget.Widget;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectList;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={2, 1, 0}, k=1, xi=48, d1={"\u0000B\n\n\n\u0000\n\b\n\u0000\n\n\u0000\n\n\b\n\n\u0000\n\n\n\u0000\n\n\b\n\n\n\b\u00002\b0\u00000B#0\b\b0\b\b0¢\b\b\tJ020J020HJ!020\u000000¢\bHJ\b0HJ\b0HR0X¢\n\u0000R0¢\b\n\u0000\b\nR0¢\b\n\u0000\b\f\rR0X.¢\n\u0000R\b00X¢\n\u0000¨"}, d2={"Lcom/gtolib/api/gui/ktflexible/HBoxBuilder;", "Lcom/gtolib/api/gui/ktflexible/LayoutBuilder;", "height", "", "style", "Lcom/gtolib/api/gui/ktflexible/Style;", "alwaysVerticalCenter", "", "<init>", "(ILcom/gtolib/api/gui/ktflexible/Style;Z)V", "getStyle", "()Lcom/gtolib/api/gui/ktflexible/Style;", "getAlwaysVerticalCenter", "()Z", "hbox", "Lcom/gtolib/api/gui/ktflexible/HBox;", "tempVerticalCenteredWidget", "Lit/unimi/dsi/fastutil/objects/ObjectArrayList;", "Lcom/lowdragmc/lowdraglib/gui/widget/Widget;", "widgetCenter", "", "widget", "buildAndInit", "init", "Lkotlin/Function1;", "Lkotlin/ExtensionFunctionType;", "getBuiltWidget", "build", "gtolib"})
@SourceDebugExtension(value={"SMAP\nFlexibleContainerBuilder.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FlexibleContainerBuilder.kt\ncom/gtolib/api/gui/ktflexible/HBoxBuilder\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,225:1\n1869#2,2:226\n1869#2,2:228\n*S KotlinDebug\n*F\n+ 1 FlexibleContainerBuilder.kt\ncom/gtolib/api/gui/ktflexible/HBoxBuilder\n*L\n128#1:226,2\n136#1:228,2\n*E\n"})
public final class HBoxBuilder
extends LayoutBuilder<HBoxBuilder> {
    private final int height;
    @NotNull
    private final Style style;
    private final boolean alwaysVerticalCenter;
    private HBox hbox;
    @NotNull
    private final ObjectArrayList<Widget> tempVerticalCenteredWidget;

    public HBoxBuilder(int n, @NotNull Style style, boolean bl) {
        Intrinsics.checkNotNullParameter(style, "");
        this.height = n;
        this.style = style;
        this.alwaysVerticalCenter = bl;
        this.tempVerticalCenteredWidget = new ObjectArrayList();
    }

    public HBoxBuilder(int n, Style style, boolean bl, int n2, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n2 & 2) != 0) {
            style = new Style(HBoxBuilder::_init_$lambda$0);
        }
        if ((n2 & 4) != 0) {
            bl = false;
        }
        this(n, style, bl);
    }

    @NotNull
    public final Style getStyle() {
        return this.style;
    }

    public final boolean getAlwaysVerticalCenter() {
        return this.alwaysVerticalCenter;
    }

    public final void widgetCenter(@NotNull Widget widget) {
        Intrinsics.checkNotNullParameter(widget, "");
        this.widget(widget);
        this.tempVerticalCenteredWidget.add((Object)widget);
    }

    @Override
    public void widget(@NotNull Widget widget) {
        Intrinsics.checkNotNullParameter(widget, "");
        super.widget(widget);
        if (this.alwaysVerticalCenter) {
            this.tempVerticalCenteredWidget.add((Object)widget);
        }
    }

    @Override
    public void buildAndInit(@NotNull Function1<? super HBoxBuilder, Unit> function1) {
        Intrinsics.checkNotNullParameter(function1, "");
        this.hbox = new HBox(this.height, this.style.getSpacing());
        HBox hBox = this.hbox;
        if (hBox == null) {
            Intrinsics.throwUninitializedPropertyAccessException("");
            hBox = null;
        }
        this.setContainerInfo$gtolib(hBox);
        function1.invoke((Object)this);
        HBox hBox2 = this.hbox;
        if (hBox2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("");
            hBox2 = null;
        }
        hBox2.getVerticalCenteredWidget().addAll((ObjectList)this.tempVerticalCenteredWidget);
        Iterable iterable = this.getChildren();
        boolean bl = false;
        for (Object t : iterable) {
            Widget widget = (Widget)t;
            boolean bl2 = false;
            HBox hBox3 = this.hbox;
            if (hBox3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("");
                hBox3 = null;
            }
            hBox3.addWidget(widget);
        }
    }

    @Override
    @NotNull
    public Widget getBuiltWidget() {
        HBox hBox = this.hbox;
        if (hBox == null) {
            Intrinsics.throwUninitializedPropertyAccessException("");
            hBox = null;
        }
        return hBox;
    }

    @Override
    @NotNull
    public Widget build() {
        HBox hBox;
        if (this.hbox == null) {
            this.hbox = new HBox(this.height, this.style.getSpacing());
            Iterable iterable = this.getChildren();
            boolean bl = false;
            for (Object t : iterable) {
                Widget widget = (Widget)t;
                boolean bl2 = false;
                HBox hBox2 = this.hbox;
                if (hBox2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("");
                    hBox2 = null;
                }
                hBox2.addWidget(widget);
            }
        }
        if ((hBox = this.hbox) == null) {
            Intrinsics.throwUninitializedPropertyAccessException("");
            hBox = null;
        }
        return hBox;
    }

    private static final Unit _init_$lambda$0(Style style) {
        Intrinsics.checkNotNullParameter(style, "");
        return Unit.INSTANCE;
    }
}

package com.gtolib.api.gui.ktflexible;

import com.gregtechceu.gtceu.api.gui.GuiTextures;
import com.gtolib.api.gui.ktflexible.ContainerSizeProvider;
import com.gtolib.api.gui.ktflexible.VBox;
import com.lowdragmc.lowdraglib.gui.widget.DraggableScrollableWidgetGroup;
import com.lowdragmc.lowdraglib.gui.widget.Widget;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={2, 1, 0}, k=1, xi=48, d1={"\u0000<\n\n\n\n\u0000\n\b\n\b\b\n\n\u0000\n\n\b\n\n\b\n\n\b\n\n\b\u00002020B!00\b\b0¢\b\bJ\b0HJ0\u000020J0\u00002\n\b00\"0¢J0\u000020J 0\u0000R0¢\b\n\u0000\b\t\nR0¢\b\n\u0000\b\nR\f0\rX¢\n\u0000R0X¢\n\u0000R08F¢\b\nR08VX¢\b\nR08VX¢\b\n¨!"}, d2={"Lcom/gtolib/api/gui/ktflexible/VScrollBox;", "Lcom/lowdragmc/lowdraglib/gui/widget/DraggableScrollableWidgetGroup;", "Lcom/gtolib/api/gui/ktflexible/ContainerSizeProvider;", "width", "", "height", "spacing", "<init>", "(III)V", "getWidth", "()I", "getHeight", "contentContainer", "Lcom/gtolib/api/gui/ktflexible/VBox;", "isUpdatingContent", "", "vBoxWidth", "getVBoxWidth", "containerWidth", "getContainerWidth", "containerHeight", "getContainerHeight", "updateScrollArea", "", "addContent", "widget", "Lcom/lowdragmc/lowdraglib/gui/widget/Widget;", "addContents", "widgets", "", "([Lcom/lowdragmc/lowdraglib/gui/widget/Widget;)Lcom/gtolib/api/gui/ktflexible/VScrollBox;", "removeContent", "clearContent", "gtolib"})
@SourceDebugExtension(value={"SMAP\nFlexibleContainerDefenition.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FlexibleContainerDefenition.kt\ncom/gtolib/api/gui/ktflexible/VScrollBox\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,281:1\n13472#2,2:282\n*S KotlinDebug\n*F\n+ 1 FlexibleContainerDefenition.kt\ncom/gtolib/api/gui/ktflexible/VScrollBox\n*L\n191#1:282,2\n*E\n"})
public final class VScrollBox
extends DraggableScrollableWidgetGroup
implements ContainerSizeProvider {
    private final int width;
    private final int height;
    @NotNull
    private final VBox contentContainer;
    private boolean isUpdatingContent;

    public VScrollBox(int n, int n2, int n3) {
        super(0, 0, n, n2);
        this.width = n;
        this.height = n2;
        this.scrollWheelDirection = DraggableScrollableWidgetGroup.ScrollWheelDirection.VERTICAL;
        this.setYScrollBarWidth(4);
        this.setYBarStyle(GuiTextures.SLIDER_BACKGROUND_VERTICAL, GuiTextures.BUTTON);
        this.draggable = false;
        this.scrollable = true;
        this.useScissor = true;
        int n4 = this.getVBoxWidth();
        this.contentContainer = new VBox(n3, n4){

            @Override
            protected void onSizeUpdate() {
                if (!isUpdatingContent) {
                    this.updateScrollArea();
                }
            }
        };
        super.addWidget(this.contentContainer);
    }

    public VScrollBox(int n, int n2, int n3, int n4, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n4 & 4) != 0) {
            n3 = 2;
        }
        this(n, n2, n3);
    }

    public final int getWidth() {
        return this.width;
    }

    public final int getHeight() {
        return this.height;
    }

    public final int getVBoxWidth() {
        return this.width - this.yBarWidth;
    }

    @Override
    public int getContainerWidth() {
        return this.getVBoxWidth();
    }

    @Override
    public int getContainerHeight() {
        return Integer.MAX_VALUE;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private final void updateScrollArea() {
        if (!this.isUpdatingContent) {
            this.isUpdatingContent = true;
            try {
                this.computeMax();
            }
            finally {
                this.isUpdatingContent = false;
            }
        }
    }

    @NotNull
    public final VScrollBox addContent(@NotNull Widget widget) {
        Intrinsics.checkNotNullParameter(widget, "");
        this.contentContainer.addWidget(widget);
        this.updateScrollArea();
        return this;
    }

    @NotNull
    public final VScrollBox addContents(Widget ... widgetArray) {
        Intrinsics.checkNotNullParameter(widgetArray, "");
        Widget[] widgetArray2 = widgetArray;
        boolean bl = false;
        int n = widgetArray2.length;
        for (int i = 0; i < n; ++i) {
            Widget widget;
            Widget widget2 = widget = widgetArray2[i];
            boolean bl2 = false;
            this.contentContainer.addWidget(widget2);
        }
        this.updateScrollArea();
        return this;
    }

    @NotNull
    public final VScrollBox removeContent(@NotNull Widget widget) {
        Intrinsics.checkNotNullParameter(widget, "");
        this.contentContainer.removeWidget(widget);
        this.updateScrollArea();
        return this;
    }

    @NotNull
    public final VScrollBox clearContent() {
        this.contentContainer.clearAllWidgets();
        this.updateScrollArea();
        return this;
    }
}

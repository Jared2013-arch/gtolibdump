package com.gtolib.api.gui.ktflexible;

import com.gtolib.api.gui.ktflexible.CustomBuilder;
import com.gtolib.api.gui.ktflexible.HBoxBuilder;
import com.gtolib.api.gui.ktflexible.LayoutBuilder;
import com.gtolib.api.gui.ktflexible.Style;
import com.gtolib.api.gui.ktflexible.VBox;
import com.gtolib.api.gui.ktflexible.VBoxBuilder;
import com.lowdragmc.lowdraglib.gui.widget.Widget;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function5;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={2, 1, 0}, k=2, xi=48, d1={"\u00004\n\u0000\n\n\n\u0000\n\b\n\b\n\n\n\n\n\u0000\n\n\n\n\u0000q\u00000*\b0202\b\b02\b\b02,\b&0\t000\n000\b2\f000\r¢\b¨"}, d2={"vBoxThreeColumn", "", "Lcom/gtolib/api/gui/ktflexible/LayoutBuilder;", "width", "", "spacing", "between", "drawInBackgroundInit", "Lkotlin/Function5;", "Lnet/minecraft/client/gui/GuiGraphics;", "", "Lcom/gtolib/api/gui/ktflexible/VBox;", "init", "Lkotlin/Function1;", "Lcom/gtolib/api/gui/ktflexible/VBoxBuilder;", "Lkotlin/ExtensionFunctionType;", "gtolib"})
public final class FlexibleContainerExtendedKt {
    public static final void vBoxThreeColumn(@NotNull LayoutBuilder<?> layoutBuilder, int n, int n2, int n3, @NotNull Function5<? super GuiGraphics, ? super Integer, ? super Integer, ? super Float, ? super VBox, Unit> function5, @NotNull Function1<? super VBoxBuilder, Unit> function1) {
        Intrinsics.checkNotNullParameter(layoutBuilder, "");
        Intrinsics.checkNotNullParameter(function5, "");
        Intrinsics.checkNotNullParameter(function1, "");
        LayoutBuilder.custom$default(layoutBuilder, new VBox(n, n2, function5){
            final Function5<GuiGraphics, Integer, Integer, Float, VBox, Unit> $drawInBackgroundInit;
            {
                this.$drawInBackgroundInit = function5;
                super(n, n2);
            }

            @OnlyIn(value=Dist.CLIENT)
            public void drawInBackground(GuiGraphics guiGraphics, int n, int n2, float f) {
                Intrinsics.checkNotNullParameter(guiGraphics, "");
                super.drawInBackground(guiGraphics, n, n2, f);
                this.$drawInBackgroundInit.invoke((Object)guiGraphics, (Object)n, (Object)n2, (Object)Float.valueOf(f), (Object)this);
            }
        }, null, arg_0 -> FlexibleContainerExtendedKt.vBoxThreeColumn$lambda$5(n3, n, n2, function1, arg_0), 2, null);
    }

    public static void vBoxThreeColumn$default(LayoutBuilder layoutBuilder, int n, int n2, int n3, Function5 function5, Function1 function1, int n4, Object object) {
        if ((n4 & 2) != 0) {
            n2 = 0;
        }
        if ((n4 & 4) != 0) {
            n3 = 0;
        }
        if ((n4 & 8) != 0) {
            function5 = FlexibleContainerExtendedKt::vBoxThreeColumn$lambda$0;
        }
        FlexibleContainerExtendedKt.vBoxThreeColumn(layoutBuilder, n, n2, n3, function5, function1);
    }

    private static final Unit vBoxThreeColumn$lambda$0(GuiGraphics guiGraphics, int n, int n2, float f, VBox vBox) {
        Intrinsics.checkNotNullParameter(guiGraphics, "");
        Intrinsics.checkNotNullParameter(vBox, "");
        return Unit.INSTANCE;
    }

    private static final Unit vBoxThreeColumn$lambda$5$lambda$1(Style style) {
        Intrinsics.checkNotNullParameter(style, "");
        style.setSpacing(0);
        return Unit.INSTANCE;
    }

    private static final Unit vBoxThreeColumn$lambda$5$lambda$4$lambda$2(int n, Style style) {
        Intrinsics.checkNotNullParameter(style, "");
        style.setSpacing(n);
        return Unit.INSTANCE;
    }

    private static final Unit vBoxThreeColumn$lambda$5$lambda$4$lambda$3(Function1 function1, VBoxBuilder vBoxBuilder) {
        Intrinsics.checkNotNullParameter(vBoxBuilder, "");
        function1.invoke(vBoxBuilder);
        return Unit.INSTANCE;
    }

    private static final Unit vBoxThreeColumn$lambda$5$lambda$4(int n, int n2, int n3, Function1 function1, HBoxBuilder hBoxBuilder) {
        Intrinsics.checkNotNullParameter(hBoxBuilder, "");
        hBoxBuilder.widget(new Widget(0, 0, n, 1));
        int n4 = n2 - n - n;
        LayoutBuilder.vBox$default(hBoxBuilder, n4, arg_0 -> FlexibleContainerExtendedKt.vBoxThreeColumn$lambda$5$lambda$4$lambda$2(n3, arg_0), false, arg_0 -> FlexibleContainerExtendedKt.vBoxThreeColumn$lambda$5$lambda$4$lambda$3(function1, arg_0), 4, null);
        hBoxBuilder.widget(new Widget(0, 0, n, 1));
        return Unit.INSTANCE;
    }

    private static final Unit vBoxThreeColumn$lambda$5(int n, int n2, int n3, Function1 function1, CustomBuilder customBuilder) {
        Intrinsics.checkNotNullParameter(customBuilder, "");
        LayoutBuilder.hBox$default(customBuilder, Integer.MAX_VALUE, FlexibleContainerExtendedKt::vBoxThreeColumn$lambda$5$lambda$1, false, arg_0 -> FlexibleContainerExtendedKt.vBoxThreeColumn$lambda$5$lambda$4(n, n2, n3, function1, arg_0), 4, null);
        return Unit.INSTANCE;
    }
}

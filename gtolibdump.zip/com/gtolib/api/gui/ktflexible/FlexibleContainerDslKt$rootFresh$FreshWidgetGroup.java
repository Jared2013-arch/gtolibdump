package com.gtolib.api.gui.ktflexible;

import com.gtolib.api.gui.ktflexible.FreshWidgetGroupAbstract;
import com.gtolib.api.gui.ktflexible.RootBuilder;
import com.lowdragmc.lowdraglib.gui.widget.Widget;
import com.lowdragmc.lowdraglib.gui.widget.WidgetGroup;
import com.lowdragmc.lowdraglib.utils.Position;
import com.lowdragmc.lowdraglib.utils.Size;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

@Metadata(mv={2, 1, 0}, k=1, xi=48, d1={"\u0000\n\u0000\n\n\u0000\n\n\u0000\n\n\b\n\n\u0000*\u0000\b\n\u000020B00¢\bJ\b\b0\tH¨\n"}, d2={"com/gtolib/api/gui/ktflexible/FlexibleContainerDslKt$rootFresh$FreshWidgetGroup", "Lcom/gtolib/api/gui/ktflexible/FreshWidgetGroupAbstract;", "position", "Lcom/lowdragmc/lowdraglib/utils/Position;", "size", "Lcom/lowdragmc/lowdraglib/utils/Size;", "<init>", "(IILkotlin/jvm/functions/Function1;Lcom/lowdragmc/lowdraglib/utils/Position;Lcom/lowdragmc/lowdraglib/utils/Size;)V", "fresh", "", "gtolib"})
public static final class FlexibleContainerDslKt$rootFresh$FreshWidgetGroup
extends FreshWidgetGroupAbstract {
    final int $width;
    final int $height;
    final Function1<RootBuilder, Unit> $init;

    public FlexibleContainerDslKt$rootFresh$FreshWidgetGroup(int n, int n2, Function1<? super RootBuilder, Unit> function1, Position position, Size size) {
        Intrinsics.checkNotNullParameter(position, "");
        Intrinsics.checkNotNullParameter(size, "");
        this.$width = n;
        this.$height = n2;
        this.$init = function1;
        Position position2 = Position.ORIGIN;
        Intrinsics.checkNotNullExpressionValue(position2, "");
        super(position2, new Size(n, n2));
    }

    @Override
    public void fresh() {
        this.clearAllWidgets();
        RootBuilder rootBuilder = new RootBuilder(this.$width, this.$height);
        rootBuilder.buildAndInit((Function1<? super RootBuilder, Unit>)this.$init);
        Widget widget = rootBuilder.getBuiltWidget();
        Intrinsics.checkNotNull(widget);
        WidgetGroup widgetGroup = (WidgetGroup)widget;
        this.addWidget(widgetGroup);
        this.initWidget();
    }
}

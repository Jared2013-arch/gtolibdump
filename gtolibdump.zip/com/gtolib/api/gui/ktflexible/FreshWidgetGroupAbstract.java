package com.gtolib.api.gui.ktflexible;

import com.lowdragmc.lowdraglib.gui.widget.WidgetGroup;
import com.lowdragmc.lowdraglib.utils.Position;
import com.lowdragmc.lowdraglib.utils.Size;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={2, 1, 0}, k=1, xi=48, d1={"\u0000\n\n\n\u0000\n\n\u0000\n\n\b\n\n\u0000\b&\u000020B00¢\bJ\b\b0\tH&¨\n"}, d2={"Lcom/gtolib/api/gui/ktflexible/FreshWidgetGroupAbstract;", "Lcom/lowdragmc/lowdraglib/gui/widget/WidgetGroup;", "position", "Lcom/lowdragmc/lowdraglib/utils/Position;", "size", "Lcom/lowdragmc/lowdraglib/utils/Size;", "<init>", "(Lcom/lowdragmc/lowdraglib/utils/Position;Lcom/lowdragmc/lowdraglib/utils/Size;)V", "fresh", "", "gtolib"})
public abstract class FreshWidgetGroupAbstract
extends WidgetGroup {
    public FreshWidgetGroupAbstract(@NotNull Position position, @NotNull Size size) {
        Intrinsics.checkNotNullParameter(position, "");
        Intrinsics.checkNotNullParameter(size, "");
        super(position, size);
    }

    public abstract void fresh();
}

package com.gtolib.api.gui.ktflexible;

import com.gtolib.api.gui.ktflexible.VBox;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function5;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@Metadata(mv={2, 1, 0}, k=1, xi=48, d1={"\u0000%\n\u0000\n\n\u0000\n\n\u0000\n\n\u0000\n\b\n\b\n\n\u0000*\u0000\b\n\u000020J(020202\b02\t0\nH¨"}, d2={"com/gtolib/api/gui/ktflexible/FlexibleContainerExtendedKt$vBoxThreeColumn$2", "Lcom/gtolib/api/gui/ktflexible/VBox;", "drawInBackground", "", "graphics", "Lnet/minecraft/client/gui/GuiGraphics;", "mouseX", "", "mouseY", "partialTicks", "", "gtolib"})
public static final class FlexibleContainerExtendedKt$vBoxThreeColumn$2
extends VBox {
    final Function5<GuiGraphics, Integer, Integer, Float, VBox, Unit> $drawInBackgroundInit;

    FlexibleContainerExtendedKt$vBoxThreeColumn$2(int n, int n2, Function5<? super GuiGraphics, ? super Integer, ? super Integer, ? super Float, ? super VBox, Unit> function5) {
        this.$drawInBackgroundInit = function5;
        super(n, n2);
    }

    @Override
    @OnlyIn(value=Dist.CLIENT)
    public void drawInBackground(GuiGraphics guiGraphics, int n, int n2, float f) {
        Intrinsics.checkNotNullParameter(guiGraphics, "");
        super.drawInBackground(guiGraphics, n, n2, f);
        this.$drawInBackgroundInit.invoke((Object)guiGraphics, (Object)n, (Object)n2, (Object)Float.valueOf(f), (Object)this);
    }
}

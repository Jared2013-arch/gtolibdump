package com.gtolib.api.gui;

import com.gregtechceu.gtceu.GTCEu;
import com.gtolib.GTOCore;
import com.lowdragmc.lowdraglib.gui.texture.ResourceTexture;

public final class GTOGuiTextures {
    public static final ResourceTexture DELETE = GTOGuiTextures.createTexture("delete");
    public static final ResourceTexture PLANET_TELEPORT = GTOGuiTextures.createTexture("planet_teleport");
    public static final ResourceTexture HIGH_SPEED_MODE = GTOGuiTextures.createTexture("high_speed_mode");
    public static final ResourceTexture PARALLEL_CONFIG = new ResourceTexture(GTCEu.id("textures/gui/icon/io_config/cover_settings.png"));
    public static final ResourceTexture OVERCLOCK_CONFIG = GTOGuiTextures.createTexture("overclock_config");
    public static final ResourceTexture PROGRESS_BAR_MINING_MODULE = GTOGuiTextures.createTexture("progress_bar_mining_module");
    public static final ResourceTexture PROGRESS_BAR_DRILLING_MODULE = GTOGuiTextures.createTexture("progress_bar_drilling_module");
    public static final ResourceTexture STRUCTURE_CHECK = GTOGuiTextures.createTexture("structure_check");
    public static final ResourceTexture FOLDING_OUTPUT = GTOGuiTextures.createTexture("folding_output");
    public static final ResourceTexture DATA_CRYSTAL_OVERLAY = GTOGuiTextures.createTexture("data_crystal_overlay");

    private static ResourceTexture createTexture(String string) {
        return new ResourceTexture(GTOCore.id("textures/gui/%s.png".formatted(new Object[]{string})));
    }
}

package com.gtolib.api.player;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.data.chemical.ChemicalHelper;
import com.gregtechceu.gtceu.api.data.chemical.material.stack.MaterialEntry;
import com.gregtechceu.gtceu.api.item.armor.ArmorComponentItem;
import com.gregtechceu.gtceu.common.data.GTDamageTypes;
import com.gtocore.common.data.GTODamageTypes;
import com.gtocore.common.data.GTOItems;
import com.gtocore.common.data.GTOMaterials;
import com.gtocore.common.item.misc.OrganType;
import com.gtocore.common.network.ServerMessage;
import com.gtolib.GTOCore;
import com.gtolib.api.annotation.DataGeneratorScanned;
import com.gtolib.api.annotation.language.RegisterLanguage;
import com.gtolib.api.capability.IWirelessChargerInteraction;
import com.gtolib.api.data.GTODimensions;
import com.gtolib.api.machine.feature.ITemperatureMachine;
import com.gtolib.api.machine.multiblock.WirelessChargerMachine;
import com.gtolib.api.misc.PlanetManagement;
import com.gtolib.api.player.IEnhancedPlayer;
import com.gtolib.utils.GTOUtils;
import com.gtolib.utils.ServerUtils;
import it.unimi.dsi.fastutil.objects.Object2FloatOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.Reference2IntOpenHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;

@DataGeneratorScanned
public final class PlayerData
implements IWirelessChargerInteraction {
    @RegisterLanguage(cn="负重过大，需要4级脊椎", en="Too much weight, need 4th spinal cord")
    private static final String WEIGHT = "gtocore.organ.weight";
    @RegisterLanguage(cn="你的身体无法承受该装备", en="Your body can't bear this armor")
    private static final String INFINITY = "gtocore.organ.infinity";
    public final Object2FloatOpenHashMap<String> floatCache = new Object2FloatOpenHashMap();
    public final Reference2IntOpenHashMap<OrganType> organTierCache = new Reference2IntOpenHashMap();
    public final List<ItemStack> organItemStacks = new ObjectArrayList();
    private WirelessChargerMachine netMachineCache;
    private final Player player;
    public boolean shiftState;
    public boolean noGravity;
    public boolean disableDrift;
    public boolean spaceState;
    public boolean wardenState;
    public boolean wingState;
    public boolean cmdState;

    public PlayerData(Player player) {
        this.player = player;
    }

    public boolean canFly() {
        return this.wardenState || this.wingState;
    }

    public void setDrift(boolean bl) {
        Player player = this.player;
        if (player instanceof ServerPlayer) {
            ServerPlayer serverPlayer = (ServerPlayer)player;
            this.disableDrift = bl;
            ServerMessage.disableDrift(serverPlayer, this.disableDrift);
        }
    }

    public void readAdditionalSaveData(CompoundTag compoundTag) {
        this.noGravity = compoundTag.m_128471_("noGravity");
        this.disableDrift = compoundTag.m_128471_("disableDrift");
        this.spaceState = compoundTag.m_128471_("spaceState");
        this.wardenState = compoundTag.m_128471_("wardenState");
        this.wingState = compoundTag.m_128471_("wingState");
        this.cmdState = compoundTag.m_128471_("cmdState");
        ListTag listTag = compoundTag.m_128437_("organItemStacks", 10);
        this.organItemStacks.clear();
        for (int i = 0; i < listTag.size(); ++i) {
            this.organItemStacks.add(ItemStack.m_41712_(listTag.m_128728_(i)));
        }
    }

    public void addAdditionalSaveData(CompoundTag compoundTag) {
        compoundTag.m_128379_("noGravity", this.noGravity);
        compoundTag.m_128379_("disableDrift", this.disableDrift);
        compoundTag.m_128379_("spaceState", this.spaceState);
        compoundTag.m_128379_("wardenState", this.wardenState);
        compoundTag.m_128379_("wingState", this.wingState);
        compoundTag.m_128379_("cmdState", this.cmdState);
        ListTag listTag = new ListTag();
        for (ItemStack itemStack : this.organItemStacks) {
            if (itemStack.m_41619_()) continue;
            listTag.add(itemStack.serializeNBT());
        }
        compoundTag.m_128365_("organItemStacks", listTag);
    }

    public void onPlayerTick() {
        Object object = this.player;
        if (object instanceof ServerPlayer) {
            ServerPlayer serverPlayer = (ServerPlayer)object;
            IEnhancedPlayer.onTick(serverPlayer);
            if (serverPlayer.f_19797_ % 20 == 12) {
                Object object2;
                Object object3;
                object = this.getLevel();
                MinecraftServer minecraftServer = ((Level)object).m_7654_();
                if (serverPlayer.m_36324_().m_38702_() > (GTOCore.difficulty == 1 ? 5 : 15) && serverPlayer.m_21223_() < serverPlayer.m_21233_() - 4.0f && serverPlayer.f_19797_ % 80 == 0 && serverPlayer.m_217043_().m_188499_()) {
                    serverPlayer.m_5634_(Math.max(1, (int)Math.log(serverPlayer.m_21233_() * (float)Math.max(1, 4 - GTOCore.difficulty) / 4.0f)));
                }
                boolean bl = false;
                boolean bl2 = false;
                WirelessChargerMachine wirelessChargerMachine = (WirelessChargerMachine)this.getNetMachine();
                ObjectArrayList objectArrayList = new ObjectArrayList();
                for (Direction object42 : Direction.values()) {
                    objectArrayList.add(serverPlayer.m_20097_().m_7494_().m_121945_(object42));
                }
                for (BlockPos blockPos : objectArrayList) {
                    MetaMachineBlockEntity metaMachineBlockEntity;
                    BlockEntity blockEntity = ((Level)object).m_7702_(blockPos);
                    if (!(blockEntity instanceof MetaMachineBlockEntity) || !((object3 = (metaMachineBlockEntity = (MetaMachineBlockEntity)blockEntity).getMetaMachine()) instanceof ITemperatureMachine)) continue;
                    object2 = (ITemperatureMachine)object3;
                    int n = 333;
                    if (object2.getTemperature() <= n) continue;
                    serverPlayer.m_6469_(GTODamageTypes.getMachineHeatWaveDamageSource(serverPlayer, (ITemperatureMachine)object2), Math.min((float)(object2.getTemperature() - n) / 10.0f, 20.0f));
                    this.player.m_20256_(this.player.m_20184_());
                }
                long l = 0L;
                for (ItemStack itemStack : serverPlayer.m_150109_().f_35974_) {
                    object2 = itemStack.m_41720_();
                    if (object2 == Items.f_41852_) continue;
                    if (object2 == GTOItems.HOT_IRON_INGOT.m_5456_()) {
                        bl2 = true;
                        continue;
                    }
                    IWirelessChargerInteraction.charge(wirelessChargerMachine, itemStack);
                    object3 = ChemicalHelper.getMaterialEntry((ItemLike)object2);
                    long l2 = ((MaterialEntry)object3).material().getMass();
                    if (l2 > 400L) {
                        l += l2;
                    }
                    if (((MaterialEntry)object3).material() != GTOMaterials.Amprosium) continue;
                    bl = true;
                }
                if (l > 10000L && this.organTierCache.getInt((Object)OrganType.Spine) < 4) {
                    this.player.m_5661_(Component.m_237115_(WEIGHT), true);
                    this.player.m_7292_(new MobEffectInstance(MobEffects.f_19597_, 20, 5, false, false));
                }
                for (ItemStack itemStack : serverPlayer.m_150109_().f_35975_) {
                    if (itemStack.m_41619_()) continue;
                    IWirelessChargerInteraction.charge(wirelessChargerMachine, itemStack);
                }
                if (bl2) {
                    float f = 1.373f;
                    ItemStack itemStack = serverPlayer.m_6844_(EquipmentSlot.CHEST);
                    if (!itemStack.m_41619_() && (object3 = itemStack.m_41720_()) instanceof ArmorComponentItem) {
                        object2 = (ArmorComponentItem)object3;
                        f *= ((ArmorComponentItem)object2).getArmorLogic().getHeatResistance();
                    }
                    if ((double)f > 0.0) {
                        serverPlayer.m_6469_(GTDamageTypes.HEAT.source((LevelAccessor)object), f);
                    }
                }
                String string = serverPlayer.m_7755_().getString();
                String string2 = serverPlayer.m_6168_().toString();
                boolean bl3 = Objects.equals(string2, "[1 warden_boots, 1 warden_leggings, 1 warden_chestplate, 1 warden_helmet]");
                boolean bl4 = Objects.equals(string2, "[1 infinity_boots, 1 infinity_pants, 1 infinity_chestplate, 1 infinity_helmet]");
                if (bl4) {
                    Iterator iterator = OrganType.getEntries().iterator();
                    while (iterator.hasNext()) {
                        OrganType organType = (OrganType)iterator.next();
                        if (organType.ordinal() == 0 || this.organTierCache.getInt((Object)organType) >= 4) continue;
                        this.player.m_5661_(Component.m_237115_(INFINITY), true);
                        ((List)serverPlayer.m_6168_()).clear();
                        break;
                    }
                }
                if (((Level)object).m_46472_().m_135782_().equals(GTODimensions.CREATE)) {
                    if (!bl4) {
                        this.discard(minecraftServer);
                    }
                    if (minecraftServer != null) {
                        ServerUtils.runCommandSilent(minecraftServer, "execute at " + string + " run kill @e[distance=..100,en=!" + string + ",type=!item]");
                    }
                } else if (((Level)object).m_46472_().m_135782_().equals(GTODimensions.OTHERSIDE)) {
                    if (!bl3 && !bl4) {
                        this.discard(minecraftServer);
                    }
                } else if (GTCEu.isProd() && GTODimensions.isPlanet(((Level)object).m_46472_().m_135782_()) && !PlanetManagement.isUnlocked(serverPlayer, ((Level)object).m_46472_().m_135782_())) {
                    serverPlayer.m_5661_(Component.m_237115_("gtocore.ununlocked"), false);
                    this.discard(minecraftServer);
                }
                CompoundTag compoundTag = serverPlayer.getPersistentData();
                if (this.wardenState && !bl3) {
                    compoundTag.m_128405_("fly_speed", 1);
                    serverPlayer.m_150110_().m_35943_(0.05f);
                    serverPlayer.m_6885_();
                }
                if (bl3) {
                    serverPlayer.m_7292_(new MobEffectInstance(MobEffects.f_19618_, 200, 0, false, false));
                    serverPlayer.m_7292_(new MobEffectInstance(MobEffects.f_19611_, 300, 0, false, false));
                }
                this.noGravity = bl;
                this.wardenState = bl3;
                this.spaceState = bl4;
            }
        }
    }

    @Override
    public BlockPos getPos() {
        return this.player.m_20097_();
    }

    @Override
    public Level getLevel() {
        return this.player.m_9236_();
    }

    private void discard(MinecraftServer minecraftServer) {
        ServerUtils.teleportToDimension(minecraftServer, this.player, GTODimensions.OVERWORLD, new Vec3(0.0, 100.0, 0.0));
        this.player.m_6074_();
    }

    @Override
    public UUID getUUID() {
        return this.player.m_20148_();
    }

    @Override
    public void setNetMachineCache(WirelessChargerMachine wirelessChargerMachine) {
        this.netMachineCache = wirelessChargerMachine;
    }

    @Override
    public WirelessChargerMachine getNetMachineCache() {
        return this.netMachineCache;
    }

    @Override
    public boolean testMachine(WirelessChargerMachine wirelessChargerMachine) {
        return wirelessChargerMachine.isFormed() && wirelessChargerMachine.isWorkingEnabled() && wirelessChargerMachine.getRate() > 0 && (wirelessChargerMachine.isInfinite() || GTOUtils.calculateDistance(wirelessChargerMachine.getPos(), this.getPos()) < (double)wirelessChargerMachine.getRange());
    }
}

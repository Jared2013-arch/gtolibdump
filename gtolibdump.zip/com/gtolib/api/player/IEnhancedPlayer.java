package com.gtolib.api.player;

import com.gregtechceu.gtceu.api.capability.GTCapabilityHelper;
import com.gregtechceu.gtceu.api.capability.IMedicalConditionTracker;
import com.gregtechceu.gtceu.api.data.chemical.material.Material;
import com.gregtechceu.gtceu.api.data.chemical.material.properties.HazardProperty;
import com.gregtechceu.gtceu.api.data.chemical.material.properties.PropertyKey;
import com.gregtechceu.gtceu.api.item.armor.ArmorComponentItem;
import com.gtocore.api.player.IOrganService;
import com.gtocore.api.player.OrganService;
import com.gtocore.common.item.armor.SpaceArmorComponentItem;
import com.gtolib.api.data.GTODimensions;
import com.gtolib.api.player.PlayerData;
import com.gtolib.utils.ItemUtils;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.items.IItemHandler;

public interface IEnhancedPlayer {
    public static final IOrganService organService = new OrganService();

    public PlayerData getPlayerData();

    public static IEnhancedPlayer of(Player player) {
        return (IEnhancedPlayer)((Object)player);
    }

    public static boolean spaceTick(ServerLevel serverLevel, LivingEntity livingEntity) {
        if (livingEntity instanceof IEnhancedPlayer) {
            IEnhancedPlayer iEnhancedPlayer = (IEnhancedPlayer)((Object)livingEntity);
            if (iEnhancedPlayer.getPlayerData().spaceState) {
                return false;
            }
            ItemStack itemStack = ((Player)livingEntity).m_150109_().m_36052_(2);
            if (itemStack.m_41720_() instanceof SpaceArmorComponentItem && SpaceArmorComponentItem.hasOxygen(livingEntity)) {
                for (ItemStack itemStack2 : livingEntity.m_6168_()) {
                    ArmorComponentItem armorComponentItem;
                    Item item = itemStack2.m_41720_();
                    if (item instanceof ArmorComponentItem && (ItemUtils.getIdLocation(armorComponentItem = (ArmorComponentItem)item).m_135815_().contains("nanomuscle") || ItemUtils.getIdLocation(armorComponentItem).m_135815_().contains("quarktech"))) continue;
                    return true;
                }
                return false;
            }
            return !iEnhancedPlayer.getPlayerData().wardenState || !serverLevel.m_46472_().m_135782_().equals(GTODimensions.OTHERSIDE);
        }
        return true;
    }

    public static float gravity(Entity entity, float f) {
        if (entity instanceof IEnhancedPlayer) {
            IEnhancedPlayer iEnhancedPlayer = (IEnhancedPlayer)((Object)entity);
            if (iEnhancedPlayer.getPlayerData().noGravity) {
                return 0.0f;
            }
        }
        return f;
    }

    public static void onTick(ServerPlayer serverPlayer) {
        organService.tick(serverPlayer);
        IMedicalConditionTracker iMedicalConditionTracker = GTCapabilityHelper.getMedicalConditionTracker(serverPlayer);
        if (iMedicalConditionTracker != null) {
            IItemHandler iItemHandler = (IItemHandler)serverPlayer.getCapability(ForgeCapabilities.ITEM_HANDLER, null).orElse(null);
            if (iItemHandler == null) {
                return;
            }
            iMedicalConditionTracker.tick();
            for (int i = 0; i < iItemHandler.getSlots(); ++i) {
                ItemStack itemStack = iItemHandler.getStackInSlot(i);
                Material material = HazardProperty.getValidHazardMaterial(itemStack);
                if (material.isNull() || !material.hasProperty(PropertyKey.HAZARD)) continue;
                HazardProperty hazardProperty = (HazardProperty)((Object)material.getProperty(PropertyKey.HAZARD));
                if (hazardProperty.hazardTrigger.protectionType().isProtected(serverPlayer)) {
                    hazardProperty.hazardTrigger.protectionType().damageEquipment(serverPlayer, 1);
                    continue;
                }
                iMedicalConditionTracker.progressRelatedCondition(material);
            }
        }
    }
}

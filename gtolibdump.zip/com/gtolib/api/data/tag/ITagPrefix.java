package com.gtolib.api.data.tag;

public interface ITagPrefix {
    default public boolean gtolib$isTagInput() {
        throw new UnsupportedOperationException("");
    }
}

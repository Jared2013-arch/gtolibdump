package com.gtolib.api.data.chemical;

import com.gregtechceu.gtceu.api.data.chemical.ChemicalHelper;
import com.gregtechceu.gtceu.api.data.chemical.material.Material;
import com.gregtechceu.gtceu.api.data.chemical.material.stack.MaterialEntry;
import com.gregtechceu.gtceu.api.data.tag.TagPrefix;
import java.util.List;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import org.jetbrains.annotations.NotNull;

public final class GTOChemicalHelper {
    public static Item getItem(MaterialEntry materialEntry) {
        List list = ChemicalHelper.getItems(materialEntry);
        if (list.isEmpty()) {
            return Items.f_41852_;
        }
        return ((ItemLike)list.get(0)).m_5456_();
    }

    public static Item getItem(TagPrefix tagPrefix, @NotNull Material material) {
        return GTOChemicalHelper.getItem(new MaterialEntry(tagPrefix, material));
    }
}

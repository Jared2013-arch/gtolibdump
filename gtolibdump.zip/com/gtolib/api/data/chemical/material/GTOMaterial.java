package com.gtolib.api.data.chemical.material;

import com.gregtechceu.gtceu.api.data.chemical.material.properties.MaterialProperties;
import net.minecraft.world.item.Rarity;

public interface GTOMaterial {
    public MaterialProperties gtolib$getProperties();

    public Rarity gtolib$rarity();

    public void gtolib$setRarity(Rarity var1);

    public boolean gtolib$glow();

    public void gtolib$setGlow();

    public int gtolib$temp();

    public void gtolib$setTemp(int var1);
}

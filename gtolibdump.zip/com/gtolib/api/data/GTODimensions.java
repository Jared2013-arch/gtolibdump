package com.gtolib.api.data;

import com.gregtechceu.gtceu.utils.collection.O2IOpenCacheHashMap;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtolib.api.data.Dimension;
import com.gtolib.api.data.Galaxy;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public final class GTODimensions {
    static final Map<String, Galaxy> GALAXY_MAP = new O2OOpenCacheHashMap();
    static final Object2ObjectOpenHashMap<ResourceLocation, Dimension> ALL_DIM = new O2OOpenCacheHashMap();
    static final Object2ObjectOpenHashMap<ResourceLocation, Dimension> ALL_DIM_AND_ORBIT_MAP = new O2OOpenCacheHashMap();
    static final Object2IntOpenHashMap<ResourceLocation> ALL_GALAXY_DIM = new O2IOpenCacheHashMap();
    public static final ResourceLocation OVERWORLD = Dimension.OVERWORLD.getLocation();
    public static final ResourceLocation THE_NETHER = Dimension.THE_NETHER.getLocation();
    public static final ResourceLocation THE_END = Dimension.THE_END.getLocation();
    public static final ResourceLocation MOON = Dimension.MOON.getLocation();
    public static final ResourceLocation MARS = Dimension.MARS.getLocation();
    public static final ResourceLocation VENUS = Dimension.VENUS.getLocation();
    public static final ResourceLocation MERCURY = Dimension.MERCURY.getLocation();
    public static final ResourceLocation GLACIO = Dimension.GLACIO.getLocation();
    public static final ResourceLocation ANCIENT_WORLD = Dimension.ANCIENT_WORLD.getLocation();
    public static final ResourceLocation TITAN = Dimension.TITAN.getLocation();
    public static final ResourceLocation PLUTO = Dimension.PLUTO.getLocation();
    public static final ResourceLocation IO = Dimension.IO.getLocation();
    public static final ResourceLocation GANYMEDE = Dimension.GANYMEDE.getLocation();
    public static final ResourceLocation ENCELADUS = Dimension.ENCELADUS.getLocation();
    public static final ResourceLocation CERES = Dimension.CERES.getLocation();
    public static final ResourceLocation BARNARDA_C = Dimension.BARNARDA_C.getLocation();
    public static final ResourceLocation OTHERSIDE = Dimension.OTHERSIDE.getLocation();
    public static final ResourceLocation FLAT = Dimension.FLAT.getLocation();
    public static final ResourceLocation VOID = Dimension.VOID.getLocation();
    public static final ResourceLocation CREATE = Dimension.CREATE.getLocation();
    public static final ResourceLocation ALFHEIM = Dimension.ALFHEIM.getLocation();
    private static final Set<ResourceLocation> VOID_SET = Set.of((Object)VOID, (Object)FLAT);

    public static boolean isVoid(ResourceLocation resourceLocation) {
        return VOID_SET.contains(resourceLocation);
    }

    public static boolean isOverworld(ResourceLocation resourceLocation) {
        if (OVERWORLD.equals(resourceLocation)) {
            return true;
        }
        return GTODimensions.isVoid(resourceLocation);
    }

    public static boolean isPlanet(ResourceLocation resourceLocation) {
        Dimension dimension = (Dimension)((Object)ALL_DIM.get((Object)resourceLocation));
        return dimension != null && dimension.isWithinGalaxy();
    }

    public static Set<ResourceKey<Level>> getDimensionKeys(ResourceLocation resourceLocation) {
        return Collections.singleton(GTODimensions.getDimensionKey(resourceLocation));
    }

    public static ResourceKey<Level> getDimensionKey(ResourceLocation resourceLocation) {
        Dimension dimension = (Dimension)((Object)ALL_DIM.get((Object)resourceLocation));
        if (dimension != null) {
            return dimension.getResourceKey();
        }
        return ResourceKey.m_135785_(Registries.f_256858_, resourceLocation);
    }

    public static String getTranslationKey(ResourceLocation resourceLocation) {
        Dimension dimension = (Dimension)((Object)ALL_DIM.get((Object)resourceLocation));
        if (dimension != null) {
            return dimension.getKey();
        }
        return resourceLocation.toString();
    }

    public static int getTier(ResourceLocation resourceLocation) {
        Dimension dimension = (Dimension)((Object)ALL_DIM.get((Object)resourceLocation));
        if (dimension == null) {
            return 0;
        }
        return dimension.getTier();
    }

    public static int getPlanetDistances(ResourceLocation resourceLocation) {
        return ALL_GALAXY_DIM.getInt((Object)resourceLocation);
    }

    @Nullable
    public static Galaxy getGalaxy(ResourceLocation resourceLocation) {
        Galaxy galaxy;
        Dimension dimension = (Dimension)((Object)ALL_DIM_AND_ORBIT_MAP.get((Object)resourceLocation));
        if (dimension != null && (galaxy = dimension.getGalaxy()) != Galaxy.NONE) {
            return galaxy;
        }
        return null;
    }

    public static void forEachPlanet(Consumer<Dimension> consumer) {
        for (Dimension dimension : Dimension.values()) {
            if (!dimension.isWithinGalaxy()) continue;
            consumer.accept(dimension);
        }
    }
}

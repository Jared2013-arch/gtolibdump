package com.gtolib.api.data;

import com.gregtechceu.gtceu.api.data.worldgen.IWorldGenLayer;
import com.gregtechceu.gtceu.api.data.worldgen.WorldGeneratorUtils;
import com.gtocore.data.tag.Tags;
import com.gtolib.api.data.Dimension;
import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.levelgen.structure.templatesystem.RuleTest;
import net.minecraft.world.level.levelgen.structure.templatesystem.TagMatchTest;
import org.jetbrains.annotations.NotNull;

public final class GTOWorldGenLayers
implements IWorldGenLayer {
    public static final GTOWorldGenLayers ALL_LAYER = new GTOWorldGenLayers("all_layer", new TagMatchTest(Tags.ALL_LAYER_STONE), Arrays.stream(Dimension.values()).filter(Dimension::canGenerate).map(Dimension::getLocation).collect(Collectors.toSet()));
    private final String id;
    private final RuleTest target;
    private final Set<ResourceLocation> levels;

    private GTOWorldGenLayers(String string, RuleTest ruleTest, Set<ResourceLocation> set) {
        this.id = string;
        this.target = ruleTest;
        this.levels = set;
        WorldGeneratorUtils.WORLD_GEN_LAYERS.put(string, this);
    }

    public Set<ResourceLocation> getLevels() {
        return this.levels;
    }

    public RuleTest getTarget() {
        return this.target;
    }

    public boolean isApplicableForLevel(ResourceLocation resourceLocation) {
        return this.levels.contains(resourceLocation);
    }

    @NotNull
    public String m_7912_() {
        return this.id;
    }

    public static void init() {
    }
}

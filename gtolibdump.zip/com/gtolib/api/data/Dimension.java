package com.gtolib.api.data;

import com.gtolib.GTOCore;
import com.gtolib.api.data.GTODimensions;
import com.gtolib.api.data.Galaxy;
import com.gtolib.utils.RLUtils;
import com.kyanite.deeperdarker.DeeperDarker;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

public enum Dimension {
    OVERWORLD(Level.f_46428_.m_135782_(), "Overworld", "主世界", 0, 3, Galaxy.SOLAR, null),
    MOON(RLUtils.ad("moon"), "Moon", "月球", 1, 3, Galaxy.SOLAR, RLUtils.ad("moon_stone")),
    MARS(RLUtils.ad("mars"), "Mars", "火星", 2, 4, Galaxy.SOLAR, RLUtils.ad("mars_stone")),
    VENUS(RLUtils.ad("venus"), "Venus", "金星", 3, 2, Galaxy.SOLAR, RLUtils.ad("venus_stone")),
    MERCURY(RLUtils.ad("mercury"), "Mercury", "水星", 4, 1, Galaxy.SOLAR, RLUtils.ad("mercury_stone")),
    CERES(GTOCore.id("ceres"), "Ceres", "谷神星", 4, 7, Galaxy.SOLAR, GTOCore.id("ceres_stone")),
    IO(GTOCore.id("io"), "Io", "木卫一", 5, 5, Galaxy.SOLAR, GTOCore.id("io_stone")),
    GANYMEDE(GTOCore.id("ganymede"), "Ganymede", "木卫三", 5, 5, Galaxy.SOLAR, GTOCore.id("ganymede_stone")),
    ENCELADUS(GTOCore.id("enceladus"), "Enceladus", "土卫二", 6, 6, Galaxy.SOLAR, GTOCore.id("enceladus_stone")),
    TITAN(GTOCore.id("titan"), "Titan", "土卫六", 6, 6, Galaxy.SOLAR, GTOCore.id("titan_stone")),
    PLUTO(GTOCore.id("pluto"), "Pluto", "冥王星", 6, 8, Galaxy.SOLAR, GTOCore.id("pluto_stone")),
    GLACIO(RLUtils.ad("glacio"), "Glacio", "霜原星", 7, 1, Galaxy.PROXIMA_CENTAURI, RLUtils.ad("glacio_stone")),
    BARNARDA_C(GTOCore.id("barnarda_c"), "Barnarda C", "巴纳德C", 8, 1, Galaxy.BARNARDA, GTOCore.id("barnarda_c_log")),
    OTHERSIDE(DeeperDarker.rl("otherside"), "Otherside", "幽冥", 9, -1, Galaxy.NONE, DeeperDarker.rl("sculk_stone")),
    ALFHEIM(RLUtils.parse("mythicbotany:alfheim"), "Alfheim", "亚尔夫海姆", 0, -1, Galaxy.NONE, GTOCore.id("alfsteel_block")),
    THE_NETHER(Level.f_46429_.m_135782_(), "Nether", "下界", 0, -1, Galaxy.NONE, null),
    THE_END(Level.f_46430_.m_135782_(), "End", "末地", 0, -1, Galaxy.NONE, null),
    ANCIENT_WORLD(GTOCore.id("ancient_world"), "Ancient World", "远古世界", 0, -1, Galaxy.NONE, GTOCore.id("reactor_core")),
    FLAT(GTOCore.id("flat"), "flat", "超平坦", 0, -1, Galaxy.NONE, RLUtils.mc("crying_obsidian")),
    VOID(GTOCore.id("void"), "Void", "虚空", 0, -1, Galaxy.NONE, RLUtils.mc("obsidian")),
    CREATE(GTOCore.id("create"), "Create", "创造", 10, -1, Galaxy.NONE, RLUtils.mc("obsidian"));

    private final ResourceKey<Level> resourceKey;
    private final ResourceLocation location;
    private final String en;
    private final String cn;
    private final String key;
    private final int tier;
    private final Galaxy galaxy;
    private final ResourceLocation itemKey;
    private final ResourceLocation orbit;

    private Dimension(ResourceLocation resourceLocation, String string2, String string3, int n2, int n3, Galaxy galaxy, ResourceLocation resourceLocation2) {
        this.location = resourceLocation;
        this.en = string2;
        this.cn = string3;
        this.tier = n2;
        this.galaxy = galaxy;
        this.resourceKey = GTODimensions.getDimensionKey(resourceLocation);
        this.itemKey = resourceLocation2;
        this.key = "gtocore.dimension." + resourceLocation.m_135815_();
        GTODimensions.ALL_DIM.put((Object)resourceLocation, (Object)this);
        if (this.isWithinGalaxy()) {
            GTODimensions.ALL_GALAXY_DIM.put((Object)resourceLocation, n3);
            this.orbit = RLUtils.fromNamespaceAndPath(resourceLocation == Level.f_46428_.m_135782_() ? "ad_astra" : resourceLocation.m_135827_(), resourceLocation.m_135815_() + "_orbit");
            GTODimensions.ALL_DIM_AND_ORBIT_MAP.put((Object)this.orbit, (Object)this);
            GTODimensions.ALL_GALAXY_DIM.put((Object)this.orbit, n3);
        } else {
            this.orbit = null;
        }
    }

    public boolean canGenerate() {
        return this.ordinal() < 18;
    }

    public boolean isWithinGalaxy() {
        return this.ordinal() < 13;
    }

    public ResourceKey<Level> getResourceKey() {
        return this.resourceKey;
    }

    public ResourceLocation getLocation() {
        return this.location;
    }

    public String getEn() {
        return this.en;
    }

    public String getCn() {
        return this.cn;
    }

    public String getKey() {
        return this.key;
    }

    public int getTier() {
        return this.tier;
    }

    public Galaxy getGalaxy() {
        return this.galaxy;
    }

    public ResourceLocation getItemKey() {
        return this.itemKey;
    }

    public ResourceLocation getOrbit() {
        return this.orbit;
    }

    static {
        GTODimensions.ALL_DIM_AND_ORBIT_MAP.putAll(GTODimensions.ALL_DIM);
    }
}

package com.gtolib.f;

import com.gregtechceu.gtceu.api.gui.GuiTextures;
import com.gregtechceu.gtceu.api.gui.widget.ToggleButtonWidget;
import com.gtocore.common.block.BlockMap;
import com.lowdragmc.lowdraglib.gui.texture.GuiTextureGroup;
import com.lowdragmc.lowdraglib.gui.texture.IGuiTexture;
import com.lowdragmc.lowdraglib.gui.texture.TextTexture;
import com.lowdragmc.lowdraglib.gui.widget.ButtonWidget;
import com.lowdragmc.lowdraglib.gui.widget.DraggableScrollableWidgetGroup;
import com.lowdragmc.lowdraglib.gui.widget.LabelWidget;
import com.lowdragmc.lowdraglib.gui.widget.WidgetGroup;
import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiConsumer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.level.block.Block;

class c
extends WidgetGroup {
    static int a;
    static int b;
    static boolean c;
    private final DraggableScrollableWidgetGroup d;
    private final DraggableScrollableWidgetGroup e;
    private final WidgetGroup f;
    private final WidgetGroup g;
    private final WidgetGroup[] h;
    private final a[] i;
    private int j = 0;
    private final BiConsumer<String, Integer> k;
    private boolean l = false;
    private boolean m = false;

    public c(int n, int n2, int n3, int n4, BooleanConsumer booleanConsumer, BiConsumer<String, Integer> biConsumer) {
        super(n, n2, n3, n4);
        if (!c) {
            a = BlockMap.MAP.size();
            b = BlockMap.MAP.values().stream().mapToInt(blockArray -> ((Block[])blockArray).length).max().orElse(0);
            c = true;
        }
        this.h = new WidgetGroup[a];
        this.i = new a[b];
        this.k = biConsumer;
        this.d = (DraggableScrollableWidgetGroup)new DraggableScrollableWidgetGroup(0, 0, 100, 100).setActive(false).setVisible(false).setBackground(new IGuiTexture[]{GuiTextures.BACKGROUND_INVERSE});
        this.e = (DraggableScrollableWidgetGroup)new DraggableScrollableWidgetGroup(0, 0, 100, 100).setActive(false).setVisible(false).setBackground(new IGuiTexture[]{GuiTextures.BACKGROUND_INVERSE});
        this.addWidget(this.d);
        this.addWidget(this.e);
        this.addWidget(new ToggleButtonWidget(this.getSizeWidth() - this.getSizeHeight(), 0, this.getSizeHeight(), this.getSizeHeight(), this::a, bl -> {
            this.l = bl;
            if (bl) {
                this.d.setActive(true);
                this.d.setVisible(true);
                this.c();
            } else {
                this.b();
            }
            booleanConsumer.accept(bl);
        }).setTexture(new GuiTextureGroup(new IGuiTexture[]{GuiTextures.VANILLA_BUTTON, new TextTexture("✎")}), new GuiTextureGroup(new IGuiTexture[]{GuiTextures.VANILLA_BUTTON, new TextTexture("✘")})).setHoverTooltips(new Component[]{Component.m_237113_("ID")}));
        this.f = new WidgetGroup();
        this.g = new WidgetGroup();
        this.d.setSelfPosition(this.getSizeWidth() + 19, 0);
        this.d.setSize(100, 180);
        this.d.addWidget(this.f);
        this.e.setSelfPosition(this.getSizeWidth() + 23 + this.d.getSizeWidth(), 0);
        this.e.setSize(100, 180);
        this.e.addWidget(this.g);
    }

    public boolean a() {
        return this.l;
    }

    public void b() {
        this.l = false;
        this.m = false;
        this.d.setActive(false);
        this.d.setVisible(false);
        this.e.setActive(false);
        this.e.setVisible(false);
    }

    public void c() {
        AtomicInteger atomicInteger = new AtomicInteger(0);
        ObjectIterator objectIterator = BlockMap.MAP.entrySet().iterator();
        while (objectIterator.hasNext()) {
            WidgetGroup widgetGroup;
            Map.Entry entry = (Map.Entry)objectIterator.next();
            String string = (String)entry.getKey();
            if (this.h[atomicInteger.get()] != null) {
                widgetGroup = this.h[atomicInteger.getAndIncrement()];
                continue;
            }
            this.h[atomicInteger.get()] = widgetGroup = new WidgetGroup(0, 0, this.getSizeWidth() - 8, 16);
            widgetGroup.setVisible(true);
            widgetGroup.setActive(true);
            widgetGroup.addWidget(new LabelWidget(4, 6 + 16 * atomicInteger.get(), Component.m_237115_("gtocore.adv_terminal.block_map." + string)));
            widgetGroup.addWidget(new ToggleButtonWidget(80, 6 + 16 * atomicInteger.getAndIncrement(), 12, 12, () -> this.m, bl -> {
                this.m = bl;
                if (bl) {
                    this.e.setActive(true);
                    this.e.setVisible(true);
                    this.a(string);
                } else {
                    this.e.setActive(false);
                    this.e.setVisible(false);
                }
            }).setTexture(new GuiTextureGroup(new IGuiTexture[]{GuiTextures.VANILLA_BUTTON, new TextTexture("▶")}), new GuiTextureGroup(new IGuiTexture[]{GuiTextures.VANILLA_BUTTON, new TextTexture("◀")})).setHoverTooltips(new Component[]{Component.m_237115_("gtocore.adv_terminal.category.select")}));
            this.f.addWidget(widgetGroup);
        }
        this.f.setSize(this.getSizeWidth() - 8, atomicInteger.get() * 16 + 20);
    }

    public void a(String string) {
        int n = 0;
        for (a object : this.i) {
            if (object == null) continue;
            this.g.removeWidget(object);
        }
        for (Block block : (Block[])BlockMap.MAP.getOrDefault((Object)string, new Block[0])) {
            a a2;
            MutableComponent mutableComponent = block.m_49954_();
            if (this.i[n] != null) {
                a2 = this.i[n];
            } else {
                this.i[n] = a2 = new a();
            }
            this.g.addWidget(a2);
            a2.c = n + 1;
            a2.a.setComponent(mutableComponent);
            a2.a.setTextSupplier(mutableComponent::getString);
            a2.a.setSelfPosition(5, 6 + 16 * n);
            a2.b.setSelfPosition(80, 6 + 16 * n++);
            a2.b.setOnPressCallback(clickData -> {
                mutableComponent.getString();
                this.j = a2.c;
                this.k.accept(string, this.j);
            }).setHoverTooltips(new Component[]{Component.m_237115_("gtocore.adv_terminal.block.confirm")});
        }
        this.g.setSize(this.getSizeWidth() - 8, n * 16 + 20);
    }

    static {
        c = false;
    }

    private static class a
    extends WidgetGroup {
        private final LabelWidget a = new LabelWidget(5, 5, Component.m_237113_("Select Block"));
        private final ButtonWidget b = (ButtonWidget)new ButtonWidget(80, 5, 12, 12, clickData -> {}).setHoverTooltips(new Component[]{Component.m_237115_("gtocore.adv_terminal.block.select")}).setBackground(new IGuiTexture[]{new GuiTextureGroup(new IGuiTexture[]{GuiTextures.VANILLA_BUTTON, new TextTexture("✔")})});
        private int c;

        public a() {
            super(0, 0, 100, 20);
            this.addWidget(this.a);
            this.addWidget(this.b);
        }
    }
}

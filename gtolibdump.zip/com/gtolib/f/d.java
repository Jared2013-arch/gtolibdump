package com.gtolib.f;

import com.gregtechceu.gtceu.api.item.tool.ToolHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.ForgeHooks;

public interface d {
    default public ItemStack a(ItemStack itemStack) {
        itemStack = itemStack.m_41777_();
        Player player = ForgeHooks.getCraftingPlayer();
        ToolHelper.damageItemWhenCrafting(itemStack, player);
        if (itemStack.m_41619_()) {
            return ItemStack.f_41583_;
        }
        return itemStack;
    }
}

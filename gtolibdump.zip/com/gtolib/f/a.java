package com.gtolib.f;

import appeng.api.config.Actionable;
import appeng.api.networking.security.IActionSource;
import appeng.api.stacks.AEFluidKey;
import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.AEKey;
import appeng.api.storage.MEStorage;
import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.item.MetaMachineItem;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.feature.IDropSaveMachine;
import com.gregtechceu.gtceu.api.machine.feature.IMachineModifyDrops;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiController;
import com.gregtechceu.gtceu.api.pattern.BlockPattern;
import com.gregtechceu.gtceu.api.pattern.MultiblockState;
import com.gregtechceu.gtceu.api.pattern.TraceabilityPredicate;
import com.gregtechceu.gtceu.api.pattern.predicates.SimplePredicate;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gtolib.d;
import com.gtolib.f.b;
import de.mari_023.ae2wtlib.wct.CraftingTerminalHandler;
import it.unimi.dsi.fastutil.ints.IntObjectPair;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.NonNullList;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import org.apache.commons.lang3.ArrayUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import oshi.util.tuples.Triplet;

class a
extends BlockPattern {
    private a(BlockPattern blockPattern) {
        super(blockPattern.blockMatches, blockPattern.structureDir, blockPattern.aisleRepetitions, blockPattern.centerOffset);
    }

    static a a(BlockPattern blockPattern) {
        return new a(blockPattern);
    }

    void a(Player player, MultiblockState multiblockState, b.a a2) {
        CraftingTerminalHandler craftingTerminalHandler;
        int n;
        Level level = player.m_9236_();
        int n2 = -this.centerOffset[4];
        multiblockState.cleanCache();
        multiblockState.clean();
        IMultiController iMultiController = multiblockState.controller;
        BlockPos blockPos2 = multiblockState.controllerPos;
        Direction direction2 = iMultiController.self().getFrontFacing();
        Direction direction3 = iMultiController.self().getUpwardsFacing();
        boolean bl = a2.h == 1;
        Object2IntOpenHashMap object2IntOpenHashMap = multiblockState.getGlobalCount();
        Object2IntOpenHashMap object2IntOpenHashMap2 = multiblockState.getLayerCount();
        O2OOpenCacheHashMap o2OOpenCacheHashMap = new O2OOpenCacheHashMap();
        Long2ObjectOpenHashMap long2ObjectOpenHashMap = new Long2ObjectOpenHashMap();
        int[] nArray = new int[this.fingerLength];
        for (int i = 0; i < this.fingerLength; ++i) {
            int n3 = this.aisleRepetitions[i][0];
            n = this.aisleRepetitions[i][1];
            nArray[i] = n3 != n ? Math.max(n3, Math.min(n, a2.d)) : n3;
        }
        MEStorage mEStorage = null;
        if (a2.g != 0 && (craftingTerminalHandler = CraftingTerminalHandler.getCraftingTerminalHandler(player)).getLocator() != null && craftingTerminalHandler.getTargetGrid() != null && craftingTerminalHandler.getTargetGrid().getStorageService() != null) {
            mEStorage = craftingTerminalHandler.getTargetGrid().getStorageService().getInventory();
        }
        ObjectArrayList objectArrayList = null;
        if (a2.j != 0) {
            objectArrayList = new ObjectArrayList();
        }
        int n4 = n2++;
        for (n = 0; n < this.fingerLength; ++n) {
            for (int i = 0; i < nArray[n]; ++i) {
                object2IntOpenHashMap2.clear();
                int n5 = 0;
                int n6 = -this.centerOffset[1];
                while (n5 < this.thumbLength) {
                    int n7 = 0;
                    int n8 = -this.centerOffset[0];
                    while (n7 < this.palmLength) {
                        block43: {
                            Object object5;
                            Object object2;
                            Block[] blockArray2;
                            Object object32;
                            Item item;
                            long l;
                            BlockPos blockPos3;
                            TraceabilityPredicate traceabilityPredicate;
                            block47: {
                                block44: {
                                    Block block;
                                    block46: {
                                        block45: {
                                            traceabilityPredicate = this.blockMatches[n][n5][n7];
                                            if (traceabilityPredicate == null || traceabilityPredicate.isAir() || traceabilityPredicate.isController) break block43;
                                            blockPos3 = this.setActualRelativeOffset(n8, n6, n4, direction2, direction3, bl).m_7918_(blockPos2.m_123341_(), blockPos2.m_123342_(), blockPos2.m_123343_());
                                            multiblockState.update(blockPos3, traceabilityPredicate);
                                            l = blockPos3.m_121878_();
                                            item = null;
                                            BlockState blockState2 = level.m_8055_(blockPos3);
                                            block = blockState2.m_60734_();
                                            if (block == Blocks.f_50016_) break block44;
                                            if (objectArrayList == null) break block45;
                                            if (block instanceof LiquidBlock) {
                                                d.a(level, blockPos3, true, true);
                                            } else {
                                                Object object4;
                                                int n9;
                                                int n10;
                                                boolean bl2 = false;
                                                block5: for (Object object32 : traceabilityPredicate.common) {
                                                    blockArray2 = ((SimplePredicate)object32).candidates == null ? null : (Block[])((SimplePredicate)object32).candidates.get();
                                                    if (blockArray2 == null) continue;
                                                    object2 = blockArray2;
                                                    n10 = ((Block[])object2).length;
                                                    for (n9 = 0; n9 < n10; ++n9) {
                                                        object4 = object2[n9];
                                                        if (object4 != block) continue;
                                                        bl2 = true;
                                                        break block5;
                                                    }
                                                }
                                                if (!bl2) {
                                                    block7: for (Object object32 : traceabilityPredicate.limited) {
                                                        blockArray2 = ((SimplePredicate)object32).candidates == null ? null : (Block[])((SimplePredicate)object32).candidates.get();
                                                        if (blockArray2 == null) continue;
                                                        object2 = blockArray2;
                                                        n10 = ((Block[])object2).length;
                                                        for (n9 = 0; n9 < n10; ++n9) {
                                                            object4 = object2[n9];
                                                            if (object4 != block) continue;
                                                            bl2 = true;
                                                            break block7;
                                                        }
                                                    }
                                                }
                                                if (bl2) {
                                                    object5 = new ItemStack(block);
                                                    if (blockState2.m_155947_() && (blockArray2 = level.m_7702_(blockPos3)) instanceof MetaMachineBlockEntity) {
                                                        object32 = (MetaMachineBlockEntity)blockArray2;
                                                        if ((blockArray2 = ((MetaMachineBlockEntity)object32).getMetaMachine()) instanceof IMachineModifyDrops) {
                                                            object2 = (IMachineModifyDrops)blockArray2;
                                                            object2.onDrops(Collections.singletonList(object5));
                                                        }
                                                        if (blockArray2 instanceof IDropSaveMachine && (object2 = (IDropSaveMachine)blockArray2).saveBreak()) {
                                                            object2.saveToItem(((ItemStack)object5).m_41784_());
                                                        }
                                                    }
                                                    if (!(mEStorage != null && mEStorage.insert(AEItemKey.of((ItemStack)object5), 1L, Actionable.MODULATE, IActionSource.ofPlayer(player)) != 0L || player.m_36356_((ItemStack)object5))) {
                                                        objectArrayList.add(player.m_36176_((ItemStack)object5, false));
                                                    }
                                                    level.m_46597_(blockPos3, Blocks.f_50016_.m_49966_());
                                                }
                                            }
                                            break block43;
                                        }
                                        if (!a2.a() || !a2.b.contains(block)) break block46;
                                        item = block.m_5456_();
                                        break block47;
                                    }
                                    long2ObjectOpenHashMap.put(l, block);
                                    for (Object object5 : traceabilityPredicate.limited) {
                                        ((SimplePredicate)object5).testLimited(multiblockState);
                                    }
                                    break block43;
                                }
                                if (a2.j == 1) break block43;
                            }
                            boolean bl3 = false;
                            object5 = new Block[]{};
                            for (Block[] blockArray2 : traceabilityPredicate.limited) {
                                int n11;
                                object2 = blockArray2.candidates == null ? null : (Block[])blockArray2.candidates.get();
                                if (object2 == null || blockArray2.minLayerCount <= 0 || !a2.b((Block[])object2) || (n11 = object2IntOpenHashMap2.getInt(blockArray2)) >= blockArray2.minLayerCount || blockArray2.maxLayerCount != -1 && n11 >= blockArray2.maxLayerCount) continue;
                                object2IntOpenHashMap2.addTo(blockArray2, 1);
                                object5 = object2;
                                bl3 = true;
                                break;
                            }
                            if (!bl3) {
                                for (Block[] blockArray2 : traceabilityPredicate.limited) {
                                    int n12;
                                    object2 = blockArray2.candidates == null ? null : (Block[])blockArray2.candidates.get();
                                    if (object2 == null || blockArray2.minCount <= 0 || !a2.b((Block[])object2) || (n12 = object2IntOpenHashMap.getInt(blockArray2)) >= blockArray2.minCount || blockArray2.maxCount != -1 && n12 >= blockArray2.maxCount) continue;
                                    object2IntOpenHashMap.addTo(blockArray2, 1);
                                    object5 = object2;
                                    bl3 = true;
                                    break;
                                }
                            }
                            if (!bl3) {
                                for (Block[] blockArray2 : traceabilityPredicate.limited) {
                                    object2 = blockArray2.candidates == null ? null : (Block[])blockArray2.candidates.get();
                                    if (object2 == null || !a2.b((Block[])object2) || blockArray2.maxLayerCount != -1 && object2IntOpenHashMap2.getOrDefault(blockArray2, Integer.MAX_VALUE) == blockArray2.maxLayerCount || blockArray2.maxCount != -1 && object2IntOpenHashMap.getOrDefault(blockArray2, Integer.MAX_VALUE) == blockArray2.maxCount) continue;
                                    object2IntOpenHashMap2.addTo(blockArray2, 1);
                                    object2IntOpenHashMap.addTo(blockArray2, 1);
                                    object5 = (Block[])ArrayUtils.addAll(object5, object2);
                                }
                                for (Block[] blockArray2 : traceabilityPredicate.common) {
                                    object2 = blockArray2.candidates == null ? null : (Block[])blockArray2.candidates.get();
                                    if (object2 == null || traceabilityPredicate.common.size() > 1 && !a2.b((Block[])object2)) continue;
                                    object5 = (Block[])ArrayUtils.addAll(object5, object2);
                                }
                            }
                            object32 = a2.a((Block[])object5);
                            if (!(a2.a() && item != null && (object2 = object32.get(0)) instanceof AEItemKey && (blockArray2 = (AEItemKey)object2).getReadOnlyStack().m_150930_(item))) {
                                blockArray2 = object32.stream().filter(aEKey -> aEKey instanceof AEItemKey).map(aEKey -> ((AEItemKey)aEKey).toStack()).toList();
                                object2 = a.a(player, (List<ItemStack>)blockArray2, mEStorage);
                                ItemStack itemStack = (ItemStack)((Triplet)object2).getA();
                                IItemHandler iItemHandler = (IItemHandler)((Triplet)object2).getB();
                                int n13 = (Integer)((Triplet)object2).getC();
                                if (itemStack != null) {
                                    BlockPlaceContext blockPlaceContext;
                                    InteractionResult interactionResult;
                                    if (a2.a() && item != null) {
                                        if (mEStorage == null || mEStorage.insert(AEItemKey.of(item), 1L, Actionable.MODULATE, IActionSource.ofPlayer(player)) == 0L) {
                                            player.m_36356_(new ItemStack(item, 1));
                                        }
                                        level.m_46597_(blockPos3, Blocks.f_50016_.m_49966_());
                                    }
                                    if ((interactionResult = ((BlockItem)(var40_57 = (BlockItem)((Object)itemStack.m_41720_()))).m_40576_(blockPlaceContext = new BlockPlaceContext(level, player, InteractionHand.MAIN_HAND, itemStack, BlockHitResult.m_82426_(player.m_20299_(0.0f), Direction.UP, blockPos3)))) != InteractionResult.FAIL) {
                                        BlockEntity blockEntity;
                                        if (iItemHandler != null) {
                                            iItemHandler.extractItem(n13, 1, false);
                                        }
                                        if (var40_57 instanceof MetaMachineItem && (blockEntity = level.m_7702_(blockPos3)) instanceof MetaMachineBlockEntity) {
                                            MetaMachineBlockEntity metaMachineBlockEntity = (MetaMachineBlockEntity)blockEntity;
                                            ((Object2ObjectOpenHashMap)o2OOpenCacheHashMap).put(blockPos3, metaMachineBlockEntity.metaMachine);
                                        }
                                        long2ObjectOpenHashMap.put(l, ((BlockItem)var40_57).m_40614_());
                                    }
                                } else {
                                    var40_57 = object32.stream().filter(aEKey -> aEKey instanceof AEFluidKey).map(aEKey -> (AEFluidKey)aEKey).toList();
                                    if (!var40_57.isEmpty()) {
                                        if (player.m_150110_().f_35937_) {
                                            level.m_7731_(blockPos3, ((AEFluidKey)var40_57.get(0)).getFluid().m_76145_().m_76188_(), 11);
                                        } else if (mEStorage != null && mEStorage.extract((AEKey)var40_57.get(0), 1000L, Actionable.MODULATE, IActionSource.ofPlayer(player)) == 1000L) {
                                            level.m_7731_(blockPos3, ((AEFluidKey)var40_57.get(0)).getFluid().m_76145_().m_76188_(), 11);
                                        }
                                    }
                                }
                            }
                        }
                        ++n7;
                        ++n8;
                    }
                    ++n5;
                    ++n6;
                }
                ++n4;
            }
        }
        if (objectArrayList != null) {
            objectArrayList.stream().filter(Objects::nonNull).forEach(itemEntity -> {
                itemEntity.m_32061_();
                itemEntity.m_6034_(player.m_20183_().m_123341_(), player.m_20183_().m_123342_(), player.m_20183_().m_123343_());
                level.m_7967_((Entity)itemEntity);
            });
        }
        Direction direction4 = iMultiController.self().getFrontFacing();
        ObjectIterator objectIterator = o2OOpenCacheHashMap.object2ObjectEntrySet().iterator();
        while (objectIterator.hasNext()) {
            Object2ObjectMap.Entry entry = (Object2ObjectMap.Entry)objectIterator.next();
            MetaMachine metaMachine = (MetaMachine)entry.getValue();
            BlockPos blockPos4 = (BlockPos)entry.getKey();
            this.resetFacing(blockPos4, metaMachine.getBlockState(), direction4, (blockPos, direction) -> {
                Object object = long2ObjectOpenHashMap.get(blockPos.m_121945_((Direction)direction).m_121878_());
                if (object == null) {
                    return metaMachine.isFacingValid((Direction)direction);
                }
                return false;
            }, blockState -> level.m_7731_(blockPos4, (BlockState)blockState, 3));
        }
    }

    private static Triplet<ItemStack, IItemHandler, Integer> a(Player player, List<ItemStack> list, MEStorage mEStorage) {
        ItemStack itemStack = null;
        IItemHandler iItemHandler = null;
        int n = -1;
        if (!player.m_7500_()) {
            IntObjectPair<IItemHandler> intObjectPair = a.a(list, player.getCapability(ForgeCapabilities.ITEM_HANDLER), player, mEStorage);
            if (intObjectPair != null) {
                n = intObjectPair.firstInt();
                iItemHandler = (IItemHandler)intObjectPair.second();
                itemStack = iItemHandler.getStackInSlot(n).m_41777_();
            }
        } else {
            ItemStack itemStack2;
            Iterator<ItemStack> iterator = list.iterator();
            while (iterator.hasNext() && ((itemStack = (itemStack2 = iterator.next()).m_41777_()).m_41619_() || !(itemStack.m_41720_() instanceof BlockItem))) {
                itemStack = null;
            }
        }
        return new Triplet(itemStack, iItemHandler, n);
    }

    @Nullable
    private static IntObjectPair<IItemHandler> a(List<ItemStack> list, LazyOptional<IItemHandler> lazyOptional, Player player, MEStorage mEStorage) {
        IItemHandler iItemHandler = lazyOptional.resolve().orElse(null);
        if (iItemHandler == null) {
            return null;
        }
        for (int i = 0; i < iItemHandler.getSlots(); ++i) {
            @NotNull ItemStack itemStack = iItemHandler.getStackInSlot(i);
            if (itemStack.m_41619_()) continue;
            @NotNull LazyOptional lazyOptional2 = itemStack.getCapability(ForgeCapabilities.ITEM_HANDLER);
            if (lazyOptional2.isPresent()) {
                IntObjectPair<IItemHandler> intObjectPair = a.a(list, lazyOptional2, player, mEStorage);
                if (intObjectPair == null) continue;
                return intObjectPair;
            }
            if (mEStorage != null) {
                for (ItemStack itemStack3 : list) {
                    if (mEStorage.extract(AEItemKey.of(itemStack3), 1L, Actionable.MODULATE, IActionSource.ofPlayer(player)) <= 0L) continue;
                    NonNullList nonNullList = NonNullList.m_122780_(1, itemStack3);
                    ItemStackHandler itemStackHandler = new ItemStackHandler(nonNullList);
                    return IntObjectPair.of(0, itemStackHandler);
                }
                continue;
            }
            if (!list.stream().anyMatch(itemStack2 -> ItemStack.m_41656_(itemStack2, itemStack)) || itemStack.m_41619_() || !(itemStack.m_41720_() instanceof BlockItem)) continue;
            return IntObjectPair.of(i, iItemHandler);
        }
        return null;
    }
}

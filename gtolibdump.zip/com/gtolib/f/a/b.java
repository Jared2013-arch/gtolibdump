package com.gtolib.f.a;

import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.gui.GuiTextures;
import com.gregtechceu.gtceu.api.gui.widget.SlotWidget;
import com.gregtechceu.gtceu.api.item.MetaMachineItem;
import com.gregtechceu.gtceu.api.machine.multiblock.part.TieredIOPartMachine;
import com.gregtechceu.gtceu.api.machine.trait.NotifiableItemStackHandler;
import com.gregtechceu.gtceu.api.transfer.item.CustomItemStackHandler;
import com.lowdragmc.lowdraglib.gui.texture.IGuiTexture;
import com.lowdragmc.lowdraglib.gui.widget.Widget;
import com.lowdragmc.lowdraglib.gui.widget.WidgetGroup;
import com.lowdragmc.lowdraglib.jei.IngredientIO;
import com.lowdragmc.lowdraglib.syncdata.annotation.Persisted;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedFieldHolder;
import org.jetbrains.annotations.NotNull;

public final class b
extends TieredIOPartMachine {
    private static final ManagedFieldHolder a = new ManagedFieldHolder(b.class, TieredIOPartMachine.MANAGED_FIELD_HOLDER);
    @Persisted
    private final NotifiableItemStackHandler b = new NotifiableItemStackHandler(this, 64, IO.NONE, IO.NONE, CustomItemStackHandler::new);

    public b(MetaMachineBlockEntity metaMachineBlockEntity) {
        super(metaMachineBlockEntity, 10, IO.IN);
        this.b.setFilter(itemStack -> itemStack.m_41720_() instanceof MetaMachineItem);
    }

    @NotNull
    public ManagedFieldHolder getFieldHolder() {
        return a;
    }

    public Widget createUIWidget() {
        int n = 8;
        WidgetGroup widgetGroup = new WidgetGroup(0, 0, 18 * n + 16, 18 * n + 16);
        WidgetGroup widgetGroup2 = new WidgetGroup(4, 4, 18 * n + 8, 18 * n + 8);
        int n2 = 0;
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                widgetGroup2.addWidget(new SlotWidget(this.b.storage, n2++, 4 + j * 18, 4 + i * 18, true, this.io.support(IO.IN)).setBackgroundTexture(GuiTextures.SLOT).setIngredientIO(this.io == IO.IN ? IngredientIO.INPUT : IngredientIO.OUTPUT));
            }
        }
        widgetGroup2.setBackground(new IGuiTexture[]{GuiTextures.BACKGROUND_INVERSE});
        widgetGroup.addWidget(widgetGroup2);
        return widgetGroup;
    }

    public boolean canShared() {
        return false;
    }

    public NotifiableItemStackHandler a() {
        return this.b;
    }
}

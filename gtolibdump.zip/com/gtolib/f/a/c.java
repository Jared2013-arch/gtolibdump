package com.gtolib.f.a;

import com.gregtechceu.gtceu.api.GTValues;
import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.gui.fancy.ConfiguratorPanel;
import com.gregtechceu.gtceu.api.item.MetaMachineItem;
import com.gregtechceu.gtceu.api.machine.MachineDefinition;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiPart;
import com.gregtechceu.gtceu.api.machine.trait.NotifiableItemStackHandler;
import com.gregtechceu.gtceu.api.machine.trait.RecipeLogic;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gregtechceu.gtceu.utils.collection.O2IOpenCacheHashMap;
import com.gtocore.common.data.GTORecipeTypes;
import com.gtolib.api.machine.feature.multiblock.IHighlightMachine;
import com.gtolib.api.machine.multiblock.TierCasingMultiblockMachine;
import com.gtolib.api.machine.trait.CustomRecipeLogic;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.RecipeRunner;
import com.gtolib.f.a.a;
import com.gtolib.f.a.b;
import com.gtolib.utils.MachineUtils;
import com.lowdragmc.lowdraglib.syncdata.annotation.DescSynced;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedFieldHolder;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class c
extends TierCasingMultiblockMachine
implements IHighlightMachine {
    private static final ManagedFieldHolder c = new ManagedFieldHolder(c.class, TierCasingMultiblockMachine.MANAGED_FIELD_HOLDER);
    @DescSynced
    private final List<BlockPos> d = new ArrayList<BlockPos>();
    private int e;
    int a;
    private final List<b> f = new ArrayList<b>(4);
    final Object2IntOpenHashMap<GTRecipeType> b = new O2IOpenCacheHashMap();

    public c(MetaMachineBlockEntity metaMachineBlockEntity) {
        super(metaMachineBlockEntity, "i_f", "g_b");
    }

    @NotNull
    public ManagedFieldHolder getFieldHolder() {
        return c;
    }

    @Override
    public void attachConfigurators(ConfiguratorPanel configuratorPanel) {
        super.attachConfigurators(configuratorPanel);
        this.attachHighlightConfigurators(configuratorPanel);
    }

    @Override
    public void onPartScan(IMultiPart iMultiPart) {
        super.onPartScan(iMultiPart);
        if (iMultiPart instanceof b) {
            b b2 = (b)((Object)iMultiPart);
            this.f.add(b2);
            this.traitSubscriptions.add(b2.a().addChangedListener(this::a));
        }
    }

    @Override
    protected void onStructureFormedAfter() {
        super.onStructureFormedAfter();
        this.a(true);
    }

    @Override
    public void onStructureFormed() {
        int n;
        int n2;
        this.f.clear();
        super.onStructureFormed();
        this.d.clear();
        BlockPos blockPos = MachineUtils.getOffsetPos(26, 0, this.getFrontFacing(), this.getPos());
        for (n2 = 3; n2 < 34; n2 += 6) {
            for (n = -1; n < 2; n += 2) {
                int n3 = n2 * n;
                this.d.add(blockPos.m_7918_(22, n3, 0));
                this.d.add(blockPos.m_7918_(-22, n3, 0));
                this.d.add(blockPos.m_7918_(0, n3, 22));
                this.d.add(blockPos.m_7918_(0, n3, -22));
            }
        }
        for (n2 = -1; n2 < 2; n2 += 2) {
            n = 40 * n2;
            this.d.add(blockPos.m_7918_(34, n, 5));
            this.d.add(blockPos.m_7918_(34, n, -5));
            this.d.add(blockPos.m_7918_(-34, n, 5));
            this.d.add(blockPos.m_7918_(-34, n, -5));
        }
        n2 = this.getCasingTier("g_b");
        this.a = n2 < 11 ? 0 : 32 * (1 << this.getCasingTier("g_b") - 11);
        this.a();
    }

    @Override
    public void onStructureInvalid() {
        super.onStructureInvalid();
        this.a = 0;
        this.d.clear();
        this.f.clear();
    }

    @Override
    public boolean onWorking() {
        if (!super.onWorking()) {
            return false;
        }
        this.a(false);
        return true;
    }

    private void a() {
        this.b.clear();
        int n = this.getCasingTier("i_f");
        for (b b2 : this.f) {
            NotifiableItemStackHandler notifiableItemStackHandler = b2.a();
            for (int i = 0; i < notifiableItemStackHandler.getSlots(); ++i) {
                MetaMachineItem metaMachineItem;
                Object object = notifiableItemStackHandler.getStackInSlot(i).m_41720_();
                if (!(object instanceof MetaMachineItem) || ((MachineDefinition)(object = (metaMachineItem = (MetaMachineItem)object).getDefinition())).getTier() > n || ((MachineDefinition)object).getRecipeTypes().length <= 0 || ((MachineDefinition)object).getRecipeTypes()[0] == GTORecipeTypes.DUMMY_RECIPES) continue;
                for (GTRecipeType gTRecipeType : ((MachineDefinition)object).getRecipeTypes()) {
                    this.b.put((Object)gTRecipeType, ((MachineDefinition)object).getTier());
                }
            }
        }
    }

    private void a(boolean bl) {
        if (bl || this.getOffsetTimer() % 40L == 0L) {
            this.e = 0;
            Level level = this.getLevel();
            if (level == null) {
                return;
            }
            for (BlockPos blockPos : this.d) {
                a a2;
                MetaMachine metaMachine = com.gtolib.f.a.c.getMachine(level, blockPos);
                if (!(metaMachine instanceof a) || !(a2 = (a)metaMachine).isFormed()) continue;
                a2.a = this;
                if (bl) {
                    a2.getRecipeLogic().updateTickSubscription();
                }
                ++this.e;
            }
        }
    }

    @Override
    public void customText(@NotNull List<Component> list) {
        super.customText(list);
        this.a(false);
        list.add(Component.m_237115_("cover.advanced_energy_detector.max").m_7220_(Component.m_237110_("gtocore.tooltip.item.craft_step", new Object[]{this.a})));
        list.add(Component.m_237110_("gtocore.machine.module", new Object[]{this.e}));
    }

    @Nullable
    private Recipe b() {
        Recipe recipe;
        if (this.getTier() > 11 && RecipeRunner.matchTickRecipe(this, recipe = this.getRecipeBuilder().duration(400).EUt(GTValues.VA[this.getTier()]).buildRawRecipe())) {
            return recipe;
        }
        return null;
    }

    @NotNull
    public RecipeLogic createRecipeLogic(Object ... objectArray) {
        return new CustomRecipeLogic(this, this::b, true);
    }

    @Override
    public List<BlockPos> getHighlightPos() {
        return this.d;
    }
}

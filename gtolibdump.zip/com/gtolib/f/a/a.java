package com.gtolib.f.a;

import appeng.api.crafting.PatternDetailsHelper;
import appeng.api.stacks.AEFluidKey;
import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import appeng.core.definitions.AEItems;
import com.gregtechceu.gtceu.api.GTValues;
import com.gregtechceu.gtceu.api.blockentity.MetaMachineBlockEntity;
import com.gregtechceu.gtceu.api.capability.recipe.FluidRecipeCapability;
import com.gregtechceu.gtceu.api.capability.recipe.ItemRecipeCapability;
import com.gregtechceu.gtceu.api.gui.fancy.ConfiguratorPanel;
import com.gregtechceu.gtceu.api.gui.fancy.IFancyConfigurator;
import com.gregtechceu.gtceu.api.item.MetaMachineItem;
import com.gregtechceu.gtceu.api.machine.MachineDefinition;
import com.gregtechceu.gtceu.api.machine.MultiblockMachineDefinition;
import com.gregtechceu.gtceu.api.machine.trait.RecipeLogic;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gregtechceu.gtceu.api.recipe.chance.logic.ChanceLogic;
import com.gregtechceu.gtceu.api.recipe.content.Content;
import com.gregtechceu.gtceu.common.data.GTRecipeTypes;
import com.gregtechceu.gtceu.utils.FormattingUtil;
import com.gregtechceu.gtceu.utils.GTUtil;
import com.gregtechceu.gtceu.utils.collection.O2LOpenCacheHashMap;
import com.gtolib.api.gui.ParallelConfigurator;
import com.gtolib.api.machine.feature.multiblock.IParallelMachine;
import com.gtolib.api.machine.multiblock.StorageMultiblockMachine;
import com.gtolib.api.machine.trait.CustomParallelTrait;
import com.gtolib.api.machine.trait.CustomRecipeLogic;
import com.gtolib.api.recipe.Recipe;
import com.gtolib.api.recipe.RecipeBuilder;
import com.gtolib.api.recipe.RecipeHelper;
import com.gtolib.api.recipe.RecipeRunner;
import com.gtolib.api.recipe.ingredient.FastFluidIngredient;
import com.gtolib.api.recipe.ingredient.FastSizedIngredient;
import com.gtolib.f.a.c;
import com.gtolib.utils.MachineUtils;
import com.gtolib.utils.MathUtil;
import com.lowdragmc.lowdraglib.gui.util.ClickData;
import com.lowdragmc.lowdraglib.gui.widget.ComponentPanelWidget;
import com.lowdragmc.lowdraglib.syncdata.annotation.Persisted;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedFieldHolder;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import it.unimi.dsi.fastutil.objects.Object2LongOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.Reference2LongMap;
import it.unimi.dsi.fastutil.objects.Reference2LongOpenHashMap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.fluids.FluidStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class a
extends StorageMultiblockMachine
implements IParallelMachine {
    private static final ManagedFieldHolder b = new ManagedFieldHolder(a.class, StorageMultiblockMachine.MANAGED_FIELD_HOLDER);
    private GTRecipeType c = GTRecipeTypes.DUMMY_RECIPES;
    c a;
    @Persisted
    private Recipe d;
    private final Reference2LongOpenHashMap<Recipe> e = new Reference2LongOpenHashMap();
    private final List<Recipe> f = new ArrayList<Recipe>();
    private final Object2LongOpenHashMap<AEItemKey> g = new O2LOpenCacheHashMap();
    private final Object2LongOpenHashMap<AEFluidKey> h = new O2LOpenCacheHashMap();
    private final Object2LongOpenHashMap<AEItemKey> i = new O2LOpenCacheHashMap();
    private final Object2LongOpenHashMap<AEFluidKey> j = new O2LOpenCacheHashMap();
    @Persisted
    private final CustomParallelTrait k = new CustomParallelTrait(this, true, iParallelMachine -> MachineUtils.getHatchParallel(((a)iParallelMachine).a));

    public a(MetaMachineBlockEntity metaMachineBlockEntity) {
        super(metaMachineBlockEntity, 1, itemStack -> true);
        this.k.setDefaultMax(false);
    }

    private void a() {
        this.c = GTRecipeTypes.DUMMY_RECIPES;
        Object object = this.getStorageStack().m_41720_();
        if (object instanceof MetaMachineItem) {
            MetaMachineItem metaMachineItem = (MetaMachineItem)object;
            object = metaMachineItem.getDefinition();
            this.c = ((MachineDefinition)object).getRecipeTypes()[0];
        }
    }

    @Override
    public void saveCustomPersistedData(@NotNull CompoundTag compoundTag, boolean bl) {
        CompoundTag compoundTag2;
        Object object;
        ObjectIterator objectIterator;
        ListTag listTag;
        super.saveCustomPersistedData(compoundTag, bl);
        if (!this.g.isEmpty()) {
            listTag = new ListTag();
            objectIterator = this.g.object2LongEntrySet().iterator();
            while (objectIterator.hasNext()) {
                object = (Object2LongMap.Entry)objectIterator.next();
                compoundTag2 = new CompoundTag();
                compoundTag2.m_128365_("k", ((AEItemKey)object.getKey()).toTag());
                compoundTag2.m_128356_("v", object.getLongValue());
                listTag.add(compoundTag2);
            }
            compoundTag.m_128365_("inputItemStackMap", listTag);
        }
        if (!this.h.isEmpty()) {
            listTag = new ListTag();
            objectIterator = this.h.object2LongEntrySet().iterator();
            while (objectIterator.hasNext()) {
                object = (Object2LongMap.Entry)objectIterator.next();
                compoundTag2 = new CompoundTag();
                compoundTag2.m_128365_("k", ((AEFluidKey)object.getKey()).toTag());
                compoundTag2.m_128356_("v", object.getLongValue());
                listTag.add(compoundTag2);
            }
            compoundTag.m_128365_("inputFluidStackMap", listTag);
        }
        if (!this.i.isEmpty()) {
            listTag = new ListTag();
            objectIterator = this.i.object2LongEntrySet().iterator();
            while (objectIterator.hasNext()) {
                object = (Object2LongMap.Entry)objectIterator.next();
                compoundTag2 = new CompoundTag();
                compoundTag2.m_128365_("k", ((AEItemKey)object.getKey()).toTag());
                compoundTag2.m_128356_("v", object.getLongValue());
                listTag.add(compoundTag2);
            }
            compoundTag.m_128365_("outputItemStackMap", listTag);
        }
        if (!this.j.isEmpty()) {
            listTag = new ListTag();
            objectIterator = this.j.object2LongEntrySet().iterator();
            while (objectIterator.hasNext()) {
                object = (Object2LongMap.Entry)objectIterator.next();
                compoundTag2 = new CompoundTag();
                compoundTag2.m_128365_("k", ((AEFluidKey)object.getKey()).toTag());
                compoundTag2.m_128356_("v", object.getLongValue());
                listTag.add(compoundTag2);
            }
            compoundTag.m_128365_("outputFluidStackMap", listTag);
        }
        if (!this.e.isEmpty()) {
            listTag = new ListTag();
            objectIterator = this.e.reference2LongEntrySet().iterator();
            while (objectIterator.hasNext()) {
                object = (Reference2LongMap.Entry)objectIterator.next();
                compoundTag2 = new CompoundTag();
                compoundTag2.m_128365_("k", ((Recipe)object.getKey()).serializeNBT());
                compoundTag2.m_128356_("v", object.getLongValue());
                listTag.add(compoundTag2);
            }
            compoundTag.m_128365_("packageRecipe", listTag);
        }
    }

    @Override
    public void loadCustomPersistedData(@NotNull CompoundTag compoundTag) {
        long l;
        Object object;
        CompoundTag compoundTag2;
        Tag tag;
        Iterator iterator;
        ListTag listTag;
        super.loadCustomPersistedData(compoundTag);
        if (compoundTag.m_128441_("inputItemStackMap")) {
            this.g.clear();
            listTag = compoundTag.m_128437_("inputItemStackMap", 10);
            iterator = listTag.iterator();
            while (iterator.hasNext()) {
                tag = (Tag)iterator.next();
                compoundTag2 = (CompoundTag)tag;
                object = AEItemKey.fromTag(compoundTag2.m_128469_("k"));
                if (object == null) continue;
                l = compoundTag2.m_128454_("v");
                this.g.put(object, l);
            }
        }
        if (compoundTag.m_128441_("inputFluidStackMap")) {
            this.h.clear();
            listTag = compoundTag.m_128437_("inputFluidStackMap", 10);
            iterator = listTag.iterator();
            while (iterator.hasNext()) {
                tag = (Tag)iterator.next();
                compoundTag2 = (CompoundTag)tag;
                object = AEFluidKey.fromTag(compoundTag2.m_128469_("k"));
                if (object == null) continue;
                l = compoundTag2.m_128454_("v");
                this.h.put(object, l);
            }
        }
        if (compoundTag.m_128441_("outputItemStackMap")) {
            this.i.clear();
            listTag = compoundTag.m_128437_("outputItemStackMap", 10);
            iterator = listTag.iterator();
            while (iterator.hasNext()) {
                tag = (Tag)iterator.next();
                compoundTag2 = (CompoundTag)tag;
                object = AEItemKey.fromTag(compoundTag2.m_128469_("k"));
                if (object == null) continue;
                l = compoundTag2.m_128454_("v");
                this.i.put(object, l);
            }
        }
        if (compoundTag.m_128441_("outputFluidStackMap")) {
            this.j.clear();
            listTag = compoundTag.m_128437_("outputFluidStackMap", 10);
            iterator = listTag.iterator();
            while (iterator.hasNext()) {
                tag = (Tag)iterator.next();
                compoundTag2 = (CompoundTag)tag;
                object = AEFluidKey.fromTag(compoundTag2.m_128469_("k"));
                if (object == null) continue;
                l = compoundTag2.m_128454_("v");
                this.j.put(object, l);
            }
        }
        if (compoundTag.m_128441_("packageRecipe")) {
            this.e.clear();
            listTag = compoundTag.m_128437_("packageRecipe", 10);
            iterator = listTag.iterator();
            while (iterator.hasNext()) {
                tag = (Tag)iterator.next();
                compoundTag2 = (CompoundTag)tag;
                object = Recipe.deserializeNBT(compoundTag2.m_128469_("k"));
                if (object == null) continue;
                l = compoundTag2.m_128454_("v");
                this.e.put(object, l);
            }
        }
    }

    @Override
    public void onMachineChanged() {
        if (this.isFormed) {
            if (this.getRecipeLogic().getLastRecipe() != null) {
                this.getRecipeLogic().markLastRecipeDirty();
            }
            this.getRecipeLogic().updateTickSubscription();
            this.a();
        }
    }

    private static boolean a(ItemStack itemStack, int n) {
        Object object = itemStack.m_41720_();
        if (object instanceof MetaMachineItem) {
            MetaMachineItem metaMachineItem = (MetaMachineItem)object;
            if ((object = metaMachineItem.getDefinition()) instanceof MultiblockMachineDefinition) {
                return false;
            }
            if (((MachineDefinition)object).getTier() > n) {
                return false;
            }
            GTRecipeType[] gTRecipeTypeArray = ((MachineDefinition)object).getRecipeTypes();
            if (gTRecipeTypeArray != null && gTRecipeTypeArray.length == 1) {
                return "electric".equals(gTRecipeTypeArray[0].group);
            }
        }
        return false;
    }

    @Override
    public boolean storageFilter(ItemStack itemStack) {
        if (this.a == null) {
            return false;
        }
        return com.gtolib.f.a.a.a(itemStack, this.a.getCasingTier("i_f"));
    }

    @Override
    public ManagedFieldHolder getFieldHolder() {
        return b;
    }

    @Override
    public boolean matchRecipe(Recipe recipe) {
        MetaMachineItem metaMachineItem;
        if (this.d != null) {
            return super.matchRecipe(recipe);
        }
        Object object = this.getStorageStack().m_41720_();
        if (object instanceof MetaMachineItem && ((MachineDefinition)(object = (metaMachineItem = (MetaMachineItem)object).getDefinition())).getTier() >= recipe.tier && this.a != null && this.a.isFormed() && this.a.b.getInt((Object)recipe.recipeType) >= recipe.tier) {
            return this.getOverclockTier() >= recipe.tier && RecipeRunner.matchRecipeInput(this, recipe);
        }
        return false;
    }

    @Override
    public void onStructureFormed() {
        super.onStructureFormed();
        this.a();
        ObjectIterator objectIterator = this.e.reference2LongEntrySet().iterator();
        while (objectIterator.hasNext()) {
            Reference2LongMap.Entry entry = (Reference2LongMap.Entry)objectIterator.next();
            boolean bl = true;
            Recipe recipe = RecipeBuilder.RECIPE_MAP.get(((Recipe)entry.getKey()).id);
            if (recipe != null) {
                List<ItemStack> list = RecipeHelper.getConsumeInputItems((GTRecipe)entry.getKey());
                List<ItemStack> list2 = RecipeHelper.getConsumeInputItems(recipe);
                if (list.size() == list2.size()) {
                    boolean bl2 = true;
                    for (int i = 0; i < list.size(); ++i) {
                        if (ItemStack.m_150942_(list.get(i), list2.get(i))) continue;
                        bl2 = false;
                        break;
                    }
                    if (bl2) {
                        List<FluidStack> list3 = RecipeHelper.getConsumeInputFluids((GTRecipe)entry.getKey());
                        List<FluidStack> list4 = RecipeHelper.getConsumeInputFluids(recipe);
                        if (list3.size() == list4.size()) {
                            boolean bl3 = true;
                            for (int i = 0; i < list3.size(); ++i) {
                                if (list3.get(i).equals(list4.get(i))) continue;
                                bl3 = false;
                                break;
                            }
                            if (bl3) {
                                bl = false;
                            }
                        }
                    }
                }
            }
            if (!bl) continue;
            this.f.add((Recipe)entry.getKey());
        }
        if (this.f.isEmpty()) {
            return;
        }
        this.b();
    }

    private void b() {
        this.d = null;
        this.e.clear();
        this.g.clear();
        this.h.clear();
        this.i.clear();
        this.j.clear();
        this.getRecipeLogic().markLastRecipeDirty();
    }

    @Override
    public void attachConfigurators(ConfiguratorPanel configuratorPanel) {
        super.attachConfigurators(configuratorPanel);
        configuratorPanel.attachConfigurators(new IFancyConfigurator[]{new ParallelConfigurator(this)});
    }

    @Override
    public void customText(List<Component> list) {
        super.customText(list);
        if (this.a == null) {
            return;
        }
        list.add(Component.m_237110_("gtocore.tooltip.item.craft_step", new Object[]{this.e.size() + " / " + this.a.a}));
        list.add(ComponentPanelWidget.withButton(Component.m_237113_("[").m_7220_(Component.m_237115_("gui.ae2.Clean")).m_7220_(Component.m_237113_("]")), "clean"));
        if (this.d == null && this.e.size() < this.a.a) {
            list.add(ComponentPanelWidget.withButton(Component.m_237113_("[").m_7220_(Component.m_237115_("gui.jade.search")).m_7220_(Component.m_237113_("]")), "search"));
        }
        if (this.d == null && !this.e.isEmpty()) {
            list.add(ComponentPanelWidget.withButton(Component.m_237113_("[").m_7220_(Component.m_237115_("gtocore.build")).m_7220_(Component.m_237113_("]")), "build"));
        }
        if (this.d != null) {
            list.add(ComponentPanelWidget.withButton(Component.m_237113_("[").m_7220_(Component.m_237115_("gui.ae2.Patterns")).m_7220_(Component.m_237113_("]")), "pattern"));
        }
    }

    @Override
    public void addDisplayText(List<Component> list) {
        super.addDisplayText(list);
        if (this.isRemote() || this.a == null) {
            return;
        }
        if (this.d != null) {
            long l = this.d.getInputEUt();
            list.add(Component.m_237113_(FormattingUtil.formatNumbers(l)).m_130946_(" EU/t (").m_130946_(GTValues.VNF[GTUtil.getFloorTierByVoltage(l)]).m_130946_(") "));
            list.add(Component.m_237113_("Duration: ").m_130946_(String.valueOf(this.d.duration)));
        } else if (!this.f.isEmpty()) {
            list.add(Component.m_237115_("attributeslib.value.boolean.invalid"));
            for (Recipe object2 : this.f) {
                list.add(Component.m_237113_("Recipe: ").m_7220_(Component.m_237115_(object2.id.toString())));
            }
        }
        if (this.e.isEmpty()) {
            return;
        }
        list.add(Component.m_237115_("gtceu.io.import"));
        ObjectIterator objectIterator = this.g.object2LongEntrySet().iterator();
        while (objectIterator.hasNext()) {
            Object2LongMap.Entry entry = (Object2LongMap.Entry)objectIterator.next();
            if (entry.getLongValue() <= 0L) continue;
            list.add(((AEItemKey)entry.getKey()).getDisplayName().m_6881_().m_130946_(" x").m_130946_(String.valueOf(entry.getLongValue())));
        }
        objectIterator = this.h.object2LongEntrySet().iterator();
        while (objectIterator.hasNext()) {
            Object2LongMap.Entry entry = (Object2LongMap.Entry)objectIterator.next();
            if (entry.getLongValue() <= 0L) continue;
            list.add(((AEFluidKey)entry.getKey()).getDisplayName().m_6881_().m_130946_(" x").m_130946_(String.valueOf(entry.getLongValue())));
        }
        list.add(Component.m_237115_("gtceu.io.export"));
        objectIterator = this.i.object2LongEntrySet().iterator();
        while (objectIterator.hasNext()) {
            Object2LongMap.Entry entry = (Object2LongMap.Entry)objectIterator.next();
            if (entry.getLongValue() <= 0L) continue;
            list.add(((AEItemKey)entry.getKey()).getDisplayName().m_6881_().m_130946_(" x").m_130946_(String.valueOf(entry.getLongValue())));
        }
        objectIterator = this.j.object2LongEntrySet().iterator();
        while (objectIterator.hasNext()) {
            Object2LongMap.Entry entry = (Object2LongMap.Entry)objectIterator.next();
            if (entry.getLongValue() <= 0L) continue;
            list.add(((AEFluidKey)entry.getKey()).getDisplayName().m_6881_().m_130946_(" x").m_130946_(String.valueOf(entry.getLongValue())));
        }
    }

    @Override
    public void handleDisplayClick(String string, ClickData clickData) {
        if (!clickData.isRemote) {
            super.handleDisplayClick(string, clickData);
            block6 : switch (string) {
                case "clean": {
                    this.b();
                    this.f.clear();
                    break;
                }
                case "pattern": {
                    Object2LongMap.Entry entry;
                    if (this.d == null || !this.inputItem(new ItemStack[]{AEItems.BLANK_PATTERN.stack()})) break;
                    ArrayList<GenericStack> arrayList = new ArrayList<GenericStack>();
                    ArrayList<GenericStack> arrayList2 = new ArrayList<GenericStack>();
                    ObjectIterator objectIterator = this.g.object2LongEntrySet().iterator();
                    while (objectIterator.hasNext()) {
                        entry = (Object2LongMap.Entry)objectIterator.next();
                        if (entry.getLongValue() <= 0L) continue;
                        arrayList.add(new GenericStack((AEKey)entry.getKey(), entry.getLongValue()));
                    }
                    objectIterator = this.h.object2LongEntrySet().iterator();
                    while (objectIterator.hasNext()) {
                        entry = (Object2LongMap.Entry)objectIterator.next();
                        if (entry.getLongValue() <= 0L) continue;
                        arrayList.add(new GenericStack((AEKey)entry.getKey(), entry.getLongValue()));
                    }
                    objectIterator = this.i.object2LongEntrySet().iterator();
                    while (objectIterator.hasNext()) {
                        entry = (Object2LongMap.Entry)objectIterator.next();
                        if (entry.getLongValue() <= 0L) continue;
                        arrayList2.add(new GenericStack((AEKey)entry.getKey(), entry.getLongValue()));
                    }
                    objectIterator = this.j.object2LongEntrySet().iterator();
                    while (objectIterator.hasNext()) {
                        entry = (Object2LongMap.Entry)objectIterator.next();
                        if (entry.getLongValue() <= 0L) continue;
                        arrayList2.add(new GenericStack((AEKey)entry.getKey(), entry.getLongValue()));
                    }
                    this.outputItem(new ItemStack[]{PatternDetailsHelper.encodeProcessingPattern(arrayList.toArray(new GenericStack[0]), arrayList2.toArray(new GenericStack[0]))});
                    break;
                }
                case "build": {
                    long l;
                    long l2;
                    AEKey aEKey;
                    Object2LongMap.Entry entry;
                    int n;
                    if (this.d != null || this.e.isEmpty()) {
                        return;
                    }
                    RecipeBuilder recipeBuilder = this.getRecipeBuilder();
                    double d = 0.0;
                    ObjectIterator objectIterator = this.e.reference2LongEntrySet().iterator();
                    while (objectIterator.hasNext()) {
                        Reference2LongMap.Entry entry2 = (Reference2LongMap.Entry)objectIterator.next();
                        d += (double)(((Recipe)entry2.getKey()).getInputEUt() * (long)((Recipe)entry2.getKey()).duration * entry2.getLongValue());
                    }
                    long l3 = this.getOverclockVoltage();
                    double d2 = d / (double)l3;
                    recipeBuilder.EUt(d2 >= (double)(n = this.gtolib$getOCLimit()) ? l3 : Math.max(1L, (long)((double)l3 * d2 / (double)n))).duration((int)Math.max(Math.max(1.0, d2), (double)n));
                    ObjectIterator objectIterator2 = this.i.object2LongEntrySet().fastIterator();
                    while (objectIterator2.hasNext()) {
                        entry = (Object2LongMap.Entry)objectIterator2.next();
                        aEKey = (AEItemKey)entry.getKey();
                        l2 = entry.getLongValue();
                        if (!this.g.containsKey((Object)aEKey)) continue;
                        l = this.g.getLong((Object)aEKey);
                        if (l >= l2) {
                            if ((l -= l2) > 0L) {
                                this.g.put((Object)aEKey, l);
                            } else {
                                this.g.removeLong((Object)aEKey);
                            }
                            objectIterator2.remove();
                            continue;
                        }
                        entry.setValue(l2 -= l);
                        this.g.removeLong((Object)aEKey);
                    }
                    objectIterator2 = this.j.object2LongEntrySet().fastIterator();
                    while (objectIterator2.hasNext()) {
                        entry = (Object2LongMap.Entry)objectIterator2.next();
                        aEKey = (AEFluidKey)entry.getKey();
                        l2 = entry.getLongValue();
                        if (!this.h.containsKey((Object)aEKey)) continue;
                        l = this.h.getLong((Object)aEKey);
                        if (l >= l2) {
                            if ((l -= l2) > 0L) {
                                this.h.put((Object)aEKey, l);
                            } else {
                                this.h.removeLong((Object)aEKey);
                            }
                            objectIterator2.remove();
                            continue;
                        }
                        entry.setValue(l2 -= l);
                        this.h.removeLong((Object)aEKey);
                    }
                    objectIterator2 = this.g.object2LongEntrySet().iterator();
                    while (objectIterator2.hasNext()) {
                        entry = (Object2LongMap.Entry)objectIterator2.next();
                        if (entry.getLongValue() <= 0L) continue;
                        recipeBuilder.inputItems(((AEItemKey)entry.getKey()).toStack(MathUtil.saturatedCast(entry.getLongValue())));
                    }
                    objectIterator2 = this.h.object2LongEntrySet().iterator();
                    while (objectIterator2.hasNext()) {
                        entry = (Object2LongMap.Entry)objectIterator2.next();
                        if (entry.getLongValue() <= 0L) continue;
                        recipeBuilder.inputFluids(((AEFluidKey)entry.getKey()).toStack(MathUtil.saturatedCast(entry.getLongValue())));
                    }
                    objectIterator2 = this.i.object2LongEntrySet().iterator();
                    while (objectIterator2.hasNext()) {
                        entry = (Object2LongMap.Entry)objectIterator2.next();
                        if (entry.getLongValue() <= 0L) continue;
                        recipeBuilder.outputItems(((AEItemKey)entry.getKey()).toStack(MathUtil.saturatedCast(entry.getLongValue())));
                    }
                    objectIterator2 = this.j.object2LongEntrySet().iterator();
                    while (objectIterator2.hasNext()) {
                        entry = (Object2LongMap.Entry)objectIterator2.next();
                        if (entry.getLongValue() <= 0L) continue;
                        recipeBuilder.outputFluids(((AEFluidKey)entry.getKey()).toStack(MathUtil.saturatedCast(entry.getLongValue())));
                    }
                    this.d = recipeBuilder.buildRawRecipe();
                    break;
                }
                case "search": {
                    if (this.c == GTRecipeTypes.DUMMY_RECIPES || this.d != null || this.e.size() >= this.a.a) {
                        return;
                    }
                    Iterator iterator = this.c.searchRecipe(this, gTRecipe -> this.matchRecipe((Recipe)gTRecipe));
                    while (iterator.hasNext()) {
                        Object object;
                        Object object2;
                        Object object3;
                        Object object4;
                        Object object5;
                        Object object6;
                        Recipe recipe = (Recipe)iterator.next();
                        if (recipe == null || !RecipeRunner.checkConditions(this, recipe)) continue;
                        long l = this.getParallelLong();
                        this.e.addTo((Object)recipe, l);
                        List list = (List)recipe.inputs.get(ItemRecipeCapability.CAP);
                        if (list != null) {
                            object6 = list.iterator();
                            while (object6.hasNext()) {
                                object5 = (Content)object6.next();
                                if (((Content)object5).chance <= 0 || !((object4 = ((Content)object5).content) instanceof FastSizedIngredient) || ((FastSizedIngredient)(object3 = (FastSizedIngredient)object4)).m_43908_().length <= 0 || ((FastSizedIngredient)object3).m_43908_()[0].m_41619_()) continue;
                                this.forEachInputItems(arg_0 -> this.a((FastSizedIngredient)object3, l, arg_0));
                            }
                        }
                        if ((object6 = (List)recipe.inputs.get(FluidRecipeCapability.CAP)) != null) {
                            object5 = object6.iterator();
                            while (object5.hasNext()) {
                                object3 = (Content)object5.next();
                                if (((Content)object3).chance <= 0 || !((object2 = ((Content)object3).content) instanceof FastFluidIngredient) || ((FastFluidIngredient)(object4 = (FastFluidIngredient)object2)).getStacks().length <= 0 || ((FastFluidIngredient)object4).getStacks()[0].isEmpty()) continue;
                                this.forEachInputFluids(arg_0 -> this.a((FastFluidIngredient)object4, l, arg_0));
                            }
                        }
                        if ((object5 = (List)recipe.outputs.get(ItemRecipeCapability.CAP)) != null) {
                            object3 = object5.iterator();
                            while (object3.hasNext()) {
                                object4 = (Content)object3.next();
                                object = ((Content)object4).content;
                                if (!(object instanceof FastSizedIngredient)) continue;
                                object2 = (FastSizedIngredient)object;
                                if (((Content)object4).chance != ChanceLogic.getMaxChancedValue() || ((FastSizedIngredient)object2).m_43908_().length <= 0 || ((FastSizedIngredient)object2).m_43908_()[0].m_41619_()) continue;
                                this.i.addTo((Object)AEItemKey.of(((FastSizedIngredient)object2).m_43908_()[0]), l * ((FastSizedIngredient)object2).getAmount());
                            }
                        }
                        if ((object3 = (List)recipe.outputs.get(FluidRecipeCapability.CAP)) == null) break block6;
                        object4 = object3.iterator();
                        while (object4.hasNext()) {
                            object2 = (Content)object4.next();
                            Object object7 = ((Content)object2).content;
                            if (!(object7 instanceof FastFluidIngredient)) continue;
                            object = (FastFluidIngredient)object7;
                            if (((Content)object2).chance != ChanceLogic.getMaxChancedValue() || ((FastFluidIngredient)object).getStacks().length <= 0 || ((FastFluidIngredient)object).getStacks()[0].isEmpty()) continue;
                            this.j.addTo((Object)AEFluidKey.of(((FastFluidIngredient)object).getStacks()[0]), l * (long)((FastFluidIngredient)object).getAmount());
                        }
                        break block6;
                    }
                    break;
                }
            }
        }
    }

    @Nullable
    private Recipe c() {
        if (this.d != null && this.a != null && this.a.isFormed() && this.a.getRecipeLogic().isWorking()) {
            Recipe recipe = this.fullModifyRecipe(this.d.copy());
            if (recipe == null) {
                return null;
            }
            if (RecipeRunner.check(this, recipe)) {
                ObjectIterator objectIterator = this.e.reference2LongEntrySet().iterator();
                while (objectIterator.hasNext()) {
                    Reference2LongMap.Entry entry = (Reference2LongMap.Entry)objectIterator.next();
                    if (this.a.b.containsKey((Object)((Recipe)entry.getKey()).recipeType)) continue;
                    return null;
                }
                return recipe;
            }
        }
        return null;
    }

    @NotNull
    public RecipeLogic createRecipeLogic(Object ... objectArray) {
        return new CustomRecipeLogic(this, this::c);
    }

    @Override
    public long getMaxParallel() {
        return this.k.getMaxParallel();
    }

    @Override
    public long getParallelLong() {
        return this.k.getParallel();
    }

    @Override
    public void setParallel(long l) {
        this.k.setParallel(l);
    }

    private boolean a(FastFluidIngredient fastFluidIngredient, long l, FluidStack fluidStack) {
        if (fastFluidIngredient.test(fluidStack)) {
            this.h.addTo((Object)AEFluidKey.of(fluidStack), l * (long)fastFluidIngredient.getAmount());
            return true;
        }
        return false;
    }

    private boolean a(FastSizedIngredient fastSizedIngredient, long l, ItemStack itemStack) {
        if (fastSizedIngredient.test(itemStack)) {
            this.g.addTo((Object)AEItemKey.of(itemStack), l * fastSizedIngredient.getAmount());
            return true;
        }
        return false;
    }
}

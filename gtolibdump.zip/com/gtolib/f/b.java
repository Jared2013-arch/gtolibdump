package com.gtolib.f;

import appeng.api.stacks.AEFluidKey;
import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.AEKey;
import com.gregtechceu.gtceu.api.block.MetaMachineBlock;
import com.gregtechceu.gtceu.api.gui.GuiTextures;
import com.gregtechceu.gtceu.api.item.component.IItemUIFactory;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiController;
import com.gregtechceu.gtceu.api.pattern.BlockPattern;
import com.gregtechceu.gtceu.api.pattern.predicates.SimplePredicate;
import com.gregtechceu.gtceu.client.renderer.MultiblockInWorldPreviewRenderer;
import com.gregtechceu.gtceu.config.ConfigHolder;
import com.gtocore.common.block.BlockMap;
import com.gtolib.api.machine.MultiblockDefinition;
import com.gtolib.f.c;
import com.hepdd.gtmthings.api.gui.widget.TerminalInputWidget;
import com.hepdd.gtmthings.api.misc.Hatch;
import com.lowdragmc.lowdraglib.gui.editor.ColorPattern;
import com.lowdragmc.lowdraglib.gui.factory.HeldItemUIFactory;
import com.lowdragmc.lowdraglib.gui.modular.ModularUI;
import com.lowdragmc.lowdraglib.gui.texture.IGuiTexture;
import com.lowdragmc.lowdraglib.gui.widget.DraggableScrollableWidgetGroup;
import com.lowdragmc.lowdraglib.gui.widget.LabelWidget;
import com.lowdragmc.lowdraglib.gui.widget.Widget;
import com.lowdragmc.lowdraglib.gui.widget.WidgetGroup;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class b
implements IItemUIFactory {
    private static final int a = 140;
    private static final int b = 34;

    public InteractionResult onItemUseFirst(ItemStack itemStack, UseOnContext useOnContext) {
        BlockPos blockPos;
        Level level;
        Object object;
        if (useOnContext.m_43723_() != null && (object = MetaMachine.getMachine(level = useOnContext.m_43725_(), blockPos = useOnContext.m_8083_())) instanceof IMultiController) {
            IMultiController iMultiController = (IMultiController)object;
            object = com.gtolib.f.b.a(useOnContext.m_43723_().m_21205_());
            Supplier[] supplierArray = iMultiController.getSubPattern();
            BlockPattern blockPattern = ((a)object).i > 0 && supplierArray != null ? (BlockPattern)supplierArray[Math.min(supplierArray.length, ((a)object).i) - 1].get() : iMultiController.getPattern();
            if (useOnContext.m_43723_().m_6144_()) {
                if (!useOnContext.m_43725_().f_46443_) {
                    if (((a)object).j == 1) {
                        iMultiController.requestCheck();
                        iMultiController.setWaitingTime(10);
                        com.gtolib.f.a.a(blockPattern).a(useOnContext.m_43723_(), iMultiController.getMultiblockState(), (a)object);
                        iMultiController.getMultiblockState().cleanCache();
                    } else {
                        iMultiController.requestCheck();
                        iMultiController.setWaitingTime(10);
                        com.gtolib.f.a.a(blockPattern).a(useOnContext.m_43723_(), iMultiController.getMultiblockState(), (a)object);
                        iMultiController.getMultiblockState().cleanCache();
                        iMultiController.setWaitingTime(0);
                    }
                }
            } else if (useOnContext.m_43725_().f_46443_) {
                MultiblockInWorldPreviewRenderer.showPreview(blockPos, iMultiController.self().getFrontFacing(), iMultiController.self().getUpwardsFacing(), MultiblockDefinition.getMatchingShapes(true, blockPattern).get(0), ConfigHolder.INSTANCE.client.inWorldPreviewDuration * 20);
            }
            return InteractionResult.SUCCESS;
        }
        return InteractionResult.PASS;
    }

    public ModularUI createUI(HeldItemUIFactory.HeldItemHolder heldItemHolder, Player player) {
        return new ModularUI(176, 166, heldItemHolder, player).widget(com.gtolib.f.b.a(player));
    }

    private static Widget a(Player player) {
        final ItemStack itemStack = player.m_21205_();
        WidgetGroup widgetGroup = new WidgetGroup(0, 0, 190, 162);
        int n2 = 1;
        widgetGroup.addWidget(new DraggableScrollableWidgetGroup(4, 4, 182, 154).setUseScissor(false).setBackground(GuiTextures.DISPLAY).setYScrollBarWidth(2).setYBarStyle(null, ColorPattern.T_WHITE.rectTexture().setRadius(1.0f)).addWidget(new LabelWidget(40, 5, "item.gtmthings.advanced_terminal.setting.title")).addWidget(new LabelWidget(4, 5 + 16 * n2, () -> {
            Block[] blockArray = (Block[])BlockMap.MAP.getOrDefault((Object)itemStack.m_41784_().m_128461_("block"), new Block[0]);
            int n = itemStack.m_41784_().m_128451_("tier");
            if (blockArray.length == 0 || n <= 0 || n > blockArray.length) {
                return Component.m_237115_("gtocore.auto_build.tier").getString();
            }
            return Component.m_237115_("gtocore.auto_build.tier").m_130946_("(").m_7220_((Component)Stream.of(blockArray).map(Block::m_49954_).toList().get(n - 1)).m_130946_(")").getString();
        }){

            @OnlyIn(value=Dist.CLIENT)
            protected void drawTooltipTexts(int n, int n2) {
                if (this.isMouseOverElement(n, n2) && this.getHoverElement(n, n2) == this && this.gui != null && this.gui.getModularUIGui() != null) {
                    ArrayList<MutableComponent> arrayList = new ArrayList<MutableComponent>(List.of());
                    int n3 = 0;
                    for (Block block : (Block[])BlockMap.MAP.getOrDefault((Object)itemStack.m_41784_().m_128461_("block"), new Block[0])) {
                        arrayList.add(Component.m_237113_(String.valueOf(++n3)).m_130946_(":").m_7220_(block.m_49954_()));
                    }
                    this.gui.getModularUIGui().setHoverTooltip(arrayList, ItemStack.f_41583_, null, null);
                }
            }
        }.setClientSideWidget()).addWidget(new c(96, 4, 76, 12, bl -> widgetGroup.setSelfPositionX(bl ? -100 : 0), (string, n) -> {
            if (string != null && n != null) {
                CompoundTag compoundTag = itemStack.m_41784_();
                compoundTag.m_128359_("block", (String)string);
                compoundTag.m_128405_("tier", (int)n);
                itemStack.m_41751_(compoundTag);
            }
        })).addWidget(new TerminalInputWidget(140, 5 + 16 * n2++, 34, 16, () -> com.gtolib.f.b.b(itemStack), n -> com.gtolib.f.b.a(n, itemStack)).setMin(0).setMax(100)).addWidget(new LabelWidget(4, 5 + 16 * n2, "item.gtmthings.advanced_terminal.setting.2").setHoverTooltips(new Component[]{Component.m_237115_("item.gtmthings.advanced_terminal.setting.2.tooltip")})).addWidget(new TerminalInputWidget(140, 5 + 16 * n2++, 34, 16, () -> com.gtolib.f.b.c(itemStack), n -> com.gtolib.f.b.b(n, itemStack)).setMin(0).setMax(1000)).addWidget(new LabelWidget(4, 5 + 16 * n2, "item.gtmthings.advanced_terminal.setting.3").setHoverTooltips(new String[]{"item.gtmthings.advanced_terminal.setting.3.tooltip"})).addWidget(new TerminalInputWidget(140, 5 + 16 * n2++, 34, 16, () -> com.gtolib.f.b.d(itemStack), n -> com.gtolib.f.b.c(n, itemStack)).setMin(0).setMax(1)).addWidget(new LabelWidget(4, 5 + 16 * n2, "gtocore.auto_build.replace").setHoverTooltips(new String[]{"gtocore.auto_build.replace.a"})).addWidget(new TerminalInputWidget(140, 5 + 16 * n2++, 34, 16, () -> com.gtolib.f.b.e(itemStack), n -> com.gtolib.f.b.d(n, itemStack)).setMin(0).setMax(1)).addWidget(new LabelWidget(4, 5 + 16 * n2, "item.gtmthings.advanced_terminal.setting.5").setHoverTooltips(new String[]{"item.gtmthings.advanced_terminal.setting.5.tooltip"})).addWidget(new TerminalInputWidget(140, 5 + 16 * n2++, 34, 16, () -> com.gtolib.f.b.f(itemStack), n -> com.gtolib.f.b.e(n, itemStack)).setMin(0).setMax(1)).addWidget(new LabelWidget(4, 5 + 16 * n2, "gtocore.auto_build.flip")).addWidget(new TerminalInputWidget(140, 5 + 16 * n2++, 34, 16, () -> com.gtolib.f.b.g(itemStack), n -> com.gtolib.f.b.f(n, itemStack)).setMin(0).setMax(1)).addWidget(new LabelWidget(4, 5 + 16 * n2, "gtocore.auto_build.module")).addWidget(new TerminalInputWidget(140, 5 + 16 * n2++, 34, 16, () -> com.gtolib.f.b.h(itemStack), n -> com.gtolib.f.b.g(n, itemStack)).setMin(0).setMax(100)).addWidget(new LabelWidget(4, 5 + 16 * n2, "gtocore.auto_build.demolition_mode")).addWidget(new TerminalInputWidget(140, 5 + 16 * n2++, 34, 16, () -> com.gtolib.f.b.i(itemStack), n -> com.gtolib.f.b.h(n, itemStack)).setMin(0).setMax(1)));
        widgetGroup.setBackground(new IGuiTexture[]{GuiTextures.BACKGROUND_INVERSE});
        return widgetGroup;
    }

    private static a a(ItemStack itemStack) {
        a a2 = new a();
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag != null && !compoundTag.m_128456_()) {
            a2.c = compoundTag.m_128451_("tier");
            a2.d = compoundTag.m_128451_("repeatCount");
            a2.e = compoundTag.m_128451_("noHatchMode");
            a2.f = compoundTag.m_128451_("replaceMode");
            a2.g = compoundTag.m_128451_("isUseAE");
            a2.h = compoundTag.m_128451_("isFlip");
            a2.i = compoundTag.m_128451_("module");
            a2.j = compoundTag.m_128451_("demolition");
            String string = compoundTag.m_128461_("block");
            if (!string.isEmpty()) {
                a2.a = (Block[])BlockMap.MAP.get(string);
                a2.b = new ReferenceOpenHashSet(a2.a);
            }
        }
        return a2;
    }

    private static int b(ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag != null && !compoundTag.m_128456_()) {
            return compoundTag.m_128451_("tier");
        }
        return 0;
    }

    private static void a(int n, ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag == null) {
            compoundTag = new CompoundTag();
        }
        compoundTag.m_128405_("tier", n);
        itemStack.m_41751_(compoundTag);
    }

    private static int c(ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag != null && !compoundTag.m_128456_()) {
            return compoundTag.m_128451_("repeatCount");
        }
        return 0;
    }

    private static void b(int n, ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag == null) {
            compoundTag = new CompoundTag();
        }
        compoundTag.m_128405_("repeatCount", n);
        itemStack.m_41751_(compoundTag);
    }

    private static int d(ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag != null && !compoundTag.m_128456_()) {
            return compoundTag.m_128451_("noHatchMode");
        }
        return 1;
    }

    private static void c(int n, ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag == null) {
            compoundTag = new CompoundTag();
        }
        compoundTag.m_128405_("noHatchMode", n);
        itemStack.m_41751_(compoundTag);
    }

    private static int e(ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag != null && !compoundTag.m_128456_()) {
            return compoundTag.m_128451_("replaceMode");
        }
        return 0;
    }

    private static void d(int n, ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag == null) {
            compoundTag = new CompoundTag();
        }
        compoundTag.m_128405_("replaceMode", n);
        itemStack.m_41751_(compoundTag);
    }

    private static int f(ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag != null && !compoundTag.m_128456_()) {
            return compoundTag.m_128451_("isUseAE");
        }
        return 0;
    }

    private static void e(int n, ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag == null) {
            compoundTag = new CompoundTag();
        }
        compoundTag.m_128405_("isUseAE", n);
        itemStack.m_41751_(compoundTag);
    }

    private static int g(ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag != null && !compoundTag.m_128456_()) {
            return compoundTag.m_128451_("isFlip");
        }
        return 0;
    }

    private static void f(int n, ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag == null) {
            compoundTag = new CompoundTag();
        }
        compoundTag.m_128405_("isFlip", n);
        itemStack.m_41751_(compoundTag);
    }

    private static int h(ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag != null && !compoundTag.m_128456_()) {
            return compoundTag.m_128451_("module");
        }
        return 0;
    }

    private static void g(int n, ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag == null) {
            compoundTag = new CompoundTag();
        }
        compoundTag.m_128405_("module", n);
        itemStack.m_41751_(compoundTag);
    }

    private static int i(ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag != null && !compoundTag.m_128456_()) {
            return compoundTag.m_128451_("demolition");
        }
        return 0;
    }

    private static void h(int n, ItemStack itemStack) {
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag == null) {
            compoundTag = new CompoundTag();
        }
        compoundTag.m_128405_("demolition", n);
        itemStack.m_41751_(compoundTag);
    }

    static class a {
        Block[] a;
        Set<Block> b = Collections.emptySet();
        int c;
        int d;
        int e = 1;
        int f;
        int g;
        int h;
        int i;
        int j;

        private a() {
        }

        public List<AEKey> a(Block[] blockArray) {
            ObjectArrayList objectArrayList = new ObjectArrayList();
            if (blockArray != null) {
                for (Block block : blockArray) {
                    if (this.a != null && this.c > 0 && blockArray.length > 1 && this.b.contains(block)) {
                        objectArrayList.add(AEItemKey.of(this.a[Math.min(this.a.length, this.c) - 1].m_5456_()));
                        return objectArrayList;
                    }
                    if (block instanceof LiquidBlock) {
                        LiquidBlock liquidBlock = (LiquidBlock)((Object)block);
                        Fluid fluid = liquidBlock.getFluid().m_5613_();
                        objectArrayList.add(AEFluidKey.of(fluid));
                        continue;
                    }
                    if (block == Blocks.f_50016_) continue;
                    objectArrayList.add(AEItemKey.of(SimplePredicate.toItem(block)));
                }
            }
            return objectArrayList;
        }

        boolean b(Block[] blockArray) {
            if (this.e == 0) {
                return true;
            }
            if (blockArray != null && blockArray.length > 1) {
                MetaMachineBlock metaMachineBlock;
                Block block = blockArray[0];
                return !(block instanceof MetaMachineBlock) || !Hatch.Set.contains(metaMachineBlock = (MetaMachineBlock)block);
            }
            return true;
        }

        boolean a() {
            return this.f == 1;
        }
    }
}

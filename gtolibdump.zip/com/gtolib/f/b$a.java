package com.gtolib.f;

import appeng.api.stacks.AEFluidKey;
import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.AEKey;
import com.gregtechceu.gtceu.api.block.MetaMachineBlock;
import com.gregtechceu.gtceu.api.pattern.predicates.SimplePredicate;
import com.hepdd.gtmthings.api.misc.Hatch;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.material.Fluid;

class b$a {
    Block[] a;
    Set<Block> b = Collections.emptySet();
    int c;
    int d;
    int e = 1;
    int f;
    int g;
    int h;
    int i;
    int j;

    private b$a() {
    }

    public List<AEKey> a(Block[] blockArray) {
        ObjectArrayList objectArrayList = new ObjectArrayList();
        if (blockArray != null) {
            for (Block block : blockArray) {
                if (this.a != null && this.c > 0 && blockArray.length > 1 && this.b.contains(block)) {
                    objectArrayList.add(AEItemKey.of(this.a[Math.min(this.a.length, this.c) - 1].m_5456_()));
                    return objectArrayList;
                }
                if (block instanceof LiquidBlock) {
                    LiquidBlock liquidBlock = (LiquidBlock)((Object)block);
                    Fluid fluid = liquidBlock.getFluid().m_5613_();
                    objectArrayList.add(AEFluidKey.of(fluid));
                    continue;
                }
                if (block == Blocks.f_50016_) continue;
                objectArrayList.add(AEItemKey.of(SimplePredicate.toItem(block)));
            }
        }
        return objectArrayList;
    }

    boolean b(Block[] blockArray) {
        if (this.e == 0) {
            return true;
        }
        if (blockArray != null && blockArray.length > 1) {
            MetaMachineBlock metaMachineBlock;
            Block block = blockArray[0];
            return !(block instanceof MetaMachineBlock) || !Hatch.Set.contains(metaMachineBlock = (MetaMachineBlock)block);
        }
        return true;
    }

    boolean a() {
        return this.f == 1;
    }
}

package com.gtolib;

import net.minecraft.core.Registry;

public interface c {
    public void gtceu$setRegistry(Registry<?> var1);
}

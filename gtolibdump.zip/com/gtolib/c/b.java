package com.gtolib.c;

import com.gregtechceu.gtceu.api.item.LampBlockItem;
import com.gregtechceu.gtceu.common.item.GTTurbineItemCoated;
import com.gregtechceu.gtceu.integration.emi.recipe.GTRecipeEMICategory;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCacheHashMap;
import com.gregtechceu.gtceu.utils.collection.O2OOpenCustomCacheHashMap;
import com.gregtechceu.gtceu.utils.collection.OpenCacheHashSet;
import com.gtocore.common.data.GTORecipes;
import com.gtocore.config.GTOConfig;
import com.gtocore.config.SparkRange;
import com.gtocore.integration.emi.GTEMIRecipe;
import com.gtolib.utils.FluidUtils;
import com.gtolib.utils.ItemUtils;
import com.gtolib.utils.RegistriesUtils;
import com.gtolib.utils.register.BlockRegisterUtils;
import dev.emi.emi.EmiPort;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.recipe.EmiRecipeManager;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.registry.EmiRecipes;
import dev.emi.emi.registry.EmiStackList;
import it.unimi.dsi.fastutil.Hash;
import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.PotionItem;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import org.embeddedt.modernfix.spark.SparkLaunchProfiler;
import vectorwing.farmersdelight.common.registry.ModItems;

public final class b
implements EmiRecipeManager {
    private static final Hash.Strategy<EmiStack> b = new EmiStackList.ComparisonHashStrategy();
    private static final Set<Item> c = Set.of((Object)BlockRegisterUtils.REACTOR_CORE.m_5456_(), (Object)((Item)ModItems.WHEAT_DOUGH.get()), (Object)RegistriesUtils.getItem("morered:red_alloy_ingot"));
    private static Map<String, List<EmiStack>> d = new Object2ObjectLinkedOpenHashMap();
    private static Map<String, List<EmiStack>> e = new Object2ObjectLinkedOpenHashMap();
    public static final List<EmiStack> a = new ObjectArrayList();
    private final List<EmiRecipeCategory> f;
    private final Map<EmiRecipeCategory, List<EmiIngredient>> g;
    private final List<EmiRecipe> h;
    private final Map<EmiStack, Set<EmiRecipe>> i = new O2OOpenCustomCacheHashMap(b);
    private final Map<EmiStack, Set<EmiRecipe>> j = new O2OOpenCustomCacheHashMap(b);
    private final Map<EmiStack, List<EmiRecipe>> k = new O2OOpenCustomCacheHashMap(b);
    private final Map<EmiStack, List<EmiRecipe>> l = new O2OOpenCustomCacheHashMap(b);
    private final Map<EmiRecipeCategory, List<EmiRecipe>> m;
    private final Map<ResourceLocation, EmiRecipe> n;

    public static void a() {
        if (d == null) {
            return;
        }
        Thread thread = new Thread(() -> {
            Object object;
            Iterator<List<EmiStack>> iterator = EmiPort.getItemRegistry().iterator();
            while (iterator.hasNext()) {
                Object object2;
                Item object22 = (Item)iterator.next();
                if (object22 == Items.f_41852_) continue;
                if (object22 instanceof LampBlockItem) {
                    object = (LampBlockItem)((Object)object22);
                    for (int i = 0; i < 8; ++i) {
                        d.computeIfAbsent("gtceu", string -> new ObjectArrayList()).add(EmiStack.of(((LampBlockItem)object).getBlock().getStackFromIndex(i)));
                    }
                    continue;
                }
                if (object22 instanceof EnchantedBookItem) {
                    Iterator iterator2 = BuiltInRegistries.f_256876_.iterator();
                    while (iterator2.hasNext()) {
                        object2 = (Enchantment)iterator2.next();
                        d.computeIfAbsent("minecraft", string -> new ObjectArrayList()).add(EmiStack.of(EnchantedBookItem.m_41161_(new EnchantmentInstance((Enchantment)object2, ((Enchantment)object2).m_6586_()))));
                    }
                    continue;
                }
                if (object22 instanceof PotionItem) {
                    PotionItem potionItem = (PotionItem)((Object)object22);
                    Iterator iterator3 = BuiltInRegistries.f_256980_.iterator();
                    while (iterator3.hasNext()) {
                        object2 = (Potion)iterator3.next();
                        d.computeIfAbsent("minecraft", string -> new ObjectArrayList()).add(EmiStack.of(PotionUtils.m_43549_(new ItemStack(potionItem), (Potion)object2)));
                    }
                    continue;
                }
                if (c.contains(object22) || object22 instanceof GTTurbineItemCoated) continue;
                object = EmiStack.of(object22);
                d.computeIfAbsent(ItemUtils.getIdLocation(object22).m_135827_(), string -> new ObjectArrayList()).add(object);
            }
            iterator = EmiPort.getFluidRegistry().iterator();
            while (iterator.hasNext()) {
                Fluid fluid = (Fluid)iterator.next();
                if (!fluid.m_7444_(fluid.m_76145_()) && (!(fluid instanceof FlowingFluid) || ((FlowingFluid)(object = (FlowingFluid)((Object)fluid))).m_5613_() != Fluids.f_76191_)) continue;
                e.computeIfAbsent(FluidUtils.getIdLocation(fluid).m_135827_(), string -> new ObjectArrayList()).add(EmiStack.of(fluid));
            }
            for (List<EmiStack> list : d.values()) {
                a.addAll(list);
            }
            for (List<EmiStack> list : e.values()) {
                a.addAll(list);
            }
            d = null;
            e = null;
        });
        thread.setDaemon(true);
        thread.setPriority(1);
        thread.start();
    }

    public b(List<EmiRecipeCategory> list, Map<EmiRecipeCategory, List<EmiIngredient>> map, List<EmiRecipe> list2) {
        Object object;
        Object object2;
        list2.addAll(GTORecipes.EMI_RECIPES);
        this.f = list;
        this.g = map;
        this.h = list2;
        this.m = new O2OOpenCacheHashMap(list.size());
        this.n = new O2OOpenCacheHashMap(list2.size());
        for (EmiRecipe object3 : list2) {
            object2 = object3.getId();
            object = object3.getCategory();
            this.m.computeIfAbsent((EmiRecipeCategory)object, emiRecipeCategory -> new ObjectArrayList()).add(object3);
            if (object2 != null) {
                this.n.put((ResourceLocation)object2, object3);
            }
            for (EmiIngredient emiIngredient : object3.getInputs()) {
                for (EmiStack emiStack2 : emiIngredient.getEmiStacks()) {
                    this.i.computeIfAbsent(emiStack2, emiStack -> new OpenCacheHashSet()).add(object3);
                }
            }
            for (EmiIngredient emiIngredient : object3.getCatalysts()) {
                for (EmiStack emiStack2 : emiIngredient.getEmiStacks()) {
                    this.i.computeIfAbsent(emiStack2, emiStack -> new OpenCacheHashSet()).add(object3);
                }
            }
            for (EmiIngredient emiIngredient : object3.getOutputs()) {
                this.j.computeIfAbsent((EmiStack)emiIngredient, emiStack -> new OpenCacheHashSet()).add(object3);
            }
        }
        for (Map.Entry entry : this.m.entrySet()) {
            object2 = (EmiRecipeCategory)entry.getKey();
            object = (List)entry.getValue();
            if (object2 instanceof GTRecipeEMICategory) {
                object.sort(Comparator.comparingInt(emiRecipe -> {
                    if (emiRecipe instanceof GTEMIRecipe) {
                        GTEMIRecipe gTEMIRecipe = (GTEMIRecipe)((Object)emiRecipe);
                        return -gTEMIRecipe.displayPriority.getAsInt();
                    }
                    return 0;
                }));
            }
            for (EmiIngredient emiIngredient : map.getOrDefault(object2, Collections.emptyList())) {
                for (EmiStack emiStack2 : emiIngredient.getEmiStacks()) {
                    EmiRecipes.byWorkstation.computeIfAbsent(emiStack2, emiStack -> new ObjectArrayList()).addAll(object);
                }
            }
        }
        if (GTOConfig.INSTANCE.startSpark == SparkRange.WORLD || GTOConfig.INSTANCE.startSpark == SparkRange.ALL) {
            SparkLaunchProfiler.stop("all");
        }
    }

    public List<EmiRecipeCategory> getCategories() {
        return this.f;
    }

    @Override
    public List<EmiIngredient> getWorkstations(EmiRecipeCategory emiRecipeCategory) {
        return this.g.getOrDefault(emiRecipeCategory, Collections.emptyList());
    }

    public List<EmiRecipe> getRecipes() {
        return this.h;
    }

    @Override
    public List<EmiRecipe> getRecipes(EmiRecipeCategory emiRecipeCategory) {
        return this.m.getOrDefault(emiRecipeCategory, Collections.emptyList());
    }

    @Nullable
    public EmiRecipe getRecipe(ResourceLocation resourceLocation) {
        return this.n.getOrDefault(resourceLocation, null);
    }

    @Override
    public List<EmiRecipe> getRecipesByInput(EmiStack emiStack2) {
        return this.k.computeIfAbsent(emiStack2, emiStack -> {
            Set<EmiRecipe> set = this.i.get(emiStack);
            if (set == null) {
                return Collections.emptyList();
            }
            this.i.remove(emiStack);
            return new ObjectArrayList(set);
        });
    }

    @Override
    public List<EmiRecipe> getRecipesByOutput(EmiStack emiStack2) {
        return this.l.computeIfAbsent(emiStack2, emiStack -> {
            Set<EmiRecipe> set = this.j.get(emiStack);
            if (set == null) {
                return Collections.emptyList();
            }
            this.j.remove(emiStack);
            return new ObjectArrayList(set);
        });
    }
}

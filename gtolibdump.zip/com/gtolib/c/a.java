package com.gtolib.c;

import appeng.api.stacks.AEKey;
import appeng.api.stacks.GenericStack;
import com.hepdd.ae2emicraftingforge.client.helper.mapper.EmiStackHelper;
import dev.emi.emi.runtime.EmiFavorites;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import java.util.Objects;

public class a {
    public static final a a = new a();
    public final List<AEKey> b = new ObjectArrayList();

    private a() {
        this.b.addAll(com.gtolib.c.a.b());
    }

    private static List<AEKey> b() {
        return EmiFavorites.favorites.stream().flatMap(emiFavorite -> emiFavorite.getStack().getEmiStacks().stream()).map(EmiStackHelper::toGenericStack).filter(Objects::nonNull).map(GenericStack::what).filter(Objects::nonNull).toList();
    }

    public static void a() {
        com.gtolib.c.a.a.b.clear();
        com.gtolib.c.a.a.b.addAll(com.gtolib.c.a.b());
    }
}
